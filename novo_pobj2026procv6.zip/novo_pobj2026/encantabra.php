<?php

declare(strict_types=1);

define('POBJ_DASHBOARD_STATE_SESSION_KEY', 'encantabra_dashboard_state');
define('POBJ_FORCED_ACTIVE_TAB', 'encantabra');

require __DIR__ . '/index.php';