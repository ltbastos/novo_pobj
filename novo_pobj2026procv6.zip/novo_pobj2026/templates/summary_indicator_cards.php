<?php

declare(strict_types=1);

if (($activeTab ?? 'resumo') !== 'resumo'
    || (($summaryFilterValues['visao_acumulada'] ?? 'MENSAL') === 'ANUAL')
    || (($summaryFilterValues['visao_acumulada'] ?? 'MENSAL') === 'MENSAL_ACUMULADO')
) {
    return;
}

$resolveFamilyKey = static function (array $row): string {
    $familyId = trim((string) ($row['id_familia'] ?? ''));

    if ($familyId !== '') {
        return 'family:' . $familyId;
    }

    $familyLabel = trim((string) ($row['nome_familia'] ?? ''));

    if ($familyLabel !== '') {
        return 'label:' . strtoupper($familyLabel);
    }

    if ((bool) ($row['is_family_level'] ?? false)) {
        $indicatorName = trim((string) ($row['nome_indicador'] ?? ''));

        if ($indicatorName !== '') {
            return 'label:' . strtoupper($indicatorName);
        }
    }

    return '';
};

$resolveFamilyLabel = static function (array $row): string {
    if ((bool) ($row['is_family_level'] ?? false)) {
        $indicatorName = trim((string) ($row['nome_indicador'] ?? ''));

        if ($indicatorName !== '') {
            return $indicatorName;
        }
    }

    return trim((string) ($row['nome_familia'] ?? ''));
};

$allRows = is_array($dashboardData['indicators'] ?? null)
    ? $dashboardData['indicators']
    : [];
$familyRowsByKey = [];

foreach ($allRows as $row) {
    if (!(bool) ($row['is_family_level'] ?? false)) {
        continue;
    }

    $familyKey = $resolveFamilyKey($row);

    if ($familyKey === '' || isset($familyRowsByKey[$familyKey])) {
        continue;
    }

    $familyRowsByKey[$familyKey] = $row;
}

$indicatorRows = array_values(array_filter(
    $allRows,
    static function (array $row) use ($resolveFamilyKey): bool {
        return (bool) ($row['is_product_root'] ?? false)
            && (bool) ($row['has_family_row'] ?? false)
            && $resolveFamilyKey($row) !== '';
    }
));

if ($indicatorRows === []) {
    return;
}

$tooltipAnchorDate = trim((string) ($displayPeriodEnd ?? ''));

if ($tooltipAnchorDate === '') {
    $tooltipAnchorDate = trim((string) (($selectedPeriod['dt_fim_periodo'] ?? null) ?? ''));
}

try {
    $tooltipAnchor = new DateTimeImmutable(clamp_date_to_today($tooltipAnchorDate !== '' ? $tooltipAnchorDate : 'today'));
} catch (Throwable $exception) {
    $tooltipAnchor = new DateTimeImmutable('today');
}

$tooltipPeriodStart = trim((string) (($selectedPeriod['dt_inicio_periodo'] ?? null) ?? ''));
$tooltipPeriodEnd = trim((string) (($selectedPeriod['dt_fim_periodo'] ?? null) ?? ''));

if ($tooltipPeriodStart === '' || $tooltipPeriodEnd === '') {
    $tooltipPeriodStart = $tooltipAnchor->modify('first day of this month')->format('Y-m-d');
    $tooltipPeriodEnd = $tooltipAnchor->modify('last day of this month')->format('Y-m-d');
}

$tooltipMonthSnapshot = resolve_business_day_snapshot(
    $tooltipPeriodStart,
    $tooltipPeriodEnd,
    $tooltipAnchor->format('Y-m-d')
);

$calculateTooltipMetrics = static function (array $item, array $snapshot): array {
    return [
        'days_total' => max(0, (int) ($snapshot['total'] ?? 0)),
        'days_remaining' => max(0, (int) ($snapshot['remaining'] ?? 0)),
        'meta' => (float) ($item['meta'] ?? 0.0),
        'realizado' => (float) ($item['realizado'] ?? 0.0),
        'referencia' => (float) ($item['referencia'] ?? 0.0),
        'referencia_percentual' => (float) ($item['referencia_percentual'] ?? 0.0),
        'meta_diaria_necessaria' => (float) ($item['nec_dia'] ?? 0.0),
        'forecast' => (float) ($item['forecast'] ?? 0.0),
    ];
};

$formatPercentMetric = static function (float $value, int $decimals = 1): string {
    return number_format($value, $decimals, ',', '.') . '%';
};

$formatForecastMetric = static function (array $item, float $value) use ($formatPercentMetric): string {
    $metricType = strtoupper(trim((string) ($item['id_tipo_indicador'] ?? 'VALOR')));

    if ($metricType === 'PERCENTUAL') {
        return $formatPercentMetric($value);
    }

    return format_metric_readable($value, $metricType);
};

$formatReferenceMetric = static function (array $item, float $value, float $percent) use ($formatPercentMetric): string {
    $metricType = strtoupper(trim((string) ($item['id_tipo_indicador'] ?? 'VALOR')));

    if ($metricType === 'PERCENTUAL') {
        return $formatPercentMetric($value);
    }

    return format_metric_readable($value, $metricType)
        . ' (' . $formatPercentMetric($percent) . ')';
};

$familyGroups = [];
$cardIndex = 0;

foreach ($indicatorRows as $row) {
    $familyKey = $resolveFamilyKey($row);
    $rowOrder = (int) ($row['ordem'] ?? 999999);
    $familyRow = $familyRowsByKey[$familyKey] ?? null;
    $familyLabel = is_array($familyRow) ? $resolveFamilyLabel($familyRow) : '';
    $familyOrder = is_array($familyRow)
        ? (int) ($familyRow['ordem'] ?? $rowOrder)
        : $rowOrder;

    if ($familyKey === '') {
        continue;
    }

    if (!isset($familyGroups[$familyKey])) {
        $familyGroups[$familyKey] = [
            'label' => $familyLabel !== '' ? $familyLabel : $resolveFamilyLabel($row),
            'sort_order' => $familyOrder,
            'pontos_atingidos' => 0.0,
            'pontos_total' => 0.0,
            'items' => [],
        ];
    }

    $cardIndex++;
    $familyGroups[$familyKey]['sort_order'] = min((int) ($familyGroups[$familyKey]['sort_order'] ?? 999999), $familyOrder);
    $familyGroups[$familyKey]['pontos_atingidos'] += (float) ($row['pontos'] ?? 0.0);
    $familyGroups[$familyKey]['pontos_total'] += (float) ($row['pontos_meta'] ?? 0.0);
    $familyGroups[$familyKey]['items'][] = array_merge($row, ['card_index' => $cardIndex]);
}

$familyGroups = array_values(array_filter($familyGroups, static function (array $familyGroup): bool {
    return ($familyGroup['items'] ?? []) !== [];
}));

usort($familyGroups, static function (array $left, array $right): int {
    $leftOrder = (int) ($left['sort_order'] ?? 999999);
    $rightOrder = (int) ($right['sort_order'] ?? 999999);

    if ($leftOrder !== $rightOrder) {
        return $leftOrder <=> $rightOrder;
    }

    return strcmp((string) ($left['label'] ?? ''), (string) ($right['label'] ?? ''));
});

foreach ($familyGroups as &$familyGroup) {
    usort($familyGroup['items'], static function (array $left, array $right): int {
        $leftOrder = (int) ($left['ordem'] ?? 999999);
        $rightOrder = (int) ($right['ordem'] ?? 999999);

        if ($leftOrder !== $rightOrder) {
            return $leftOrder <=> $rightOrder;
        }

        $leftName = strtolower(trim((string) ($left['nome_indicador'] ?? '')));
        $rightName = strtolower(trim((string) ($right['nome_indicador'] ?? '')));

        if ($leftName !== $rightName) {
            return $leftName <=> $rightName;
        }

        return trim((string) ($left['id_indicador'] ?? '')) <=> trim((string) ($right['id_indicador'] ?? ''));
    });
}
unset($familyGroup);

if ($familyGroups === []) {
    return;
}

$resolveIndicatorBadgeClass = static function (float $percent): string {
    if ($percent < 50) {
        return 'summary-product-card__badge--low';
    }

    if ($percent < 100) {
        return 'summary-product-card__badge--warn';
    }

    return 'summary-product-card__badge--ok';
};

$resolveIndicatorBarClass = static function (float $percent): string {
    if ($percent < 50) {
        return 'summary-product-card__track--low';
    }

    if ($percent < 100) {
        return 'summary-product-card__track--warn';
    }

    return 'summary-product-card__track--ok';
};

$metricLabel = static function (string $metric): string {
    $metric = strtoupper(trim($metric));

    if ($metric === 'PERCENTUAL') {
        return 'Percentual';
    }

    if ($metric === 'QUANTIDADE') {
        return 'Quantidade';
    }

    return 'Valor';
};

$formatCssPercent = static function (float $percent): string {
    return number_format(max(0, min(100, $percent)), 2, '.', '') . '%';
};
?>
<section class="summary-products-section" aria-label="Cards de indicadores" data-resumo-pane="cards">
    <?php foreach ($familyGroups as $familyGroup): ?>
        <section class="summary-products-family">
            <header class="summary-products-family__header">
                <h2 class="summary-products-family__title">
                    <span><?= e($familyGroup['label']) ?></span>
                    <span class="summary-products-family__meta">Pontos: <?= e(format_points_readable((float) $familyGroup['pontos_atingidos'])) ?> / <?= e(format_points_readable((float) $familyGroup['pontos_total'])) ?></span>
                </h2>
            </header>

            <div class="summary-products-family__grid">
                <?php foreach ($familyGroup['items'] as $item): ?>
                    <?php
                    $progressPercent = (float) ($item['percentual_atingimento'] ?? 0.0);
                    $pointsAchieved = (float) ($item['pontos'] ?? 0.0);
                    $pointsTotal = (float) ($item['pontos_meta'] ?? 0.0);
                    $pointsPercent = $pointsTotal > 0 ? ($pointsAchieved / $pointsTotal) * 100 : 0.0;
                    $metaValue = format_metric((float) ($item['meta'] ?? 0.0), (string) ($item['id_tipo_indicador'] ?? 'VALOR'));
                    $metaValueReadable = format_metric_readable((float) ($item['meta'] ?? 0.0), (string) ($item['id_tipo_indicador'] ?? 'VALOR'));
                    $realizadoValue = format_metric((float) ($item['realizado'] ?? 0.0), (string) ($item['id_tipo_indicador'] ?? 'VALOR'));
                    $realizadoValueReadable = format_metric_readable((float) ($item['realizado'] ?? 0.0), (string) ($item['id_tipo_indicador'] ?? 'VALOR'));
                    $absoluteRatioValue = '';
                    $absoluteRatioLabel = '';

                    if (($item['id_tipo_indicador'] ?? '') === 'PERCENTUAL' && (bool) ($item['usa_base_absoluta'] ?? false)) {
                        $absoluteRatioValue = format_quantity_readable((float) ($item['realizado_absoluto'] ?? 0.0)) . ' / ' . format_quantity_readable((float) ($item['base_absoluta'] ?? 0.0));
                        $absoluteRatioLabel = trim((string) ($item['realizado_absoluto_label'] ?? 'Realizado')) . ' / ' . trim((string) ($item['base_absoluta_label'] ?? 'Base'));
                    }

                    $updatedAt = format_date_br($item['ultima_atualizacao'] ?? null);
                    $tooltipId = 'indicator-tooltip-' . (string) ($item['id_indicador'] ?? $item['card_index']);
                    $detailActionFields = json_attr([
                        'tab' => 'resumo',
                        'indicator_focus' => (string) ($item['id_indicador'] ?? ''),
                        'indicator_page' => '1',
                    ]);
                    $tooltipMetrics = $calculateTooltipMetrics($item, $tooltipMonthSnapshot);
                    ?>
                    <article
                        class="summary-product-card"
                        style="--card-delay: <?= e((string) (max(0, ((int) $item['card_index'] - 1) * 70))) ?>ms; --bar-delay: <?= e((string) (200 + max(0, ((int) $item['card_index'] - 1) * 70))) ?>ms;"
                        data-tip-card
                        data-dashboard-action="open_indicator_focus"
                        data-dashboard-fields="<?= $detailActionFields ?>"
                        data-dashboard-message="Carregando detalhamento do indicador..."
                        tabindex="0"
                        role="link"
                        aria-label="Abrir detalhamento do indicador <?= e((string) ($item['nome_indicador'] ?? '')) ?>"
                    >
                        <div class="summary-product-card__title">
                            <span class="summary-product-card__icon" aria-hidden="true">
                                <i data-lucide="chart-line"></i>
                            </span>
                            <span class="summary-product-card__name" title="<?= e((string) ($item['nome_indicador'] ?? '')) ?>"><?= e((string) ($item['nome_indicador'] ?? '')) ?></span>
                            <button class="summary-product-card__badge <?= e($resolveIndicatorBadgeClass($progressPercent)) ?>" type="button" aria-label="Atingimento do indicador: <?= e(number_format($progressPercent, 1, ',', '.')) ?>%" aria-describedby="<?= e($tooltipId) ?>" data-tip-trigger>
                                <?= e(number_format($progressPercent, $progressPercent >= 100 ? 0 : 1, ',', '.')) ?>%
                            </button>
                            <div class="summary-product-card__tooltip" id="<?= e($tooltipId) ?>" role="tooltip" data-tip>
                                <h3 class="summary-product-card__tooltip-title">Pulso do indicador no mes</h3>
                                <div class="summary-product-card__tooltip-row"><span>Dias uteis do mes</span><strong><?= e(format_int_readable((float) ($tooltipMetrics['days_total'] ?? 0))) ?></strong></div>
                                <div class="summary-product-card__tooltip-row"><span>Dias uteis restantes</span><strong><?= e(format_int_readable((float) ($tooltipMetrics['days_remaining'] ?? 0))) ?></strong></div>
                                <div class="summary-product-card__tooltip-row"><span>Meta</span><strong><?= e(format_metric_readable((float) ($tooltipMetrics['meta'] ?? 0.0), (string) ($item['id_tipo_indicador'] ?? 'VALOR'))) ?></strong></div>
                                <div class="summary-product-card__tooltip-row"><span>Realizado</span><strong><?= e(format_metric_readable((float) ($tooltipMetrics['realizado'] ?? 0.0), (string) ($item['id_tipo_indicador'] ?? 'VALOR'))) ?></strong></div>
                                <?php if ($absoluteRatioValue !== ''): ?>
                                    <div class="summary-product-card__tooltip-row"><span><?= e($absoluteRatioLabel) ?></span><strong><?= e($absoluteRatioValue) ?></strong></div>
                                <?php endif; ?>
                                <div class="summary-product-card__tooltip-row"><span>Referencia</span><strong><?= e($formatReferenceMetric($item, (float) ($tooltipMetrics['referencia'] ?? 0.0), (float) ($tooltipMetrics['referencia_percentual'] ?? 0.0))) ?></strong></div>
                                <div class="summary-product-card__tooltip-row"><span>Meta diaria necessaria</span><strong><?= e(format_metric_readable((float) ($tooltipMetrics['meta_diaria_necessaria'] ?? 0.0), (string) ($item['id_tipo_indicador'] ?? 'VALOR'))) ?></strong></div>
                                <div class="summary-product-card__tooltip-row"><span>Forecast do mes</span><strong><?= e($formatForecastMetric($item, (float) ($tooltipMetrics['forecast'] ?? 0.0))) ?></strong></div>
                            </div>
                        </div>

                        <div class="summary-product-card__meta">
                            <span class="summary-product-card__pill">Pontos: <?= e(format_points_readable($pointsAchieved)) ?> / <?= e(format_points_readable($pointsTotal)) ?></span>
                            <span class="summary-product-card__pill">Peso: <?= e(format_points_readable((float) ($item['peso'] ?? 0.0))) ?></span>
                            <span class="summary-product-card__pill"><?= e($metricLabel((string) ($item['id_tipo_indicador'] ?? 'VALOR'))) ?></span>
                        </div>

                        <div class="summary-product-card__kpis">
                            <div class="summary-product-card__kv">
                                <small>Meta</small>
                                <strong title="<?= e($metaValue) ?>"><?= e($metaValueReadable) ?></strong>
                            </div>
                            <div class="summary-product-card__kv">
                                <small>Realizado</small>
                                <strong title="<?= e($realizadoValue) ?>"><?= e($realizadoValueReadable) ?></strong>
                            </div>
                        </div>

                        <div class="summary-product-card__progress">
                            <div class="summary-product-card__progress-head">
                                <small>Atingimento de pontos</small>
                            </div>

                            <div class="summary-product-card__progress-body">
                                <span class="summary-product-card__progress-goal"><?= e(format_points_readable($pointsAchieved)) ?> pts</span>
                                <div class="summary-product-card__track <?= e($resolveIndicatorBarClass($pointsPercent)) ?>" role="progressbar" aria-valuenow="<?= e(number_format(max(0, min(100, $pointsPercent)), 1, '.', '')) ?>" aria-valuemin="0" aria-valuemax="100">
                                    <span class="summary-product-card__fill" style="--target: <?= e($formatCssPercent($pointsPercent)) ?>;"></span>
                                    <span class="summary-product-card__progress-label" style="--target: <?= e($formatCssPercent($pointsPercent)) ?>;">
                                        <span class="summary-product-card__progress-value"><?= e(number_format($pointsPercent, 1, ',', '.')) ?>%</span>
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="summary-product-card__foot">Atualizado em <?= e($updatedAt !== '' ? $updatedAt : 'N/A') ?></div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endforeach; ?>
</section>
