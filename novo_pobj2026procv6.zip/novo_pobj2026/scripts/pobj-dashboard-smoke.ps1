[CmdletBinding()]
param(
    [string]$BaseUrl = 'http://localhost/novo_pobj2026/index.php',
    [int]$TimeoutSec = 30
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Web

$session = New-Object Microsoft.PowerShell.Commands.WebRequestSession
$results = New-Object System.Collections.Generic.List[string]

function Add-Result {
    param([string]$Message)

    $script:results.Add($Message)
}

function Assert-Check {
    param(
        [bool]$Condition,
        [string]$SuccessMessage,
        [string]$FailureMessage
    )

    if (-not $Condition) {
        throw $FailureMessage
    }

    Add-Result("OK: $SuccessMessage")
}

function Get-Page {
    param(
        [string]$Url,
        [hashtable]$Headers = @{}
    )

    return Invoke-WebRequest -Uri $Url -WebSession $script:session -Headers $Headers -UseBasicParsing -TimeoutSec $TimeoutSec
}

function Post-Form {
    param([hashtable]$Body)

    return Invoke-WebRequest -Uri $BaseUrl -Method Post -Body $Body -WebSession $script:session -UseBasicParsing -TimeoutSec $TimeoutSec
}

function Get-CsrfToken {
    param([string]$Html)

    $match = [regex]::Match($Html, 'name="csrf_token" value="([^"]+)"')

    if (-not $match.Success) {
        throw 'Nao foi possivel localizar o csrf_token na pagina.'
    }

    return $match.Groups[1].Value
}

function Get-SelectOptions {
    param(
        [string]$Html,
        [string]$SelectName
    )

    $pattern = '(?s)<select[^>]*name="' + [regex]::Escape($SelectName) + '"[^>]*>(.*?)</select>'
    $selectMatch = [regex]::Match($Html, $pattern)

    if (-not $selectMatch.Success) {
        throw ('Nao foi possivel localizar o select ' + $SelectName)
    }

    $optionMatches = [regex]::Matches($selectMatch.Groups[1].Value, '<option value="([^"]*)"[^>]*>(.*?)</option>')
    $options = @()

    foreach ($optionMatch in $optionMatches) {
        $options += [pscustomobject]@{
            Value = $optionMatch.Groups[1].Value
            Label = [System.Web.HttpUtility]::HtmlDecode(($optionMatch.Groups[2].Value -replace '<[^>]+>', '')).Trim()
            Raw = $optionMatch.Value
        }
    }

    return $options
}

function Html-Decode {
    param([string]$Value)

    return [System.Web.HttpUtility]::HtmlDecode($Value)
}

function ConvertTo-Hashtable {
    param([object]$Value)

    $hash = @{}

    if ($null -eq $Value) {
        return $hash
    }

    foreach ($property in $Value.PSObject.Properties) {
        $hash[$property.Name] = [string]$property.Value
    }

    return $hash
}

function Get-FirstDashboardFields {
    param(
        [string]$Html,
        [string]$ActionName
    )

    $pattern = '(?s)data-dashboard-action="' + [regex]::Escape($ActionName) + '"[^>]*data-dashboard-fields="([^"]+)"'
    $match = [regex]::Match($Html, $pattern)

    if (-not $match.Success) {
        throw ('Nao foi possivel localizar data-dashboard-fields para a acao ' + $ActionName)
    }

    $decoded = Html-Decode $match.Groups[1].Value
    return ConvertTo-Hashtable (ConvertFrom-Json $decoded)
}

function Has-CleanUrl {
    param($Response)

    $finalUri = $Response.BaseResponse.ResponseUri
    return $finalUri.AbsolutePath -match '/novo_pobj2026/index\.php$' -and [string]::IsNullOrEmpty($finalUri.Query)
}

try {
    $root = Get-Page -Url $BaseUrl
    $csrf = Get-CsrfToken -Html $root.Content

    Assert-Check -Condition (Has-CleanUrl -Response $root) -SuccessMessage 'GET inicial abriu index.php sem query string visivel' -FailureMessage 'GET inicial retornou URL com query string inesperada.'
    Assert-Check -Condition ($root.Content -match 'name="visao_acumulada"') -SuccessMessage 'Tela inicial carregou o formulario principal de filtros' -FailureMessage 'Tela inicial nao trouxe o formulario principal de filtros.'

    $periodOptions = Get-SelectOptions -Html $root.Content -SelectName 'periodo_mes'
    $selectedPeriod = $periodOptions | Where-Object { $_.Value -ne '' } | Select-Object -First 1

    if ($null -eq $selectedPeriod) {
        throw 'Nao foi possivel localizar um periodo valido para o smoke test.'
    }

    $filterResponse = Post-Form -Body @{
        csrf_token = $csrf
        action = 'apply_summary_filters'
        tab = 'resumo'
        advanced_filters = 'open'
        periodo_mes = $selectedPeriod.Value
        visao_acumulada = 'SEMESTRAL'
    }
    $csrf = Get-CsrfToken -Html $filterResponse.Content

    Assert-Check -Condition (Has-CleanUrl -Response $filterResponse) -SuccessMessage 'POST de filtros redirecionou para URL limpa' -FailureMessage 'POST de filtros terminou com query string visivel.'
    Assert-Check -Condition ($filterResponse.Content -match 'name="visao_acumulada"[\s\S]*?<option value="SEMESTRAL" selected') -SuccessMessage 'Visao acumulada ficou persistida em sessao apos o POST' -FailureMessage 'Visao acumulada nao ficou selecionada apos o POST.'
    Assert-Check -Condition ($filterResponse.Content -match ('name="periodo_mes"[\s\S]*?<option value="' + [regex]::Escape($selectedPeriod.Value) + '" selected')) -SuccessMessage 'Periodo ficou persistido em sessao apos o POST' -FailureMessage 'Periodo nao ficou selecionado apos o POST.'

    $detailResponse = Post-Form -Body @{
        csrf_token = $csrf
        action = 'set_dashboard_tab'
        tab = 'detalhamento'
    }
    $csrf = Get-CsrfToken -Html $detailResponse.Content

    Assert-Check -Condition (Has-CleanUrl -Response $detailResponse) -SuccessMessage 'Troca para a aba Detalhamento manteve URL limpa' -FailureMessage 'A aba Detalhamento terminou com query string visivel.'
    Assert-Check -Condition ($detailResponse.Content -match 'data-detail-root') -SuccessMessage 'A aba Detalhamento abriu corretamente' -FailureMessage 'A aba Detalhamento nao abriu corretamente.'

    $detailViewMatches = [regex]::Matches($detailResponse.Content, 'data-detail-table-view="([^"]+)"')
    $detailViews = @()

    foreach ($match in $detailViewMatches) {
        $value = $match.Groups[1].Value

        if ($value -ne '' -and -not $detailViews.Contains($value)) {
            $detailViews += $value
        }
    }

    if ($detailViews -contains 'contrato') {
        $ajaxDetailView = 'contrato'
    } elseif ($detailViews.Count -gt 0) {
        $ajaxDetailView = $detailViews[0]
    } else {
        $ajaxDetailView = ''
    }

    if ($ajaxDetailView -eq '') {
        throw 'Nao foi possivel localizar uma visao de detalhamento para o teste AJAX.'
    }

    $ajaxUrl = $BaseUrl + '?detail_table_view=' + [System.Uri]::EscapeDataString($ajaxDetailView)

    if ($ajaxDetailView -eq 'contrato') {
        $ajaxUrl += '&detail_page=1'
    }

    $ajaxResponse = Get-Page -Url $ajaxUrl -Headers @{ 'X-Requested-With' = 'XMLHttpRequest' }
    Assert-Check -Condition ($ajaxResponse.Content -match ('data-detail-table-pane="' + [regex]::Escape($ajaxDetailView) + '"')) -SuccessMessage 'GET interno do Detalhamento respondeu a pane esperada' -FailureMessage 'GET interno do Detalhamento nao retornou a pane esperada.'

    $resumoResponse = Post-Form -Body @{
        csrf_token = $csrf
        action = 'set_dashboard_tab'
        tab = 'resumo'
    }
    $csrf = Get-CsrfToken -Html $resumoResponse.Content
    Assert-Check -Condition (Has-CleanUrl -Response $resumoResponse) -SuccessMessage 'Volta para Resumo manteve URL limpa' -FailureMessage 'Volta para Resumo terminou com query string visivel.'

    $indicatorFields = Get-FirstDashboardFields -Html $resumoResponse.Content -ActionName 'open_indicator_focus'
    $indicatorPost = @{
        csrf_token = $csrf
        action = 'open_indicator_focus'
    }

    foreach ($entry in $indicatorFields.GetEnumerator()) {
        $indicatorPost[$entry.Key] = $entry.Value
    }

    $indicatorResponse = Post-Form -Body $indicatorPost
    $csrf = Get-CsrfToken -Html $indicatorResponse.Content

    Assert-Check -Condition (Has-CleanUrl -Response $indicatorResponse) -SuccessMessage 'Abertura do modal do indicador manteve URL limpa' -FailureMessage 'Abertura do modal do indicador terminou com query string visivel.'
    Assert-Check -Condition ($indicatorResponse.Content -match 'data-indicator-detail-modal') -SuccessMessage 'Modal do indicador abriu corretamente' -FailureMessage 'Modal do indicador nao abriu corretamente.'

    $closeFields = Get-FirstDashboardFields -Html $indicatorResponse.Content -ActionName 'close_indicator_focus'
    $closePost = @{
        csrf_token = $csrf
        action = 'close_indicator_focus'
    }

    foreach ($entry in $closeFields.GetEnumerator()) {
        $closePost[$entry.Key] = $entry.Value
    }

    $closedResponse = Post-Form -Body $closePost
    $csrf = Get-CsrfToken -Html $closedResponse.Content

    Assert-Check -Condition (Has-CleanUrl -Response $closedResponse) -SuccessMessage 'Fechamento do modal do indicador manteve URL limpa' -FailureMessage 'Fechamento do modal do indicador terminou com query string visivel.'
    Assert-Check -Condition ($closedResponse.Content -notmatch 'data-indicator-detail-modal') -SuccessMessage 'Modal do indicador fechou corretamente' -FailureMessage 'Modal do indicador continuou aberto apos o POST de fechamento.'

    $rankingResponse = Post-Form -Body @{
        csrf_token = $csrf
        action = 'set_dashboard_tab'
        tab = 'rankings'
    }
    $csrf = Get-CsrfToken -Html $rankingResponse.Content

    Assert-Check -Condition (Has-CleanUrl -Response $rankingResponse) -SuccessMessage 'Troca para Rankings manteve URL limpa' -FailureMessage 'A aba Rankings terminou com query string visivel.'
    Assert-Check -Condition ($rankingResponse.Content -match 'ranking-shell') -SuccessMessage 'A aba Rankings abriu corretamente' -FailureMessage 'A aba Rankings nao abriu corretamente.'

    $encResponse = Post-Form -Body @{
        csrf_token = $csrf
        action = 'set_encantabra_tab'
        tab = 'encantabra'
        enc_tab = 'resultado'
    }
    $csrf = Get-CsrfToken -Html $encResponse.Content

    Assert-Check -Condition (Has-CleanUrl -Response $encResponse) -SuccessMessage 'Troca para EncantaBra manteve URL limpa' -FailureMessage 'A tela EncantaBra terminou com query string visivel.'
    Assert-Check -Condition ($encResponse.Content -match 'encantabra-view') -SuccessMessage 'A tela EncantaBra abriu corretamente' -FailureMessage 'A tela EncantaBra nao abriu corretamente.'

    $encTabResponse = Post-Form -Body @{
        csrf_token = $csrf
        action = 'set_encantabra_tab'
        tab = 'encantabra'
        enc_tab = 'regulamento'
    }

    Assert-Check -Condition (Has-CleanUrl -Response $encTabResponse) -SuccessMessage 'Troca interna de aba do EncantaBra manteve URL limpa' -FailureMessage 'A troca interna de aba do EncantaBra terminou com query string visivel.'
    Assert-Check -Condition ($encTabResponse.Content -match 'Regulamento') -SuccessMessage 'A aba interna de regulamento do EncantaBra abriu corretamente' -FailureMessage 'A aba interna de regulamento do EncantaBra nao abriu corretamente.'

    $results | ForEach-Object { Write-Output $_ }
    Write-Output ('SMOKE_TOTAL=' + $results.Count)
} catch {
    Write-Error $_
    exit 1
}