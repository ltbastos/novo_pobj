# Analise Inteligente da Visao Executiva

## Objetivo

Este documento explica, de forma simples, como funciona hoje a secao **Analise Inteligente** da aba **Visao executiva** do POBJ.

Tambem aponta **onde cada regra esta implementada** caso o time precise alterar, remover ou criar novas regras.

## Resumo rapido

Hoje a secao **nao calcula os textos em tempo real na tela**.

O fluxo atual e este:

1. Um script gera os insights e grava tudo na tabela `f_exec_insights`.
2. A procedure `sp_pobj_list_executive_insights` le essa tabela.
3. O service `PobjDashboardService` busca os registros e separa em:
   - positivos
   - negativos
4. O template `executive_view.php` apenas renderiza os cards na tela.

Em outras palavras:

- **Regra de negocio**: fica no script de seed
- **Leitura do banco**: fica na procedure + service
- **Exibicao na tela**: fica no template

## Onde esta cada parte

### 1. Tela

Arquivo:

- `templates/executive_view.php`

Bloco da secao:

- secao `executive-panel--analysis`

Responsabilidade:

- mostrar os cards positivos e negativos
- nao define a regra de negocio

Se quiser:

- remover a secao da tela
- esconder a secao
- mudar o texto visual dos titulos da area

o ponto principal e esse arquivo.

### 2. Service que carrega os insights

Arquivo:

- `src/Services/PobjDashboardService.php`

Metodos principais:

- `getExecutiveViewData()`
- `getExecutiveInsightsData()`
- `resolveExecutiveInsightScope()`

Responsabilidade:

- decidir qual recorte deve ser buscado
- chamar a procedure
- separar os itens em `positive` e `negative`

Esse trecho **nao cria as regras**. Ele so escolhe o escopo e le o que ja foi gravado no banco.

### 3. Procedure que le os insights

Arquivo:

- `database/02_novo_pobj_rotinas.sql`

Procedure:

- `sp_pobj_list_executive_insights`

Responsabilidade:

- fazer `SELECT` na tabela `f_exec_insights`
- filtrar por:
  - `ANOMES`
  - `VISAO`
  - `SCOPE_LEVEL`
  - `SCOPE_KEY`

Essa procedure tambem **nao cria a regra**. Ela apenas busca o que ja existe.

### 4. Regras de negocio atuais

Arquivo principal:

- `database/20260419_seed_f_exec_insights.php`

Trechos mais importantes:

- `buildInsightsForScope()`
- `resolveChildLevel()`
- `resolveChildIdentity()`
- `bucketRowsByScope()`

Responsabilidade:

- analisar os snapshots
- montar os textos
- definir quais insights entram
- gravar o resultado na tabela `f_exec_insights`

Se o time quiser **mudar a regra de negocio**, este e o principal arquivo.

### 5. Tabela onde o resultado fica salvo

Arquivo de referencia:

- `database/01_novo_pobj_banco_completo.sql`

Tabela:

- `f_exec_insights`

Campos mais importantes:

- `ANOMES`
- `VISAO`
- `SCOPE_LEVEL`
- `SCOPE_KEY`
- `POLARIDADE`
- `ORDEM`
- `TIPO_INSIGHT`
- `TITULO`
- `TEXTO`
- `DESTAQUE`
- `ITEM_LABEL`

## Regras atuais

As regras atuais sao geradas no metodo `buildInsightsForScope()` do arquivo:

- `database/20260419_seed_f_exec_insights.php`

Hoje existem basicamente **5 tipos de insight**.

### 1. `MELHORA_VS_MES_ANTERIOR`

Tipo:

- positivo

Regra:

- compara o atingimento do mes atual contra o mes anterior
- procura o indicador com a **maior melhora**
- se a variacao for positiva, gera o insight

Exemplo do que ele comunica:

- "Voce melhorou X p.p. em determinado indicador"

Onde mudar:

- `database/20260419_seed_f_exec_insights.php`
- funcao `buildInsightsForScope()`
- bloco que monta `$improvements`

### 2. `QUEDA_VS_MES_ANTERIOR`

Tipo:

- negativo

Regra:

- compara o atingimento do mes atual contra o mes anterior
- procura o indicador com a **maior queda**
- se a variacao for negativa, gera o insight

Exemplo do que ele comunica:

- "Voce piorou X p.p. em determinado indicador"

Onde mudar:

- `database/20260419_seed_f_exec_insights.php`
- funcao `buildInsightsForScope()`
- bloco que monta `$drops`

### 3. `MELHOR_DESTAQUE_ATUAL`

Tipo:

- positivo

Regra:

- olha o recorte atual
- agrupa os dados no nivel filho do escopo atual
- pega o item com **melhor atingimento**

Exemplo:

- melhor regional dentro da diretoria
- melhor agencia dentro da regional
- melhor gerente dentro da agencia
- melhor produto dentro do gerente

Exemplo do que ele comunica:

- "X e o melhor destaque do recorte"

Onde mudar:

- `database/20260419_seed_f_exec_insights.php`
- funcao `buildInsightsForScope()`
- bloco que usa `$childGroups[0]`

### 4. `CONCENTRACAO_RESULTADO`

Tipo:

- negativo

Regra:

- soma o `realizado` total do recorte
- identifica o item filho com maior participacao no resultado
- calcula quanto esse item representa do total
- gera um alerta de concentracao

Exemplo do que ele comunica:

- "X% do resultado esta concentrado em Y"

Onde mudar:

- `database/20260419_seed_f_exec_insights.php`
- funcao `buildInsightsForScope()`
- bloco que calcula `$topShare`

### 5. `PONTO_DE_ATENCAO`

Tipo:

- negativo

Regra:

- olha os agrupamentos filhos do recorte atual
- pega o item com **pior atingimento**
- gera o alerta principal de atencao

Exemplo do que ele comunica:

- "X e o principal ponto de atencao"

Onde mudar:

- `database/20260419_seed_f_exec_insights.php`
- funcao `buildInsightsForScope()`
- bloco que usa o ultimo item de `$childGroups`

## Como o sistema decide o "nivel filho"

Esse detalhe e importante porque varias regras usam o melhor/pior item filho do recorte.

Arquivo:

- `database/20260419_seed_f_exec_insights.php`

Funcao:

- `resolveChildLevel()`

Regra atual de descida:

- `GLOBAL` -> `regional`
- `SEGMENTO` -> `diretoria`
- `DIRETORIA` -> `regional`
- `REGIONAL` -> `agencia`
- `AGENCIA` -> `gerente_gestao`
  - se nao houver gerente de gestao, cai para `gerente`
- `GERENTE_GESTAO` -> `gerente`
- `GERENTE` -> `produto`

Se o time quiser mudar a profundidade da leitura, esse e um dos pontos principais.

## Como o sistema decide o escopo

Existem dois momentos diferentes:

### 1. No seed

Arquivo:

- `database/20260419_seed_f_exec_insights.php`

Funcao:

- `bucketRowsByScope()`

O script grava insights para varios escopos:

- `GLOBAL`
- `SEGMENTO`
- `DIRETORIA`
- `REGIONAL`
- `AGENCIA`
- `GERENTE_GESTAO`
- `GERENTE`

### 2. Em tempo de execucao

Arquivo:

- `src/Services/PobjDashboardService.php`

Metodo:

- `resolveExecutiveInsightScope()`

Prioridade atual:

1. gerente
2. gerente_gestao
3. agencia
4. regional
5. diretoria
6. segmento
7. escopo do perfil logado
8. `GLOBAL`

Se o time quiser mudar qual insight aparece para cada filtro/perfil, este metodo precisa ser revisado.

## Quantidade maxima de cards

Arquivo:

- `database/20260419_seed_f_exec_insights.php`

Regra atual:

- no maximo `3` positivos
- no maximo `3` negativos

Trecho:

- `array_slice($positive, 0, 3)`
- `array_slice($negative, 0, 3)`

Se quiser aumentar ou reduzir a quantidade, esse e o ponto.

## Visoes atendidas hoje

Arquivo:

- `database/20260419_seed_f_exec_insights.php`

Regra atual:

- gera insights para:
  - `MENSAL`
  - `SEMESTRAL`
  - `ACUMULADO`

Hoje a secao nao esta preparada por regra propria para:

- `ANUAL`
- `MENSAL_ACUMULADO`

No runtime, quando vier `MENSAL_ACUMULADO`, o service normaliza para `MENSAL`.

Arquivo:

- `src/Services/PobjDashboardService.php`

Metodo:

- `getExecutiveInsightsData()`

## O que o time precisa fazer para mudar uma regra

### Se quiser so mudar texto

Opcoes:

- mudar o texto no seed e regerar a tabela
- ou alterar direto os registros da tabela `f_exec_insights`

Melhor caminho:

- ajustar o seed
- regerar a tabela

### Se quiser mudar a logica de negocio

Ponto principal:

- `database/20260419_seed_f_exec_insights.php`

Normalmente vai mexer em:

- `buildInsightsForScope()`
- `resolveChildLevel()`
- `resolveChildIdentity()`
- `bucketRowsByScope()`

### Se quiser criar uma nova regra

Ponto principal:

- `database/20260419_seed_f_exec_insights.php`

Passos:

1. criar a nova regra dentro de `buildInsightsForScope()`
2. definir:
   - polaridade
   - titulo
   - texto
   - destaque
   - item_label
   - ordem
3. regerar a tabela `f_exec_insights`

### Se quiser remover uma regra

Ponto principal:

- `database/20260419_seed_f_exec_insights.php`

Basta remover o bloco que monta aquele insight e depois regerar a tabela.

### Se quiser remover a secao inteira da tela

Opcoes:

- remover o bloco no template:
  - `templates/executive_view.php`
- ou fazer o service retornar vazio:
  - `src/Services/PobjDashboardService.php`
  - metodo `getExecutiveInsightsData()`

## Impacto tecnico de mudancas

### Mudanca so de tela

Exemplo:

- trocar titulo da secao
- esconder card
- mudar layout visual

Impacto:

- baixo
- normalmente sem mexer no banco

Arquivo principal:

- `templates/executive_view.php`

### Mudanca de regra

Exemplo:

- trocar a definicao do melhor destaque
- mudar o criterio de concentracao
- trocar o nivel filho

Impacto:

- medio
- precisa regerar `f_exec_insights`

Arquivo principal:

- `database/20260419_seed_f_exec_insights.php`

### Mudanca de leitura por filtro/perfil

Exemplo:

- quando filtrar agencia, buscar outro escopo
- quando o perfil for gerente, priorizar outro nivel

Impacto:

- medio

Arquivo principal:

- `src/Services/PobjDashboardService.php`
- metodo `resolveExecutiveInsightScope()`

## Recomendacao para manutencao

Se o time for evoluir essa secao, o caminho mais seguro e:

1. ajustar a regra no seed `20260419_seed_f_exec_insights.php`
2. regerar os registros da tabela `f_exec_insights`
3. validar a leitura na procedure `sp_pobj_list_executive_insights`
4. validar a exibicao final em `templates/executive_view.php`

## Resumo final

Hoje a secao **Analise Inteligente** funciona como uma camada de leitura de insights **precalculados**.

O ponto mais importante para lembrar e:

- **se quiser mudar regra de negocio, mexa no seed**
- **se quiser mudar o que aparece para cada filtro/perfil, mexa no service**
- **se quiser mudar so a aparencia, mexa no template**

