DROP PROCEDURE IF EXISTS sp_pobj_list_executive_focus_rows;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_executive_focus_rows(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_group_level VARCHAR(32),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
proc: BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_has_hierarchy_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;
    DECLARE v_join_sql LONGTEXT DEFAULT '';
    DECLARE v_group_sql LONGTEXT DEFAULT 'CAST(f.`COD_REGIONAL` AS CHAR)';
    DECLARE v_label_sql LONGTEXT DEFAULT 'COALESCE(NULLIF(TRIM(f.`DS_REGIONAL`), ''''), CAST(f.`COD_REGIONAL` AS CHAR))';
    DECLARE v_level VARCHAR(32);

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT('fGestaoGerente' USING utf8) COLLATE utf8_unicode_ci
    ) INTO v_has_management_table;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'dHierarquia'
    ) INTO v_has_hierarchy_table;

    SET v_level = LOWER(TRIM(COALESCE(p_group_level, 'regional')));

    IF v_has_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS group_value, CAST(NULL AS CHAR) AS display_label, 0 AS row_count, 0 AS pontos_meta_total, 0 AS pontos_real_total, 0 AS atingimento_medio, 0 AS forecast_medio, 0 AS referencia_total, 0 AS referencia_perc_media, 0 AS metric_type_count, CAST(NULL AS CHAR) AS metric_type_single, 0 AS valor_meta_total, 0 AS valor_real_total, 0 AS realizado_count FROM DUAL WHERE 1 = 0;
    ELSE
        IF v_level = 'agencia' THEN
            SET v_group_sql = 'CAST(f.`COD_AGENCIA` AS CHAR)';
            SET v_label_sql = 'COALESCE(NULLIF(TRIM(f.`DS_AGENCIA`), ''''), CAST(f.`COD_AGENCIA` AS CHAR))';
        ELSEIF v_level = 'gerente_gestao' THEN
            IF v_has_management_table = 0 OR v_has_hierarchy_table = 0 THEN
                SELECT CAST(NULL AS CHAR) AS group_value, CAST(NULL AS CHAR) AS display_label, 0 AS row_count, 0 AS pontos_meta_total, 0 AS pontos_real_total, 0 AS atingimento_medio, 0 AS forecast_medio, 0 AS referencia_total, 0 AS referencia_perc_media, 0 AS metric_type_count, CAST(NULL AS CHAR) AS metric_type_single, 0 AS valor_meta_total, 0 AS valor_real_total, 0 AS realizado_count FROM DUAL WHERE 1 = 0;
                LEAVE proc;
            END IF;

            SET v_join_sql = ' INNER JOIN fGestaoGerente gg ON gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci INNER JOIN dHierarquia hgg ON hgg.ativo_sn = 1 AND hgg.funcional = gg.funcional_gerente_gestao';
            SET v_group_sql = 'CAST(gg.funcional_gerente_gestao AS CHAR)';
            SET v_label_sql = 'COALESCE(NULLIF(TRIM(hgg.nome), ''''), CAST(gg.funcional_gerente_gestao AS CHAR))';
        ELSEIF v_level = 'gerente' THEN
            IF v_has_hierarchy_table = 1 THEN
                SET v_join_sql = ' LEFT JOIN dHierarquia hg ON hg.ativo_sn = 1 AND CAST(hg.funcional AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci';
                SET v_label_sql = 'COALESCE(NULLIF(TRIM(hg.nome), ''''), NULLIF(TRIM(f.`DS_UNIDADE`), ''''), CAST(f.`COD_UNIDADE` AS CHAR))';
            ELSE
                SET v_label_sql = 'COALESCE(NULLIF(TRIM(f.`DS_UNIDADE`), ''''), CAST(f.`COD_UNIDADE` AS CHAR))';
            END IF;

            SET v_group_sql = 'CAST(f.`COD_UNIDADE` AS CHAR)';
        ELSEIF v_level = 'produto' THEN
            SET v_group_sql = 'COALESCE(NULLIF(TRIM(COALESCE(f.`LABEL`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`ITEM_AB`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`DS_FAMILIA`, '''')), ''''), CAST(f.`ID_FAMILIA` AS CHAR))';
            SET v_label_sql = 'COALESCE(NULLIF(TRIM(COALESCE(f.`DS_INDICADOR`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`ITEM_AB`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`LABEL`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`DS_FAMILIA`, '''')), ''''), CAST(f.`ID_FAMILIA` AS CHAR))';
        ELSEIF v_level = 'familia' THEN
            SET v_group_sql = 'COALESCE(NULLIF(TRIM(COALESCE(f.`DS_FAMILIA`, '''')), ''''), CAST(f.`ID_FAMILIA` AS CHAR))';
            SET v_label_sql = 'COALESCE(NULLIF(TRIM(COALESCE(f.`DS_FAMILIA`, '''')), ''''), CAST(f.`ID_FAMILIA` AS CHAR))';
        END IF;

        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT ',
            v_group_sql, ' AS group_value, ',
            v_label_sql, ' AS display_label, ',
            'COUNT(*) AS row_count, ',
            'COALESCE(SUM(COALESCE(f.`PONTOS_POBJ`, 0)), 0) AS pontos_meta_total, ',
            'COALESCE(SUM(COALESCE(f.`PONTOS_PRODUCAO`, 0)), 0) AS pontos_real_total, ',
            'COALESCE(AVG(COALESCE(f.`ATING_INI`, 0)), 0) AS atingimento_medio, ',
            'COALESCE(AVG(COALESCE(f.`ATG_FINAL`, 0)), 0) AS forecast_medio, ',
            'COALESCE(SUM(CASE WHEN UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR''))) = ''PERCENTUAL'' THEN 0 ELSE COALESCE(f.`REFERENCIA`, 0) END), 0) AS referencia_total, ',
            'COALESCE(AVG(CASE WHEN UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR''))) = ''PERCENTUAL'' THEN COALESCE(f.`REF_PERC`, 0) END), 0) AS referencia_perc_media, ',
            'COUNT(DISTINCT UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR'')))) AS metric_type_count, ',
            'MIN(UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR'')))) AS metric_type_single, ',
            'COALESCE(SUM(COALESCE(f.`VLR_META`, 0)), 0) AS valor_meta_total, ',
            'COALESCE(SUM(COALESCE(f.`VLR_PRODUCAO`, 0)), 0) AS valor_real_total, ',
            'COALESCE(SUM(CASE WHEN COALESCE(f.`VLR_PRODUCAO`, 0) > 0 OR COALESCE(f.`PONTOS_PRODUCAO`, 0) > 0 THEN 1 ELSE 0 END), 0) AS realizado_count ',
            'FROM ', v_table_sql, ' f',
            v_join_sql,
            ' WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes),
            ' AND COALESCE(f.`NIVEL`, 0) = 1',
            ' AND UPPER(REPLACE(TRIM(COALESCE(f.`DS_NIVEL`, '''')), '' '', ''_'')) = ''PRODUTO'''
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_scope_functional));
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento, ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) = ', QUOTE(p_segmento));
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) = ', QUOTE(p_diretoria));
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) = ', QUOTE(p_regional));
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) = ', QUOTE(p_agencia));
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente_gestao), ' OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) = CAST(f.`COD_UNIDADE` AS CHAR) AND gg.funcional_gerente_gestao = ', QUOTE(p_gerente_gestao), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente_gestao));
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente));
        END IF;
        IF COALESCE(p_familia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_FAMILIA` AS CHAR) = ', QUOTE(p_familia));
        END IF;
        IF COALESCE(p_indicador, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_INDICADOR` AS CHAR) = ', QUOTE(p_indicador));
        END IF;

        SET v_sql = CONCAT(v_sql, ' GROUP BY group_value, display_label HAVING COALESCE(group_value, '''') <> '''' ORDER BY display_label');

        SET @sp_pobj_list_executive_focus_rows_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_executive_focus_rows_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;


DROP PROCEDURE IF EXISTS sp_pobj_list_executive_heatmap_sections;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_executive_heatmap_sections(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_group_level VARCHAR(32),
    IN p_row_keys_csv TEXT,
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
proc: BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_has_hierarchy_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;
    DECLARE v_join_sql LONGTEXT DEFAULT '';
    DECLARE v_group_sql LONGTEXT DEFAULT 'CAST(f.`COD_REGIONAL` AS CHAR)';
    DECLARE v_level VARCHAR(32);

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fGestaoGerente') INTO v_has_management_table;
    SELECT EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'dHierarquia') INTO v_has_hierarchy_table;

    SET v_level = LOWER(TRIM(COALESCE(p_group_level, 'regional')));

    IF v_has_table = 0 OR COALESCE(TRIM(p_row_keys_csv), '') = '' THEN
        SELECT CAST(NULL AS CHAR) AS row_key, CAST(NULL AS CHAR) AS family_key, 0 AS row_count, 0 AS pontos_meta_total, 0 AS pontos_real_total, 0 AS atingimento_medio, 0 AS forecast_medio, 0 AS referencia_total, 0 AS referencia_perc_media, 0 AS metric_type_count, CAST(NULL AS CHAR) AS metric_type_single, 0 AS valor_meta_total, 0 AS valor_real_total, 0 AS realizado_count FROM DUAL WHERE 1 = 0;
        LEAVE proc;
    END IF;

    IF v_level = 'agencia' THEN
        SET v_group_sql = 'CAST(f.`COD_AGENCIA` AS CHAR)';
    ELSEIF v_level = 'gerente_gestao' THEN
        IF v_has_management_table = 0 OR v_has_hierarchy_table = 0 THEN
            SELECT CAST(NULL AS CHAR) AS row_key, CAST(NULL AS CHAR) AS family_key, 0 AS row_count, 0 AS pontos_meta_total, 0 AS pontos_real_total, 0 AS atingimento_medio, 0 AS forecast_medio, 0 AS referencia_total, 0 AS referencia_perc_media, 0 AS metric_type_count, CAST(NULL AS CHAR) AS metric_type_single, 0 AS valor_meta_total, 0 AS valor_real_total, 0 AS realizado_count FROM DUAL WHERE 1 = 0;
            LEAVE proc;
        END IF;

        SET v_join_sql = ' INNER JOIN fGestaoGerente gg ON gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci INNER JOIN dHierarquia hgg ON hgg.ativo_sn = 1 AND hgg.funcional = gg.funcional_gerente_gestao';
        SET v_group_sql = 'CAST(gg.funcional_gerente_gestao AS CHAR)';
    ELSEIF v_level = 'gerente' THEN
        IF v_has_hierarchy_table = 1 THEN
            SET v_join_sql = ' LEFT JOIN dHierarquia hg ON hg.ativo_sn = 1 AND CAST(hg.funcional AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci';
        END IF;

        SET v_group_sql = 'CAST(f.`COD_UNIDADE` AS CHAR)';
    ELSEIF v_level = 'produto' THEN
        SET v_group_sql = 'COALESCE(NULLIF(TRIM(COALESCE(f.`LABEL`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`ITEM_AB`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`DS_FAMILIA`, '''')), ''''), CAST(f.`ID_FAMILIA` AS CHAR))';
    END IF;

    SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
    SET v_sql = CONCAT(
        'SELECT ',
        v_group_sql, ' AS row_key, ',
        'COALESCE(NULLIF(TRIM(COALESCE(f.`DS_FAMILIA`, '''')), ''''), CAST(f.`ID_FAMILIA` AS CHAR)) AS family_key, ',
        'COUNT(*) AS row_count, ',
        'COALESCE(SUM(COALESCE(f.`PONTOS_POBJ`, 0)), 0) AS pontos_meta_total, ',
        'COALESCE(SUM(COALESCE(f.`PONTOS_PRODUCAO`, 0)), 0) AS pontos_real_total, ',
        'COALESCE(AVG(COALESCE(f.`ATING_INI`, 0)), 0) AS atingimento_medio, ',
        'COALESCE(AVG(COALESCE(f.`ATG_FINAL`, 0)), 0) AS forecast_medio, ',
        'COALESCE(SUM(CASE WHEN UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR''))) = ''PERCENTUAL'' THEN 0 ELSE COALESCE(f.`REFERENCIA`, 0) END), 0) AS referencia_total, ',
        'COALESCE(AVG(CASE WHEN UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR''))) = ''PERCENTUAL'' THEN COALESCE(f.`REF_PERC`, 0) END), 0) AS referencia_perc_media, ',
        'COUNT(DISTINCT UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR'')))) AS metric_type_count, ',
        'MIN(UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR'')))) AS metric_type_single, ',
        'COALESCE(SUM(COALESCE(f.`VLR_META`, 0)), 0) AS valor_meta_total, ',
        'COALESCE(SUM(COALESCE(f.`VLR_PRODUCAO`, 0)), 0) AS valor_real_total, ',
        'COALESCE(SUM(CASE WHEN COALESCE(f.`VLR_PRODUCAO`, 0) > 0 OR COALESCE(f.`PONTOS_PRODUCAO`, 0) > 0 THEN 1 ELSE 0 END), 0) AS realizado_count ',
        'FROM ', v_table_sql, ' f',
        v_join_sql,
        ' WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes),
        ' AND COALESCE(f.`NIVEL`, 0) = 1',
        ' AND UPPER(REPLACE(TRIM(COALESCE(f.`DS_NIVEL`, '''')), '' '', ''_'')) = ''PRODUTO''',
        ' AND FIND_IN_SET(', v_group_sql, ' COLLATE utf8_unicode_ci, CONVERT(', QUOTE(p_row_keys_csv), ' USING utf8) COLLATE utf8_unicode_ci) > 0'
    );

    IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
    ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
        SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
    ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
        SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
    ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
        SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
    ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
        SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
    END IF;

    IF COALESCE(p_segmento, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci');
    END IF;
    IF COALESCE(p_diretoria, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_diretoria), ' USING utf8) COLLATE utf8_unicode_ci');
    END IF;
    IF COALESCE(p_regional, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_regional), ' USING utf8) COLLATE utf8_unicode_ci');
    END IF;
    IF COALESCE(p_agencia, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_agencia), ' USING utf8) COLLATE utf8_unicode_ci');
    END IF;
    IF COALESCE(p_gerente_gestao, '') <> '' THEN
        IF v_has_management_table = 1 THEN
            SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci AND gg.funcional_gerente_gestao COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci))');
        ELSE
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
    END IF;
    IF COALESCE(p_gerente, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente), ' USING utf8) COLLATE utf8_unicode_ci');
    END IF;
    IF COALESCE(p_familia, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_FAMILIA` AS CHAR) = ', QUOTE(p_familia));
    END IF;
    IF COALESCE(p_indicador, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_INDICADOR` AS CHAR) = ', QUOTE(p_indicador));
    END IF;

    SET v_sql = CONCAT(v_sql, ' GROUP BY row_key, family_key HAVING COALESCE(row_key, '''') <> '''' AND COALESCE(family_key, '''') <> '''' ORDER BY row_key, family_key');

    SET @sp_pobj_list_executive_heatmap_sections_sql = v_sql;
    PREPARE stmt FROM @sp_pobj_list_executive_heatmap_sections_sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END$$

DELIMITER ;


DROP PROCEDURE IF EXISTS sp_pobj_get_executive_snapshot_totals;

DELIMITER $$

CREATE PROCEDURE sp_pobj_get_executive_snapshot_totals(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_table = 0 THEN
        SELECT 0 AS row_count, 0 AS pontos_meta_total, 0 AS pontos_real_total, 0 AS atingimento_medio, 0 AS forecast_medio, 0 AS referencia_total, 0 AS referencia_perc_media, 0 AS metric_type_count, CAST(NULL AS CHAR) AS metric_type_single, 0 AS valor_meta_total, 0 AS valor_real_total;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT ',
            'COUNT(*) AS row_count, ',
            'COALESCE(SUM(COALESCE(f.`PONTOS_POBJ`, 0)), 0) AS pontos_meta_total, ',
            'COALESCE(SUM(COALESCE(f.`PONTOS_PRODUCAO`, 0)), 0) AS pontos_real_total, ',
            'COALESCE(AVG(COALESCE(f.`ATING_INI`, 0)), 0) AS atingimento_medio, ',
            'COALESCE(AVG(COALESCE(f.`ATG_FINAL`, 0)), 0) AS forecast_medio, ',
            'COALESCE(SUM(CASE WHEN UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR''))) = ''PERCENTUAL'' THEN 0 ELSE COALESCE(f.`REFERENCIA`, 0) END), 0) AS referencia_total, ',
            'COALESCE(AVG(CASE WHEN UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR''))) = ''PERCENTUAL'' THEN COALESCE(f.`REF_PERC`, 0) END), 0) AS referencia_perc_media, ',
            'COUNT(DISTINCT UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR'')))) AS metric_type_count, ',
            'MIN(UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR'')))) AS metric_type_single, ',
            'COALESCE(SUM(COALESCE(f.`VLR_META`, 0)), 0) AS valor_meta_total, ',
            'COALESCE(SUM(COALESCE(f.`VLR_PRODUCAO`, 0)), 0) AS valor_real_total ',
            'FROM ', v_table_sql, ' f ',
            'WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes),
            ' AND COALESCE(f.`NIVEL`, 0) = 1',
            ' AND UPPER(REPLACE(TRIM(COALESCE(f.`DS_NIVEL`, '''')), '' '', ''_'')) = ''PRODUTO'''
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_scope_functional));
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento, ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) = ', QUOTE(p_segmento));
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) = ', QUOTE(p_diretoria));
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) = ', QUOTE(p_regional));
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) = ', QUOTE(p_agencia));
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente_gestao), ' OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) = CAST(f.`COD_UNIDADE` AS CHAR) AND gg.funcional_gerente_gestao = ', QUOTE(p_gerente_gestao), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente_gestao));
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente));
        END IF;
        IF COALESCE(p_familia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_FAMILIA` AS CHAR) = ', QUOTE(p_familia));
        END IF;
        IF COALESCE(p_indicador, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_INDICADOR` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_indicador), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;

        SET @sp_pobj_get_executive_snapshot_totals_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_get_executive_snapshot_totals_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;