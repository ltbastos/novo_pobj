SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci;

DROP PROCEDURE IF EXISTS sp_pobj_list_semestral_family_options;
DROP PROCEDURE IF EXISTS sp_pobj_list_semestral_indicator_options;
DROP PROCEDURE IF EXISTS sp_pobj_list_semestral_indicator_rows;
DROP PROCEDURE IF EXISTS sp_pobj_seed_produto_informativo_snapshot;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_semestral_family_options(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT('fGestaoGerente' USING utf8) COLLATE utf8_unicode_ci
    ) INTO v_has_management_table;

    IF v_has_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS value, CAST(NULL AS CHAR) AS label FROM DUAL WHERE 1 = 0;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT CAST(f.`ID_FAMILIA` AS CHAR) AS value, COALESCE(f.`DS_FAMILIA`, CAST(f.`ID_FAMILIA` AS CHAR)) AS label, ',
            'MIN(COALESCE(f.`ORDEM`, 999999)) AS ordem ',
            'FROM ', v_table_sql, ' f ',
            'WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes),
            ' AND COALESCE(f.`NIVEL`, 0) = 1 AND UPPER(TRIM(COALESCE(f.`DS_NIVEL`, ''''))) = ''PRODUTO'''
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_scope_functional));
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento, ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) = ', QUOTE(p_segmento));
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) = ', QUOTE(p_diretoria));
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) = ', QUOTE(p_regional));
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) = ', QUOTE(p_agencia));
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente_gestao), ' OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) = CAST(f.`COD_UNIDADE` AS CHAR) AND gg.funcional_gerente_gestao = ', QUOTE(p_gerente_gestao), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente_gestao));
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente));
        END IF;

        SET v_sql = CONCAT(v_sql, ' GROUP BY f.`ID_FAMILIA`, COALESCE(f.`DS_FAMILIA`, CAST(f.`ID_FAMILIA` AS CHAR)) ORDER BY ordem, label');
        SET @sp_pobj_list_semestral_family_options_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_semestral_family_options_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

CREATE PROCEDURE sp_pobj_list_semestral_indicator_options(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT('fGestaoGerente' USING utf8) COLLATE utf8_unicode_ci
    ) INTO v_has_management_table;

    IF v_has_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS value, CAST(NULL AS CHAR) AS label FROM DUAL WHERE 1 = 0;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT CAST(f.`ID_INDICADOR` AS CHAR) AS value, COALESCE(f.`DS_INDICADOR`, CAST(f.`ID_INDICADOR` AS CHAR)) AS label, ',
            'MIN(COALESCE(f.`ORDEM`, 999999)) AS ordem ',
            'FROM ', v_table_sql, ' f ',
            'WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes),
            ' AND COALESCE(f.`NIVEL`, 0) = 1 AND UPPER(TRIM(COALESCE(f.`DS_NIVEL`, ''''))) = ''PRODUTO'''
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_scope_functional));
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento, ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) = ', QUOTE(p_segmento));
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) = ', QUOTE(p_diretoria));
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) = ', QUOTE(p_regional));
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) = ', QUOTE(p_agencia));
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente_gestao), ' OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) = CAST(f.`COD_UNIDADE` AS CHAR) AND gg.funcional_gerente_gestao = ', QUOTE(p_gerente_gestao), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente_gestao));
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente));
        END IF;
        IF COALESCE(p_familia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_FAMILIA` AS CHAR) = ', QUOTE(p_familia));
        END IF;

        SET v_sql = CONCAT(v_sql, ' GROUP BY f.`ID_INDICADOR`, COALESCE(f.`DS_INDICADOR`, CAST(f.`ID_INDICADOR` AS CHAR)) ORDER BY ordem, label');
        SET @sp_pobj_list_semestral_indicator_options_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_semestral_indicator_options_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

CREATE PROCEDURE sp_pobj_list_semestral_indicator_rows(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT('fGestaoGerente' USING utf8) COLLATE utf8_unicode_ci
    ) INTO v_has_management_table;

    IF v_has_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS id_indicador FROM DUAL WHERE 1 = 0;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT ',
            'CAST(f.`ID_INDICADOR` AS CHAR) AS id_indicador, ',
            'MAX(CAST(f.`ID_PAI_INDICADOR` AS CHAR)) AS id_pai_indicador, ',
            'MIN(COALESCE(f.`ORDEM`, 999999)) AS ordem, ',
            'MAX(COALESCE(f.`NIVEL`, 0)) AS nivel, ',
            'MAX(COALESCE(f.`DS_NIVEL`, '''')) AS ds_nivel, ',
            'MAX(CAST(f.`ID_PROGRAMA` AS CHAR)) AS id_programa, ',
            'MAX(COALESCE(f.`DS_INDICADOR`, CAST(f.`ID_INDICADOR` AS CHAR))) AS nome_indicador, ',
            'CAST(f.`ID_FAMILIA` AS CHAR) AS id_familia, ',
            'MAX(COALESCE(f.`DS_FAMILIA`, CAST(f.`ID_FAMILIA` AS CHAR))) AS nome_familia, ',
            'CAST('''' AS CHAR) AS id_tipo_indicador, ',
            'CAST('''' AS CHAR) AS nome_tipo_indicador, ',
            'MAX(f.`DS_METRICA`) AS ds_metrica, ',
            'COUNT(*) AS row_count, ',
            'COALESCE(MAX(COALESCE(f.`VLR_META`, 0)), 0) AS meta_total, ',
            'COALESCE(MAX(COALESCE(f.`VLR_PRODUCAO`, 0)), 0) AS realizado_total, ',
            'COALESCE(MAX(COALESCE(f.`ATING_INI`, 0)), 0) AS atingimento_inicial, ',
            'COALESCE(MAX(COALESCE(f.`ATG_FINAL`, 0)), 0) AS forecast_valor, ',
            'COALESCE(MAX(COALESCE(f.`NEC_DIA`, 0)), 0) AS nec_dia_valor, ',
            'COALESCE(MAX(COALESCE(f.`REFERENCIA`, 0)), 0) AS referencia_valor, ',
            'COALESCE(MAX(COALESCE(f.`REF_PERC`, 0)), 0) AS referencia_percentual_valor, ',
            'COALESCE(MAX(COALESCE(f.`PESO_FINAL_PRODUCAO`, 0)), 0) AS peso_valor, ',
            'COALESCE(MAX(COALESCE(f.`PONTOS_POBJ`, 0)), 0) AS pontos_meta_valor, ',
            'COALESCE(MAX(COALESCE(f.`PONTOS_PRODUCAO`, 0)), 0) AS pontos_realizado_valor, ',
            'MAX(COALESCE(f.`DATA_BASE`, '''')) AS data_base_max ',
            'FROM ', v_table_sql, ' f ',
            'WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes)
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_scope_functional));
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento, ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) = ', QUOTE(p_segmento));
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) = ', QUOTE(p_diretoria));
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) = ', QUOTE(p_regional));
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) = ', QUOTE(p_agencia));
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente_gestao), ' OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) = CAST(f.`COD_UNIDADE` AS CHAR) AND gg.funcional_gerente_gestao = ', QUOTE(p_gerente_gestao), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente_gestao));
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente));
        END IF;
        IF COALESCE(p_familia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_FAMILIA` AS CHAR) = ', QUOTE(p_familia));
        END IF;
        IF COALESCE(p_indicador, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_INDICADOR` AS CHAR) = ', QUOTE(p_indicador));
        END IF;

        SET v_sql = CONCAT(v_sql, ' GROUP BY f.`ID_FAMILIA`, f.`ID_INDICADOR` ORDER BY ordem, MAX(COALESCE(f.`DS_FAMILIA`, CAST(f.`ID_FAMILIA` AS CHAR))), MAX(COALESCE(f.`DS_INDICADOR`, CAST(f.`ID_INDICADOR` AS CHAR)))');

        SET @sp_pobj_list_semestral_indicator_rows_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_semestral_indicator_rows_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

CREATE PROCEDURE sp_pobj_seed_produto_informativo_snapshot(IN p_table_name VARCHAR(64))
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    IF v_has_table = 1 THEN
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');

        SET @seed_snapshot_delete_sql = CONCAT(
            'DELETE FROM ', v_table_sql,
            ' WHERE `ID_INDICADOR` = 36000 AND `ID_PAI_INDICADOR` = 39022 AND `NIVEL` = 2'
        );
        PREPARE stmt FROM @seed_snapshot_delete_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;

        SET @seed_snapshot_insert_sql = CONCAT(
            'INSERT INTO ', v_table_sql, ' (',
            '`ANOMES`, `DATA_BASE`, `ID_PROGRAMA`, `ORDEM`, `ID_EIXO`, `ID_FAMILIA`, `ID_PAI_FAMILIA`, `DS_FAMILIA`, ',
            '`ID_PAI_INDICADOR`, `ID_INDICADOR`, `DS_INDICADOR`, `ID_METRICA`, `DS_METRICA`, `ID_PERIODICIDADE`, `DS_PERIODICIDADE`, ',
            '`LABEL`, `ITEM_AB`, `NIVEL`, `DS_NIVEL`, `COD_AGENCIA`, `DS_AGENCIA`, `COD_REGIONAL`, `DS_REGIONAL`, `COD_DIRETORIA`, `DS_DIRETORIA`, ',
            '`COD_UNIDADE`, `DS_UNIDADE`, `VLR_META`, `VLR_PRODUCAO`, `ATING_INI`, `ATING_FINAL`, `PESO_POBJ`, `LIMITADOR_MIN`, `LIMITADOR_MAX`, ',
            '`FLG_POBJ`, `REFERENCIA`, `NEC_DIA`, `ATG_FINAL`, `REF_PERC`, `PESO_FINAL_POBJ`, `PESO_FINAL_PRODUCAO`, `PONTOS_POBJ`, `PONTOS_PRODUCAO`, ',
            '`ativo_sn`, `origem_carga`',
            ') ',
            'SELECT ',
            'p.`ANOMES`, p.`DATA_BASE`, p.`ID_PROGRAMA`, p.`ORDEM`, p.`ID_EIXO`, p.`ID_FAMILIA`, p.`ID_PAI_FAMILIA`, p.`DS_FAMILIA`, ',
            '39022, 36000, ''CLIENTES'', p.`ID_METRICA`, p.`DS_METRICA`, p.`ID_PERIODICIDADE`, p.`DS_PERIODICIDADE`, ',
            '''clientes'', ''clientes'', 2, ''PRODUTO_INFORMATIVO'', p.`COD_AGENCIA`, p.`DS_AGENCIA`, p.`COD_REGIONAL`, p.`DS_REGIONAL`, p.`COD_DIRETORIA`, p.`DS_DIRETORIA`, ',
            'p.`COD_UNIDADE`, p.`DS_UNIDADE`, p.`VLR_META`, p.`VLR_PRODUCAO`, p.`ATING_INI`, p.`ATING_FINAL`, 0, p.`LIMITADOR_MIN`, p.`LIMITADOR_MAX`, ',
            'p.`FLG_POBJ`, p.`REFERENCIA`, p.`NEC_DIA`, p.`ATG_FINAL`, p.`REF_PERC`, 0, 0, 0, 0, p.`ativo_sn`, ''SUBINDICADOR_36000'' ',
            'FROM ', v_table_sql, ' p ',
            'WHERE p.`ativo_sn` = 1 AND p.`ID_INDICADOR` = 39022 AND COALESCE(p.`NIVEL`, 0) = 1'
        );
        PREPARE stmt FROM @seed_snapshot_insert_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;

CALL sp_pobj_seed_produto_informativo_snapshot('f_produtividade_mensal_202601');
CALL sp_pobj_seed_produto_informativo_snapshot('f_produtividade_mensal_202602');
CALL sp_pobj_seed_produto_informativo_snapshot('f_produtividade_mensal_202603');
CALL sp_pobj_seed_produto_informativo_snapshot('f_produtividade_mensal_202604');

CALL sp_pobj_seed_produto_informativo_snapshot('f_acumulado_202601');
CALL sp_pobj_seed_produto_informativo_snapshot('f_acumulado_202602');
CALL sp_pobj_seed_produto_informativo_snapshot('f_acumulado_202603');
CALL sp_pobj_seed_produto_informativo_snapshot('f_acumulado_202604');

CALL sp_pobj_seed_produto_informativo_snapshot('f_produtividade_semestral_202601');
CALL sp_pobj_seed_produto_informativo_snapshot('f_produtividade_semestral_202602');
CALL sp_pobj_seed_produto_informativo_snapshot('f_produtividade_semestral_202603');
CALL sp_pobj_seed_produto_informativo_snapshot('f_produtividade_semestral_202604');

DROP PROCEDURE IF EXISTS sp_pobj_seed_produto_informativo_snapshot;
