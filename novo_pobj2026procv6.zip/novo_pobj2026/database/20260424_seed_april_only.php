<?php

declare(strict_types=1);

require dirname(__DIR__) . DIRECTORY_SEPARATOR . 'bootstrap.php';

use App\Database;
$connection = Database::connection();
$connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$connection->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
$connection->exec('DROP PROCEDURE IF EXISTS sp_pobj_count_semestral_visible_units');
$connection->exec(<<<'SQL'
CREATE PROCEDURE sp_pobj_count_semestral_visible_units(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND CONVERT(TABLE_NAME USING utf8mb4) COLLATE utf8mb4_unicode_ci = CONVERT(p_table_name USING utf8mb4) COLLATE utf8mb4_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND CONVERT(TABLE_NAME USING utf8mb4) COLLATE utf8mb4_unicode_ci = CONVERT('fGestaoGerente' USING utf8mb4) COLLATE utf8mb4_unicode_ci
    ) INTO v_has_management_table;

    IF v_has_table = 0 THEN
        SELECT 0 AS visible_units;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT COUNT(DISTINCT CAST(f.`COD_UNIDADE` AS CHAR)) AS visible_units ',
            'FROM ', v_table_sql, ' f ',
            'WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes)
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8mb4_unicode_ci = CONVERT(', QUOTE(p_scope_functional), ' USING utf8mb4) COLLATE utf8mb4_unicode_ci');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8mb4_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8mb4) COLLATE utf8mb4_unicode_ci) > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8mb4_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8mb4) COLLATE utf8mb4_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8mb4_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8mb4) COLLATE utf8mb4_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8mb4_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8mb4) COLLATE utf8mb4_unicode_ci) > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_diretoria), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_regional), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_agencia), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci AND gg.funcional_gerente_gestao COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;

        SET @sp_pobj_count_semestral_visible_units_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_count_semestral_visible_units_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END
SQL
);

$tableExists = static function (PDO $pdo, string $tableName): bool {
    $statement = $pdo->prepare(
        'SELECT 1
         FROM information_schema.TABLES
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = :table_name
         LIMIT 1'
    );
    $statement->execute(['table_name' => $tableName]);

    return (bool) $statement->fetchColumn();
};

$insertRows = static function (PDO $pdo, string $tableName, array $rows): void {
    if ($rows === []) {
        return;
    }

    $columns = array_keys($rows[0]);
    $quotedColumns = array_map(static function (string $column): string {
        return '`' . $column . '`';
    }, $columns);
    $placeholders = implode(', ', array_fill(0, count($columns), '?'));
    $sql = sprintf(
        'INSERT INTO `%s` (%s) VALUES (%s)',
        $tableName,
        implode(', ', $quotedColumns),
        $placeholders
    );
    $statement = $pdo->prepare($sql);

    foreach ($rows as $row) {
        $statement->execute(array_values($row));
    }
};

$formatPercent = static function (float $value): string {
    return number_format($value, 1, ',', '.') . '%';
};

$formatMetricValue = static function (float $value, string $metricType): string {
    $metricType = strtoupper(trim($metricType));

    if ($metricType === 'QUANTIDADE') {
        return number_format($value, 0, ',', '.');
    }

    $absolute = abs($value);

    if ($absolute >= 1000000) {
        return number_format($value / 1000000, 1, ',', '.') . ' mi';
    }

    if ($absolute >= 1000) {
        return number_format($value / 1000, 0, ',', '.') . ' mil';
    }

    return number_format($value, 0, ',', '.');
};

$dropSnapshotTables = [
    'f_produtividade_mensal_202601',
    'f_produtividade_mensal_202602',
    'f_produtividade_mensal_202603',
    'f_acumulado_202601',
    'f_acumulado_202602',
    'f_acumulado_202603',
    'f_produtividade_semestral_202601',
    'f_produtividade_semestral_202602',
    'f_produtividade_semestral_202603',
    'f_analitico_202601',
    'f_analitico_202602',
    'f_analitico_202603',
];

foreach ($dropSnapshotTables as $tableName) {
    $connection->exec(sprintf('DROP TABLE IF EXISTS `%s`', $tableName));
}

$requiredTables = [
    'f_produtividade_mensal_202604',
    'f_acumulado_202604',
    'f_produtividade_semestral_202604',
    'f_analitico_202604',
    'f_variavel',
    'f_exec_insights',
    'dPeriodoApuracao',
];

foreach ($requiredTables as $tableName) {
    if (!$tableExists($connection, $tableName)) {
        throw new RuntimeException(sprintf('Tabela obrigatoria nao encontrada: %s', $tableName));
    }
}

$anomes = 202604;
$dataBase = '2026-04-30';
$remainingDays = 4.0;

$families = [
    101 => ['name' => 'CAPTACAO DIGITAL', 'axis' => 1],
    202 => ['name' => 'RELACIONAMENTO PRIME', 'axis' => 2],
];

$units = [
    '5888638' => [
        'program_id' => 18,
        'program_label' => 'CAPTACAO DIGITAL',
        'code' => '5888638',
        'name' => 'RODRIGO FERREIRA BIONE GUGLIOTTI',
        'agency_code' => '5295',
        'agency_name' => 'PRIME DIGITAL SP III',
        'regional_code' => '8606',
        'regional_name' => 'G.R.PLAT.PRIME 1',
        'directorate_code' => '46950',
        'directorate_name' => 'D.R. DIGITAL PRIME',
        'manager_functional' => '9529501',
        'manager_name' => 'Gestao PRIME DIGITAL SP III 1',
    ],
    '5891272' => [
        'program_id' => 18,
        'program_label' => 'CAPTACAO DIGITAL',
        'code' => '5891272',
        'name' => 'SHIRLEY WADA DOS SANTOS',
        'agency_code' => '5295',
        'agency_name' => 'PRIME DIGITAL SP III',
        'regional_code' => '8606',
        'regional_name' => 'G.R.PLAT.PRIME 1',
        'directorate_code' => '46950',
        'directorate_name' => 'D.R. DIGITAL PRIME',
        'manager_functional' => '9529502',
        'manager_name' => 'Gestao PRIME DIGITAL SP III 2',
    ],
    '6742831' => [
        'program_id' => 18,
        'program_label' => 'CAPTACAO DIGITAL',
        'code' => '6742831',
        'name' => 'DAIANE RICARDINA DA SILVA MIRANDA',
        'agency_code' => '5522',
        'agency_name' => 'PRIME DIGITAL SP I',
        'regional_code' => '8484',
        'regional_name' => 'G.R.PLAT.PRIME 2',
        'directorate_code' => '46950',
        'directorate_name' => 'D.R. DIGITAL PRIME',
        'manager_functional' => '9552201',
        'manager_name' => 'Gestao PRIME DIGITAL SP I 1',
    ],
    '9228357' => [
        'program_id' => 18,
        'program_label' => 'CAPTACAO DIGITAL',
        'code' => '9228357',
        'name' => 'VANESSA DE CASSIA PACHECO',
        'agency_code' => '6096',
        'agency_name' => 'PRIME BH II',
        'regional_code' => '8445',
        'regional_name' => 'G.R.PLAT.PRIME 3',
        'directorate_code' => '4697',
        'directorate_name' => 'D.R. DIGITAL PRIME',
        'manager_functional' => '9609601',
        'manager_name' => 'Gestao PRIME BH II 1',
    ],
    '9302719' => [
        'program_id' => 18,
        'program_label' => 'CAPTACAO DIGITAL',
        'code' => '9302719',
        'name' => 'PAULA KOLANSKI DE ALENCAR BARBOSA',
        'agency_code' => '6096',
        'agency_name' => 'PRIME BH II',
        'regional_code' => '8445',
        'regional_name' => 'G.R.PLAT.PRIME 3',
        'directorate_code' => '4697',
        'directorate_name' => 'D.R. DIGITAL PRIME',
        'manager_functional' => '9609602',
        'manager_name' => 'Gestao PRIME BH II 2',
    ],
    '9313368' => [
        'program_id' => 18,
        'program_label' => 'CAPTACAO DIGITAL',
        'code' => '9313368',
        'name' => 'RAPHAELA MATTOS AGUIAR SILVA',
        'agency_code' => '6096',
        'agency_name' => 'PRIME BH II',
        'regional_code' => '8445',
        'regional_name' => 'G.R.PLAT.PRIME 3',
        'directorate_code' => '4697',
        'directorate_name' => 'D.R. DIGITAL PRIME',
        'manager_functional' => '9609601',
        'manager_name' => 'Gestao PRIME BH II 1',
    ],
    '9314231' => [
        'program_id' => 18,
        'program_label' => 'CAPTACAO DIGITAL',
        'code' => '9314231',
        'name' => 'PEDRO HENRIQUE DE CARVALHO FREITAS',
        'agency_code' => '6096',
        'agency_name' => 'PRIME BH II',
        'regional_code' => '8445',
        'regional_name' => 'G.R.PLAT.PRIME 3',
        'directorate_code' => '4697',
        'directorate_name' => 'D.R. DIGITAL PRIME',
        'manager_functional' => '9609602',
        'manager_name' => 'Gestao PRIME BH II 2',
    ],
    '9317689' => [
        'program_id' => 18,
        'program_label' => 'CAPTACAO DIGITAL',
        'code' => '9317689',
        'name' => 'ROGER PATRI FERREIRA SILVA',
        'agency_code' => '6096',
        'agency_name' => 'PRIME BH II',
        'regional_code' => '8445',
        'regional_name' => 'G.R.PLAT.PRIME 3',
        'directorate_code' => '4697',
        'directorate_name' => 'D.R. DIGITAL PRIME',
        'manager_functional' => '9609601',
        'manager_name' => 'Gestao PRIME BH II 1',
    ],
];

$indicatorBlueprints = [
    [
        'id' => 41001,
        'parent_id' => 41001,
        'family_id' => 101,
        'level' => 1,
        'level_name' => 'PRODUTO',
        'name' => 'Credito Imobiliario Prime',
        'short_name' => 'Credito Prime',
        'metric' => 'VALOR',
        'order' => 10,
        'meta' => 120000.00,
        'realizado' => 132000.00,
        'weight' => 12.00,
        'unit' => '5888638',
    ],
    [
        'id' => 41101,
        'parent_id' => 41001,
        'family_id' => 101,
        'level' => 2,
        'level_name' => 'PRODUTO_INFORMATIVO',
        'name' => 'Origem Imobiliaria Digital',
        'short_name' => 'Origem Digital',
        'metric' => 'VALOR',
        'order' => 11,
        'meta' => 42000.00,
        'realizado' => 46500.00,
        'weight' => 4.00,
        'unit' => '5888638',
    ],
    [
        'id' => 41002,
        'parent_id' => 41002,
        'family_id' => 101,
        'level' => 1,
        'level_name' => 'PRODUTO',
        'name' => 'Seguro Vida Consultivo',
        'short_name' => 'Seguro Vida',
        'metric' => 'VALOR',
        'order' => 20,
        'meta' => 95000.00,
        'realizado' => 88250.00,
        'weight' => 10.00,
        'unit' => '5891272',
    ],
    [
        'id' => 41003,
        'parent_id' => 41003,
        'family_id' => 101,
        'level' => 1,
        'level_name' => 'PRODUTO',
        'name' => 'Consorcio Patrimonial',
        'short_name' => 'Consorcio',
        'metric' => 'VALOR',
        'order' => 30,
        'meta' => 67000.00,
        'realizado' => 74200.00,
        'weight' => 9.00,
        'unit' => '6742831',
    ],
    [
        'id' => 42001,
        'parent_id' => 42001,
        'family_id' => 202,
        'level' => 1,
        'level_name' => 'PRODUTO',
        'name' => 'Carteira Ativa',
        'short_name' => 'Carteira',
        'metric' => 'QUANTIDADE',
        'order' => 40,
        'meta' => 120.00,
        'realizado' => 126.00,
        'weight' => 6.00,
        'unit' => '9228357',
    ],
    [
        'id' => 42002,
        'parent_id' => 42002,
        'family_id' => 202,
        'level' => 1,
        'level_name' => 'PRODUTO',
        'name' => 'Retencao Premium',
        'short_name' => 'Retencao',
        'metric' => 'QUANTIDADE',
        'order' => 50,
        'meta' => 110.00,
        'realizado' => 96.00,
        'weight' => 6.00,
        'unit' => '9302719',
    ],
    [
        'id' => 42003,
        'parent_id' => 42003,
        'family_id' => 202,
        'level' => 1,
        'level_name' => 'PRODUTO',
        'name' => 'Conversao Digital PF',
        'short_name' => 'Conversao PF',
        'metric' => 'QUANTIDADE',
        'order' => 60,
        'meta' => 90.00,
        'realizado' => 79.00,
        'weight' => 5.00,
        'unit' => '9313368',
    ],
    [
        'id' => 42004,
        'parent_id' => 42004,
        'family_id' => 202,
        'level' => 1,
        'level_name' => 'PRODUTO',
        'name' => 'Clientes Informativos',
        'short_name' => 'Clientes',
        'metric' => 'QUANTIDADE',
        'order' => 70,
        'meta' => 150.00,
        'realizado' => 138.00,
        'weight' => 7.00,
        'unit' => '9314231',
    ],
    [
        'id' => 42101,
        'parent_id' => 42004,
        'family_id' => 202,
        'level' => 2,
        'level_name' => 'PRODUTO_INFORMATIVO',
        'name' => 'Clientes PF Informados',
        'short_name' => 'Clientes PF',
        'metric' => 'QUANTIDADE',
        'order' => 71,
        'meta' => 90.00,
        'realizado' => 84.00,
        'weight' => 3.00,
        'unit' => '9314231',
    ],
    [
        'id' => 42111,
        'parent_id' => 42101,
        'family_id' => 202,
        'level' => 3,
        'level_name' => 'PRODUTO_INFORMATIVO',
        'name' => 'Clientes Alta Renda',
        'short_name' => 'Alta Renda',
        'metric' => 'QUANTIDADE',
        'order' => 72,
        'meta' => 35.00,
        'realizado' => 31.00,
        'weight' => 1.00,
        'unit' => '9314231',
    ],
    [
        'id' => 42005,
        'parent_id' => 42005,
        'family_id' => 202,
        'level' => 1,
        'level_name' => 'PRODUTO',
        'name' => 'Expansao Base Prime',
        'short_name' => 'Expansao',
        'metric' => 'QUANTIDADE',
        'order' => 80,
        'meta' => 100.00,
        'realizado' => 108.00,
        'weight' => 6.00,
        'unit' => '9317689',
    ],
];

$metricIdMap = [
    'VALOR' => 1,
    'QUANTIDADE' => 2,
];

$buildSnapshotRows = static function (string $periodLabel, int $periodicityId, string $origin) use (
    $indicatorBlueprints,
    $families,
    $units,
    $metricIdMap,
    $anomes,
    $dataBase,
    $remainingDays
): array {
    $rows = [];
    $rowId = 1;
    $familyOrderById = [];

    foreach ($indicatorBlueprints as $blueprint) {
        if ((int) ($blueprint['level'] ?? 0) !== 1) {
            continue;
        }

        $familyId = (int) ($blueprint['family_id'] ?? 0);
        $familyOrder = max(0, ((int) ($blueprint['order'] ?? 0)) - 1);

        if (!isset($familyOrderById[$familyId]) || $familyOrder < $familyOrderById[$familyId]) {
            $familyOrderById[$familyId] = $familyOrder;
        }
    }

    foreach ($indicatorBlueprints as $blueprint) {
        if ((int) ($blueprint['level'] ?? 0) !== 1) {
            continue;
        }

        $unit = $units[$blueprint['unit']];
        $family = $families[$blueprint['family_id']];
        $familyId = (int) $blueprint['family_id'];

        $rows[] = [
            'id_produtividade_semestral' => $rowId++,
            'ANOMES' => $anomes,
            'DATA_BASE' => $dataBase,
            'ID_PROGRAMA' => $unit['program_id'],
            'ORDEM' => $familyOrderById[$familyId] ?? max(0, ((int) ($blueprint['order'] ?? 0)) - 1),
            'ID_EIXO' => $family['axis'],
            'ID_FAMILIA' => $familyId,
            'ID_PAI_FAMILIA' => null,
            'DS_FAMILIA' => $family['name'],
            'ID_PAI_INDICADOR' => null,
            'ID_INDICADOR' => $familyId,
            'DS_INDICADOR' => $family['name'],
            'ID_METRICA' => 1,
            'DS_METRICA' => 'VALOR',
            'ID_PERIODICIDADE' => $periodicityId,
            'DS_PERIODICIDADE' => $periodLabel,
            'LABEL' => $family['name'],
            'ITEM_AB' => $family['name'],
            'NIVEL' => 0,
            'DS_NIVEL' => 'FAMILIA',
            'COD_AGENCIA' => $unit['agency_code'],
            'DS_AGENCIA' => $unit['agency_name'],
            'COD_REGIONAL' => $unit['regional_code'],
            'DS_REGIONAL' => $unit['regional_name'],
            'COD_DIRETORIA' => $unit['directorate_code'],
            'DS_DIRETORIA' => $unit['directorate_name'],
            'COD_UNIDADE' => $unit['code'],
            'DS_UNIDADE' => $unit['name'],
            'VLR_META' => 0.0,
            'VLR_PRODUCAO' => 0.0,
            'ATING_INI' => 0.0,
            'ATING_FINAL' => 0.0,
            'PESO_POBJ' => 0.0,
            'LIMITADOR_MIN' => 0.0,
            'LIMITADOR_MAX' => 120.0,
            'FLG_POBJ' => 1,
            'REFERENCIA' => 0.0,
            'NEC_DIA' => 0.0,
            'ATG_FINAL' => 0.0,
            'REF_PERC' => 0.0,
            'PESO_FINAL_POBJ' => 0.0,
            'PESO_FINAL_PRODUCAO' => 0.0,
            'PONTOS_POBJ' => 0.0,
            'PONTOS_PRODUCAO' => 0.0,
            'ativo_sn' => 1,
            'origem_carga' => $origin,
        ];
    }

    foreach ($indicatorBlueprints as $blueprint) {
        $unit = $units[$blueprint['unit']];
        $family = $families[$blueprint['family_id']];
        $metricType = strtoupper(trim((string) $blueprint['metric']));
        $meta = (float) $blueprint['meta'];
        $realizado = (float) $blueprint['realizado'];
        $atingimento = $meta > 0 ? round(($realizado / $meta) * 100, 2) : 0.0;
        $weight = (float) $blueprint['weight'];
        $points = round($weight * min(100.0, $atingimento) / 100.0, 2);
        $neededPerDay = $realizado >= $meta
            ? 0.0
            : round(($meta - $realizado) / $remainingDays, 2);

        $rows[] = [
            'id_produtividade_semestral' => $rowId++,
            'ANOMES' => $anomes,
            'DATA_BASE' => $dataBase,
            'ID_PROGRAMA' => $unit['program_id'],
            'ORDEM' => $blueprint['order'],
            'ID_EIXO' => $family['axis'],
            'ID_FAMILIA' => $blueprint['family_id'],
            'ID_PAI_FAMILIA' => null,
            'DS_FAMILIA' => $family['name'],
            'ID_PAI_INDICADOR' => $blueprint['parent_id'],
            'ID_INDICADOR' => $blueprint['id'],
            'DS_INDICADOR' => $blueprint['name'],
            'ID_METRICA' => $metricIdMap[$metricType] ?? 1,
            'DS_METRICA' => $metricType,
            'ID_PERIODICIDADE' => $periodicityId,
            'DS_PERIODICIDADE' => $periodLabel,
            'LABEL' => $blueprint['name'],
            'ITEM_AB' => $blueprint['short_name'],
            'NIVEL' => $blueprint['level'],
            'DS_NIVEL' => $blueprint['level_name'],
            'COD_AGENCIA' => $unit['agency_code'],
            'DS_AGENCIA' => $unit['agency_name'],
            'COD_REGIONAL' => $unit['regional_code'],
            'DS_REGIONAL' => $unit['regional_name'],
            'COD_DIRETORIA' => $unit['directorate_code'],
            'DS_DIRETORIA' => $unit['directorate_name'],
            'COD_UNIDADE' => $unit['code'],
            'DS_UNIDADE' => $unit['name'],
            'VLR_META' => $meta,
            'VLR_PRODUCAO' => $realizado,
            'ATING_INI' => $atingimento,
            'ATING_FINAL' => $atingimento,
            'PESO_POBJ' => $weight,
            'LIMITADOR_MIN' => 0.00,
            'LIMITADOR_MAX' => 120.00,
            'FLG_POBJ' => 1,
            'REFERENCIA' => $meta,
            'NEC_DIA' => $neededPerDay,
            'ATG_FINAL' => $atingimento,
            'REF_PERC' => round(min(100.0, $atingimento), 2),
            'PESO_FINAL_POBJ' => $weight,
            'PESO_FINAL_PRODUCAO' => $points,
            'PONTOS_POBJ' => $points,
            'PONTOS_PRODUCAO' => $points,
            'ativo_sn' => 1,
            'origem_carga' => $origin,
        ];
    }

    return $rows;
};

$rootIndicators = array_values(array_filter(
    $indicatorBlueprints,
    static function (array $blueprint): bool {
        return (int) $blueprint['level'] === 1;
    }
));

$buildVariableRows = static function () use ($rootIndicators, $units, $anomes, $dataBase): array {
    $rows = [];
    $rowId = 1;

    foreach ($rootIndicators as $indicator) {
        $unit = $units[$indicator['unit']];
        $meta = round((float) $indicator['weight'] * 1000.0, 2);
        $percent = (float) $indicator['meta'] > 0
            ? ((float) $indicator['realizado'] / (float) $indicator['meta']) * 100.0
            : 0.0;
        $realizado = round($meta * min(1.15, max(0.0, $percent / 100.0)), 2);

        $rows[] = [
            'id_variavel' => $rowId++,
            'ANOMES' => $anomes,
            'DATA_BASE' => $dataBase,
            'FUNCIONAL' => $unit['code'],
            'VLR_META' => $meta,
            'VLR_REALIZADO' => $realizado,
            'ativo_sn' => 1,
            'origem_carga' => 'APRIL_ONLY_SEED',
        ];
    }

    return $rows;
};

$buildAnalyticRows = static function () use ($indicatorBlueprints, $families, $units, $anomes): array {
    $rows = [];
    $rowId = 1;

    foreach ($indicatorBlueprints as $indicator) {
        $unit = $units[$indicator['unit']];
        $family = $families[$indicator['family_id']];
        $document = str_pad((string) (91000000000 + $rowId), 11, '0', STR_PAD_LEFT);
        $contractNumber = 'APR-' . str_pad((string) $rowId, 5, '0', STR_PAD_LEFT);
        $transactionDate = sprintf('2026-04-%02d', min(28, 3 + $rowId));

        $rows[] = [
            'id_analitico' => $rowId,
            'AnoMes' => $anomes,
            'ID_Indicador' => $indicator['id'],
            'Agencia' => $unit['agency_code'],
            'Agencia2' => $unit['agency_code'],
            'Conta' => str_pad((string) (700000 + $rowId), 8, '0', STR_PAD_LEFT),
            'Carteira' => $unit['code'],
            'Contrato' => $contractNumber,
            'Vlr_Financiado' => (float) $indicator['realizado'],
            'Realizado' => (float) $indicator['realizado'],
            'Realizado_2' => (float) $indicator['realizado'],
            'CPF_CNPJ' => $document,
            'CPF_CNPJ_FIL' => null,
            'CPF_CNPJ_DIG' => null,
            'Dt_Celeb_Contrato' => $transactionDate,
            'ID_Segmento' => (string) $unit['program_id'],
            'DS_Segmento' => $unit['program_label'],
            'DS_Produto' => $indicator['name'],
            'ID_Posto' => null,
            'Produto_Macro' => $family['name'],
            'Cod_Prod' => (string) $indicator['id'],
            'Cod_Sub' => (int) $indicator['level'] > 1 ? (string) $indicator['parent_id'] : null,
            'Cod_Garantia' => null,
            'Vlr_Orig_Garantia' => null,
            'NrProposta' => 'PROP-' . $contractNumber,
            'Identificador_Producao' => 'APRIL-SEED-' . $indicator['id'],
            'Juncao_Final_Realizado' => $unit['code'],
            'Funcional_Gerente_Conta' => $unit['code'],
            'Gerente_Negocios' => $unit['name'],
            'Juncao_BC' => $unit['agency_code'],
            'Gerente_Gestao' => $unit['manager_name'],
            'Funcional_Assistente' => null,
            'ID_posto_principal' => null,
            'ID_Tipo_Encarteiramento' => null,
            'DiretoriaMacro' => (int) $unit['directorate_code'],
            'Juncao_DR' => $unit['directorate_code'],
            'Juncao_GR' => $unit['regional_code'],
            'Juncao_Final_Classic' => $unit['code'],
            'Juncao_AG_PA' => $unit['agency_code'],
            'Juncao_GR_PA' => $unit['regional_code'],
            'Juncao_DR_PA' => $unit['directorate_code'],
            'Funcional_GA' => $unit['manager_functional'],
            'Assessor_GR' => $unit['regional_name'],
            'Assessor_DR' => $unit['directorate_name'],
            'Juncao_Assistente_PA' => null,
            'FlagDesconsiderarProducao' => 0,
            'ativo_sn' => 1,
            'origem_carga' => 'APRIL_ONLY_SEED',
        ];

        $rowId++;
    }

    return $rows;
};

$buildInsightRows = static function () use (
    $rootIndicators,
    $units,
    $formatPercent,
    $formatMetricValue,
    $anomes
): array {
    $groups = [];
    $rows = [];
    $rowId = 1;
    $views = ['MENSAL', 'ACUMULADO', 'SEMESTRAL'];

    $addToGroup = static function (array &$bucket, string $level, string $key, array $row): void {
        if (!isset($bucket[$level])) {
            $bucket[$level] = [];
        }

        if (!isset($bucket[$level][$key])) {
            $bucket[$level][$key] = [];
        }

        $bucket[$level][$key][] = $row;
    };

    foreach ($rootIndicators as $indicator) {
        $unit = $units[$indicator['unit']];
        $percent = (float) $indicator['meta'] > 0
            ? round(((float) $indicator['realizado'] / (float) $indicator['meta']) * 100.0, 2)
            : 0.0;
        $row = array_merge($indicator, [
            'program_id' => (string) $unit['program_id'],
            'directorate_code' => $unit['directorate_code'],
            'regional_code' => $unit['regional_code'],
            'agency_code' => $unit['agency_code'],
            'manager_functional' => $unit['manager_functional'],
            'unit_code' => $unit['code'],
            'percent' => $percent,
        ]);

        $addToGroup($groups, 'GLOBAL', 'GLOBAL', $row);
        $addToGroup($groups, 'SEGMENTO', (string) $unit['program_id'], $row);
        $addToGroup($groups, 'DIRETORIA', $unit['directorate_code'], $row);
        $addToGroup($groups, 'REGIONAL', $unit['regional_code'], $row);
        $addToGroup($groups, 'AGENCIA', $unit['agency_code'], $row);
        $addToGroup($groups, 'GERENTE_GESTAO', $unit['manager_functional'], $row);
        $addToGroup($groups, 'GERENTE', $unit['code'], $row);
    }

    foreach ($views as $view) {
        foreach ($groups as $scopeLevel => $scopeRows) {
            foreach ($scopeRows as $scopeKey => $items) {
                usort($items, static function (array $left, array $right): int {
                    if ((float) $left['percent'] !== (float) $right['percent']) {
                        return ((float) $right['percent']) <=> ((float) $left['percent']);
                    }

                    return ((int) $left['order']) <=> ((int) $right['order']);
                });

                $best = $items[0];
                $worst = $items[count($items) - 1];
                $bestPercent = (float) $best['percent'];
                $worstPercent = (float) $worst['percent'];
                $bestMetric = strtoupper(trim((string) $best['metric']));
                $worstMetric = strtoupper(trim((string) $worst['metric']));

                $rows[] = [
                    'id_exec_insight' => $rowId++,
                    'ANOMES' => $anomes,
                    'VISAO' => $view,
                    'SCOPE_LEVEL' => $scopeLevel,
                    'SCOPE_KEY' => $scopeKey,
                    'POLARIDADE' => 'POSITIVO',
                    'ORDEM' => 1,
                    'TIPO_INSIGHT' => 'MELHOR_DESTAQUE_ATUAL',
                    'TITULO' => $best['name'] . ' e o melhor destaque do recorte',
                    'TEXTO' => sprintf(
                        'Hoje este recorte entrega %s de atingimento, com realizado de %s sobre meta de %s.',
                        $formatPercent($bestPercent),
                        $formatMetricValue((float) $best['realizado'], $bestMetric),
                        $formatMetricValue((float) $best['meta'], $bestMetric)
                    ),
                    'DESTAQUE' => $formatPercent($bestPercent),
                    'ITEM_LABEL' => $best['name'],
                    'ativo_sn' => 1,
                ];

                $negativeTitle = $worstPercent >= 100.0
                    ? $worst['name'] . ' e o menor atingimento relativo do recorte'
                    : $worst['name'] . ' e o principal ponto de atencao';
                $negativeText = $worstPercent >= 100.0
                    ? sprintf(
                        'Mesmo acima da meta, ele tem o menor atingimento relativo do recorte, com %s sobre a meta atual.',
                        $formatPercent($worstPercent)
                    )
                    : sprintf(
                        'Neste recorte ele esta com %s de atingimento, com realizado de %s sobre meta de %s.',
                        $formatPercent($worstPercent),
                        $formatMetricValue((float) $worst['realizado'], $worstMetric),
                        $formatMetricValue((float) $worst['meta'], $worstMetric)
                    );

                $rows[] = [
                    'id_exec_insight' => $rowId++,
                    'ANOMES' => $anomes,
                    'VISAO' => $view,
                    'SCOPE_LEVEL' => $scopeLevel,
                    'SCOPE_KEY' => $scopeKey,
                    'POLARIDADE' => 'NEGATIVO',
                    'ORDEM' => 1,
                    'TIPO_INSIGHT' => 'PONTO_DE_ATENCAO',
                    'TITULO' => $negativeTitle,
                    'TEXTO' => $negativeText,
                    'DESTAQUE' => $formatPercent($worstPercent),
                    'ITEM_LABEL' => $worst['name'],
                    'ativo_sn' => 1,
                ];
            }
        }
    }

    return $rows;
};

$monthlyRows = $buildSnapshotRows('MENSAL', 1, 'APRIL_ONLY_SEED_MENSAL');
$accumulatedRows = $buildSnapshotRows('ACUMULADO', 2, 'APRIL_ONLY_SEED_ACUMULADO');
$semestralRows = $buildSnapshotRows('SEMESTRAL', 3, 'APRIL_ONLY_SEED_SEMESTRAL');
$analyticRows = $buildAnalyticRows();
$variableRows = $buildVariableRows();
$insightRows = $buildInsightRows();

try {
    $connection->beginTransaction();

    $connection->exec("DELETE FROM `f_produtividade_mensal_202604`");
    $connection->exec("DELETE FROM `f_acumulado_202604`");
    $connection->exec("DELETE FROM `f_produtividade_semestral_202604`");
    $connection->exec("DELETE FROM `f_analitico_202604`");
    $connection->exec("DELETE FROM `f_variavel`");
    $connection->exec("DELETE FROM `f_exec_insights`");
    $connection->exec("DELETE FROM `dPeriodoApuracao` WHERE `id_periodo` <> '202604'");

    if ($tableExists($connection, 'dPrograma')) {
        $statement = $connection->prepare(
            'UPDATE `dPrograma`
             SET `segmento` = :segmento,
                 `desc_programa` = :descricao,
                 `ativo_sn` = 1
             WHERE `id_programa` = :id_programa'
        );
        $statement->execute([
            'segmento' => 'CAPTACAO DIGITAL',
            'descricao' => 'Captacao Digital Prime',
            'id_programa' => 18,
        ]);
        $statement->execute([
            'segmento' => 'RELACIONAMENTO PRIME',
            'descricao' => 'Relacionamento Prime Digital',
            'id_programa' => 22,
        ]);
    }

    $periodStatement = $connection->prepare(
        'INSERT INTO `dPeriodoApuracao`
            (`id_periodo`, `descricao_periodo`, `dt_inicio_periodo`, `dt_fim_periodo`, `ativo_sn`, `origem_carga`)
         VALUES
            (:id_periodo, :descricao, :dt_inicio, :dt_fim, 1, :origem)
         ON DUPLICATE KEY UPDATE
            `descricao_periodo` = VALUES(`descricao_periodo`),
            `dt_inicio_periodo` = VALUES(`dt_inicio_periodo`),
            `dt_fim_periodo` = VALUES(`dt_fim_periodo`),
            `ativo_sn` = VALUES(`ativo_sn`),
            `origem_carga` = VALUES(`origem_carga`)'
    );
    $periodStatement->execute([
        'id_periodo' => '202604',
        'descricao' => 'Abril/2026',
        'dt_inicio' => '2026-04-01',
        'dt_fim' => '2026-04-30',
        'origem' => 'APRIL_ONLY_SEED',
    ]);

    $insertRows($connection, 'f_produtividade_mensal_202604', $monthlyRows);
    $insertRows($connection, 'f_acumulado_202604', $accumulatedRows);
    $insertRows($connection, 'f_produtividade_semestral_202604', $semestralRows);
    $insertRows($connection, 'f_analitico_202604', $analyticRows);
    $insertRows($connection, 'f_variavel', $variableRows);
    $insertRows($connection, 'f_exec_insights', $insightRows);

    $connection->commit();
} catch (Throwable $exception) {
    if ($connection->inTransaction()) {
        $connection->rollBack();
    }

    throw $exception;
}

echo "April-only seed applied\n";
echo 'Rows mensal: ' . count($monthlyRows) . "\n";
echo 'Rows acumulado: ' . count($accumulatedRows) . "\n";
echo 'Rows semestral: ' . count($semestralRows) . "\n";
echo 'Rows analitico: ' . count($analyticRows) . "\n";
echo 'Rows variavel: ' . count($variableRows) . "\n";
echo 'Rows insights: ' . count($insightRows) . "\n";
