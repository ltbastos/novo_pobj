DROP PROCEDURE IF EXISTS sp_pobj_list_semestral_family_options;
DROP PROCEDURE IF EXISTS sp_pobj_list_semestral_indicator_options;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_semestral_family_options(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT('fGestaoGerente' USING utf8) COLLATE utf8_unicode_ci
    ) INTO v_has_management_table;

    IF v_has_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS value, CAST(NULL AS CHAR) AS label FROM DUAL WHERE 1 = 0;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT CAST(f.`ID_FAMILIA` AS CHAR) AS value, COALESCE(f.`DS_FAMILIA`, CAST(f.`ID_FAMILIA` AS CHAR)) AS label, ',
            'MIN(COALESCE(f.`ORDEM`, 999999)) AS ordem ',
            'FROM ', v_table_sql, ' f ',
            'WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes),
            ' AND COALESCE(f.`NIVEL`, 0) = 0 AND UPPER(TRIM(COALESCE(f.`DS_NIVEL`, ''''))) = ''FAMILIA'''
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_diretoria), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_regional), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_agencia), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci AND gg.funcional_gerente_gestao COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;

        SET v_sql = CONCAT(v_sql, ' GROUP BY f.`ID_FAMILIA`, COALESCE(f.`DS_FAMILIA`, CAST(f.`ID_FAMILIA` AS CHAR)) ORDER BY ordem, label');
        SET @sp_pobj_list_semestral_family_options_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_semestral_family_options_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

CREATE PROCEDURE sp_pobj_list_semestral_indicator_options(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT('fGestaoGerente' USING utf8) COLLATE utf8_unicode_ci
    ) INTO v_has_management_table;

    IF v_has_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS value, CAST(NULL AS CHAR) AS label FROM DUAL WHERE 1 = 0;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT CAST(f.`ID_INDICADOR` AS CHAR) AS value, COALESCE(f.`DS_INDICADOR`, CAST(f.`ID_INDICADOR` AS CHAR)) AS label, ',
            'MIN(COALESCE(f.`ORDEM`, 999999)) AS ordem ',
            'FROM ', v_table_sql, ' f ',
            'WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes),
            ' AND COALESCE(f.`NIVEL`, 0) = 1 AND UPPER(TRIM(COALESCE(f.`DS_NIVEL`, ''''))) = ''PRODUTO''',
            ' AND EXISTS (',
            'SELECT 1 FROM ', v_table_sql, ' ff ',
            'WHERE ff.ativo_sn = 1 AND ff.`ANOMES` = ', QUOTE(p_anomes),
            ' AND ff.`ID_FAMILIA` = f.`ID_FAMILIA`',
            ' AND COALESCE(ff.`NIVEL`, 0) = 0 AND UPPER(TRIM(COALESCE(ff.`DS_NIVEL`, ''''))) = ''FAMILIA''',
            ')'
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_diretoria), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_regional), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_agencia), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci AND gg.funcional_gerente_gestao COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_familia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_FAMILIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_familia), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;

        SET v_sql = CONCAT(v_sql, ' GROUP BY f.`ID_INDICADOR`, COALESCE(f.`DS_INDICADOR`, CAST(f.`ID_INDICADOR` AS CHAR)) ORDER BY ordem, label');
        SET @sp_pobj_list_semestral_indicator_options_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_semestral_indicator_options_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;
