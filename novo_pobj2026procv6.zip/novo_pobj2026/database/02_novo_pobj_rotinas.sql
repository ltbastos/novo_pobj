﻿-- Rotinas do banco novo_pobj
-- Execute depois do arquivo 01_novo_pobj_banco_completo.sql
CREATE DATABASE IF NOT EXISTS `novo_pobj` CHARACTER SET utf8 COLLATE utf8_unicode_ci;
ALTER DATABASE `novo_pobj` CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `novo_pobj`;
SET NAMES utf8;

DROP PROCEDURE IF EXISTS sp_profile_list_profiles;
DROP PROCEDURE IF EXISTS sp_profile_exists;
DROP PROCEDURE IF EXISTS sp_profile_get_profile;
DROP PROCEDURE IF EXISTS sp_profile_get_junctions;
DROP PROCEDURE IF EXISTS sp_profile_resolve_gr_from_agencies;
DROP PROCEDURE IF EXISTS sp_profile_resolve_dr_from_regionals;
DROP PROCEDURE IF EXISTS sp_profile_resolve_dr_from_agencies;
DROP PROCEDURE IF EXISTS sp_util_table_exists;
DROP PROCEDURE IF EXISTS sp_util_column_exists;
DROP PROCEDURE IF EXISTS sp_prime_matches_mesu_field;
DROP PROCEDURE IF EXISTS sp_prime_matches_functional;

DELIMITER $$

CREATE PROCEDURE sp_profile_list_profiles()
BEGIN
    SELECT
        h.funcional,
        h.nome,
        h.email,
        h.nivel,
        COALESCE(m.juncao, '') AS juncao_principal,
        COALESCE(m.tipo_juncao, '') AS tipo_juncao
    FROM dHierarquia h
    LEFT JOIN fMultiJuncao m
        ON m.funcional = h.funcional
       AND m.ativo_sn = 1
       AND m.principal_sn = 1
    WHERE h.ativo_sn = 1
    ORDER BY
        CASE h.nivel
            WHEN 'DP' THEN 1
            WHEN 'SG' THEN 2
            WHEN 'DR' THEN 3
            WHEN 'GE' THEN 4
            WHEN 'GR' THEN 5
            WHEN 'AG' THEN 6
            WHEN 'GG' THEN 7
            WHEN 'TL' THEN 8
            WHEN 'GC' THEN 9
            WHEN 'PA' THEN 10
            WHEN 'AS' THEN 11
            ELSE 99
        END,
        h.nome;
END$$

CREATE PROCEDURE sp_profile_exists(IN p_functional VARCHAR(32))
BEGIN
    SELECT EXISTS(
        SELECT 1
        FROM dHierarquia
                WHERE funcional COLLATE utf8_unicode_ci = CONVERT(p_functional USING utf8) COLLATE utf8_unicode_ci
          AND ativo_sn = 1
    ) AS profile_exists;
END$$

CREATE PROCEDURE sp_profile_get_profile(IN p_functional VARCHAR(32))
BEGIN
    SELECT funcional, nome, email, cargo, nivel
    FROM dHierarquia
        WHERE funcional COLLATE utf8_unicode_ci = CONVERT(p_functional USING utf8) COLLATE utf8_unicode_ci
      AND ativo_sn = 1
    LIMIT 1;
END$$

CREATE PROCEDURE sp_profile_get_junctions(IN p_functional VARCHAR(32))
BEGIN
    SELECT funcional, juncao, tipo_juncao, principal_sn, ativo_sn
    FROM fMultiJuncao
        WHERE funcional COLLATE utf8_unicode_ci = CONVERT(p_functional USING utf8) COLLATE utf8_unicode_ci
      AND ativo_sn = 1
    ORDER BY principal_sn DESC, juncao;
END$$

CREATE PROCEDURE sp_profile_resolve_gr_from_agencies(IN p_agencies_csv TEXT)
BEGIN
    SELECT DISTINCT juncao_gr
    FROM dMesu
    WHERE ativo_sn = 1
      AND COALESCE(p_agencies_csv, '') <> ''
            AND FIND_IN_SET(juncao_ag COLLATE utf8_unicode_ci, CONVERT(p_agencies_csv USING utf8) COLLATE utf8_unicode_ci) > 0
    ORDER BY juncao_gr;
END$$

CREATE PROCEDURE sp_profile_resolve_dr_from_regionals(IN p_regionals_csv TEXT)
BEGIN
    SELECT DISTINCT juncao_dr
    FROM dMesu
    WHERE ativo_sn = 1
      AND COALESCE(p_regionals_csv, '') <> ''
            AND FIND_IN_SET(juncao_gr COLLATE utf8_unicode_ci, CONVERT(p_regionals_csv USING utf8) COLLATE utf8_unicode_ci) > 0
    ORDER BY juncao_dr;
END$$

CREATE PROCEDURE sp_profile_resolve_dr_from_agencies(IN p_agencies_csv TEXT)
BEGIN
    SELECT DISTINCT juncao_dr
    FROM dMesu
    WHERE ativo_sn = 1
      AND COALESCE(p_agencies_csv, '') <> ''
            AND FIND_IN_SET(juncao_ag COLLATE utf8_unicode_ci, CONVERT(p_agencies_csv USING utf8) COLLATE utf8_unicode_ci) > 0
    ORDER BY juncao_dr;
END$$

CREATE PROCEDURE sp_util_table_exists(IN p_table_name VARCHAR(64))
BEGIN
    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
    ) AS table_exists;
END$$

CREATE PROCEDURE sp_util_column_exists(IN p_table_name VARCHAR(64), IN p_column_name VARCHAR(64))
BEGIN
    SELECT EXISTS(
        SELECT 1
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
          AND COLUMN_NAME COLLATE utf8_unicode_ci = CONVERT(p_column_name USING utf8) COLLATE utf8_unicode_ci
    ) AS column_exists;
END$$

CREATE PROCEDURE sp_prime_matches_mesu_field(IN p_scope_code VARCHAR(2), IN p_values_csv TEXT)
BEGIN
    DECLARE v_has_subsegment TINYINT DEFAULT 0;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'dMesu'
          AND COLUMN_NAME = 'subsegmento'
    ) INTO v_has_subsegment;

    IF COALESCE(TRIM(p_values_csv), '') = '' THEN
        SELECT 0 AS matches_prime;
    ELSEIF p_scope_code = 'AG' THEN
        IF v_has_subsegment = 1 THEN
            SELECT EXISTS(
                SELECT 1
                FROM dMesu m
                WHERE m.ativo_sn = 1
                  AND FIND_IN_SET(m.juncao_ag COLLATE utf8_unicode_ci, CONVERT(p_values_csv USING utf8) COLLATE utf8_unicode_ci) > 0
                  AND LOWER(COALESCE(m.subsegmento, '')) = 'prime'
            ) AS matches_prime;
        ELSE
            SELECT EXISTS(
                SELECT 1
                FROM dMesu m
                WHERE m.ativo_sn = 1
                  AND FIND_IN_SET(m.juncao_ag COLLATE utf8_unicode_ci, CONVERT(p_values_csv USING utf8) COLLATE utf8_unicode_ci) > 0
                  AND (
                        LOWER(COALESCE(m.nome_diretoria, '')) LIKE '%norte%'
                        OR LOWER(COALESCE(m.nome_regional, '')) LIKE '%norte%'
                        OR LOWER(COALESCE(m.nome_agencia, '')) LIKE '%norte%'
                  )
            ) AS matches_prime;
        END IF;
    ELSEIF p_scope_code = 'GR' THEN
        IF v_has_subsegment = 1 THEN
            SELECT EXISTS(
                SELECT 1
                FROM dMesu m
                WHERE m.ativo_sn = 1
                  AND FIND_IN_SET(m.juncao_gr COLLATE utf8_unicode_ci, CONVERT(p_values_csv USING utf8) COLLATE utf8_unicode_ci) > 0
                  AND LOWER(COALESCE(m.subsegmento, '')) = 'prime'
            ) AS matches_prime;
        ELSE
            SELECT EXISTS(
                SELECT 1
                FROM dMesu m
                WHERE m.ativo_sn = 1
                  AND FIND_IN_SET(m.juncao_gr COLLATE utf8_unicode_ci, CONVERT(p_values_csv USING utf8) COLLATE utf8_unicode_ci) > 0
                  AND (
                        LOWER(COALESCE(m.nome_diretoria, '')) LIKE '%norte%'
                        OR LOWER(COALESCE(m.nome_regional, '')) LIKE '%norte%'
                        OR LOWER(COALESCE(m.nome_agencia, '')) LIKE '%norte%'
                  )
            ) AS matches_prime;
        END IF;
    ELSEIF p_scope_code = 'DR' THEN
        IF v_has_subsegment = 1 THEN
            SELECT EXISTS(
                SELECT 1
                FROM dMesu m
                WHERE m.ativo_sn = 1
                  AND FIND_IN_SET(m.juncao_dr COLLATE utf8_unicode_ci, CONVERT(p_values_csv USING utf8) COLLATE utf8_unicode_ci) > 0
                  AND LOWER(COALESCE(m.subsegmento, '')) = 'prime'
            ) AS matches_prime;
        ELSE
            SELECT EXISTS(
                SELECT 1
                FROM dMesu m
                WHERE m.ativo_sn = 1
                  AND FIND_IN_SET(m.juncao_dr COLLATE utf8_unicode_ci, CONVERT(p_values_csv USING utf8) COLLATE utf8_unicode_ci) > 0
                  AND (
                        LOWER(COALESCE(m.nome_diretoria, '')) LIKE '%norte%'
                        OR LOWER(COALESCE(m.nome_regional, '')) LIKE '%norte%'
                        OR LOWER(COALESCE(m.nome_agencia, '')) LIKE '%norte%'
                  )
            ) AS matches_prime;
        END IF;
    ELSE
        SELECT 0 AS matches_prime;
    END IF;
END$$

CREATE PROCEDURE sp_prime_matches_functional(IN p_functional VARCHAR(32))
BEGIN
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_has_subsegment TINYINT DEFAULT 0;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'dMesu'
          AND COLUMN_NAME = 'subsegmento'
    ) INTO v_has_subsegment;

    IF COALESCE(TRIM(p_functional), '') = '' THEN
        SELECT 0 AS matches_prime;
    ELSEIF v_has_management_table = 1 AND EXISTS(
        SELECT 1
        FROM fGestaoGerente gg
        INNER JOIN fMultiJuncao j
            ON j.funcional = gg.funcional_gerente
           AND j.ativo_sn = 1
        INNER JOIN dMesu m
            ON m.ativo_sn = 1
           AND (
                (j.tipo_juncao = 'AG' AND m.juncao_ag = j.juncao)
                OR (j.tipo_juncao = 'GR' AND m.juncao_gr = j.juncao)
                OR (j.tipo_juncao = 'DR' AND m.juncao_dr = j.juncao)
           )
        WHERE gg.ativo_sn = 1
            AND gg.funcional_gerente_gestao COLLATE utf8_unicode_ci = CONVERT(p_functional USING utf8) COLLATE utf8_unicode_ci
          AND (
                (v_has_subsegment = 1 AND LOWER(COALESCE(m.subsegmento, '')) = 'prime')
                OR (
                    v_has_subsegment = 0
                    AND (
                        LOWER(COALESCE(m.nome_diretoria, '')) LIKE '%norte%'
                        OR LOWER(COALESCE(m.nome_regional, '')) LIKE '%norte%'
                        OR LOWER(COALESCE(m.nome_agencia, '')) LIKE '%norte%'
                    )
                )
          )
    ) THEN
        SELECT 1 AS matches_prime;
    ELSE
        SELECT EXISTS(
            SELECT 1
            FROM fMultiJuncao j
            INNER JOIN dMesu m
                ON m.ativo_sn = 1
               AND (
                    (j.tipo_juncao = 'AG' AND m.juncao_ag = j.juncao)
                    OR (j.tipo_juncao = 'GR' AND m.juncao_gr = j.juncao)
                    OR (j.tipo_juncao = 'DR' AND m.juncao_dr = j.juncao)
               )
            WHERE j.ativo_sn = 1
              AND j.funcional COLLATE utf8_unicode_ci = CONVERT(p_functional USING utf8) COLLATE utf8_unicode_ci
              AND (
                    (v_has_subsegment = 1 AND LOWER(COALESCE(m.subsegmento, '')) = 'prime')
                    OR (
                        v_has_subsegment = 0
                        AND (
                            LOWER(COALESCE(m.nome_diretoria, '')) LIKE '%norte%'
                            OR LOWER(COALESCE(m.nome_regional, '')) LIKE '%norte%'
                            OR LOWER(COALESCE(m.nome_agencia, '')) LIKE '%norte%'
                        )
                    )
              )
        ) AS matches_prime;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_count_analytic_detail_rows;

DELIMITER $$

CREATE PROCEDURE sp_pobj_count_analytic_detail_rows(
    IN p_table_name VARCHAR(64),
    IN p_snapshot_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_profile_level VARCHAR(16),
    IN p_profile_functional VARCHAR(32),
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_snapshot_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_snapshot_sql TEXT;
    DECLARE v_sql LONGTEXT;
    DECLARE v_manager_field VARCHAR(128) DEFAULT 'CAST(a.`Funcional_Gerente_Conta` AS CHAR) COLLATE utf8_unicode_ci';

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    IF p_snapshot_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_snapshot_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_snapshot_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_table = 0 OR v_has_snapshot_table = 0 THEN
        SELECT 0 AS total_rows;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_snapshot_sql = CONCAT('`', REPLACE(p_snapshot_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT COUNT(*) AS total_rows ',
            'FROM ', v_table_sql, ' a ',
            'LEFT JOIN (',
            'SELECT CAST(pm.`ID_INDICADOR` AS CHAR) AS id_indicador, ',
            'MAX(CAST(pm.`ID_FAMILIA` AS CHAR)) AS id_familia ',
            'FROM ', v_snapshot_sql, ' pm ',
            'WHERE pm.ativo_sn = 1 ',
            'GROUP BY pm.`ID_INDICADOR`',
            ') im ON im.id_indicador = CAST(a.`ID_Indicador` AS CHAR) ',
            'WHERE a.ativo_sn = 1 ',
            'AND a.`AnoMes` = ', QUOTE(p_anomes)
        );

        IF UPPER(COALESCE(p_profile_level, '')) IN ('GC', 'PA', 'AS') AND COALESCE(TRIM(p_profile_functional), '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF UPPER(COALESCE(p_profile_level, '')) IN ('GG', 'TL') AND COALESCE(TRIM(p_profile_functional), '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (', v_manager_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = ', v_manager_field, ' AND gg.funcional_gerente_gestao = ', QUOTE(p_profile_functional), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(a.`Agencia` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(a.`Juncao_DR` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(a.`Juncao_GR` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(a.`Agencia` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND EXISTS (SELECT 1 FROM ', v_snapshot_sql, ' pm',
                ' WHERE pm.ativo_sn = 1',
                ' AND pm.`ANOMES` = ', QUOTE(p_anomes),
                ' AND CAST(pm.`ID_INDICADOR` AS CHAR) = CAST(a.`ID_Indicador` AS CHAR)',
                ' AND CAST(pm.`COD_AGENCIA` AS CHAR) = CAST(a.`Agencia` AS CHAR)',
                ' AND CAST(pm.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = ', v_manager_field,
                ' AND CAST(pm.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci)'
            );
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`Juncao_DR` AS CHAR) = ', QUOTE(p_diretoria));
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`Juncao_GR` AS CHAR) = ', QUOTE(p_regional));
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`Agencia` AS CHAR) = ', QUOTE(p_agencia));
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (', v_manager_field, ' = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = ', v_manager_field, ' AND gg.funcional_gerente_gestao = ', QUOTE(p_gerente_gestao), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_gerente), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_familia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(im.`id_familia` AS CHAR) = ', QUOTE(p_familia));
        END IF;
        IF COALESCE(p_indicador, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`ID_Indicador` AS CHAR) = ', QUOTE(p_indicador));
        END IF;

        SET @sp_pobj_count_analytic_detail_rows_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_count_analytic_detail_rows_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_count_analytic_detail_rows_by_indicator;
DROP PROCEDURE IF EXISTS sp_pobj_list_analytic_detail_rows;

DELIMITER $$

CREATE PROCEDURE sp_pobj_count_analytic_detail_rows_by_indicator(
    IN p_table_name VARCHAR(64),
    IN p_snapshot_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_profile_level VARCHAR(16),
    IN p_profile_functional VARCHAR(32),
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_snapshot_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_snapshot_sql TEXT;
    DECLARE v_sql LONGTEXT;
    DECLARE v_manager_field VARCHAR(128) DEFAULT 'CAST(a.`Funcional_Gerente_Conta` AS CHAR) COLLATE utf8_unicode_ci';

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND CONVERT(TABLE_NAME USING utf8mb4) COLLATE utf8mb4_unicode_ci = CONVERT(p_table_name USING utf8mb4) COLLATE utf8mb4_unicode_ci
        ) INTO v_has_table;
    END IF;

    IF p_snapshot_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_snapshot_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_snapshot_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND CONVERT(TABLE_NAME USING utf8mb4) COLLATE utf8mb4_unicode_ci = CONVERT('fGestaoGerente' USING utf8mb4) COLLATE utf8mb4_unicode_ci
    ) INTO v_has_management_table;

    IF v_has_table = 0 OR v_has_snapshot_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS id_indicador, 0 AS total_rows FROM DUAL WHERE 1 = 0;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_snapshot_sql = CONCAT('`', REPLACE(p_snapshot_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT CAST(a.`ID_Indicador` AS CHAR) AS id_indicador, COUNT(*) AS total_rows ',
            'FROM ', v_table_sql, ' a ',
            'LEFT JOIN (',
            'SELECT CAST(pm.`ID_INDICADOR` AS CHAR) AS id_indicador, ',
            'MAX(CAST(pm.`ID_FAMILIA` AS CHAR)) AS id_familia ',
            'FROM ', v_snapshot_sql, ' pm ',
            'WHERE pm.ativo_sn = 1 ',
            'GROUP BY pm.`ID_INDICADOR`',
            ') im ON im.id_indicador = CAST(a.`ID_Indicador` AS CHAR) ',
            'WHERE a.ativo_sn = 1 ',
            'AND a.`AnoMes` = ', QUOTE(p_anomes)
        );

        IF UPPER(COALESCE(p_profile_level, '')) IN ('GC', 'PA', 'AS') AND COALESCE(TRIM(p_profile_functional), '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF UPPER(COALESCE(p_profile_level, '')) IN ('GG', 'TL') AND COALESCE(TRIM(p_profile_functional), '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (', v_manager_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = ', v_manager_field, ' AND gg.funcional_gerente_gestao = ', QUOTE(p_profile_functional), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(a.`Agencia` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(a.`Juncao_DR` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(a.`Juncao_GR` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(a.`Agencia` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND EXISTS (SELECT 1 FROM ', v_snapshot_sql, ' pm',
                ' WHERE pm.ativo_sn = 1',
                ' AND pm.`ANOMES` = ', QUOTE(p_anomes),
                ' AND CAST(pm.`ID_INDICADOR` AS CHAR) = CAST(a.`ID_Indicador` AS CHAR)',
                ' AND CAST(pm.`COD_AGENCIA` AS CHAR) = CAST(a.`Agencia` AS CHAR)',
                ' AND CAST(pm.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = ', v_manager_field,
                ' AND CAST(pm.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci)'
            );
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`Juncao_DR` AS CHAR) = ', QUOTE(p_diretoria));
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`Juncao_GR` AS CHAR) = ', QUOTE(p_regional));
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`Agencia` AS CHAR) = ', QUOTE(p_agencia));
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (', v_manager_field, ' = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = ', v_manager_field, ' AND gg.funcional_gerente_gestao = ', QUOTE(p_gerente_gestao), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_gerente), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_familia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(im.`id_familia` AS CHAR) = ', QUOTE(p_familia));
        END IF;
        IF COALESCE(p_indicador, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`ID_Indicador` AS CHAR) = ', QUOTE(p_indicador));
        END IF;

        SET v_sql = CONCAT(v_sql, ' GROUP BY CAST(a.`ID_Indicador` AS CHAR)');

        SET @sp_pobj_count_analytic_detail_rows_by_indicator_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_count_analytic_detail_rows_by_indicator_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

CREATE PROCEDURE sp_pobj_list_analytic_detail_rows(
    IN p_table_name VARCHAR(64),
    IN p_snapshot_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_limit_rows INT,
    IN p_offset_rows INT,
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_profile_level VARCHAR(16),
    IN p_profile_functional VARCHAR(32),
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_snapshot_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_snapshot_sql TEXT;
    DECLARE v_join_management_sql TEXT DEFAULT '';
    DECLARE v_select_management_sql TEXT DEFAULT '';
    DECLARE v_sql LONGTEXT;
    DECLARE v_manager_field VARCHAR(128) DEFAULT 'CAST(a.`Funcional_Gerente_Conta` AS CHAR) COLLATE utf8_unicode_ci';
    DECLARE v_limit_rows INT DEFAULT 1;
    DECLARE v_offset_rows INT DEFAULT 0;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    IF p_snapshot_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_snapshot_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_snapshot_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_table = 0 OR v_has_snapshot_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS id_transacao FROM DUAL WHERE 1 = 0;
    ELSE
        SET v_limit_rows = GREATEST(1, COALESCE(p_limit_rows, 1));
        SET v_offset_rows = GREATEST(0, COALESCE(p_offset_rows, 0));
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_snapshot_sql = CONCAT('`', REPLACE(p_snapshot_table_name, '`', '``'), '`');

        IF v_has_management_table = 1 THEN
            SET v_join_management_sql = ' LEFT JOIN fGestaoGerente gg ON gg.ativo_sn = 1 AND CAST(gg.`funcional_gerente` AS CHAR) COLLATE utf8_unicode_ci = CAST(a.`Funcional_Gerente_Conta` AS CHAR) COLLATE utf8_unicode_ci LEFT JOIN dHierarquia hgg ON hgg.ativo_sn = 1 AND CAST(hgg.`funcional` AS CHAR) COLLATE utf8_unicode_ci = CAST(gg.`funcional_gerente_gestao` AS CHAR) COLLATE utf8_unicode_ci ';
            SET v_select_management_sql = 'CAST(gg.`funcional_gerente_gestao` AS CHAR) AS funcional_gerente_gestao, COALESCE(NULLIF(TRIM(a.`Gerente_Gestao`), ''''), NULLIF(TRIM(hgg.`nome`), ''''), CAST(gg.`funcional_gerente_gestao` AS CHAR)) AS nome_gerente_gestao, ';
        ELSE
            SET v_select_management_sql = 'CAST(NULL AS CHAR) AS funcional_gerente_gestao, COALESCE(NULLIF(TRIM(a.`Gerente_Gestao`), ''''), CAST('''' AS CHAR)) AS nome_gerente_gestao, ';
        END IF;

        SET v_sql = CONCAT(
            'SELECT ',
            'a.`id_analitico` AS id_transacao, ',
            'CAST(a.`ID_Indicador` AS CHAR) AS id_indicador, ',
            'CAST('''' AS CHAR) AS id_subindicador, ',
            'CAST(a.`Funcional_Gerente_Conta` AS CHAR) AS funcional, ',
            'COALESCE(NULLIF(TRIM(a.`Gerente_Negocios`), ''''), NULLIF(TRIM(hg.`nome`), ''''), CAST(a.`Funcional_Gerente_Conta` AS CHAR)) AS nome_gerente, ',
            v_select_management_sql,
            'CAST(a.`Agencia` AS CHAR) AS juncao_ag, ',
            'COALESCE(NULLIF(TRIM(dm.`nome_agencia`), ''''), CAST(a.`Agencia` AS CHAR)) AS nome_agencia, ',
            'CAST(a.`Juncao_GR` AS CHAR) AS juncao_gr, ',
            'COALESCE(NULLIF(TRIM(dm.`nome_regional`), ''''), CAST(a.`Juncao_GR` AS CHAR)) AS nome_regional, ',
            'CAST(a.`Juncao_DR` AS CHAR) AS juncao_dr, ',
            'COALESCE(NULLIF(TRIM(dm.`nome_diretoria`), ''''), CAST(a.`Juncao_DR` AS CHAR)) AS nome_diretoria, ',
            'COALESCE(NULLIF(TRIM(a.`ID_Segmento`), ''''), NULLIF(TRIM(a.`DS_Segmento`), ''''), '''') AS segmento, ',
            'CAST(a.`Contrato` AS CHAR) AS numero_contrato, ',
            'CAST(a.`Conta` AS CHAR) AS conta, ',
            'a.`Dt_Celeb_Contrato` AS data_transacao, ',
            'COALESCE(NULLIF(TRIM(a.`Produto_Macro`), ''''), ''Sem status'') AS status_transacao, ',
            'COALESCE(NULLIF(TRIM(a.`DS_Produto`), ''''), '''') AS observacao, ',
            'a.`CPF_CNPJ` AS cpf_cnpj, ',
            'a.`CPF_CNPJ_FIL` AS cpf_cnpj_fil, ',
            'a.`CPF_CNPJ_DIG` AS cpf_cnpj_dig, ',
            'COALESCE(NULLIF(TRIM(a.`DS_Produto`), ''''), ''Cliente nao identificado'') AS nome_cliente, ',
            'COALESCE(a.`Realizado`, 0) AS valor_realizado, ',
            'COALESCE(im.`nome_indicador`, CAST(a.`ID_Indicador` AS CHAR)) AS nome_indicador, ',
            'COALESCE(im.`id_familia`, '''') AS id_familia, ',
            'COALESCE(im.`nome_familia`, ''Sem familia'') AS nome_familia, ',
            'COALESCE(im.`ds_metrica`, ''VALOR'') AS ds_metrica ',
            'FROM ', v_table_sql, ' a ',
            'LEFT JOIN dMesu dm ON dm.ativo_sn = 1 AND CAST(dm.`juncao_ag` AS CHAR) = CAST(a.`Agencia` AS CHAR) ',
            'LEFT JOIN dHierarquia hg ON hg.ativo_sn = 1 AND CAST(hg.`funcional` AS CHAR) COLLATE utf8_unicode_ci = CAST(a.`Funcional_Gerente_Conta` AS CHAR) COLLATE utf8_unicode_ci ',
            v_join_management_sql,
            'LEFT JOIN (',
            'SELECT ',
            'CAST(pm.`ID_INDICADOR` AS CHAR) AS id_indicador, ',
            'MAX(COALESCE(pm.`DS_INDICADOR`, CAST(pm.`ID_INDICADOR` AS CHAR))) AS nome_indicador, ',
            'MAX(CAST(pm.`ID_FAMILIA` AS CHAR)) AS id_familia, ',
            'MAX(COALESCE(pm.`DS_FAMILIA`, CAST(pm.`ID_FAMILIA` AS CHAR))) AS nome_familia, ',
            'MAX(pm.`DS_METRICA`) AS ds_metrica ',
            'FROM ', v_snapshot_sql, ' pm ',
            'WHERE pm.ativo_sn = 1 ',
            'GROUP BY pm.`ID_INDICADOR`',
            ') im ON im.id_indicador = CAST(a.`ID_Indicador` AS CHAR) ',
            'WHERE a.ativo_sn = 1 ',
            'AND a.`AnoMes` = ', QUOTE(p_anomes)
        );

        IF UPPER(COALESCE(p_profile_level, '')) IN ('GC', 'PA', 'AS') AND COALESCE(TRIM(p_profile_functional), '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF UPPER(COALESCE(p_profile_level, '')) IN ('GG', 'TL') AND COALESCE(TRIM(p_profile_functional), '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (', v_manager_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = ', v_manager_field, ' AND gg.funcional_gerente_gestao = ', QUOTE(p_profile_functional), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(a.`Agencia` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(a.`Juncao_DR` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(a.`Juncao_GR` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(a.`Agencia` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND EXISTS (SELECT 1 FROM ', v_snapshot_sql, ' pm',
                ' WHERE pm.ativo_sn = 1',
                ' AND pm.`ANOMES` = ', QUOTE(p_anomes),
                ' AND CAST(pm.`ID_INDICADOR` AS CHAR) = CAST(a.`ID_Indicador` AS CHAR)',
                ' AND CAST(pm.`COD_AGENCIA` AS CHAR) = CAST(a.`Agencia` AS CHAR)',
                ' AND CAST(pm.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = ', v_manager_field,
                ' AND CAST(pm.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci)'
            );
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`Juncao_DR` AS CHAR) = ', QUOTE(p_diretoria));
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`Juncao_GR` AS CHAR) = ', QUOTE(p_regional));
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`Agencia` AS CHAR) = ', QUOTE(p_agencia));
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (', v_manager_field, ' = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = ', v_manager_field, ' AND gg.funcional_gerente_gestao = ', QUOTE(p_gerente_gestao), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_gerente), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_familia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(im.`id_familia` AS CHAR) = ', QUOTE(p_familia));
        END IF;
        IF COALESCE(p_indicador, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`ID_Indicador` AS CHAR) = ', QUOTE(p_indicador));
        END IF;

        SET v_sql = CONCAT(v_sql, ' ORDER BY nome_diretoria, nome_regional, nome_agencia, nome_gerente_gestao, nome_gerente, nome_familia, nome_indicador, data_transacao DESC, numero_contrato LIMIT ', v_limit_rows, ' OFFSET ', v_offset_rows);

        SET @sp_pobj_list_analytic_detail_rows_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_analytic_detail_rows_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_annual_performance_totals;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_annual_performance_totals(
    IN p_report_year INT,
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente_gestao_functionals_csv TEXT,
    IN p_gerente_gestao_agencies_csv TEXT,
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_points_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fPontos'
    ) INTO v_has_points_table;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_points_table = 0 THEN
        SELECT CAST(NULL AS UNSIGNED) AS month_number, 0 AS pontos_meta, 0 AS pontos_realizado FROM DUAL WHERE 1 = 0;
    ELSE
        SELECT
            MONTH(p.data_realizado) AS month_number,
            COALESCE(SUM(p.pontos_meta), 0) AS pontos_meta,
            COALESCE(SUM(p.pontos_realizado), 0) AS pontos_realizado
        FROM fPontos p
        WHERE p.ativo_sn = 1
          AND p.data_realizado IS NOT NULL
          AND YEAR(p.data_realizado) = p_report_year
          AND (
                COALESCE(p_scope_code, 'GLOBAL') = 'GLOBAL'
                OR (COALESCE(p_scope_code, 'GLOBAL') = 'SELF' AND CAST(p.funcional AS CHAR) COLLATE utf8_unicode_ci = CONVERT(p_scope_functional USING utf8) COLLATE utf8_unicode_ci)
                OR (COALESCE(p_scope_code, 'GLOBAL') = 'DR' AND FIND_IN_SET(CAST(p.juncao_dr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_scope_allowed_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0)
                OR (COALESCE(p_scope_code, 'GLOBAL') = 'GR' AND FIND_IN_SET(CAST(p.juncao_gr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_scope_allowed_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0)
                OR (COALESCE(p_scope_code, 'GLOBAL') NOT IN ('GLOBAL', 'SELF', 'DR', 'GR') AND FIND_IN_SET(CAST(p.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_scope_allowed_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0)
          )
          AND (COALESCE(p_segmento, '') = '' OR p.segmento = p_segmento)
          AND (COALESCE(p_diretoria, '') = '' OR p.juncao_dr = p_diretoria)
          AND (COALESCE(p_regional, '') = '' OR p.juncao_gr = p_regional)
          AND (COALESCE(p_agencia, '') = '' OR p.juncao_ag = p_agencia)
          AND (
                COALESCE(p_gerente_gestao, '') = ''
                OR (
                    v_has_management_table = 1
                    AND FIND_IN_SET(CAST(p.funcional AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_gerente_gestao_functionals_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0
                )
                OR (
                    v_has_management_table = 0
                    AND FIND_IN_SET(CAST(p.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_gerente_gestao_agencies_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0
                )
          )
          AND (COALESCE(p_gerente, '') = '' OR p.funcional = p_gerente)
          AND (
                COALESCE(p_familia, '') = ''
                OR EXISTS (
                    SELECT 1
                    FROM dIndicador i
                    WHERE i.id_indicador = p.id_indicador
                      AND i.id_familia = p_familia
                      AND i.ativo_sn = 1
                )
          )
          AND (COALESCE(p_indicador, '') = '' OR p.id_indicador = p_indicador)
        GROUP BY MONTH(p.data_realizado)
        ORDER BY MONTH(p.data_realizado);
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_executive_chart_totals;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_executive_chart_totals(
    IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente_gestao_functionals_csv TEXT,
    IN p_gerente_gestao_agencies_csv TEXT,
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_points_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fPontos'
    ) INTO v_has_points_table;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_points_table = 0 OR p_start_date IS NULL OR p_end_date IS NULL THEN
        SELECT CAST(NULL AS CHAR) AS month_key, CAST(NULL AS CHAR) AS section_key, CAST(NULL AS CHAR) AS section_label, 999 AS section_order, 0 AS real_total, 0 AS meta_total FROM DUAL WHERE 1 = 0;
    ELSE
        SELECT
            DATE_FORMAT(f.data_realizado, '%Y-%m') AS month_key,
            CAST(fam.id_familia AS CHAR) AS section_key,
            fam.nome_familia AS section_label,
            COALESCE(fam.ordem_exibicao, 999) AS section_order,
            COALESCE(SUM(f.pontos_realizado), 0) AS real_total,
            COALESCE(SUM(f.pontos_meta), 0) AS meta_total
        FROM fPontos f
        INNER JOIN dIndicador i
            ON i.id_indicador = f.id_indicador
           AND i.ativo_sn = 1
        INNER JOIN dFamiliaProduto fam
            ON fam.id_familia = i.id_familia
           AND fam.ativo_sn = 1
        WHERE f.ativo_sn = 1
          AND f.data_realizado BETWEEN p_start_date AND p_end_date
          AND (
                COALESCE(p_scope_code, 'GLOBAL') = 'GLOBAL'
                OR (COALESCE(p_scope_code, 'GLOBAL') = 'SELF' AND CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci = CONVERT(p_scope_functional USING utf8) COLLATE utf8_unicode_ci)
                OR (COALESCE(p_scope_code, 'GLOBAL') = 'DR' AND FIND_IN_SET(CAST(f.juncao_dr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_scope_allowed_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0)
                OR (COALESCE(p_scope_code, 'GLOBAL') = 'GR' AND FIND_IN_SET(CAST(f.juncao_gr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_scope_allowed_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0)
                OR (COALESCE(p_scope_code, 'GLOBAL') NOT IN ('GLOBAL', 'SELF', 'DR', 'GR') AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_scope_allowed_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0)
          )
          AND (COALESCE(p_segmento, '') = '' OR f.segmento = p_segmento)
          AND (COALESCE(p_diretoria, '') = '' OR f.juncao_dr = p_diretoria)
          AND (COALESCE(p_regional, '') = '' OR f.juncao_gr = p_regional)
          AND (COALESCE(p_agencia, '') = '' OR f.juncao_ag = p_agencia)
          AND (
                COALESCE(p_gerente_gestao, '') = ''
                OR (
                    v_has_management_table = 1
                    AND FIND_IN_SET(CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_gerente_gestao_functionals_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0
                )
                OR (
                    v_has_management_table = 0
                    AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_gerente_gestao_agencies_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0
                )
          )
          AND (COALESCE(p_gerente, '') = '' OR f.funcional = p_gerente)
          AND (
                COALESCE(p_familia, '') = ''
                OR EXISTS (
                    SELECT 1
                    FROM dIndicador di
                    WHERE di.id_indicador = f.id_indicador
                      AND di.id_familia = p_familia
                      AND di.ativo_sn = 1
                )
          )
          AND (COALESCE(p_indicador, '') = '' OR f.id_indicador = p_indicador)
        GROUP BY month_key, fam.id_familia, fam.nome_familia, fam.ordem_exibicao;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_count_executive_daily_granularity_days;

DELIMITER $$

CREATE PROCEDURE sp_pobj_count_executive_daily_granularity_days(
    IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente_gestao_functionals_csv TEXT,
    IN p_gerente_gestao_agencies_csv TEXT,
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_points_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fPontos'
    ) INTO v_has_points_table;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_points_table = 0 OR p_start_date IS NULL OR p_end_date IS NULL THEN
        SELECT 0 AS day_count;
    ELSE
        SELECT COUNT(DISTINCT f.data_realizado) AS day_count
        FROM fPontos f
        INNER JOIN dIndicador i
            ON i.id_indicador = f.id_indicador
           AND i.ativo_sn = 1
        WHERE f.ativo_sn = 1
          AND f.data_realizado BETWEEN p_start_date AND p_end_date
          AND (
                COALESCE(p_scope_code, 'GLOBAL') = 'GLOBAL'
                OR (COALESCE(p_scope_code, 'GLOBAL') = 'SELF' AND CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci = CONVERT(p_scope_functional USING utf8) COLLATE utf8_unicode_ci)
                OR (COALESCE(p_scope_code, 'GLOBAL') = 'DR' AND FIND_IN_SET(CAST(f.juncao_dr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_scope_allowed_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0)
                OR (COALESCE(p_scope_code, 'GLOBAL') = 'GR' AND FIND_IN_SET(CAST(f.juncao_gr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_scope_allowed_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0)
                OR (COALESCE(p_scope_code, 'GLOBAL') NOT IN ('GLOBAL', 'SELF', 'DR', 'GR') AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_scope_allowed_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0)
          )
          AND (COALESCE(p_segmento, '') = '' OR f.segmento = p_segmento)
          AND (COALESCE(p_diretoria, '') = '' OR f.juncao_dr = p_diretoria)
          AND (COALESCE(p_regional, '') = '' OR f.juncao_gr = p_regional)
          AND (COALESCE(p_agencia, '') = '' OR f.juncao_ag = p_agencia)
          AND (
                COALESCE(p_gerente_gestao, '') = ''
                OR (
                    v_has_management_table = 1
                    AND FIND_IN_SET(CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_gerente_gestao_functionals_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0
                )
                OR (
                    v_has_management_table = 0
                    AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_gerente_gestao_agencies_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0
                )
          )
          AND (COALESCE(p_gerente, '') = '' OR f.funcional = p_gerente)
          AND (
                COALESCE(p_familia, '') = ''
                OR EXISTS (
                    SELECT 1
                    FROM dIndicador di
                    WHERE di.id_indicador = f.id_indicador
                      AND di.id_familia = p_familia
                      AND di.ativo_sn = 1
                )
          )
          AND (COALESCE(p_indicador, '') = '' OR f.id_indicador = p_indicador);
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_executive_grouped_performance;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_executive_grouped_performance(
    IN p_group_level VARCHAR(32),
    IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente_gestao_functionals_csv TEXT,
    IN p_gerente_gestao_agencies_csv TEXT,
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_points_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_group_sql TEXT;
    DECLARE v_label_sql TEXT;
    DECLARE v_joins_sql LONGTEXT DEFAULT '';
    DECLARE v_management_join_sql LONGTEXT;
    DECLARE v_management_functional_sql VARCHAR(128);
    DECLARE v_sql LONGTEXT;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fPontos'
    ) INTO v_has_points_table;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_points_table = 0 OR p_start_date IS NULL OR p_end_date IS NULL THEN
        SELECT CAST(NULL AS CHAR) AS group_value, CAST(NULL AS CHAR) AS display_label, 0 AS real_mens, 0 AS meta_mens FROM DUAL WHERE 1 = 0;
    ELSE
        IF v_has_management_table = 1 THEN
            SET v_management_join_sql = 'LEFT JOIN fGestaoGerente mgg ON mgg.funcional_gerente = f.funcional AND mgg.ativo_sn = 1 LEFT JOIN dHierarquia hgg ON hgg.funcional = mgg.funcional_gerente_gestao AND hgg.nivel IN (''GG'', ''TL'') AND hgg.ativo_sn = 1';
            SET v_management_functional_sql = 'mgg.funcional_gerente_gestao';
        ELSE
            SET v_management_join_sql = 'LEFT JOIN fMultiJuncao mgg ON mgg.juncao = f.juncao_ag AND mgg.tipo_juncao = ''AG'' AND mgg.principal_sn = 1 AND mgg.ativo_sn = 1 LEFT JOIN dHierarquia hgg ON hgg.funcional = mgg.funcional AND hgg.nivel = ''AG'' AND hgg.ativo_sn = 1';
            SET v_management_functional_sql = 'mgg.funcional';
        END IF;

        CASE COALESCE(p_group_level, 'gerente_gestao')
            WHEN 'segmento' THEN
                SET v_group_sql = 'f.segmento';
                SET v_label_sql = 'CONCAT(COALESCE(s.juncao_segmento, f.segmento), '' - '', COALESCE(s.nome_segmento, f.segmento))';
                SET v_joins_sql = 'LEFT JOIN dSegmento s ON s.segmento = f.segmento AND s.ativo_sn = 1';
            WHEN 'diretoria' THEN
                SET v_group_sql = 'f.juncao_dr';
                SET v_label_sql = 'CONCAT(f.juncao_dr, '' - '', COALESCE(dr.nome_diretoria, f.juncao_dr))';
                SET v_joins_sql = 'LEFT JOIN (SELECT juncao_dr, MAX(nome_diretoria) AS nome_diretoria FROM dMesu WHERE ativo_sn = 1 GROUP BY juncao_dr) dr ON dr.juncao_dr = f.juncao_dr';
            WHEN 'regional' THEN
                SET v_group_sql = 'f.juncao_gr';
                SET v_label_sql = 'CONCAT(f.juncao_gr, '' - '', COALESCE(gr.nome_regional, f.juncao_gr))';
                SET v_joins_sql = 'LEFT JOIN (SELECT juncao_gr, MAX(nome_regional) AS nome_regional FROM dMesu WHERE ativo_sn = 1 GROUP BY juncao_gr) gr ON gr.juncao_gr = f.juncao_gr';
            WHEN 'agencia' THEN
                SET v_group_sql = 'f.juncao_ag';
                SET v_label_sql = 'CONCAT(f.juncao_ag, '' - '', COALESCE(ag.nome_agencia, f.juncao_ag))';
                SET v_joins_sql = 'LEFT JOIN (SELECT juncao_ag, MAX(nome_agencia) AS nome_agencia FROM dMesu WHERE ativo_sn = 1 GROUP BY juncao_ag) ag ON ag.juncao_ag = f.juncao_ag';
            WHEN 'gerente_agencia' THEN
                SET v_group_sql = 'hag.funcional';
                SET v_label_sql = 'CONCAT(hag.funcional, '' - '', COALESCE(hag.nome, hag.funcional))';
                SET v_joins_sql = 'LEFT JOIN (SELECT m.juncao, m.funcional FROM fMultiJuncao m INNER JOIN dHierarquia h_ag ON h_ag.funcional = m.funcional AND h_ag.nivel = ''AG'' AND h_ag.ativo_sn = 1 WHERE m.tipo_juncao = ''AG'' AND m.principal_sn = 1 AND m.ativo_sn = 1) mag ON mag.juncao = f.juncao_ag LEFT JOIN dHierarquia hag ON hag.funcional = mag.funcional AND hag.ativo_sn = 1';
            WHEN 'gerente' THEN
                SET v_group_sql = 'f.funcional';
                SET v_label_sql = 'CONCAT(f.funcional, '' - '', COALESCE(hg.nome, f.funcional))';
                SET v_joins_sql = 'LEFT JOIN dHierarquia hg ON hg.funcional = f.funcional AND hg.ativo_sn = 1';
            ELSE
                SET v_group_sql = v_management_functional_sql;
                SET v_label_sql = CONCAT('CONCAT(', v_management_functional_sql, ', '' - '', COALESCE(hgg.nome, ', v_management_functional_sql, '))');
                SET v_joins_sql = v_management_join_sql;
        END CASE;

        SET v_sql = CONCAT(
            'SELECT ',
            v_group_sql, ' AS group_value, ',
            v_label_sql, ' AS display_label, ',
            'COALESCE(SUM(f.pontos_realizado), 0) AS real_mens, ',
            'COALESCE(SUM(f.pontos_meta), 0) AS meta_mens ',
            'FROM fPontos f ',
            'INNER JOIN dIndicador i ON i.id_indicador = f.id_indicador AND i.ativo_sn = 1 ',
            'LEFT JOIN dFamiliaProduto fam ON fam.id_familia = i.id_familia AND fam.ativo_sn = 1 ',
            v_joins_sql, ' ',
            'WHERE f.ativo_sn = 1 ',
            'AND f.data_realizado BETWEEN ', QUOTE(p_start_date), ' AND ', QUOTE(p_end_date), ' ',
            'AND (',
                'COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GLOBAL'' ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''SELF'' AND CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_scope_functional, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''DR'' AND FIND_IN_SET(CAST(f.juncao_dr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GR'' AND FIND_IN_SET(CAST(f.juncao_gr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') NOT IN (''GLOBAL'', ''SELF'', ''DR'', ''GR'') AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
            ') ',
            'AND (', QUOTE(COALESCE(p_segmento, '')), ' = '''' OR f.segmento = ', QUOTE(COALESCE(p_segmento, '')), ') ',
            'AND (', QUOTE(COALESCE(p_diretoria, '')), ' = '''' OR f.juncao_dr = ', QUOTE(COALESCE(p_diretoria, '')), ') ',
            'AND (', QUOTE(COALESCE(p_regional, '')), ' = '''' OR f.juncao_gr = ', QUOTE(COALESCE(p_regional, '')), ') ',
            'AND (', QUOTE(COALESCE(p_agencia, '')), ' = '''' OR f.juncao_ag = ', QUOTE(COALESCE(p_agencia, '')), ') ',
            'AND (',
                QUOTE(COALESCE(p_gerente_gestao, '')), ' = '''' ',
                'OR (', v_has_management_table, ' = 1 AND FIND_IN_SET(CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_functionals_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (', v_has_management_table, ' = 0 AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_agencies_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
            ') ',
            'AND (', QUOTE(COALESCE(p_gerente, '')), ' = '''' OR f.funcional = ', QUOTE(COALESCE(p_gerente, '')), ') ',
            'AND (', QUOTE(COALESCE(p_familia, '')), ' = '''' OR EXISTS (SELECT 1 FROM dIndicador di WHERE di.id_indicador = f.id_indicador AND di.id_familia = ', QUOTE(COALESCE(p_familia, '')), ' AND di.ativo_sn = 1)) ',
            'AND (', QUOTE(COALESCE(p_indicador, '')), ' = '''' OR f.id_indicador = ', QUOTE(COALESCE(p_indicador, '')), ') ',
            'GROUP BY group_value, display_label ',
            'HAVING COALESCE(group_value, '''') <> '''''
        );

        SET @sp_pobj_list_executive_grouped_performance_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_executive_grouped_performance_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_executive_focus_rows;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_executive_focus_rows(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_group_level VARCHAR(32),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
proc: BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_has_hierarchy_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;
    DECLARE v_join_sql LONGTEXT DEFAULT '';
    DECLARE v_group_sql LONGTEXT DEFAULT 'CAST(f.`COD_REGIONAL` AS CHAR)';
    DECLARE v_label_sql LONGTEXT DEFAULT 'COALESCE(NULLIF(TRIM(f.`DS_REGIONAL`), ''''), CAST(f.`COD_REGIONAL` AS CHAR))';
    DECLARE v_level VARCHAR(32);

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT('fGestaoGerente' USING utf8) COLLATE utf8_unicode_ci
    ) INTO v_has_management_table;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'dHierarquia'
    ) INTO v_has_hierarchy_table;

    SET v_level = LOWER(TRIM(COALESCE(p_group_level, 'regional')));

    IF v_has_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS group_value, CAST(NULL AS CHAR) AS display_label, 0 AS row_count, 0 AS pontos_meta_total, 0 AS pontos_real_total, 0 AS atingimento_medio, 0 AS forecast_medio, 0 AS referencia_total, 0 AS referencia_perc_media, 0 AS metric_type_count, CAST(NULL AS CHAR) AS metric_type_single, 0 AS valor_meta_total, 0 AS valor_real_total, 0 AS realizado_count FROM DUAL WHERE 1 = 0;
    ELSE
        IF v_level = 'agencia' THEN
            SET v_group_sql = 'CAST(f.`COD_AGENCIA` AS CHAR)';
            SET v_label_sql = 'COALESCE(NULLIF(TRIM(f.`DS_AGENCIA`), ''''), CAST(f.`COD_AGENCIA` AS CHAR))';
        ELSEIF v_level = 'gerente_gestao' THEN
            IF v_has_management_table = 0 OR v_has_hierarchy_table = 0 THEN
                SELECT CAST(NULL AS CHAR) AS group_value, CAST(NULL AS CHAR) AS display_label, 0 AS row_count, 0 AS pontos_meta_total, 0 AS pontos_real_total, 0 AS atingimento_medio, 0 AS forecast_medio, 0 AS referencia_total, 0 AS referencia_perc_media, 0 AS metric_type_count, CAST(NULL AS CHAR) AS metric_type_single, 0 AS valor_meta_total, 0 AS valor_real_total, 0 AS realizado_count FROM DUAL WHERE 1 = 0;
                LEAVE proc;
            END IF;

            SET v_join_sql = ' INNER JOIN fGestaoGerente gg ON gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci INNER JOIN dHierarquia hgg ON hgg.ativo_sn = 1 AND hgg.funcional = gg.funcional_gerente_gestao';
            SET v_group_sql = 'CAST(gg.funcional_gerente_gestao AS CHAR)';
            SET v_label_sql = 'COALESCE(NULLIF(TRIM(hgg.nome), ''''), CAST(gg.funcional_gerente_gestao AS CHAR))';
        ELSEIF v_level = 'gerente' THEN
            IF v_has_hierarchy_table = 1 THEN
                SET v_join_sql = ' LEFT JOIN dHierarquia hg ON hg.ativo_sn = 1 AND CAST(hg.funcional AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci';
                SET v_label_sql = 'COALESCE(NULLIF(TRIM(hg.nome), ''''), NULLIF(TRIM(f.`DS_UNIDADE`), ''''), CAST(f.`COD_UNIDADE` AS CHAR))';
            ELSE
                SET v_label_sql = 'COALESCE(NULLIF(TRIM(f.`DS_UNIDADE`), ''''), CAST(f.`COD_UNIDADE` AS CHAR))';
            END IF;

            SET v_group_sql = 'CAST(f.`COD_UNIDADE` AS CHAR)';
        ELSEIF v_level = 'produto' THEN
            SET v_group_sql = 'COALESCE(NULLIF(TRIM(COALESCE(f.`LABEL`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`ITEM_AB`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`DS_FAMILIA`, '''')), ''''), CAST(f.`ID_FAMILIA` AS CHAR))';
            SET v_label_sql = 'COALESCE(NULLIF(TRIM(COALESCE(f.`DS_INDICADOR`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`ITEM_AB`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`LABEL`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`DS_FAMILIA`, '''')), ''''), CAST(f.`ID_FAMILIA` AS CHAR))';
        ELSEIF v_level = 'familia' THEN
            SET v_group_sql = 'COALESCE(NULLIF(TRIM(COALESCE(f.`DS_FAMILIA`, '''')), ''''), CAST(f.`ID_FAMILIA` AS CHAR))';
            SET v_label_sql = 'COALESCE(NULLIF(TRIM(COALESCE(f.`DS_FAMILIA`, '''')), ''''), CAST(f.`ID_FAMILIA` AS CHAR))';
        END IF;

        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT ',
            v_group_sql, ' AS group_value, ',
            v_label_sql, ' AS display_label, ',
            'COUNT(*) AS row_count, ',
            'COALESCE(SUM(COALESCE(f.`PONTOS_POBJ`, 0)), 0) AS pontos_meta_total, ',
            'COALESCE(SUM(COALESCE(f.`PONTOS_PRODUCAO`, 0)), 0) AS pontos_real_total, ',
            'COALESCE(AVG(COALESCE(f.`ATING_INI`, 0)), 0) AS atingimento_medio, ',
            'COALESCE(AVG(COALESCE(f.`ATG_FINAL`, 0)), 0) AS forecast_medio, ',
            'COALESCE(SUM(CASE WHEN UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR''))) = ''PERCENTUAL'' THEN 0 ELSE COALESCE(f.`REFERENCIA`, 0) END), 0) AS referencia_total, ',
            'COALESCE(AVG(CASE WHEN UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR''))) = ''PERCENTUAL'' THEN COALESCE(f.`REF_PERC`, 0) END), 0) AS referencia_perc_media, ',
            'COUNT(DISTINCT UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR'')))) AS metric_type_count, ',
            'MIN(UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR'')))) AS metric_type_single, ',
            'COALESCE(SUM(COALESCE(f.`VLR_META`, 0)), 0) AS valor_meta_total, ',
            'COALESCE(SUM(COALESCE(f.`VLR_PRODUCAO`, 0)), 0) AS valor_real_total, ',
            'COALESCE(SUM(CASE WHEN COALESCE(f.`VLR_PRODUCAO`, 0) > 0 OR COALESCE(f.`PONTOS_PRODUCAO`, 0) > 0 THEN 1 ELSE 0 END), 0) AS realizado_count ',
            'FROM ', v_table_sql, ' f',
            v_join_sql,
            ' WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes),
            ' AND COALESCE(f.`NIVEL`, 0) = 1',
            ' AND UPPER(REPLACE(TRIM(COALESCE(f.`DS_NIVEL`, '''')), '' '', ''_'')) = ''PRODUTO'''
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_scope_functional));
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento, ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) = ', QUOTE(p_segmento));
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) = ', QUOTE(p_diretoria));
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) = ', QUOTE(p_regional));
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) = ', QUOTE(p_agencia));
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente_gestao), ' OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) = CAST(f.`COD_UNIDADE` AS CHAR) AND gg.funcional_gerente_gestao = ', QUOTE(p_gerente_gestao), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente_gestao));
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente));
        END IF;
        IF COALESCE(p_familia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_FAMILIA` AS CHAR) = ', QUOTE(p_familia));
        END IF;
        IF COALESCE(p_indicador, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_INDICADOR` AS CHAR) = ', QUOTE(p_indicador));
        END IF;

        SET v_sql = CONCAT(v_sql, ' GROUP BY group_value, display_label HAVING COALESCE(group_value, '''') <> '''' ORDER BY display_label');

        SET @sp_pobj_list_executive_focus_rows_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_executive_focus_rows_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_executive_heatmap_matrix;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_executive_heatmap_matrix(
    IN p_unit_level VARCHAR(32),
    IN p_section_mode VARCHAR(32),
    IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente_gestao_functionals_csv TEXT,
    IN p_gerente_gestao_agencies_csv TEXT,
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_points_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_unit_sql TEXT;
    DECLARE v_unit_label_sql TEXT;
    DECLARE v_unit_joins_sql LONGTEXT DEFAULT '';
    DECLARE v_section_sql TEXT;
    DECLARE v_section_label_sql TEXT;
    DECLARE v_section_order_sql TEXT;
    DECLARE v_management_join_sql LONGTEXT;
    DECLARE v_management_functional_sql VARCHAR(128);
    DECLARE v_sql LONGTEXT;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fPontos'
    ) INTO v_has_points_table;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_points_table = 0 OR p_start_date IS NULL OR p_end_date IS NULL THEN
        SELECT CAST(NULL AS CHAR) AS unit_key, CAST(NULL AS CHAR) AS unit_label, CAST(NULL AS CHAR) AS section_key, CAST(NULL AS CHAR) AS section_label, 999 AS section_order, 0 AS real_total, 0 AS meta_total FROM DUAL WHERE 1 = 0;
    ELSE
        IF v_has_management_table = 1 THEN
            SET v_management_join_sql = 'LEFT JOIN fGestaoGerente mgg ON mgg.funcional_gerente = f.funcional AND mgg.ativo_sn = 1 LEFT JOIN dHierarquia hgg ON hgg.funcional = mgg.funcional_gerente_gestao AND hgg.nivel IN (''GG'', ''TL'') AND hgg.ativo_sn = 1';
            SET v_management_functional_sql = 'mgg.funcional_gerente_gestao';
        ELSE
            SET v_management_join_sql = 'LEFT JOIN fMultiJuncao mgg ON mgg.juncao = f.juncao_ag AND mgg.tipo_juncao = ''AG'' AND mgg.principal_sn = 1 AND mgg.ativo_sn = 1 LEFT JOIN dHierarquia hgg ON hgg.funcional = mgg.funcional AND hgg.nivel = ''AG'' AND hgg.ativo_sn = 1';
            SET v_management_functional_sql = 'mgg.funcional';
        END IF;

        CASE COALESCE(p_unit_level, 'gerente_gestao')
            WHEN 'segmento' THEN
                SET v_unit_sql = 'f.segmento';
                SET v_unit_label_sql = 'CONCAT(COALESCE(s.juncao_segmento, f.segmento), '' - '', COALESCE(s.nome_segmento, f.segmento))';
                SET v_unit_joins_sql = 'LEFT JOIN dSegmento s ON s.segmento = f.segmento AND s.ativo_sn = 1';
            WHEN 'diretoria' THEN
                SET v_unit_sql = 'f.juncao_dr';
                SET v_unit_label_sql = 'CONCAT(f.juncao_dr, '' - '', COALESCE(dr.nome_diretoria, f.juncao_dr))';
                SET v_unit_joins_sql = 'LEFT JOIN (SELECT juncao_dr, MAX(nome_diretoria) AS nome_diretoria FROM dMesu WHERE ativo_sn = 1 GROUP BY juncao_dr) dr ON dr.juncao_dr = f.juncao_dr';
            WHEN 'regional' THEN
                SET v_unit_sql = 'f.juncao_gr';
                SET v_unit_label_sql = 'CONCAT(f.juncao_gr, '' - '', COALESCE(gr.nome_regional, f.juncao_gr))';
                SET v_unit_joins_sql = 'LEFT JOIN (SELECT juncao_gr, MAX(nome_regional) AS nome_regional FROM dMesu WHERE ativo_sn = 1 GROUP BY juncao_gr) gr ON gr.juncao_gr = f.juncao_gr';
            WHEN 'agencia' THEN
                SET v_unit_sql = 'f.juncao_ag';
                SET v_unit_label_sql = 'CONCAT(f.juncao_ag, '' - '', COALESCE(ag.nome_agencia, f.juncao_ag))';
                SET v_unit_joins_sql = 'LEFT JOIN (SELECT juncao_ag, MAX(nome_agencia) AS nome_agencia FROM dMesu WHERE ativo_sn = 1 GROUP BY juncao_ag) ag ON ag.juncao_ag = f.juncao_ag';
            WHEN 'gerente_agencia' THEN
                SET v_unit_sql = 'hag.funcional';
                SET v_unit_label_sql = 'CONCAT(hag.funcional, '' - '', COALESCE(hag.nome, hag.funcional))';
                SET v_unit_joins_sql = 'LEFT JOIN (SELECT m.juncao, m.funcional FROM fMultiJuncao m INNER JOIN dHierarquia h_ag ON h_ag.funcional = m.funcional AND h_ag.nivel = ''AG'' AND h_ag.ativo_sn = 1 WHERE m.tipo_juncao = ''AG'' AND m.principal_sn = 1 AND m.ativo_sn = 1) mag ON mag.juncao = f.juncao_ag LEFT JOIN dHierarquia hag ON hag.funcional = mag.funcional AND hag.ativo_sn = 1';
            WHEN 'gerente' THEN
                SET v_unit_sql = 'f.funcional';
                SET v_unit_label_sql = 'CONCAT(f.funcional, '' - '', COALESCE(hg.nome, f.funcional))';
                SET v_unit_joins_sql = 'LEFT JOIN dHierarquia hg ON hg.funcional = f.funcional AND hg.ativo_sn = 1';
            ELSE
                SET v_unit_sql = v_management_functional_sql;
                SET v_unit_label_sql = CONCAT('CONCAT(', v_management_functional_sql, ', '' - '', COALESCE(hgg.nome, ', v_management_functional_sql, '))');
                SET v_unit_joins_sql = v_management_join_sql;
        END CASE;

        IF COALESCE(p_section_mode, 'familia') = 'indicador' THEN
            SET v_section_sql = 'i.id_indicador';
            SET v_section_label_sql = 'i.nome_indicador';
            SET v_section_order_sql = 'COALESCE(i.ordem_exibicao, 999)';
        ELSE
            SET v_section_sql = 'fam.id_familia';
            SET v_section_label_sql = 'fam.nome_familia';
            SET v_section_order_sql = 'COALESCE(fam.ordem_exibicao, 999)';
        END IF;

        SET v_sql = CONCAT(
            'SELECT ',
            v_unit_sql, ' AS unit_key, ',
            v_unit_label_sql, ' AS unit_label, ',
            v_section_sql, ' AS section_key, ',
            v_section_label_sql, ' AS section_label, ',
            v_section_order_sql, ' AS section_order, ',
            'COALESCE(SUM(f.pontos_realizado), 0) AS real_total, ',
            'COALESCE(SUM(f.pontos_meta), 0) AS meta_total ',
            'FROM fPontos f ',
            'INNER JOIN dIndicador i ON i.id_indicador = f.id_indicador AND i.ativo_sn = 1 ',
            'LEFT JOIN dFamiliaProduto fam ON fam.id_familia = i.id_familia AND fam.ativo_sn = 1 ',
            v_unit_joins_sql, ' ',
            'WHERE f.ativo_sn = 1 ',
            'AND f.data_realizado BETWEEN ', QUOTE(p_start_date), ' AND ', QUOTE(p_end_date), ' ',
            'AND (',
                'COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GLOBAL'' ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''SELF'' AND CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_scope_functional, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''DR'' AND FIND_IN_SET(CAST(f.juncao_dr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GR'' AND FIND_IN_SET(CAST(f.juncao_gr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') NOT IN (''GLOBAL'', ''SELF'', ''DR'', ''GR'') AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
            ') ',
            'AND (', QUOTE(COALESCE(p_segmento, '')), ' = '''' OR f.segmento = ', QUOTE(COALESCE(p_segmento, '')), ') ',
            'AND (', QUOTE(COALESCE(p_diretoria, '')), ' = '''' OR f.juncao_dr = ', QUOTE(COALESCE(p_diretoria, '')), ') ',
            'AND (', QUOTE(COALESCE(p_regional, '')), ' = '''' OR f.juncao_gr = ', QUOTE(COALESCE(p_regional, '')), ') ',
            'AND (', QUOTE(COALESCE(p_agencia, '')), ' = '''' OR f.juncao_ag = ', QUOTE(COALESCE(p_agencia, '')), ') ',
            'AND (',
                QUOTE(COALESCE(p_gerente_gestao, '')), ' = '''' ',
                'OR (', v_has_management_table, ' = 1 AND FIND_IN_SET(CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_functionals_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (', v_has_management_table, ' = 0 AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_agencies_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
            ') ',
            'AND (', QUOTE(COALESCE(p_gerente, '')), ' = '''' OR f.funcional = ', QUOTE(COALESCE(p_gerente, '')), ') ',
            'AND (', QUOTE(COALESCE(p_familia, '')), ' = '''' OR EXISTS (SELECT 1 FROM dIndicador di WHERE di.id_indicador = f.id_indicador AND di.id_familia = ', QUOTE(COALESCE(p_familia, '')), ' AND di.ativo_sn = 1)) ',
            'AND (', QUOTE(COALESCE(p_indicador, '')), ' = '''' OR f.id_indicador = ', QUOTE(COALESCE(p_indicador, '')), ') ',
            'GROUP BY unit_key, unit_label, section_key, section_label, section_order'
        );

        SET @sp_pobj_list_executive_heatmap_matrix_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_executive_heatmap_matrix_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_executive_heatmap_sections;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_executive_heatmap_sections(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_group_level VARCHAR(32),
    IN p_row_keys_csv TEXT,
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
proc: BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_has_hierarchy_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;
    DECLARE v_join_sql LONGTEXT DEFAULT '';
    DECLARE v_group_sql LONGTEXT DEFAULT 'CAST(f.`COD_REGIONAL` AS CHAR)';
    DECLARE v_level VARCHAR(32);

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fGestaoGerente') INTO v_has_management_table;
    SELECT EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'dHierarquia') INTO v_has_hierarchy_table;

    SET v_level = LOWER(TRIM(COALESCE(p_group_level, 'regional')));

    IF v_has_table = 0 OR COALESCE(TRIM(p_row_keys_csv), '') = '' THEN
        SELECT CAST(NULL AS CHAR) AS row_key, CAST(NULL AS CHAR) AS family_key, 0 AS row_count, 0 AS pontos_meta_total, 0 AS pontos_real_total, 0 AS atingimento_medio, 0 AS forecast_medio, 0 AS referencia_total, 0 AS referencia_perc_media, 0 AS metric_type_count, CAST(NULL AS CHAR) AS metric_type_single, 0 AS valor_meta_total, 0 AS valor_real_total, 0 AS realizado_count FROM DUAL WHERE 1 = 0;
        LEAVE proc;
    END IF;

    IF v_level = 'agencia' THEN
        SET v_group_sql = 'CAST(f.`COD_AGENCIA` AS CHAR)';
    ELSEIF v_level = 'gerente_gestao' THEN
        IF v_has_management_table = 0 OR v_has_hierarchy_table = 0 THEN
            SELECT CAST(NULL AS CHAR) AS row_key, CAST(NULL AS CHAR) AS family_key, 0 AS row_count, 0 AS pontos_meta_total, 0 AS pontos_real_total, 0 AS atingimento_medio, 0 AS forecast_medio, 0 AS referencia_total, 0 AS referencia_perc_media, 0 AS metric_type_count, CAST(NULL AS CHAR) AS metric_type_single, 0 AS valor_meta_total, 0 AS valor_real_total, 0 AS realizado_count FROM DUAL WHERE 1 = 0;
            LEAVE proc;
        END IF;

        SET v_join_sql = ' INNER JOIN fGestaoGerente gg ON gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci INNER JOIN dHierarquia hgg ON hgg.ativo_sn = 1 AND hgg.funcional = gg.funcional_gerente_gestao';
        SET v_group_sql = 'CAST(gg.funcional_gerente_gestao AS CHAR)';
    ELSEIF v_level = 'gerente' THEN
        IF v_has_hierarchy_table = 1 THEN
            SET v_join_sql = ' LEFT JOIN dHierarquia hg ON hg.ativo_sn = 1 AND CAST(hg.funcional AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci';
        END IF;

        SET v_group_sql = 'CAST(f.`COD_UNIDADE` AS CHAR)';
    ELSEIF v_level = 'produto' THEN
        SET v_group_sql = 'COALESCE(NULLIF(TRIM(COALESCE(f.`LABEL`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`ITEM_AB`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`DS_FAMILIA`, '''')), ''''), CAST(f.`ID_FAMILIA` AS CHAR))';
    END IF;

    SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
    SET v_sql = CONCAT(
        'SELECT ',
        v_group_sql, ' AS row_key, ',
        'COALESCE(NULLIF(TRIM(COALESCE(f.`DS_FAMILIA`, '''')), ''''), CAST(f.`ID_FAMILIA` AS CHAR)) AS family_key, ',
        'COUNT(*) AS row_count, ',
        'COALESCE(SUM(COALESCE(f.`PONTOS_POBJ`, 0)), 0) AS pontos_meta_total, ',
        'COALESCE(SUM(COALESCE(f.`PONTOS_PRODUCAO`, 0)), 0) AS pontos_real_total, ',
        'COALESCE(AVG(COALESCE(f.`ATING_INI`, 0)), 0) AS atingimento_medio, ',
        'COALESCE(AVG(COALESCE(f.`ATG_FINAL`, 0)), 0) AS forecast_medio, ',
        'COALESCE(SUM(CASE WHEN UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR''))) = ''PERCENTUAL'' THEN 0 ELSE COALESCE(f.`REFERENCIA`, 0) END), 0) AS referencia_total, ',
        'COALESCE(AVG(CASE WHEN UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR''))) = ''PERCENTUAL'' THEN COALESCE(f.`REF_PERC`, 0) END), 0) AS referencia_perc_media, ',
        'COUNT(DISTINCT UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR'')))) AS metric_type_count, ',
        'MIN(UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR'')))) AS metric_type_single, ',
        'COALESCE(SUM(COALESCE(f.`VLR_META`, 0)), 0) AS valor_meta_total, ',
        'COALESCE(SUM(COALESCE(f.`VLR_PRODUCAO`, 0)), 0) AS valor_real_total, ',
        'COALESCE(SUM(CASE WHEN COALESCE(f.`VLR_PRODUCAO`, 0) > 0 OR COALESCE(f.`PONTOS_PRODUCAO`, 0) > 0 THEN 1 ELSE 0 END), 0) AS realizado_count ',
        'FROM ', v_table_sql, ' f',
        v_join_sql,
        ' WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes),
        ' AND COALESCE(f.`NIVEL`, 0) = 1',
        ' AND UPPER(REPLACE(TRIM(COALESCE(f.`DS_NIVEL`, '''')), '' '', ''_'')) = ''PRODUTO''',
        ' AND FIND_IN_SET(', v_group_sql, ' COLLATE utf8_unicode_ci, CONVERT(', QUOTE(p_row_keys_csv), ' USING utf8) COLLATE utf8_unicode_ci) > 0'
    );

    IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
    ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
        SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
    ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
        SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
    ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
        SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
    ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
        SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
    END IF;

    IF COALESCE(p_segmento, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci');
    END IF;
    IF COALESCE(p_diretoria, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_diretoria), ' USING utf8) COLLATE utf8_unicode_ci');
    END IF;
    IF COALESCE(p_regional, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_regional), ' USING utf8) COLLATE utf8_unicode_ci');
    END IF;
    IF COALESCE(p_agencia, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_agencia), ' USING utf8) COLLATE utf8_unicode_ci');
    END IF;
    IF COALESCE(p_gerente_gestao, '') <> '' THEN
        IF v_has_management_table = 1 THEN
            SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci AND gg.funcional_gerente_gestao COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci))');
        ELSE
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
    END IF;
    IF COALESCE(p_gerente, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente), ' USING utf8) COLLATE utf8_unicode_ci');
    END IF;
    IF COALESCE(p_familia, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_FAMILIA` AS CHAR) = ', QUOTE(p_familia));
    END IF;
    IF COALESCE(p_indicador, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_INDICADOR` AS CHAR) = ', QUOTE(p_indicador));
    END IF;

    SET v_sql = CONCAT(v_sql, ' GROUP BY row_key, family_key HAVING COALESCE(row_key, '''') <> '''' AND COALESCE(family_key, '''') <> '''' ORDER BY row_key, family_key');

    SET @sp_pobj_list_executive_heatmap_sections_sql = v_sql;
    PREPARE stmt FROM @sp_pobj_list_executive_heatmap_sections_sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_get_executive_history_anchor_dates;

DELIMITER $$

CREATE PROCEDURE sp_pobj_get_executive_history_anchor_dates(
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente_gestao_functionals_csv TEXT,
    IN p_gerente_gestao_agencies_csv TEXT,
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_has_points_table TINYINT DEFAULT 0;
    DECLARE v_has_meta_table TINYINT DEFAULT 0;
    DECLARE v_point_date VARCHAR(32) DEFAULT '';
    DECLARE v_meta_date VARCHAR(32) DEFAULT '';
    DECLARE v_sql LONGTEXT;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fPontos'
    ) INTO v_has_points_table;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fMeta'
    ) INTO v_has_meta_table;

    IF v_has_points_table = 1 THEN
        SET v_sql = CONCAT(
            'SELECT MAX(f.data_realizado) INTO @sp_pobj_exec_history_point_date ',
            'FROM fPontos f ',
            'INNER JOIN dIndicador i ON i.id_indicador = f.id_indicador AND i.ativo_sn = 1 ',
            'WHERE f.ativo_sn = 1 ',
            'AND COALESCE(f.data_realizado, '''') <> '''' ',
            'AND (',
                'COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GLOBAL'' ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''SELF'' AND CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_scope_functional, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''DR'' AND FIND_IN_SET(CAST(f.juncao_dr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GR'' AND FIND_IN_SET(CAST(f.juncao_gr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') NOT IN (''GLOBAL'', ''SELF'', ''DR'', ''GR'') AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
            ') ',
            'AND (', QUOTE(COALESCE(p_segmento, '')), ' = '''' OR f.segmento = ', QUOTE(COALESCE(p_segmento, '')), ') ',
            'AND (', QUOTE(COALESCE(p_diretoria, '')), ' = '''' OR f.juncao_dr = ', QUOTE(COALESCE(p_diretoria, '')), ') ',
            'AND (', QUOTE(COALESCE(p_regional, '')), ' = '''' OR f.juncao_gr = ', QUOTE(COALESCE(p_regional, '')), ') ',
            'AND (', QUOTE(COALESCE(p_agencia, '')), ' = '''' OR f.juncao_ag = ', QUOTE(COALESCE(p_agencia, '')), ') ',
            'AND (',
                QUOTE(COALESCE(p_gerente_gestao, '')), ' = '''' ',
                'OR (', v_has_management_table, ' = 1 AND FIND_IN_SET(CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_functionals_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (', v_has_management_table, ' = 0 AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_agencies_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
            ') ',
            'AND (', QUOTE(COALESCE(p_gerente, '')), ' = '''' OR f.funcional = ', QUOTE(COALESCE(p_gerente, '')), ') ',
            'AND (', QUOTE(COALESCE(p_familia, '')), ' = '''' OR i.id_familia = ', QUOTE(COALESCE(p_familia, '')), ') ',
            'AND (', QUOTE(COALESCE(p_indicador, '')), ' = '''' OR f.id_indicador = ', QUOTE(COALESCE(p_indicador, '')), ')'
        );
        SET @sp_pobj_exec_history_anchor_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_exec_history_anchor_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
        SET v_point_date = COALESCE(@sp_pobj_exec_history_point_date, '');
    END IF;

    IF v_has_meta_table = 1 THEN
        SET v_sql = CONCAT(
            'SELECT MAX(f.dt_meta) INTO @sp_pobj_exec_history_meta_date ',
            'FROM fMeta f ',
            'INNER JOIN dIndicador i ON i.id_indicador = f.id_indicador AND i.ativo_sn = 1 ',
            'WHERE f.ativo_sn = 1 ',
            'AND COALESCE(f.dt_meta, '''') <> '''' ',
            'AND (',
                'COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GLOBAL'' ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''SELF'' AND CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_scope_functional, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''DR'' AND FIND_IN_SET(CAST(f.juncao_dr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GR'' AND FIND_IN_SET(CAST(f.juncao_gr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') NOT IN (''GLOBAL'', ''SELF'', ''DR'', ''GR'') AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
            ') ',
            'AND (', QUOTE(COALESCE(p_segmento, '')), ' = '''' OR f.segmento = ', QUOTE(COALESCE(p_segmento, '')), ') ',
            'AND (', QUOTE(COALESCE(p_diretoria, '')), ' = '''' OR f.juncao_dr = ', QUOTE(COALESCE(p_diretoria, '')), ') ',
            'AND (', QUOTE(COALESCE(p_regional, '')), ' = '''' OR f.juncao_gr = ', QUOTE(COALESCE(p_regional, '')), ') ',
            'AND (', QUOTE(COALESCE(p_agencia, '')), ' = '''' OR f.juncao_ag = ', QUOTE(COALESCE(p_agencia, '')), ') ',
            'AND (',
                QUOTE(COALESCE(p_gerente_gestao, '')), ' = '''' ',
                'OR (', v_has_management_table, ' = 1 AND FIND_IN_SET(CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_functionals_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (', v_has_management_table, ' = 0 AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_agencies_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
            ') ',
            'AND (', QUOTE(COALESCE(p_gerente, '')), ' = '''' OR f.funcional = ', QUOTE(COALESCE(p_gerente, '')), ') ',
            'AND (', QUOTE(COALESCE(p_familia, '')), ' = '''' OR i.id_familia = ', QUOTE(COALESCE(p_familia, '')), ') ',
            'AND (', QUOTE(COALESCE(p_indicador, '')), ' = '''' OR f.id_indicador = ', QUOTE(COALESCE(p_indicador, '')), ')'
        );
        SET @sp_pobj_exec_history_anchor_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_exec_history_anchor_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
        SET v_meta_date = COALESCE(@sp_pobj_exec_history_meta_date, '');
    END IF;

    SELECT v_point_date AS point_date, v_meta_date AS meta_date;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_executive_insights;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_executive_insights(
    IN p_anomes VARCHAR(16),
    IN p_visao VARCHAR(16),
    IN p_scope_level VARCHAR(32),
    IN p_scope_key VARCHAR(64)
)
BEGIN
    SELECT
        `POLARIDADE`,
        `ORDEM`,
        `TIPO_INSIGHT`,
        `TITULO`,
        `TEXTO`,
        `DESTAQUE`,
        `ITEM_LABEL`
    FROM `f_exec_insights`
    WHERE `ativo_sn` = 1
      AND `ANOMES` = p_anomes
      AND `VISAO` = p_visao
      AND `SCOPE_LEVEL` = p_scope_level
      AND `SCOPE_KEY` = p_scope_key
    ORDER BY `POLARIDADE`, `ORDEM`;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_executive_meta_monthly_totals;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_executive_meta_monthly_totals(
    IN p_level VARCHAR(32),
    IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente_gestao_functionals_csv TEXT,
    IN p_gerente_gestao_agencies_csv TEXT,
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_meta_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_group_sql TEXT;
    DECLARE v_group_joins_sql LONGTEXT DEFAULT '';
    DECLARE v_management_join_sql LONGTEXT;
    DECLARE v_management_functional_sql VARCHAR(128);
    DECLARE v_sql LONGTEXT;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fMeta'
    ) INTO v_has_meta_table;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_meta_table = 0 OR p_start_date IS NULL OR p_end_date IS NULL THEN
        SELECT CAST(NULL AS CHAR) AS month_key, CAST(NULL AS CHAR) AS group_value, 0 AS meta_total FROM DUAL WHERE 1 = 0;
    ELSE
        IF v_has_management_table = 1 THEN
            SET v_management_join_sql = 'LEFT JOIN fGestaoGerente mgg ON mgg.funcional_gerente = f.funcional AND mgg.ativo_sn = 1 LEFT JOIN dHierarquia hgg ON hgg.funcional = mgg.funcional_gerente_gestao AND hgg.nivel IN (''GG'', ''TL'') AND hgg.ativo_sn = 1';
            SET v_management_functional_sql = 'mgg.funcional_gerente_gestao';
        ELSE
            SET v_management_join_sql = 'LEFT JOIN fMultiJuncao mgg ON mgg.juncao = f.juncao_ag AND mgg.tipo_juncao = ''AG'' AND mgg.principal_sn = 1 AND mgg.ativo_sn = 1 LEFT JOIN dHierarquia hgg ON hgg.funcional = mgg.funcional AND hgg.nivel = ''AG'' AND hgg.ativo_sn = 1';
            SET v_management_functional_sql = 'mgg.funcional';
        END IF;

        CASE COALESCE(p_level, 'gerente_gestao')
            WHEN 'segmento' THEN
                SET v_group_sql = 'f.segmento';
            WHEN 'diretoria' THEN
                SET v_group_sql = 'f.juncao_dr';
            WHEN 'regional' THEN
                SET v_group_sql = 'f.juncao_gr';
            WHEN 'agencia' THEN
                SET v_group_sql = 'f.juncao_ag';
            WHEN 'gerente_agencia' THEN
                SET v_group_sql = 'hag.funcional';
                SET v_group_joins_sql = 'LEFT JOIN (SELECT m.juncao, m.funcional FROM fMultiJuncao m INNER JOIN dHierarquia h_ag ON h_ag.funcional = m.funcional AND h_ag.nivel = ''AG'' AND h_ag.ativo_sn = 1 WHERE m.tipo_juncao = ''AG'' AND m.principal_sn = 1 AND m.ativo_sn = 1) mag ON mag.juncao = f.juncao_ag LEFT JOIN dHierarquia hag ON hag.funcional = mag.funcional AND hag.ativo_sn = 1';
            WHEN 'gerente' THEN
                SET v_group_sql = 'f.funcional';
            ELSE
                SET v_group_sql = v_management_functional_sql;
                SET v_group_joins_sql = v_management_join_sql;
        END CASE;

        SET v_sql = CONCAT(
            'SELECT ',
            'DATE_FORMAT(f.dt_meta, ''%Y-%m'') AS month_key, ',
            'CAST(', v_group_sql, ' AS CHAR) AS group_value, ',
            'COALESCE(SUM(f.valor_meta), 0) AS meta_total ',
            'FROM fMeta f ',
            'INNER JOIN dIndicador i ON i.id_indicador = f.id_indicador AND i.ativo_sn = 1 ',
            'LEFT JOIN dFamiliaProduto fam ON fam.id_familia = i.id_familia AND fam.ativo_sn = 1 ',
            v_group_joins_sql, ' ',
            'WHERE f.ativo_sn = 1 ',
            'AND COALESCE(f.dt_meta, '''') <> '''' ',
            'AND EXISTS (',
                'SELECT 1 FROM dcalendario dc ',
                'WHERE dc.data_calendario = f.dt_meta ',
                  'AND dc.ativo_sn = 1 ',
                  'AND dc.data_calendario BETWEEN ', QUOTE(p_start_date), ' AND ', QUOTE(p_end_date),
            ') ',
            'AND (',
                'COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GLOBAL'' ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''SELF'' AND CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_scope_functional, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''DR'' AND FIND_IN_SET(CAST(f.juncao_dr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GR'' AND FIND_IN_SET(CAST(f.juncao_gr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') NOT IN (''GLOBAL'', ''SELF'', ''DR'', ''GR'') AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
            ') ',
            'AND (', QUOTE(COALESCE(p_segmento, '')), ' = '''' OR f.segmento = ', QUOTE(COALESCE(p_segmento, '')), ') ',
            'AND (', QUOTE(COALESCE(p_diretoria, '')), ' = '''' OR f.juncao_dr = ', QUOTE(COALESCE(p_diretoria, '')), ') ',
            'AND (', QUOTE(COALESCE(p_regional, '')), ' = '''' OR f.juncao_gr = ', QUOTE(COALESCE(p_regional, '')), ') ',
            'AND (', QUOTE(COALESCE(p_agencia, '')), ' = '''' OR f.juncao_ag = ', QUOTE(COALESCE(p_agencia, '')), ') ',
            'AND (',
                QUOTE(COALESCE(p_gerente_gestao, '')), ' = '''' ',
                'OR (', v_has_management_table, ' = 1 AND FIND_IN_SET(CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_functionals_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (', v_has_management_table, ' = 0 AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_agencies_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
            ') ',
            'AND (', QUOTE(COALESCE(p_gerente, '')), ' = '''' OR f.funcional = ', QUOTE(COALESCE(p_gerente, '')), ') ',
            'AND (', QUOTE(COALESCE(p_familia, '')), ' = '''' OR i.id_familia = ', QUOTE(COALESCE(p_familia, '')), ') ',
            'AND (', QUOTE(COALESCE(p_indicador, '')), ' = '''' OR f.id_indicador = ', QUOTE(COALESCE(p_indicador, '')), ') ',
            'GROUP BY month_key, group_value ',
            'HAVING COALESCE(group_value, '''') <> '''''
        );

        SET @sp_pobj_list_executive_meta_monthly_totals_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_executive_meta_monthly_totals_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_get_executive_point_summary;

DELIMITER $$

CREATE PROCEDURE sp_pobj_get_executive_point_summary(
    IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente_gestao_functionals_csv TEXT,
    IN p_gerente_gestao_agencies_csv TEXT,
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_points_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fPontos'
    ) INTO v_has_points_table;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_points_table = 0 OR p_start_date IS NULL OR p_end_date IS NULL THEN
        SELECT 0 AS real_total, 0 AS meta_total;
    ELSE
        SELECT
            COALESCE(SUM(f.pontos_realizado), 0) AS real_total,
            COALESCE(SUM(f.pontos_meta), 0) AS meta_total
        FROM fPontos f
        INNER JOIN dIndicador i
            ON i.id_indicador = f.id_indicador
           AND i.ativo_sn = 1
        WHERE f.ativo_sn = 1
          AND f.data_realizado BETWEEN p_start_date AND p_end_date
          AND (
                COALESCE(p_scope_code, 'GLOBAL') = 'GLOBAL'
                OR (COALESCE(p_scope_code, 'GLOBAL') = 'SELF' AND CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci = CONVERT(p_scope_functional USING utf8) COLLATE utf8_unicode_ci)
                OR (COALESCE(p_scope_code, 'GLOBAL') = 'DR' AND FIND_IN_SET(CAST(f.juncao_dr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_scope_allowed_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0)
                OR (COALESCE(p_scope_code, 'GLOBAL') = 'GR' AND FIND_IN_SET(CAST(f.juncao_gr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_scope_allowed_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0)
                OR (COALESCE(p_scope_code, 'GLOBAL') NOT IN ('GLOBAL', 'SELF', 'DR', 'GR') AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_scope_allowed_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0)
          )
          AND (COALESCE(p_segmento, '') = '' OR f.segmento = p_segmento)
          AND (COALESCE(p_diretoria, '') = '' OR f.juncao_dr = p_diretoria)
          AND (COALESCE(p_regional, '') = '' OR f.juncao_gr = p_regional)
          AND (COALESCE(p_agencia, '') = '' OR f.juncao_ag = p_agencia)
          AND (
                COALESCE(p_gerente_gestao, '') = ''
                OR (
                    v_has_management_table = 1
                    AND FIND_IN_SET(CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_gerente_gestao_functionals_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0
                )
                OR (
                    v_has_management_table = 0
                    AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(COALESCE(p_gerente_gestao_agencies_csv, '') USING utf8) COLLATE utf8_unicode_ci) > 0
                )
          )
          AND (COALESCE(p_gerente, '') = '' OR f.funcional = p_gerente)
          AND (
                COALESCE(p_familia, '') = ''
                OR EXISTS (
                    SELECT 1
                    FROM dIndicador di
                    WHERE di.id_indicador = f.id_indicador
                      AND di.id_familia = p_familia
                      AND di.ativo_sn = 1
                )
          )
          AND (COALESCE(p_indicador, '') = '' OR f.id_indicador = p_indicador);
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_get_executive_snapshot_totals;

DELIMITER $$

CREATE PROCEDURE sp_pobj_get_executive_snapshot_totals(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_table = 0 THEN
        SELECT 0 AS row_count, 0 AS pontos_meta_total, 0 AS pontos_real_total, 0 AS atingimento_medio, 0 AS forecast_medio, 0 AS referencia_total, 0 AS referencia_perc_media, 0 AS metric_type_count, CAST(NULL AS CHAR) AS metric_type_single, 0 AS valor_meta_total, 0 AS valor_real_total;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT ',
            'COUNT(*) AS row_count, ',
            'COALESCE(SUM(COALESCE(f.`PONTOS_POBJ`, 0)), 0) AS pontos_meta_total, ',
            'COALESCE(SUM(COALESCE(f.`PONTOS_PRODUCAO`, 0)), 0) AS pontos_real_total, ',
            'COALESCE(AVG(COALESCE(f.`ATING_INI`, 0)), 0) AS atingimento_medio, ',
            'COALESCE(AVG(COALESCE(f.`ATG_FINAL`, 0)), 0) AS forecast_medio, ',
            'COALESCE(SUM(CASE WHEN UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR''))) = ''PERCENTUAL'' THEN 0 ELSE COALESCE(f.`REFERENCIA`, 0) END), 0) AS referencia_total, ',
            'COALESCE(AVG(CASE WHEN UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR''))) = ''PERCENTUAL'' THEN COALESCE(f.`REF_PERC`, 0) END), 0) AS referencia_perc_media, ',
            'COUNT(DISTINCT UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR'')))) AS metric_type_count, ',
            'MIN(UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''VALOR'')))) AS metric_type_single, ',
            'COALESCE(SUM(COALESCE(f.`VLR_META`, 0)), 0) AS valor_meta_total, ',
            'COALESCE(SUM(COALESCE(f.`VLR_PRODUCAO`, 0)), 0) AS valor_real_total ',
            'FROM ', v_table_sql, ' f ',
            'WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes),
            ' AND COALESCE(f.`NIVEL`, 0) = 1',
            ' AND UPPER(REPLACE(TRIM(COALESCE(f.`DS_NIVEL`, '''')), '' '', ''_'')) = ''PRODUTO'''
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_scope_functional));
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento, ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) = ', QUOTE(p_segmento));
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) = ', QUOTE(p_diretoria));
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) = ', QUOTE(p_regional));
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) = ', QUOTE(p_agencia));
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente_gestao), ' OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) = CAST(f.`COD_UNIDADE` AS CHAR) AND gg.funcional_gerente_gestao = ', QUOTE(p_gerente_gestao), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente_gestao));
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente));
        END IF;
        IF COALESCE(p_familia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_FAMILIA` AS CHAR) = ', QUOTE(p_familia));
        END IF;
        IF COALESCE(p_indicador, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_INDICADOR` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_indicador), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;

        SET @sp_pobj_get_executive_snapshot_totals_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_get_executive_snapshot_totals_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_executive_unit_trend;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_executive_unit_trend(
    IN p_unit_level VARCHAR(32),
    IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente_gestao_functionals_csv TEXT,
    IN p_gerente_gestao_agencies_csv TEXT,
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_points_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_unit_sql TEXT;
    DECLARE v_unit_joins_sql LONGTEXT DEFAULT '';
    DECLARE v_management_join_sql LONGTEXT;
    DECLARE v_management_functional_sql VARCHAR(128);
    DECLARE v_sql LONGTEXT;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fPontos'
    ) INTO v_has_points_table;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_points_table = 0 OR p_start_date IS NULL OR p_end_date IS NULL THEN
        SELECT CAST(NULL AS CHAR) AS unit_key, CAST(NULL AS CHAR) AS month_key, 0 AS real_total, 0 AS meta_total FROM DUAL WHERE 1 = 0;
    ELSE
        IF v_has_management_table = 1 THEN
            SET v_management_join_sql = 'LEFT JOIN fGestaoGerente mgg ON mgg.funcional_gerente = f.funcional AND mgg.ativo_sn = 1 LEFT JOIN dHierarquia hgg ON hgg.funcional = mgg.funcional_gerente_gestao AND hgg.nivel IN (''GG'', ''TL'') AND hgg.ativo_sn = 1';
            SET v_management_functional_sql = 'mgg.funcional_gerente_gestao';
        ELSE
            SET v_management_join_sql = 'LEFT JOIN fMultiJuncao mgg ON mgg.juncao = f.juncao_ag AND mgg.tipo_juncao = ''AG'' AND mgg.principal_sn = 1 AND mgg.ativo_sn = 1 LEFT JOIN dHierarquia hgg ON hgg.funcional = mgg.funcional AND hgg.nivel = ''AG'' AND hgg.ativo_sn = 1';
            SET v_management_functional_sql = 'mgg.funcional';
        END IF;

        CASE COALESCE(p_unit_level, 'gerente_gestao')
            WHEN 'segmento' THEN
                SET v_unit_sql = 'f.segmento';
                SET v_unit_joins_sql = 'LEFT JOIN dSegmento s ON s.segmento = f.segmento AND s.ativo_sn = 1';
            WHEN 'diretoria' THEN
                SET v_unit_sql = 'f.juncao_dr';
                SET v_unit_joins_sql = 'LEFT JOIN (SELECT juncao_dr, MAX(nome_diretoria) AS nome_diretoria FROM dMesu WHERE ativo_sn = 1 GROUP BY juncao_dr) dr ON dr.juncao_dr = f.juncao_dr';
            WHEN 'regional' THEN
                SET v_unit_sql = 'f.juncao_gr';
                SET v_unit_joins_sql = 'LEFT JOIN (SELECT juncao_gr, MAX(nome_regional) AS nome_regional FROM dMesu WHERE ativo_sn = 1 GROUP BY juncao_gr) gr ON gr.juncao_gr = f.juncao_gr';
            WHEN 'agencia' THEN
                SET v_unit_sql = 'f.juncao_ag';
                SET v_unit_joins_sql = 'LEFT JOIN (SELECT juncao_ag, MAX(nome_agencia) AS nome_agencia FROM dMesu WHERE ativo_sn = 1 GROUP BY juncao_ag) ag ON ag.juncao_ag = f.juncao_ag';
            WHEN 'gerente_agencia' THEN
                SET v_unit_sql = 'hag.funcional';
                SET v_unit_joins_sql = 'LEFT JOIN (SELECT m.juncao, m.funcional FROM fMultiJuncao m INNER JOIN dHierarquia h_ag ON h_ag.funcional = m.funcional AND h_ag.nivel = ''AG'' AND h_ag.ativo_sn = 1 WHERE m.tipo_juncao = ''AG'' AND m.principal_sn = 1 AND m.ativo_sn = 1) mag ON mag.juncao = f.juncao_ag LEFT JOIN dHierarquia hag ON hag.funcional = mag.funcional AND hag.ativo_sn = 1';
            WHEN 'gerente' THEN
                SET v_unit_sql = 'f.funcional';
                SET v_unit_joins_sql = 'LEFT JOIN dHierarquia hg ON hg.funcional = f.funcional AND hg.ativo_sn = 1';
            ELSE
                SET v_unit_sql = v_management_functional_sql;
                SET v_unit_joins_sql = v_management_join_sql;
        END CASE;

        SET v_sql = CONCAT(
            'SELECT ',
            v_unit_sql, ' AS unit_key, ',
            'DATE_FORMAT(f.data_realizado, ''%Y-%m'') AS month_key, ',
            'COALESCE(SUM(f.pontos_realizado), 0) AS real_total, ',
            'COALESCE(SUM(f.pontos_meta), 0) AS meta_total ',
            'FROM fPontos f ',
            'INNER JOIN dIndicador i ON i.id_indicador = f.id_indicador AND i.ativo_sn = 1 ',
            'LEFT JOIN dFamiliaProduto fam ON fam.id_familia = i.id_familia AND fam.ativo_sn = 1 ',
            v_unit_joins_sql, ' ',
            'WHERE f.ativo_sn = 1 ',
            'AND COALESCE(f.data_realizado, '''') <> '''' ',
            'AND f.data_realizado BETWEEN ', QUOTE(p_start_date), ' AND ', QUOTE(p_end_date), ' ',
            'AND (',
                'COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GLOBAL'' ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''SELF'' AND CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_scope_functional, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''DR'' AND FIND_IN_SET(CAST(f.juncao_dr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GR'' AND FIND_IN_SET(CAST(f.juncao_gr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') NOT IN (''GLOBAL'', ''SELF'', ''DR'', ''GR'') AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
            ') ',
            'AND (', QUOTE(COALESCE(p_segmento, '')), ' = '''' OR f.segmento = ', QUOTE(COALESCE(p_segmento, '')), ') ',
            'AND (', QUOTE(COALESCE(p_diretoria, '')), ' = '''' OR f.juncao_dr = ', QUOTE(COALESCE(p_diretoria, '')), ') ',
            'AND (', QUOTE(COALESCE(p_regional, '')), ' = '''' OR f.juncao_gr = ', QUOTE(COALESCE(p_regional, '')), ') ',
            'AND (', QUOTE(COALESCE(p_agencia, '')), ' = '''' OR f.juncao_ag = ', QUOTE(COALESCE(p_agencia, '')), ') ',
            'AND (',
                QUOTE(COALESCE(p_gerente_gestao, '')), ' = '''' ',
                'OR (', v_has_management_table, ' = 1 AND FIND_IN_SET(CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_functionals_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (', v_has_management_table, ' = 0 AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_agencies_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
            ') ',
            'AND (', QUOTE(COALESCE(p_gerente, '')), ' = '''' OR f.funcional = ', QUOTE(COALESCE(p_gerente, '')), ') ',
            'AND (', QUOTE(COALESCE(p_familia, '')), ' = '''' OR EXISTS (SELECT 1 FROM dIndicador di WHERE di.id_indicador = f.id_indicador AND di.id_familia = ', QUOTE(COALESCE(p_familia, '')), ' AND di.ativo_sn = 1)) ',
            'AND (', QUOTE(COALESCE(p_indicador, '')), ' = '''' OR f.id_indicador = ', QUOTE(COALESCE(p_indicador, '')), ') ',
            'GROUP BY unit_key, month_key'
        );

        SET @sp_pobj_list_executive_unit_trend_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_executive_unit_trend_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_resolve_hierarchy_path_with_management;
DROP PROCEDURE IF EXISTS sp_pobj_resolve_hierarchy_path_without_management;

DELIMITER $$

CREATE PROCEDURE sp_pobj_resolve_hierarchy_path_with_management(
    IN p_period_id VARCHAR(64),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_selector VARCHAR(32),
    IN p_selected_value VARCHAR(64)
)
BEGIN
    SELECT DISTINCT
        f.segmento,
        f.juncao_dr,
        f.juncao_gr,
        f.juncao_ag,
        COALESCE(hgg.funcional, '') AS gerente_gestao
    FROM fMeta f
    LEFT JOIN fGestaoGerente mgg
        ON mgg.funcional_gerente COLLATE utf8_unicode_ci = f.funcional COLLATE utf8_unicode_ci
       AND mgg.ativo_sn = 1
    LEFT JOIN dHierarquia hgg
        ON hgg.funcional COLLATE utf8_unicode_ci = mgg.funcional_gerente_gestao COLLATE utf8_unicode_ci
       AND hgg.nivel IN ('GG', 'TL')
       AND hgg.ativo_sn = 1
    WHERE f.id_periodo COLLATE utf8_unicode_ci = CONVERT(p_period_id USING utf8) COLLATE utf8_unicode_ci
      AND f.ativo_sn = 1
      AND (
            COALESCE(p_scope_code, 'GLOBAL') = 'GLOBAL'
            OR (
                p_scope_code = 'SELF'
                AND f.funcional COLLATE utf8_unicode_ci = CONVERT(p_scope_functional USING utf8) COLLATE utf8_unicode_ci
            )
            OR (
                p_scope_code = 'DR'
                AND FIND_IN_SET(f.juncao_dr COLLATE utf8_unicode_ci, CONVERT(p_scope_allowed_csv USING utf8) COLLATE utf8_unicode_ci) > 0
            )
            OR (
                p_scope_code = 'GR'
                AND FIND_IN_SET(f.juncao_gr COLLATE utf8_unicode_ci, CONVERT(p_scope_allowed_csv USING utf8) COLLATE utf8_unicode_ci) > 0
            )
            OR (
                p_scope_code NOT IN ('GLOBAL', 'SELF', 'DR', 'GR')
                AND FIND_IN_SET(f.juncao_ag COLLATE utf8_unicode_ci, CONVERT(p_scope_allowed_csv USING utf8) COLLATE utf8_unicode_ci) > 0
            )
      )
      AND (
            (p_selector = 'GERENTE' AND f.funcional COLLATE utf8_unicode_ci = CONVERT(p_selected_value USING utf8) COLLATE utf8_unicode_ci)
            OR (p_selector = 'GERENTE_GESTAO' AND COALESCE(hgg.funcional, '') COLLATE utf8_unicode_ci = CONVERT(p_selected_value USING utf8) COLLATE utf8_unicode_ci)
            OR (p_selector = 'AGENCIA' AND f.juncao_ag COLLATE utf8_unicode_ci = CONVERT(p_selected_value USING utf8) COLLATE utf8_unicode_ci)
            OR (p_selector = 'REGIONAL' AND f.juncao_gr COLLATE utf8_unicode_ci = CONVERT(p_selected_value USING utf8) COLLATE utf8_unicode_ci)
            OR (p_selector = 'DIRETORIA' AND f.juncao_dr COLLATE utf8_unicode_ci = CONVERT(p_selected_value USING utf8) COLLATE utf8_unicode_ci)
      );
END$$

CREATE PROCEDURE sp_pobj_resolve_hierarchy_path_without_management(
    IN p_period_id VARCHAR(64),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_selector VARCHAR(32),
    IN p_selected_value VARCHAR(64)
)
BEGIN
    SELECT DISTINCT
        f.segmento,
        f.juncao_dr,
        f.juncao_gr,
        f.juncao_ag,
        COALESCE(hag.funcional, '') AS gerente_gestao
    FROM fMeta f
    LEFT JOIN fMultiJuncao mag
        ON mag.juncao COLLATE utf8_unicode_ci = f.juncao_ag COLLATE utf8_unicode_ci
       AND mag.tipo_juncao = 'AG'
       AND mag.principal_sn = 1
       AND mag.ativo_sn = 1
    LEFT JOIN dHierarquia hag
        ON hag.funcional COLLATE utf8_unicode_ci = mag.funcional COLLATE utf8_unicode_ci
       AND hag.nivel = 'AG'
       AND hag.ativo_sn = 1
    WHERE f.id_periodo COLLATE utf8_unicode_ci = CONVERT(p_period_id USING utf8) COLLATE utf8_unicode_ci
      AND f.ativo_sn = 1
      AND (
            COALESCE(p_scope_code, 'GLOBAL') = 'GLOBAL'
            OR (
                p_scope_code = 'SELF'
                AND f.funcional COLLATE utf8_unicode_ci = CONVERT(p_scope_functional USING utf8) COLLATE utf8_unicode_ci
            )
            OR (
                p_scope_code = 'DR'
                AND FIND_IN_SET(f.juncao_dr COLLATE utf8_unicode_ci, CONVERT(p_scope_allowed_csv USING utf8) COLLATE utf8_unicode_ci) > 0
            )
            OR (
                p_scope_code = 'GR'
                AND FIND_IN_SET(f.juncao_gr COLLATE utf8_unicode_ci, CONVERT(p_scope_allowed_csv USING utf8) COLLATE utf8_unicode_ci) > 0
            )
            OR (
                p_scope_code NOT IN ('GLOBAL', 'SELF', 'DR', 'GR')
                AND FIND_IN_SET(f.juncao_ag COLLATE utf8_unicode_ci, CONVERT(p_scope_allowed_csv USING utf8) COLLATE utf8_unicode_ci) > 0
            )
      )
      AND (
            (p_selector = 'GERENTE' AND f.funcional COLLATE utf8_unicode_ci = CONVERT(p_selected_value USING utf8) COLLATE utf8_unicode_ci)
            OR (p_selector = 'GERENTE_GESTAO' AND COALESCE(hag.funcional, '') COLLATE utf8_unicode_ci = CONVERT(p_selected_value USING utf8) COLLATE utf8_unicode_ci)
            OR (p_selector = 'AGENCIA' AND f.juncao_ag COLLATE utf8_unicode_ci = CONVERT(p_selected_value USING utf8) COLLATE utf8_unicode_ci)
            OR (p_selector = 'REGIONAL' AND f.juncao_gr COLLATE utf8_unicode_ci = CONVERT(p_selected_value USING utf8) COLLATE utf8_unicode_ci)
            OR (p_selector = 'DIRETORIA' AND f.juncao_dr COLLATE utf8_unicode_ci = CONVERT(p_selected_value USING utf8) COLLATE utf8_unicode_ci)
      );
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_resolve_functional_group_id;
DROP PROCEDURE IF EXISTS sp_pobj_resolve_functionals_by_group_levels;
DROP PROCEDURE IF EXISTS sp_pobj_resolve_junctions_by_group_levels;
DROP PROCEDURE IF EXISTS sp_pobj_resolve_agencies_by_functional;
DROP PROCEDURE IF EXISTS sp_pobj_resolve_functionals_by_management_functional;
DROP PROCEDURE IF EXISTS sp_pobj_resolve_agency_manager_functional;

DELIMITER $$

CREATE PROCEDURE sp_pobj_resolve_functional_group_id(IN p_functional VARCHAR(32))
BEGIN
    SELECT id_grupo
    FROM fGrupoFuncional
    WHERE funcional COLLATE utf8_unicode_ci = CONVERT(p_functional USING utf8) COLLATE utf8_unicode_ci
      AND ativo_sn = 1
    LIMIT 1;
END$$

CREATE PROCEDURE sp_pobj_resolve_functionals_by_group_levels(IN p_group_id VARCHAR(64), IN p_levels_csv TEXT)
BEGIN
    SELECT DISTINCT gf.funcional
    FROM fGrupoFuncional gf
    INNER JOIN dHierarquia h
        ON h.funcional = gf.funcional
       AND h.ativo_sn = 1
    WHERE gf.id_grupo COLLATE utf8_unicode_ci = CONVERT(p_group_id USING utf8) COLLATE utf8_unicode_ci
      AND gf.ativo_sn = 1
      AND FIND_IN_SET(h.nivel COLLATE utf8_unicode_ci, CONVERT(p_levels_csv USING utf8) COLLATE utf8_unicode_ci) > 0;
END$$

CREATE PROCEDURE sp_pobj_resolve_junctions_by_group_levels(IN p_group_id VARCHAR(64), IN p_junction_type VARCHAR(8), IN p_levels_csv TEXT)
BEGIN
    SELECT DISTINCT m.juncao
    FROM fGrupoFuncional gf
    INNER JOIN dHierarquia h
        ON h.funcional = gf.funcional
       AND h.ativo_sn = 1
    INNER JOIN fMultiJuncao m
        ON m.funcional = gf.funcional
       AND m.tipo_juncao COLLATE utf8_unicode_ci = CONVERT(p_junction_type USING utf8) COLLATE utf8_unicode_ci
       AND m.ativo_sn = 1
    WHERE gf.id_grupo COLLATE utf8_unicode_ci = CONVERT(p_group_id USING utf8) COLLATE utf8_unicode_ci
      AND gf.ativo_sn = 1
      AND FIND_IN_SET(h.nivel COLLATE utf8_unicode_ci, CONVERT(p_levels_csv USING utf8) COLLATE utf8_unicode_ci) > 0;
END$$

CREATE PROCEDURE sp_pobj_resolve_agencies_by_functional(IN p_functional VARCHAR(32))
BEGIN
    SELECT DISTINCT juncao
    FROM fMultiJuncao
    WHERE funcional COLLATE utf8_unicode_ci = CONVERT(p_functional USING utf8) COLLATE utf8_unicode_ci
      AND tipo_juncao = 'AG'
      AND ativo_sn = 1;
END$$

CREATE PROCEDURE sp_pobj_resolve_functionals_by_management_functional(IN p_functional VARCHAR(32))
BEGIN
    SELECT DISTINCT funcional_gerente AS funcional
    FROM fGestaoGerente
    WHERE funcional_gerente_gestao COLLATE utf8_unicode_ci = CONVERT(p_functional USING utf8) COLLATE utf8_unicode_ci
      AND ativo_sn = 1;
END$$

CREATE PROCEDURE sp_pobj_resolve_agency_manager_functional(IN p_agency VARCHAR(64))
BEGIN
    SELECT mag.funcional
    FROM fMultiJuncao mag
    INNER JOIN dHierarquia hag
        ON hag.funcional = mag.funcional
       AND hag.nivel = 'AG'
       AND hag.ativo_sn = 1
    WHERE mag.juncao COLLATE utf8_unicode_ci = CONVERT(p_agency USING utf8) COLLATE utf8_unicode_ci
      AND mag.tipo_juncao = 'AG'
      AND mag.principal_sn = 1
      AND mag.ativo_sn = 1
    LIMIT 1;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_indicator_aggregate_rows;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_indicator_aggregate_rows(
    IN p_table_name VARCHAR(64),
    IN p_value_field VARCHAR(64),
    IN p_date_field VARCHAR(64),
    IN p_aggregate_type VARCHAR(16),
    IN p_supports_subindicator TINYINT,
    IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente_gestao_functionals_csv TEXT,
    IN p_gerente_gestao_agencies_csv TEXT,
    IN p_gerente VARCHAR(32),
    IN p_indicador VARCHAR(64),
    IN p_subindicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_select_sql LONGTEXT DEFAULT '';
    DECLARE v_date_sql LONGTEXT DEFAULT '';
    DECLARE v_sql LONGTEXT;

    IF COALESCE(p_table_name, '') = ''
       OR COALESCE(p_value_field, '') = ''
       OR COALESCE(p_date_field, '') = ''
       OR COALESCE(p_table_name, '') NOT REGEXP '^[A-Za-z0-9_]+$'
       OR COALESCE(p_value_field, '') NOT REGEXP '^[A-Za-z0-9_]+$'
       OR COALESCE(p_date_field, '') NOT REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT
            CAST(NULL AS CHAR) AS id_indicador,
            0 AS total,
            0 AS average_value,
            CAST(NULL AS CHAR) AS last_date
        FROM DUAL
        WHERE 1 = 0;
    ELSE
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_general_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_general_ci
        ) INTO v_has_table;

        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = 'fGestaoGerente'
        ) INTO v_has_management_table;

        IF v_has_table = 0 THEN
            SELECT
                CAST(NULL AS CHAR) AS id_indicador,
                0 AS total,
                0 AS average_value,
                CAST(NULL AS CHAR) AS last_date
            FROM DUAL
            WHERE 1 = 0;
        ELSE
            CASE UPPER(COALESCE(p_aggregate_type, 'SUM'))
                WHEN 'MAX_DATE' THEN
                    SET v_select_sql = CONCAT(
                        'CAST(f.id_indicador AS CHAR) AS id_indicador, ',
                        '0 AS total, ',
                        '0 AS average_value, ',
                        'CAST(MAX(f.`', p_date_field, '`) AS CHAR) AS last_date '
                    );
                    SET v_date_sql = CONCAT('AND COALESCE(f.`', p_date_field, '`, '''') <> '''' ');
                WHEN 'AVG' THEN
                    SET v_select_sql = CONCAT(
                        'CAST(f.id_indicador AS CHAR) AS id_indicador, ',
                        '0 AS total, ',
                        'COALESCE(AVG(f.`', p_value_field, '`), 0) AS average_value, ',
                        'CAST(NULL AS CHAR) AS last_date '
                    );
                ELSE
                    SET v_select_sql = CONCAT(
                        'CAST(f.id_indicador AS CHAR) AS id_indicador, ',
                        'COALESCE(SUM(f.`', p_value_field, '`), 0) AS total, ',
                        '0 AS average_value, ',
                        'CAST(NULL AS CHAR) AS last_date '
                    );
            END CASE;

            IF p_start_date IS NOT NULL AND p_end_date IS NOT NULL THEN
                SET v_date_sql = CONCAT(
                    'AND COALESCE(f.`', p_date_field, '`, '''') <> '''' ',
                    'AND EXISTS (',
                        'SELECT 1 FROM dcalendario dc ',
                        'WHERE dc.data_calendario = f.`', p_date_field, '` ',
                          'AND dc.ativo_sn = 1 ',
                          'AND dc.data_calendario BETWEEN ', QUOTE(p_start_date), ' AND ', QUOTE(p_end_date),
                    ') '
                );
            END IF;

            SET v_sql = CONCAT(
                'SELECT ', v_select_sql,
                'FROM `', p_table_name, '` f ',
                'WHERE f.ativo_sn = 1 ',
                v_date_sql,
                'AND (',
                    'COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GLOBAL'' ',
                    'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''SELF'' AND CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_scope_functional, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
                    'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''DR'' AND FIND_IN_SET(CAST(f.juncao_dr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                    'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GR'' AND FIND_IN_SET(CAST(f.juncao_gr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                    'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') NOT IN (''GLOBAL'', ''SELF'', ''DR'', ''GR'') AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
                ') ',
                'AND (', QUOTE(COALESCE(p_segmento, '')), ' = '''' OR f.segmento = ', QUOTE(COALESCE(p_segmento, '')), ') ',
                'AND (', QUOTE(COALESCE(p_segmento, '')), ' = '''' OR CAST(f.segmento AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_segmento, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
                'AND (', QUOTE(COALESCE(p_diretoria, '')), ' = '''' OR CAST(f.juncao_dr AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_diretoria, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
                'AND (', QUOTE(COALESCE(p_regional, '')), ' = '''' OR CAST(f.juncao_gr AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_regional, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
                'AND (', QUOTE(COALESCE(p_agencia, '')), ' = '''' OR CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_agencia, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
                'AND (',
                    QUOTE(COALESCE(p_gerente_gestao, '')), ' = '''' ',
                    'OR (', v_has_management_table, ' = 1 AND FIND_IN_SET(CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_functionals_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                    'OR (', v_has_management_table, ' = 0 AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_agencies_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
                ') ',
                'AND (', QUOTE(COALESCE(p_gerente, '')), ' = '''' OR CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_gerente, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
                'AND (', QUOTE(COALESCE(p_indicador, '')), ' = '''' OR f.id_indicador = ', QUOTE(COALESCE(p_indicador, '')), ') ',
                'AND (', p_supports_subindicator, ' = 0 OR ', QUOTE(COALESCE(p_subindicador, '')), ' = '''' OR f.id_subindicador = ', QUOTE(COALESCE(p_subindicador, '')), ') ',
                'GROUP BY f.id_indicador'
            );

            SET @sp_pobj_list_indicator_aggregate_rows_sql = v_sql;
            PREPARE stmt FROM @sp_pobj_list_indicator_aggregate_rows_sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;
        END IF;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_get_snapshot_indicator_analytic_summary;

DELIMITER $$

CREATE PROCEDURE sp_pobj_get_snapshot_indicator_analytic_summary(
    IN p_table_name VARCHAR(64),
    IN p_snapshot_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_indicator_id VARCHAR(64),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_profile_level VARCHAR(16),
    IN p_profile_functional VARCHAR(32),
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_snapshot_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_snapshot_sql TEXT;
    DECLARE v_sql LONGTEXT;
    DECLARE v_manager_field VARCHAR(128) DEFAULT 'CAST(a.`Funcional_Gerente_Conta` AS CHAR) COLLATE utf8_unicode_ci';

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    IF p_snapshot_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_snapshot_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_snapshot_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_table = 0 THEN
        SELECT 0 AS transactions_total, 0 AS contracts_total, 0 AS clients_total, 0 AS transaction_volume, '' AS last_transaction_date;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_snapshot_sql = CONCAT('`', REPLACE(p_snapshot_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT ',
            'COUNT(*) AS transactions_total, ',
            'COUNT(DISTINCT NULLIF(TRIM(COALESCE(CAST(a.`Contrato` AS CHAR), '''')), '''')) AS contracts_total, ',
            'COUNT(DISTINCT NULLIF(TRIM(COALESCE(CAST(a.`CPF_CNPJ` AS CHAR), '''')), '''')) AS clients_total, ',
            'COALESCE(SUM(CASE WHEN COALESCE(a.`FlagDesconsiderarProducao`, 0) = 1 THEN 0 ELSE COALESCE(a.`Realizado`, 0) END), 0) AS transaction_volume, ',
            'MAX(a.`Dt_Celeb_Contrato`) AS last_transaction_date ',
            'FROM ', v_table_sql, ' a ',
            'WHERE a.ativo_sn = 1 ',
            'AND a.`AnoMes` = ', QUOTE(p_anomes), ' ',
            'AND CAST(a.`ID_Indicador` AS CHAR) = ', QUOTE(p_indicator_id)
        );

        IF UPPER(COALESCE(p_profile_level, '')) IN ('GC', 'PA', 'AS') AND COALESCE(TRIM(p_profile_functional), '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF UPPER(COALESCE(p_profile_level, '')) IN ('GG', 'TL') AND COALESCE(TRIM(p_profile_functional), '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (', v_manager_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = ', v_manager_field, ' AND gg.funcional_gerente_gestao = ', QUOTE(p_profile_functional), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(a.`Agencia` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(a.`Juncao_DR` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(a.`Juncao_GR` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(a.`Agencia` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            IF v_has_snapshot_table = 1 THEN
                SET v_sql = CONCAT(
                    v_sql,
                    ' AND EXISTS (SELECT 1 FROM ', v_snapshot_sql, ' pm',
                    ' WHERE pm.ativo_sn = 1',
                    ' AND pm.`ANOMES` = ', QUOTE(p_anomes),
                    ' AND CAST(pm.`ID_INDICADOR` AS CHAR) = CAST(a.`ID_Indicador` AS CHAR)',
                    ' AND CAST(pm.`COD_AGENCIA` AS CHAR) = CAST(a.`Agencia` AS CHAR)',
                    ' AND CAST(pm.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = ', v_manager_field,
                    ' AND CAST(pm.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci)'
                );
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND 1 = 0');
            END IF;
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`Juncao_DR` AS CHAR) = ', QUOTE(p_diretoria));
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`Juncao_GR` AS CHAR) = ', QUOTE(p_regional));
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`Agencia` AS CHAR) = ', QUOTE(p_agencia));
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (', v_manager_field, ' = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = ', v_manager_field, ' AND gg.funcional_gerente_gestao = ', QUOTE(p_gerente_gestao), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_gerente), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;

        SET @sp_pobj_get_snapshot_indicator_analytic_summary_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_get_snapshot_indicator_analytic_summary_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_snapshot_indicator_insight_rows;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_snapshot_indicator_insight_rows(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_indicator_id VARCHAR(64),
    IN p_group_level VARCHAR(32),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64)
)
proc: BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_has_hierarchy_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;
    DECLARE v_join_sql LONGTEXT DEFAULT '';
    DECLARE v_group_sql LONGTEXT DEFAULT '';
    DECLARE v_label_sql LONGTEXT DEFAULT '';
    DECLARE v_level VARCHAR(32);

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT('fGestaoGerente' USING utf8) COLLATE utf8_unicode_ci
    ) INTO v_has_management_table;
    SELECT EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'dHierarquia') INTO v_has_hierarchy_table;

    IF v_has_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS group_value, CAST(NULL AS CHAR) AS display_label, 0 AS meta_total, 0 AS realizado_total, 0 AS atingimento_medio FROM DUAL WHERE 1 = 0;
        LEAVE proc;
    END IF;

    SET v_level = LOWER(TRIM(COALESCE(p_group_level, '')));

    IF v_level = 'diretoria' THEN
        SET v_group_sql = 'CAST(f.`COD_DIRETORIA` AS CHAR)';
        SET v_label_sql = 'COALESCE(NULLIF(TRIM(f.`DS_DIRETORIA`), ''''), CAST(f.`COD_DIRETORIA` AS CHAR))';
    ELSEIF v_level = 'regional' THEN
        SET v_group_sql = 'CAST(f.`COD_REGIONAL` AS CHAR)';
        SET v_label_sql = 'COALESCE(NULLIF(TRIM(f.`DS_REGIONAL`), ''''), CAST(f.`COD_REGIONAL` AS CHAR))';
    ELSEIF v_level = 'agencia' THEN
        SET v_group_sql = 'CAST(f.`COD_AGENCIA` AS CHAR)';
        SET v_label_sql = 'COALESCE(NULLIF(TRIM(f.`DS_AGENCIA`), ''''), CAST(f.`COD_AGENCIA` AS CHAR))';
    ELSEIF v_level = 'gerente_gestao' THEN
        IF v_has_management_table = 0 OR v_has_hierarchy_table = 0 THEN
            SELECT CAST(NULL AS CHAR) AS group_value, CAST(NULL AS CHAR) AS display_label, 0 AS meta_total, 0 AS realizado_total, 0 AS atingimento_medio FROM DUAL WHERE 1 = 0;
            LEAVE proc;
        END IF;

        SET v_join_sql = ' INNER JOIN fGestaoGerente gg ON gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci INNER JOIN dHierarquia hgg ON hgg.ativo_sn = 1 AND hgg.funcional = gg.funcional_gerente_gestao';
        SET v_group_sql = 'CAST(gg.funcional_gerente_gestao AS CHAR)';
        SET v_label_sql = 'COALESCE(NULLIF(TRIM(hgg.nome), ''''), CAST(gg.funcional_gerente_gestao AS CHAR))';
    ELSEIF v_level = 'gerente' THEN
        IF v_has_hierarchy_table = 1 THEN
            SET v_join_sql = ' LEFT JOIN dHierarquia hg ON hg.ativo_sn = 1 AND CAST(hg.funcional AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci';
            SET v_label_sql = 'COALESCE(NULLIF(TRIM(hg.nome), ''''), NULLIF(TRIM(f.`DS_UNIDADE`), ''''), CAST(f.`COD_UNIDADE` AS CHAR))';
        ELSE
            SET v_label_sql = 'COALESCE(NULLIF(TRIM(f.`DS_UNIDADE`), ''''), CAST(f.`COD_UNIDADE` AS CHAR))';
        END IF;

        SET v_group_sql = 'CAST(f.`COD_UNIDADE` AS CHAR)';
    ELSEIF v_level = 'produto' THEN
        SET v_group_sql = 'COALESCE(NULLIF(TRIM(COALESCE(f.`LABEL`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`ITEM_AB`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`DS_FAMILIA`, '''')), ''''), CAST(f.`ID_FAMILIA` AS CHAR))';
        SET v_label_sql = 'COALESCE(NULLIF(TRIM(COALESCE(f.`DS_INDICADOR`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`ITEM_AB`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`LABEL`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`DS_FAMILIA`, '''')), ''''), CAST(f.`ID_FAMILIA` AS CHAR))';
    END IF;

    IF v_group_sql = '' OR v_label_sql = '' THEN
        SELECT CAST(NULL AS CHAR) AS group_value, CAST(NULL AS CHAR) AS display_label, 0 AS meta_total, 0 AS realizado_total, 0 AS atingimento_medio FROM DUAL WHERE 1 = 0;
        LEAVE proc;
    END IF;

    SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
    SET v_sql = CONCAT(
        'SELECT ',
        v_group_sql, ' AS group_value, ',
        v_label_sql, ' AS display_label, ',
        'COALESCE(SUM(COALESCE(f.`VLR_META`, 0)), 0) AS meta_total, ',
        'COALESCE(SUM(COALESCE(f.`VLR_PRODUCAO`, 0)), 0) AS realizado_total, ',
        'COALESCE(AVG(COALESCE(f.`ATING_FINAL`, 0)), 0) AS atingimento_medio ',
        'FROM ', v_table_sql, ' f',
        v_join_sql,
        ' WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes),
        ' AND CAST(f.`ID_INDICADOR` AS CHAR) = ', QUOTE(p_indicator_id)
    );

    IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
    ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
        SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
    ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
        SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
    ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
        SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
    ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
        SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
    END IF;

    IF COALESCE(p_segmento, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND ss.segmento COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci)');
    END IF;
    IF COALESCE(p_diretoria, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_diretoria), ' USING utf8) COLLATE utf8_unicode_ci');
    END IF;
    IF COALESCE(p_regional, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_regional), ' USING utf8) COLLATE utf8_unicode_ci');
    END IF;
    IF COALESCE(p_agencia, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_agencia), ' USING utf8) COLLATE utf8_unicode_ci');
    END IF;
    IF COALESCE(p_gerente_gestao, '') <> '' THEN
        IF v_has_management_table = 1 THEN
            SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci AND gg.funcional_gerente_gestao COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci))');
        ELSE
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
    END IF;
    IF COALESCE(p_gerente, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente), ' USING utf8) COLLATE utf8_unicode_ci');
    END IF;
    IF COALESCE(p_familia, '') <> '' THEN
        SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_FAMILIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_familia), ' USING utf8) COLLATE utf8_unicode_ci');
    END IF;

    SET v_sql = CONCAT(v_sql, ' GROUP BY group_value, display_label HAVING COALESCE(group_value, '''') <> '''' ORDER BY display_label');

    SET @sp_pobj_list_snapshot_indicator_insight_rows_sql = v_sql;
    PREPARE stmt FROM @sp_pobj_list_snapshot_indicator_insight_rows_sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_indicator_rows_base;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_indicator_rows_base(
    IN p_period_id VARCHAR(32),
    IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente_gestao_functionals_csv TEXT,
    IN p_gerente_gestao_agencies_csv TEXT,
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64),
    IN p_subindicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_meta_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_has_indicator_period_table TINYINT DEFAULT 0;
    DECLARE v_date_sql LONGTEXT DEFAULT '';
    DECLARE v_weight_join_sql LONGTEXT DEFAULT '';
    DECLARE v_weight_select_sql LONGTEXT DEFAULT '0 AS peso ';
    DECLARE v_sql LONGTEXT;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fMeta'
    ) INTO v_has_meta_table;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fIndicadorPeriodo'
    ) INTO v_has_indicator_period_table;

    IF v_has_meta_table = 0 THEN
        SELECT
            CAST(NULL AS CHAR) AS id_indicador,
            CAST(NULL AS CHAR) AS nome_indicador,
            CAST(NULL AS CHAR) AS nome_familia,
            CAST(NULL AS CHAR) AS id_tipo_indicador,
            CAST(NULL AS CHAR) AS nome_tipo_indicador,
            0 AS peso
        FROM DUAL
        WHERE 1 = 0;
    ELSE
        IF p_start_date IS NOT NULL AND p_end_date IS NOT NULL THEN
            SET v_date_sql = CONCAT(
                'AND COALESCE(fm.dt_meta, '''') <> '''' ',
                'AND EXISTS (',
                    'SELECT 1 FROM dcalendario dc ',
                    'WHERE dc.data_calendario = fm.dt_meta ',
                      'AND dc.ativo_sn = 1 ',
                      'AND dc.data_calendario BETWEEN ', QUOTE(p_start_date), ' AND ', QUOTE(p_end_date),
                ') '
            );
        END IF;

        IF v_has_indicator_period_table = 1 THEN
            SET v_weight_join_sql = CONCAT(
                'LEFT JOIN fIndicadorPeriodo ip ON ip.id_indicador = i.id_indicador ',
                'AND ip.id_periodo = ', QUOTE(COALESCE(p_period_id, '')), ' ',
                'AND ip.ativo_sn = 1 '
            );
            SET v_weight_select_sql = 'COALESCE(ip.peso, 0) AS peso ';
        END IF;

        SET v_sql = CONCAT(
            'SELECT DISTINCT ',
                'CAST(i.id_indicador AS CHAR) AS id_indicador, ',
                'i.nome_indicador, ',
                'f.nome_familia, ',
                'CAST(t.id_tipo_indicador AS CHAR) AS id_tipo_indicador, ',
                't.nome_tipo_indicador, ',
                v_weight_select_sql,
            'FROM dIndicador i ',
            'INNER JOIN dFamiliaProduto f ON f.id_familia = i.id_familia ',
            'INNER JOIN dTipoIndicador t ON t.id_tipo_indicador = i.id_tipo_indicador ',
            'INNER JOIN fMeta fm ON fm.id_indicador = i.id_indicador AND fm.ativo_sn = 1 ',
            v_weight_join_sql,
            'WHERE i.ativo_sn = 1 ',
            v_date_sql,
            'AND (',
                'COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GLOBAL'' ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''SELF'' AND CAST(fm.funcional AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_scope_functional, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''DR'' AND FIND_IN_SET(CAST(fm.juncao_dr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GR'' AND FIND_IN_SET(CAST(fm.juncao_gr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') NOT IN (''GLOBAL'', ''SELF'', ''DR'', ''GR'') AND FIND_IN_SET(CAST(fm.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
            ') ',
            'AND (', QUOTE(COALESCE(p_segmento, '')), ' = '''' OR CAST(fm.segmento AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_segmento, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
            'AND (', QUOTE(COALESCE(p_diretoria, '')), ' = '''' OR CAST(fm.juncao_dr AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_diretoria, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
            'AND (', QUOTE(COALESCE(p_regional, '')), ' = '''' OR CAST(fm.juncao_gr AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_regional, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
            'AND (', QUOTE(COALESCE(p_agencia, '')), ' = '''' OR CAST(fm.juncao_ag AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_agencia, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
            'AND (',
                QUOTE(COALESCE(p_gerente_gestao, '')), ' = '''' ',
                'OR (', v_has_management_table, ' = 1 AND FIND_IN_SET(CAST(fm.funcional AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_functionals_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (', v_has_management_table, ' = 0 AND FIND_IN_SET(CAST(fm.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_agencies_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
            ') ',
            'AND (', QUOTE(COALESCE(p_gerente, '')), ' = '''' OR CAST(fm.funcional AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_gerente, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
            'AND (', QUOTE(COALESCE(p_familia, '')), ' = '''' OR CAST(i.id_familia AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_familia, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
            'AND (', QUOTE(COALESCE(p_indicador, '')), ' = '''' OR CAST(i.id_indicador AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_indicador, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
            'AND (', QUOTE(COALESCE(p_subindicador, '')), ' = '''' OR EXISTS (',
                'SELECT 1 FROM dSubindicador s ',
                'WHERE s.id_indicador = i.id_indicador ',
                  'AND CAST(s.id_subindicador AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_subindicador, '')), ' USING utf8) COLLATE utf8_unicode_ci ',
                  'AND s.ativo_sn = 1',
            ')) ',
            'ORDER BY ',
                'COALESCE(f.ordem_exibicao, 999), ',
                'COALESCE(i.ordem_exibicao, 999), ',
                'i.nome_indicador'
        );

        SET @sp_pobj_list_indicator_rows_base_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_indicator_rows_base_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_snapshot_indicator_transactions;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_snapshot_indicator_transactions(
    IN p_table_name VARCHAR(64),
    IN p_snapshot_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_indicator_id VARCHAR(64),
    IN p_limit_rows INT,
    IN p_offset_rows INT,
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_profile_level VARCHAR(16),
    IN p_profile_functional VARCHAR(32),
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_snapshot_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_snapshot_sql TEXT;
    DECLARE v_sql LONGTEXT;
    DECLARE v_manager_field VARCHAR(128) DEFAULT 'CAST(a.`Funcional_Gerente_Conta` AS CHAR) COLLATE utf8_unicode_ci';
    DECLARE v_limit_rows INT DEFAULT 1;
    DECLARE v_offset_rows INT DEFAULT 0;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    IF p_snapshot_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_snapshot_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_snapshot_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS data_transacao FROM DUAL WHERE 1 = 0;
    ELSE
        SET v_limit_rows = GREATEST(1, COALESCE(p_limit_rows, 1));
        SET v_offset_rows = GREATEST(0, COALESCE(p_offset_rows, 0));
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_snapshot_sql = CONCAT('`', REPLACE(p_snapshot_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT ',
            'a.`Dt_Celeb_Contrato` AS data_transacao, ',
            'a.`Agencia` AS agencia, ',
            'a.`Agencia2` AS agencia_2, ',
            'a.`Conta` AS conta, ',
            'a.`Carteira` AS carteira, ',
            'a.`Contrato` AS numero_contrato, ',
            'COALESCE(a.`Vlr_Financiado`, 0) AS valor_financiado, ',
            'COALESCE(a.`Realizado`, 0) AS valor_realizado, ',
            'COALESCE(a.`Realizado_2`, 0) AS valor_realizado_2, ',
            'a.`CPF_CNPJ` AS cpf_cnpj, ',
            'a.`CPF_CNPJ_FIL` AS cpf_cnpj_fil, ',
            'a.`CPF_CNPJ_DIG` AS cpf_cnpj_dig, ',
            'a.`ID_Segmento` AS id_segmento, ',
            'a.`DS_Produto` AS nome_produto, ',
            'a.`Produto_Macro` AS produto_macro, ',
            'COALESCE(a.`Vlr_Orig_Garantia`, 0) AS valor_origem_garantia, ',
            'a.`NrProposta` AS nr_proposta, ',
            'a.`Identificador_Producao` AS identificador_producao, ',
            'a.`Juncao_Final_Realizado` AS juncao_final_realizado, ',
            'a.`Funcional_Gerente_Conta` AS funcional_gerente_conta, ',
            'a.`Gerente_Negocios` AS gerente_negocios, ',
            'a.`Juncao_BC` AS juncao_bc, ',
            'a.`Gerente_Gestao` AS gerente_gestao, ',
            'a.`Funcional_Assistente` AS funcional_assistente, ',
            'a.`Juncao_DR` AS juncao_dr, ',
            'a.`Juncao_GR` AS juncao_gr, ',
            'a.`Juncao_Final_Classic` AS juncao_final_classic, ',
            'a.`Juncao_GR_PA` AS juncao_gr_pa, ',
            'a.`Juncao_DR_PA` AS juncao_dr_pa, ',
            'a.`Funcional_GA` AS funcional_ga, ',
            'a.`Assessor_GR` AS assessor_gr, ',
            'a.`Assessor_DR` AS assessor_dr, ',
            'a.`Juncao_Assistente_PA` AS juncao_assistente_pa, ',
            'COALESCE(a.`FlagDesconsiderarProducao`, 0) AS flag_desconsiderar_producao ',
            'FROM ', v_table_sql, ' a ',
            'WHERE a.ativo_sn = 1 ',
            'AND a.`AnoMes` = ', QUOTE(p_anomes), ' ',
            'AND CAST(a.`ID_Indicador` AS CHAR) = ', QUOTE(p_indicator_id)
        );

        IF UPPER(COALESCE(p_profile_level, '')) IN ('GC', 'PA', 'AS') AND COALESCE(TRIM(p_profile_functional), '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF UPPER(COALESCE(p_profile_level, '')) IN ('GG', 'TL') AND COALESCE(TRIM(p_profile_functional), '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (', v_manager_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = ', v_manager_field, ' AND gg.funcional_gerente_gestao = ', QUOTE(p_profile_functional), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(a.`Agencia` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(a.`Juncao_DR` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(a.`Juncao_GR` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(a.`Agencia` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            IF v_has_snapshot_table = 1 THEN
                SET v_sql = CONCAT(
                    v_sql,
                    ' AND EXISTS (SELECT 1 FROM ', v_snapshot_sql, ' pm',
                    ' WHERE pm.ativo_sn = 1',
                    ' AND pm.`ANOMES` = ', QUOTE(p_anomes),
                    ' AND CAST(pm.`ID_INDICADOR` AS CHAR) = CAST(a.`ID_Indicador` AS CHAR)',
                    ' AND CAST(pm.`COD_AGENCIA` AS CHAR) = CAST(a.`Agencia` AS CHAR)',
                    ' AND CAST(pm.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = ', v_manager_field,
                    ' AND CAST(pm.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci)'
                );
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND 1 = 0');
            END IF;
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`Juncao_DR` AS CHAR) = ', QUOTE(p_diretoria));
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`Juncao_GR` AS CHAR) = ', QUOTE(p_regional));
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(a.`Agencia` AS CHAR) = ', QUOTE(p_agencia));
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (', v_manager_field, ' = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = ', v_manager_field, ' AND gg.funcional_gerente_gestao = ', QUOTE(p_gerente_gestao), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_manager_field, ' = CONVERT(', QUOTE(p_gerente), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;

        SET v_sql = CONCAT(v_sql, ' ORDER BY a.`Dt_Celeb_Contrato` DESC, a.`Contrato` DESC, a.`id_analitico` DESC LIMIT ', v_limit_rows, ' OFFSET ', v_offset_rows);

        SET @sp_pobj_list_snapshot_indicator_transactions_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_snapshot_indicator_transactions_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_get_snapshot_indicator_trend_point;

DELIMITER $$

CREATE PROCEDURE sp_pobj_get_snapshot_indicator_trend_point(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32),
    IN p_indicator_id VARCHAR(64),
    IN p_familia VARCHAR(64)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_table = 0 THEN
        SELECT 0 AS meta_total, 0 AS realizado_total, 0 AS atingimento_medio;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT ',
            'COALESCE(SUM(COALESCE(f.`VLR_META`, 0)), 0) AS meta_total, ',
            'COALESCE(SUM(COALESCE(f.`VLR_PRODUCAO`, 0)), 0) AS realizado_total, ',
            'COALESCE(AVG(COALESCE(f.`ATING_FINAL`, 0)), 0) AS atingimento_medio ',
            'FROM ', v_table_sql, ' f ',
            'WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes),
            ' AND CAST(f.`ID_INDICADOR` AS CHAR) = ', QUOTE(p_indicator_id)
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_scope_functional));
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento, ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR), ', QUOTE(COALESCE(p_scope_allowed_csv, '')), ') > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) = ', QUOTE(p_segmento));
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) = ', QUOTE(p_diretoria));
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) = ', QUOTE(p_regional));
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) = ', QUOTE(p_agencia));
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente_gestao), ' OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) = CAST(f.`COD_UNIDADE` AS CHAR) AND gg.funcional_gerente_gestao = ', QUOTE(p_gerente_gestao), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente_gestao));
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) = ', QUOTE(p_gerente));
        END IF;
        IF COALESCE(p_familia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_FAMILIA` AS CHAR) = ', QUOTE(p_familia));
        END IF;

        SET @sp_pobj_get_snapshot_indicator_trend_point_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_get_snapshot_indicator_trend_point_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_periods;
DROP PROCEDURE IF EXISTS sp_pobj_get_period_definition;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_periods()
BEGIN
    SELECT id_periodo, descricao_periodo, dt_inicio_periodo, dt_fim_periodo
    FROM dPeriodoApuracao
    WHERE ativo_sn = 1
    ORDER BY dt_inicio_periodo DESC;
END$$

CREATE PROCEDURE sp_pobj_get_period_definition(IN p_period_id VARCHAR(64))
BEGIN
    SELECT id_periodo, descricao_periodo, dt_inicio_periodo, dt_fim_periodo
    FROM dPeriodoApuracao
    WHERE id_periodo COLLATE utf8_unicode_ci = CONVERT(p_period_id USING utf8) COLLATE utf8_unicode_ci
    LIMIT 1;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_semestral_family_options;
DROP PROCEDURE IF EXISTS sp_pobj_list_semestral_indicator_options;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_semestral_family_options(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT('fGestaoGerente' USING utf8) COLLATE utf8_unicode_ci
    ) INTO v_has_management_table;

    IF v_has_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS value, CAST(NULL AS CHAR) AS label FROM DUAL WHERE 1 = 0;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT CAST(f.`ID_FAMILIA` AS CHAR) AS value, COALESCE(f.`DS_FAMILIA`, CAST(f.`ID_FAMILIA` AS CHAR)) AS label, ',
            'MIN(COALESCE(f.`ORDEM`, 999999)) AS ordem ',
            'FROM ', v_table_sql, ' f ',
            'WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes),
            ' AND COALESCE(f.`NIVEL`, 0) = 0 AND UPPER(TRIM(COALESCE(f.`DS_NIVEL`, ''''))) = ''FAMILIA'''
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_diretoria), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_regional), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_agencia), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci AND gg.funcional_gerente_gestao COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;

        SET v_sql = CONCAT(v_sql, ' GROUP BY f.`ID_FAMILIA`, COALESCE(f.`DS_FAMILIA`, CAST(f.`ID_FAMILIA` AS CHAR)) ORDER BY ordem, label');
        SET @sp_pobj_list_semestral_family_options_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_semestral_family_options_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

CREATE PROCEDURE sp_pobj_list_semestral_indicator_options(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND CONVERT(TABLE_NAME USING utf8) COLLATE utf8_unicode_ci = CONVERT('fGestaoGerente' USING utf8) COLLATE utf8_unicode_ci
    ) INTO v_has_management_table;

    IF v_has_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS value, CAST(NULL AS CHAR) AS label FROM DUAL WHERE 1 = 0;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT CAST(f.`ID_INDICADOR` AS CHAR) AS value, COALESCE(f.`DS_INDICADOR`, CAST(f.`ID_INDICADOR` AS CHAR)) AS label, ',
            'MIN(COALESCE(f.`ORDEM`, 999999)) AS ordem ',
            'FROM ', v_table_sql, ' f ',
            'WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes),
            ' AND COALESCE(f.`NIVEL`, 0) = 1 AND UPPER(TRIM(COALESCE(f.`DS_NIVEL`, ''''))) = ''PRODUTO''',
            ' AND EXISTS (',
            'SELECT 1 FROM ', v_table_sql, ' ff ',
            'WHERE ff.ativo_sn = 1 AND ff.`ANOMES` = ', QUOTE(p_anomes),
            ' AND ff.`ID_FAMILIA` = f.`ID_FAMILIA`',
            ' AND COALESCE(ff.`NIVEL`, 0) = 0 AND UPPER(TRIM(COALESCE(ff.`DS_NIVEL`, ''''))) = ''FAMILIA''',
            ')'
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_diretoria), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_regional), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_agencia), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci AND gg.funcional_gerente_gestao COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_familia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_FAMILIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_familia), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;

        SET v_sql = CONCAT(v_sql, ' GROUP BY f.`ID_INDICADOR`, COALESCE(f.`DS_INDICADOR`, CAST(f.`ID_INDICADOR` AS CHAR)) ORDER BY ordem, label');
        SET @sp_pobj_list_semestral_indicator_options_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_semestral_indicator_options_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




CREATE TABLE IF NOT EXISTS dPrograma (
    id_programa INT UNSIGNED NOT NULL,
    segmento VARCHAR(120) NOT NULL,
    programa_acumulado VARCHAR(160) DEFAULT NULL,
    desc_programa VARCHAR(255) DEFAULT NULL,
    alias_programa_acumulado VARCHAR(160) DEFAULT NULL,
    tipo VARCHAR(32) DEFAULT NULL,
    dt_ini_validade DATE DEFAULT NULL,
    dt_fim_validade DATE DEFAULT NULL,
    campo_agrupamento_programa VARCHAR(120) DEFAULT NULL,
    nivel_ps VARCHAR(16) DEFAULT NULL,
    alias_programa_semestral VARCHAR(160) DEFAULT NULL,
    programa_semestral VARCHAR(160) DEFAULT NULL,
    alias_programa_mensal VARCHAR(160) DEFAULT NULL,
    programa_mensal VARCHAR(160) DEFAULT NULL,
    ativo_sn TINYINT(1) NOT NULL DEFAULT 1,
    PRIMARY KEY (id_programa),
    KEY idx_d_programa_segmento (segmento),
    KEY idx_d_programa_ativo (ativo_sn)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO dPrograma (
    id_programa,
    segmento,
    programa_acumulado,
    desc_programa,
    alias_programa_acumulado,
    tipo,
    dt_ini_validade,
    dt_fim_validade,
    campo_agrupamento_programa,
    nivel_ps,
    alias_programa_semestral,
    programa_semestral,
    alias_programa_mensal,
    programa_mensal,
    ativo_sn
) VALUES
    (
        18,
        'DIGITAL PRIME',
        'LIDER_DIGITAL_PRIME',
        'Gerente Gestao Digital',
        'LIDER_DIGITAL_PRIME',
        'PADE',
        '2024-01-01',
        NULL,
        'Gerente_Gestao',
        'GC',
        'LIDER_DIGITAL_PRIME_S',
        'LIDER_DIGITAL_PRIME_S',
        'LIDER_DIGITAL_PRIME_M',
        'LIDER_DIGITAL_PRIME_M',
        1
    ),
    (
        22,
        'DIGITAL PRIME',
        'PADE_DIG_PRIME',
        'Gerente Relacionamento Prime Digital',
        'PADE_DIG_PRIME',
        'PADE',
        '2024-01-01',
        NULL,
        'Funcional_Gerente_Conta',
        'GC',
        'PADE_DIG_PRIME_S',
        'PADE_DIGITAL_PRIME_S',
        'PADE_DIG_PRIME_M',
        'PADE_DIGITAL_PRIME_M',
        1
    ),
    (
        33,
        'PA',
        'ASSIST_PA_MUB',
        'PA Assistente',
        'ASSIST_PA_MUB',
        'PADE',
        '2024-01-01',
        NULL,
        'ID_Posto_Principal',
        'PA',
        'ASSIST_PA_MUB_S',
        'PA_ASSISTENTE_S',
        'ASSIST_PA_MUB_M',
        'PA_ASSISTENTE_M',
        1
    )
ON DUPLICATE KEY UPDATE
    segmento = VALUES(segmento),
    programa_acumulado = VALUES(programa_acumulado),
    desc_programa = VALUES(desc_programa),
    alias_programa_acumulado = VALUES(alias_programa_acumulado),
    tipo = VALUES(tipo),
    dt_ini_validade = VALUES(dt_ini_validade),
    dt_fim_validade = VALUES(dt_fim_validade),
    campo_agrupamento_programa = VALUES(campo_agrupamento_programa),
    nivel_ps = VALUES(nivel_ps),
    alias_programa_semestral = VALUES(alias_programa_semestral),
    programa_semestral = VALUES(programa_semestral),
    alias_programa_mensal = VALUES(alias_programa_mensal),
    programa_mensal = VALUES(programa_mensal),
    ativo_sn = VALUES(ativo_sn);


DROP PROCEDURE IF EXISTS sp_pobj_list_semestral_segment_options;
DROP PROCEDURE IF EXISTS sp_pobj_list_semestral_hierarchy_options;
DROP PROCEDURE IF EXISTS sp_pobj_list_semestral_unit_options;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_semestral_segment_options(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente VARCHAR(32)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    IF v_has_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS value, CAST(NULL AS CHAR) AS label FROM DUAL WHERE 1 = 0;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT DISTINCT ',
            'CAST(f.`ID_PROGRAMA` AS CHAR) AS value, ',
            'COALESCE(NULLIF(TRIM(dp.`segmento`), ''''), CONCAT(CAST(f.`ID_PROGRAMA` AS CHAR), '' - Programa'')) AS label ',
            'FROM ', v_table_sql, ' f ',
            'LEFT JOIN dPrograma dp ',
            '    ON dp.id_programa = f.`ID_PROGRAMA` ',
            '   AND dp.ativo_sn = 1 ',
            'WHERE f.ativo_sn = 1 ',
            '  AND f.`ANOMES` = ', QUOTE(p_anomes),
            '  AND COALESCE(CAST(f.`ID_PROGRAMA` AS CHAR), '''') <> '''''
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(',
                QUOTE(p_scope_functional),
                ' USING utf8) COLLATE utf8_unicode_ci'
            );
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND EXISTS (',
                'SELECT 1 ',
                'FROM dMesu sm ',
                'INNER JOIN dSegmento ss ',
                '    ON ss.id_segmento = sm.id_segmento ',
                '   AND ss.ativo_sn = 1 ',
                'WHERE sm.ativo_sn = 1 ',
                '  AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) ',
                '  AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(',
                QUOTE(COALESCE(p_scope_allowed_csv, '')),
                ' USING utf8) COLLATE utf8_unicode_ci) > 0',
                ')'
            );
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(',
                QUOTE(COALESCE(p_scope_allowed_csv, '')),
                ' USING utf8) COLLATE utf8_unicode_ci) > 0'
            );
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(',
                QUOTE(COALESCE(p_scope_allowed_csv, '')),
                ' USING utf8) COLLATE utf8_unicode_ci) > 0'
            );
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(',
                QUOTE(COALESCE(p_scope_allowed_csv, '')),
                ' USING utf8) COLLATE utf8_unicode_ci) > 0'
            );
        END IF;

        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(',
                QUOTE(p_diretoria),
                ' USING utf8) COLLATE utf8_unicode_ci'
            );
        END IF;

        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(',
                QUOTE(p_regional),
                ' USING utf8) COLLATE utf8_unicode_ci'
            );
        END IF;

        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(',
                QUOTE(p_agencia),
                ' USING utf8) COLLATE utf8_unicode_ci'
            );
        END IF;

        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(',
                QUOTE(p_gerente),
                ' USING utf8) COLLATE utf8_unicode_ci'
            );
        END IF;

        SET v_sql = CONCAT(v_sql, ' ORDER BY CAST(f.`ID_PROGRAMA` AS UNSIGNED), label');

        SET @sp_pobj_segment_options_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_segment_options_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

CREATE PROCEDURE sp_pobj_list_semestral_hierarchy_options(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_level VARCHAR(16),
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_code_field VARCHAR(32);
    DECLARE v_label_field VARCHAR(32);
    DECLARE v_sql LONGTEXT;

    IF p_level = 'DIRETORIA' THEN
        SET v_code_field = 'COD_DIRETORIA';
        SET v_label_field = 'DS_DIRETORIA';
    ELSEIF p_level = 'REGIONAL' THEN
        SET v_code_field = 'COD_REGIONAL';
        SET v_label_field = 'DS_REGIONAL';
    ELSEIF p_level = 'AGENCIA' THEN
        SET v_code_field = 'COD_AGENCIA';
        SET v_label_field = 'DS_AGENCIA';
    ELSE
        SET v_code_field = '';
        SET v_label_field = '';
    END IF;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    IF v_has_table = 0 OR v_code_field = '' OR v_label_field = '' THEN
        SELECT CAST(NULL AS CHAR) AS value, CAST(NULL AS CHAR) AS label FROM DUAL WHERE 1 = 0;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT DISTINCT ',
            'CAST(f.`', v_code_field, '` AS CHAR) AS value, ',
            'CONCAT(CAST(f.`', v_code_field, '` AS CHAR), '' - '', COALESCE(f.`', v_label_field, '`, CAST(f.`', v_code_field, '` AS CHAR))) AS label ',
            'FROM ', v_table_sql, ' f ',
            'WHERE f.ativo_sn = 1 ',
            '  AND f.`ANOMES` = ', QUOTE(p_anomes),
            '  AND COALESCE(CAST(f.`', v_code_field, '` AS CHAR), '''') <> '''''
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(',
                QUOTE(p_scope_functional),
                ' USING utf8) COLLATE utf8_unicode_ci'
            );
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND EXISTS (',
                'SELECT 1 ',
                'FROM dMesu sm ',
                'INNER JOIN dSegmento ss ',
                '    ON ss.id_segmento = sm.id_segmento ',
                '   AND ss.ativo_sn = 1 ',
                'WHERE sm.ativo_sn = 1 ',
                '  AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) ',
                '  AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(',
                QUOTE(COALESCE(p_scope_allowed_csv, '')),
                ' USING utf8) COLLATE utf8_unicode_ci) > 0',
                ')'
            );
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(',
                QUOTE(COALESCE(p_scope_allowed_csv, '')),
                ' USING utf8) COLLATE utf8_unicode_ci) > 0'
            );
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(',
                QUOTE(COALESCE(p_scope_allowed_csv, '')),
                ' USING utf8) COLLATE utf8_unicode_ci) > 0'
            );
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(',
                QUOTE(COALESCE(p_scope_allowed_csv, '')),
                ' USING utf8) COLLATE utf8_unicode_ci) > 0'
            );
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND CAST(f.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(',
                QUOTE(p_segmento),
                ' USING utf8) COLLATE utf8_unicode_ci'
            );
        END IF;

        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(',
                QUOTE(p_diretoria),
                ' USING utf8) COLLATE utf8_unicode_ci'
            );
        END IF;

        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(',
                QUOTE(p_regional),
                ' USING utf8) COLLATE utf8_unicode_ci'
            );
        END IF;

        SET v_sql = CONCAT(v_sql, ' ORDER BY label');

        SET @sp_pobj_hierarchy_options_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_hierarchy_options_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

CREATE PROCEDURE sp_pobj_list_semestral_unit_options(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    IF v_has_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS value, CAST(NULL AS CHAR) AS label FROM DUAL WHERE 1 = 0;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT DISTINCT ',
            'CAST(f.`COD_UNIDADE` AS CHAR) AS value, ',
            'CONCAT(CAST(f.`COD_UNIDADE` AS CHAR), '' - '', COALESCE(NULLIF(TRIM(f.`DS_UNIDADE`), ''''), CAST(f.`COD_UNIDADE` AS CHAR))) AS label ',
            'FROM ', v_table_sql, ' f ',
            'WHERE f.ativo_sn = 1 ',
            '  AND f.`ANOMES` = ', QUOTE(p_anomes),
            '  AND COALESCE(CAST(f.`COD_UNIDADE` AS CHAR), '''') <> '''''
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(',
                QUOTE(p_scope_functional),
                ' USING utf8) COLLATE utf8_unicode_ci'
            );
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND EXISTS (',
                'SELECT 1 ',
                'FROM dMesu sm ',
                'INNER JOIN dSegmento ss ',
                '    ON ss.id_segmento = sm.id_segmento ',
                '   AND ss.ativo_sn = 1 ',
                'WHERE sm.ativo_sn = 1 ',
                '  AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) ',
                '  AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(',
                QUOTE(COALESCE(p_scope_allowed_csv, '')),
                ' USING utf8) COLLATE utf8_unicode_ci) > 0',
                ')'
            );
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(',
                QUOTE(COALESCE(p_scope_allowed_csv, '')),
                ' USING utf8) COLLATE utf8_unicode_ci) > 0'
            );
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(',
                QUOTE(COALESCE(p_scope_allowed_csv, '')),
                ' USING utf8) COLLATE utf8_unicode_ci) > 0'
            );
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(',
                QUOTE(COALESCE(p_scope_allowed_csv, '')),
                ' USING utf8) COLLATE utf8_unicode_ci) > 0'
            );
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND CAST(f.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(',
                QUOTE(p_segmento),
                ' USING utf8) COLLATE utf8_unicode_ci'
            );
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(',
                QUOTE(p_diretoria),
                ' USING utf8) COLLATE utf8_unicode_ci'
            );
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(',
                QUOTE(p_regional),
                ' USING utf8) COLLATE utf8_unicode_ci'
            );
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(',
                QUOTE(p_agencia),
                ' USING utf8) COLLATE utf8_unicode_ci'
            );
        END IF;

        SET v_sql = CONCAT(v_sql, ' ORDER BY label');

        SET @sp_pobj_unit_options_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_unit_options_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_semestral_indicator_rows;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_semestral_indicator_rows(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fGestaoGerente') INTO v_has_management_table;

    IF v_has_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS id_indicador FROM DUAL WHERE 1 = 0;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT ',
            'CAST(f.`ID_INDICADOR` AS CHAR) AS id_indicador, ',
            'MAX(CAST(f.`ID_PAI_INDICADOR` AS CHAR)) AS id_pai_indicador, ',
            'MIN(COALESCE(f.`ORDEM`, 999999)) AS ordem, ',
            'MAX(COALESCE(f.`NIVEL`, 0)) AS nivel, ',
            'MAX(COALESCE(f.`DS_NIVEL`, '''')) AS ds_nivel, ',
            'MAX(CAST(f.`ID_PROGRAMA` AS CHAR)) AS id_programa, ',
            'MAX(COALESCE(f.`DS_INDICADOR`, CAST(f.`ID_INDICADOR` AS CHAR))) AS nome_indicador, ',
            'CAST(f.`ID_FAMILIA` AS CHAR) AS id_familia, ',
            'MAX(COALESCE(f.`DS_FAMILIA`, CAST(f.`ID_FAMILIA` AS CHAR))) AS nome_familia, ',
            'CAST('''' AS CHAR) AS id_tipo_indicador, ',
            'CAST('''' AS CHAR) AS nome_tipo_indicador, ',
            'MAX(f.`DS_METRICA`) AS ds_metrica, ',
            'COUNT(*) AS row_count, ',
            'COALESCE(MAX(COALESCE(f.`VLR_META`, 0)), 0) AS meta_total, ',
            'COALESCE(MAX(COALESCE(f.`VLR_PRODUCAO`, 0)), 0) AS realizado_total, ',
            'COALESCE(MAX(COALESCE(f.`ATING_INI`, 0)), 0) AS atingimento_inicial, ',
            'COALESCE(MAX(COALESCE(f.`ATG_FINAL`, 0)), 0) AS forecast_valor, ',
            'COALESCE(MAX(COALESCE(f.`NEC_DIA`, 0)), 0) AS nec_dia_valor, ',
            'COALESCE(MAX(COALESCE(f.`REFERENCIA`, 0)), 0) AS referencia_valor, ',
            'COALESCE(MAX(COALESCE(f.`REF_PERC`, 0)), 0) AS referencia_percentual_valor, ',
            'COALESCE(MAX(COALESCE(f.`PESO_FINAL_PRODUCAO`, 0)), 0) AS peso_valor, ',
            'COALESCE(MAX(COALESCE(f.`PONTOS_POBJ`, 0)), 0) AS pontos_meta_valor, ',
            'COALESCE(MAX(COALESCE(f.`PONTOS_PRODUCAO`, 0)), 0) AS pontos_realizado_valor, ',
            'MAX(COALESCE(f.`DATA_BASE`, '''')) AS data_base_max ',
            'FROM ', v_table_sql, ' f ',
            'WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes)
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_diretoria), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_regional), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_agencia), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci AND gg.funcional_gerente_gestao COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_familia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_FAMILIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_familia), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_indicador, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_INDICADOR` AS CHAR) = ', QUOTE(p_indicador));
        END IF;

        SET v_sql = CONCAT(v_sql, ' GROUP BY f.`ID_FAMILIA`, f.`ID_INDICADOR` ORDER BY ordem, MAX(COALESCE(f.`DS_FAMILIA`, CAST(f.`ID_FAMILIA` AS CHAR))), MAX(COALESCE(f.`DS_INDICADOR`, CAST(f.`ID_INDICADOR` AS CHAR)))');

        SET @sp_pobj_list_semestral_indicator_rows_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_semestral_indicator_rows_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_has_snapshot_management_managers;
DROP PROCEDURE IF EXISTS sp_pobj_list_semestral_management_manager_options;
DROP PROCEDURE IF EXISTS sp_pobj_list_semestral_commercial_manager_options;

DELIMITER $$

CREATE PROCEDURE sp_pobj_has_snapshot_management_managers(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_table = 0 OR v_has_management_table = 0 THEN
        SELECT 0 AS has_management_managers;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT EXISTS(',
            'SELECT 1 ',
            'FROM ', v_table_sql, ' f ',
            'INNER JOIN fGestaoGerente gg ',
            '    ON gg.ativo_sn = 1 ',
            '   AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci ',
            'WHERE f.ativo_sn = 1 ',
            '  AND f.`ANOMES` = ', QUOTE(p_anomes)
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(
                v_sql,
                ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 ',
                'WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) ',
                'AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)'
            );
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_diretoria), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_regional), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_agencia), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;

        SET v_sql = CONCAT(v_sql, ') AS has_management_managers');
        SET @sp_pobj_has_snapshot_management_managers_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_has_snapshot_management_managers_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

CREATE PROCEDURE sp_pobj_list_semestral_management_manager_options(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_has_hierarchy_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fGestaoGerente') INTO v_has_management_table;
    SELECT EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'dHierarquia') INTO v_has_hierarchy_table;

    IF v_has_table = 0 OR v_has_management_table = 0 OR v_has_hierarchy_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS value, CAST(NULL AS CHAR) AS label FROM DUAL WHERE 1 = 0;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT DISTINCT h.funcional AS value, CONCAT(h.funcional, '' - '', h.nome) AS label ',
            'FROM dHierarquia h ',
            'INNER JOIN fGestaoGerente gg ON gg.funcional_gerente_gestao COLLATE utf8_unicode_ci = h.funcional COLLATE utf8_unicode_ci AND gg.ativo_sn = 1 ',
            'INNER JOIN ', v_table_sql, ' f ON CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = gg.funcional_gerente COLLATE utf8_unicode_ci ',
            'WHERE h.ativo_sn = 1 AND h.nivel IN (''GG'', ''TL'') AND f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes)
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_diretoria), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_regional), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_agencia), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;

        SET v_sql = CONCAT(v_sql, ' ORDER BY h.nome');
        SET @sp_pobj_list_semestral_management_manager_options_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_semestral_management_manager_options_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

CREATE PROCEDURE sp_pobj_list_semestral_commercial_manager_options(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_has_hierarchy_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fGestaoGerente') INTO v_has_management_table;
    SELECT EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'dHierarquia') INTO v_has_hierarchy_table;

    IF v_has_table = 0 OR v_has_hierarchy_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS value, CAST(NULL AS CHAR) AS label FROM DUAL WHERE 1 = 0;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT DISTINCT h.funcional AS value, CONCAT(h.funcional, '' - '', h.nome) AS label ',
            'FROM dHierarquia h ',
            'INNER JOIN ', v_table_sql, ' f ON CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = h.funcional COLLATE utf8_unicode_ci '
        );

        IF v_has_management_table = 1 THEN
            SET v_sql = CONCAT(v_sql, 'LEFT JOIN fGestaoGerente gg ON gg.funcional_gerente COLLATE utf8_unicode_ci = h.funcional COLLATE utf8_unicode_ci AND gg.ativo_sn = 1 ');
        END IF;

        SET v_sql = CONCAT(v_sql, 'WHERE h.ativo_sn = 1 AND h.nivel IN (''GC'', ''PA'', ''AS'') AND f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes));

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_diretoria), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_regional), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_agencia), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;

        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND gg.funcional_gerente_gestao COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND 1 = 0');
            END IF;
        END IF;

        SET v_sql = CONCAT(v_sql, ' ORDER BY h.nome');
        SET @sp_pobj_list_semestral_commercial_manager_options_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_semestral_commercial_manager_options_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_snapshot_detail_rows;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_snapshot_detail_rows(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_join_management_sql TEXT DEFAULT '';
    DECLARE v_select_management_sql TEXT DEFAULT '';
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(SELECT 1 FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'fGestaoGerente') INTO v_has_management_table;

    IF v_has_table = 0 THEN
        SELECT CAST(NULL AS CHAR) AS id_detail FROM DUAL WHERE 1 = 0;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');

        IF v_has_management_table = 1 THEN
            SET v_join_management_sql = ' LEFT JOIN fGestaoGerente gg ON gg.ativo_sn = 1 AND CAST(gg.`funcional_gerente` AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci LEFT JOIN dHierarquia hgg ON hgg.ativo_sn = 1 AND CAST(hgg.`funcional` AS CHAR) COLLATE utf8_unicode_ci = CAST(gg.`funcional_gerente_gestao` AS CHAR) COLLATE utf8_unicode_ci ';
            SET v_select_management_sql = 'CAST(gg.`funcional_gerente_gestao` AS CHAR) AS funcional_gerente_gestao, COALESCE(NULLIF(TRIM(hgg.`nome`), ''''), CAST(gg.`funcional_gerente_gestao` AS CHAR), '''') AS nome_gerente_gestao, ';
        ELSE
            SET v_select_management_sql = 'CAST(NULL AS CHAR) AS funcional_gerente_gestao, CAST('''' AS CHAR) AS nome_gerente_gestao, ';
        END IF;

        SET v_sql = CONCAT(
            'SELECT ',
            'CAST(f.`id_produtividade_semestral` AS CHAR) AS id_detail, ',
            'CAST(f.`ID_INDICADOR` AS CHAR) AS id_indicador, ',
            'COALESCE(NULLIF(TRIM(COALESCE(f.`ITEM_AB`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`LABEL`, '''')), ''''), CAST('''' AS CHAR)) AS id_subindicador, ',
            'CAST(f.`COD_UNIDADE` AS CHAR) AS funcional, ',
            'COALESCE(NULLIF(TRIM(hg.`nome`), ''''), NULLIF(TRIM(f.`DS_UNIDADE`), ''''), CAST(f.`COD_UNIDADE` AS CHAR)) AS nome_gerente, ',
            v_select_management_sql,
            'CAST(f.`COD_AGENCIA` AS CHAR) AS juncao_ag, ',
            'COALESCE(NULLIF(TRIM(f.`DS_AGENCIA`), ''''), CAST(f.`COD_AGENCIA` AS CHAR)) AS nome_agencia, ',
            'CAST(f.`COD_REGIONAL` AS CHAR) AS juncao_gr, ',
            'COALESCE(NULLIF(TRIM(f.`DS_REGIONAL`), ''''), CAST(f.`COD_REGIONAL` AS CHAR)) AS nome_regional, ',
            'CAST(f.`COD_DIRETORIA` AS CHAR) AS juncao_dr, ',
            'COALESCE(NULLIF(TRIM(f.`DS_DIRETORIA`), ''''), CAST(f.`COD_DIRETORIA` AS CHAR)) AS nome_diretoria, ',
            'f.`DATA_BASE` AS data_transacao, ',
            'COALESCE(f.`VLR_PRODUCAO`, 0) AS valor_realizado, ',
            'COALESCE(f.`VLR_META`, 0) AS valor_meta_detail, ',
            'COALESCE(f.`ATING_INI`, 0) AS atingimento_detail, ',
            'CASE WHEN UPPER(TRIM(COALESCE(f.`DS_METRICA`, ''''))) = ''PERCENTUAL'' THEN COALESCE(f.`REF_PERC`, 0) ELSE COALESCE(f.`REFERENCIA`, 0) END AS referencia_detail, ',
            'COALESCE(f.`NEC_DIA`, 0) AS necessidade_diaria_detail, ',
            'COALESCE(f.`ATG_FINAL`, 0) AS forecast_detail, ',
            'COALESCE(f.`PESO_FINAL_PRODUCAO`, 0) AS peso_detail, ',
            'COALESCE(f.`PONTOS_PRODUCAO`, 0) AS pontos_detail, ',
            'COALESCE(f.`DS_METRICA`, '''') AS ds_metrica, ',
            'COALESCE(f.`DS_FAMILIA`, CAST(f.`ID_FAMILIA` AS CHAR)) AS nome_familia, ',
            'COALESCE(f.`DS_INDICADOR`, CAST(f.`ID_INDICADOR` AS CHAR)) AS nome_indicador, ',
            'COALESCE(NULLIF(TRIM(COALESCE(f.`ITEM_AB`, '''')), ''''), NULLIF(TRIM(COALESCE(f.`LABEL`, '''')), ''''), ''Sem subindicador'') AS nome_subindicador ',
            'FROM ', v_table_sql, ' f ',
            'LEFT JOIN dHierarquia hg ON hg.ativo_sn = 1 AND CAST(hg.`funcional` AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci ',
            v_join_management_sql,
            'WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes)
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_diretoria), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_regional), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_agencia), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci AND gg.funcional_gerente_gestao COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;

        SET v_sql = CONCAT(v_sql, ' ORDER BY nome_diretoria, nome_regional, nome_agencia, nome_gerente_gestao, nome_gerente, nome_familia, nome_indicador, nome_subindicador');

        SET @sp_pobj_list_snapshot_detail_rows_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_snapshot_detail_rows_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_list_subindicator_totals_by_indicator;

DELIMITER $$

CREATE PROCEDURE sp_pobj_list_subindicator_totals_by_indicator(
    IN p_start_date DATE,
    IN p_end_date DATE,
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente_gestao_functionals_csv TEXT,
    IN p_gerente_gestao_agencies_csv TEXT,
    IN p_gerente VARCHAR(32),
    IN p_familia VARCHAR(64),
    IN p_indicador VARCHAR(64)
)
BEGIN
    DECLARE v_has_realizado_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_date_filter_sql LONGTEXT DEFAULT '';
    DECLARE v_sql LONGTEXT;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fRealizado'
    ) INTO v_has_realizado_table;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_realizado_table = 0 THEN
        SELECT
            CAST(NULL AS CHAR) AS id_indicador,
            CAST(NULL AS CHAR) AS id_subindicador,
            CAST(NULL AS CHAR) AS nome_subindicador,
            999 AS ordem_exibicao,
            0 AS total
        FROM DUAL
        WHERE 1 = 0;
    ELSE
        IF p_start_date IS NOT NULL AND p_end_date IS NOT NULL THEN
            SET v_date_filter_sql = CONCAT(
                'AND COALESCE(f.dt_realizado, '''') <> '''' ',
                'AND EXISTS (',
                    'SELECT 1 FROM dcalendario dc ',
                    'WHERE dc.data_calendario = f.dt_realizado ',
                      'AND dc.ativo_sn = 1 ',
                      'AND dc.data_calendario BETWEEN ', QUOTE(p_start_date), ' AND ', QUOTE(p_end_date),
                ') '
            );
        END IF;

        SET v_sql = CONCAT(
            'SELECT ',
            'CAST(f.id_indicador AS CHAR) AS id_indicador, ',
            'CAST(f.id_subindicador AS CHAR) AS id_subindicador, ',
            'COALESCE(s.nome_subindicador, ''Sem subindicador'') AS nome_subindicador, ',
            'COALESCE(s.ordem_exibicao, 999) AS ordem_exibicao, ',
            'COALESCE(SUM(f.valor_realizado), 0) AS total ',
            'FROM fRealizado f ',
            'LEFT JOIN dSubindicador s ON s.id_subindicador = f.id_subindicador AND s.ativo_sn = 1 ',
            'WHERE f.ativo_sn = 1 ',
            'AND COALESCE(f.id_subindicador, 0) > 0 ',
            v_date_filter_sql,
            'AND (',
                'COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GLOBAL'' ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''SELF'' AND CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_scope_functional, '')), ' USING utf8) COLLATE utf8_unicode_ci) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''DR'' AND FIND_IN_SET(CAST(f.juncao_dr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') = ''GR'' AND FIND_IN_SET(CAST(f.juncao_gr AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (COALESCE(', QUOTE(COALESCE(p_scope_code, 'GLOBAL')), ', ''GLOBAL'') NOT IN (''GLOBAL'', ''SELF'', ''DR'', ''GR'') AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
            ') ',
            'AND (', QUOTE(COALESCE(p_segmento, '')), ' = '''' OR f.segmento = ', QUOTE(COALESCE(p_segmento, '')), ') ',
            'AND (', QUOTE(COALESCE(p_diretoria, '')), ' = '''' OR f.juncao_dr = ', QUOTE(COALESCE(p_diretoria, '')), ') ',
            'AND (', QUOTE(COALESCE(p_regional, '')), ' = '''' OR f.juncao_gr = ', QUOTE(COALESCE(p_regional, '')), ') ',
            'AND (', QUOTE(COALESCE(p_agencia, '')), ' = '''' OR f.juncao_ag = ', QUOTE(COALESCE(p_agencia, '')), ') ',
            'AND (',
                QUOTE(COALESCE(p_gerente_gestao, '')), ' = '''' ',
                'OR (', v_has_management_table, ' = 1 AND FIND_IN_SET(CAST(f.funcional AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_functionals_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) ',
                'OR (', v_has_management_table, ' = 0 AND FIND_IN_SET(CAST(f.juncao_ag AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_gerente_gestao_agencies_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)',
            ') ',
            'AND (', QUOTE(COALESCE(p_gerente, '')), ' = '''' OR f.funcional = ', QUOTE(COALESCE(p_gerente, '')), ') ',
            'AND (', QUOTE(COALESCE(p_familia, '')), ' = '''' OR EXISTS (',
                'SELECT 1 FROM dIndicador i ',
                'WHERE i.id_indicador = f.id_indicador ',
                  'AND i.id_familia = ', QUOTE(COALESCE(p_familia, '')), ' ',
                  'AND i.ativo_sn = 1',
            ')) ',
            'AND (', QUOTE(COALESCE(p_indicador, '')), ' = '''' OR f.id_indicador = ', QUOTE(COALESCE(p_indicador, '')), ') ',
            'GROUP BY f.id_indicador, f.id_subindicador, s.nome_subindicador, s.ordem_exibicao ',
            'ORDER BY f.id_indicador, COALESCE(s.ordem_exibicao, 999), s.nome_subindicador'
        );

        SET @sp_pobj_list_subindicator_totals_by_indicator_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_list_subindicator_totals_by_indicator_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_table_has_visible_scope_data;

DELIMITER $$

CREATE PROCEDURE sp_pobj_table_has_visible_scope_data(
    IN p_table_name VARCHAR(64),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_scope_sql LONGTEXT DEFAULT '1 = 1';
    DECLARE v_sql LONGTEXT;

    IF COALESCE(p_table_name, '') = '' OR COALESCE(p_table_name, '') NOT REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT 0 AS has_rows;
    ELSE
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_general_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_general_ci
        ) INTO v_has_table;

        IF v_has_table = 0 THEN
            SELECT 0 AS has_rows;
        ELSE
            CASE UPPER(COALESCE(p_scope_code, 'GLOBAL'))
                WHEN 'SELF' THEN
                    SET v_scope_sql = CONCAT(
                        'CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(COALESCE(p_scope_functional, '')), ' USING utf8) COLLATE utf8_unicode_ci'
                    );
                WHEN 'SG' THEN
                    IF COALESCE(p_scope_allowed_csv, '') = '' THEN
                        SET v_scope_sql = '0 = 1';
                    ELSE
                        SET v_scope_sql = CONCAT(
                            'EXISTS (',
                                'SELECT 1 FROM dMesu sm ',
                                'INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 ',
                                'WHERE sm.ativo_sn = 1 ',
                                  'AND CAST(sm.juncao_ag AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci ',
                                  'AND FIND_IN_SET(CAST(ss.segmento AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0',
                            ')'
                        );
                    END IF;
                WHEN 'DR' THEN
                    SET v_scope_sql = CONCAT(
                        'FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0'
                    );
                WHEN 'GR' THEN
                    SET v_scope_sql = CONCAT(
                        'FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0'
                    );
                WHEN 'GLOBAL' THEN
                    SET v_scope_sql = '1 = 1';
                ELSE
                    SET v_scope_sql = CONCAT(
                        'FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0'
                    );
            END CASE;

            SET v_sql = CONCAT(
                'SELECT EXISTS (',
                    'SELECT 1 FROM `', p_table_name, '` f ',
                    'WHERE f.ativo_sn = 1 ',
                      'AND ', v_scope_sql, ' ',
                    'LIMIT 1',
                ') AS has_rows'
            );

            SET @sp_pobj_table_has_visible_scope_data_sql = v_sql;
            PREPARE stmt FROM @sp_pobj_table_has_visible_scope_data_sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;
        END IF;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_get_variable_summary;

DELIMITER $$

CREATE PROCEDURE sp_pobj_get_variable_summary(
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_profile_level VARCHAR(16),
    IN p_profile_functional VARCHAR(32),
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32)
)
BEGIN
    DECLARE v_has_variable_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_sql LONGTEXT;
    DECLARE v_functional_field VARCHAR(128) DEFAULT 'CAST(v.`FUNCIONAL` AS CHAR) COLLATE utf8_unicode_ci';

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'f_variavel'
    ) INTO v_has_variable_table;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_variable_table = 0 THEN
        SELECT 0 AS meta_total, 0 AS realizado_total;
    ELSE
        SET v_sql = CONCAT(
            'SELECT ',
            'COALESCE(SUM(COALESCE(v.`VLR_META`, 0)), 0) AS meta_total, ',
            'COALESCE(SUM(COALESCE(v.`VLR_REALIZADO`, 0)), 0) AS realizado_total ',
            'FROM `f_variavel` v ',
            'WHERE v.ativo_sn = 1 ',
            'AND v.`ANOMES` = ', QUOTE(p_anomes)
        );

        IF UPPER(COALESCE(p_profile_level, '')) IN ('GC', 'PA', 'AS') AND COALESCE(TRIM(p_profile_functional), '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_functional_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF UPPER(COALESCE(p_profile_level, '')) IN ('GG', 'TL') AND COALESCE(TRIM(p_profile_functional), '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (', v_functional_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND gg.funcional_gerente_gestao = ', QUOTE(p_profile_functional), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND ', v_functional_field, ' = CONVERT(', QUOTE(p_profile_functional), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_functional_field, ' = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND (EXISTS (SELECT 1 FROM fMultiJuncao mj WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''SG'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND FIND_IN_SET(mj.juncao COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) OR EXISTS (SELECT 1 FROM fMultiJuncao mj INNER JOIN dMesu dm ON dm.ativo_sn = 1 AND CAST(dm.juncao_ag AS CHAR) = CAST(mj.juncao AS CHAR) INNER JOIN dSegmento ss ON ss.id_segmento = dm.id_segmento AND ss.ativo_sn = 1 WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''AG'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) OR EXISTS (SELECT 1 FROM fMultiJuncao mj INNER JOIN dMesu dm ON dm.ativo_sn = 1 AND CAST(dm.juncao_gr AS CHAR) = CAST(mj.juncao AS CHAR) INNER JOIN dSegmento ss ON ss.id_segmento = dm.id_segmento AND ss.ativo_sn = 1 WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''GR'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) OR EXISTS (SELECT 1 FROM fMultiJuncao mj INNER JOIN dMesu dm ON dm.ativo_sn = 1 AND CAST(dm.juncao_dr AS CHAR) = CAST(mj.juncao AS CHAR) INNER JOIN dSegmento ss ON ss.id_segmento = dm.id_segmento AND ss.ativo_sn = 1 WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''DR'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0))');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND (EXISTS (SELECT 1 FROM fMultiJuncao mj WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''DR'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND FIND_IN_SET(mj.juncao COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) OR EXISTS (SELECT 1 FROM fMultiJuncao mj INNER JOIN dMesu dm ON dm.ativo_sn = 1 AND CAST(dm.juncao_gr AS CHAR) = CAST(mj.juncao AS CHAR) WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''GR'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND FIND_IN_SET(dm.juncao_dr COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) OR EXISTS (SELECT 1 FROM fMultiJuncao mj INNER JOIN dMesu dm ON dm.ativo_sn = 1 AND CAST(dm.juncao_ag AS CHAR) = CAST(mj.juncao AS CHAR) WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''AG'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND FIND_IN_SET(dm.juncao_dr COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0))');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND (EXISTS (SELECT 1 FROM fMultiJuncao mj WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''GR'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND FIND_IN_SET(mj.juncao COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0) OR EXISTS (SELECT 1 FROM fMultiJuncao mj INNER JOIN dMesu dm ON dm.ativo_sn = 1 AND CAST(dm.juncao_ag AS CHAR) = CAST(mj.juncao AS CHAR) WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''AG'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND FIND_IN_SET(dm.juncao_gr COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0))');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM fMultiJuncao mj WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''AG'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND FIND_IN_SET(mj.juncao COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND (EXISTS (SELECT 1 FROM fMultiJuncao mj WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''SG'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND mj.juncao COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci) OR EXISTS (SELECT 1 FROM fMultiJuncao mj INNER JOIN dMesu dm ON dm.ativo_sn = 1 AND CAST(dm.juncao_ag AS CHAR) = CAST(mj.juncao AS CHAR) INNER JOIN dSegmento ss ON ss.id_segmento = dm.id_segmento AND ss.ativo_sn = 1 WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''AG'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND ss.segmento COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci) OR EXISTS (SELECT 1 FROM fMultiJuncao mj INNER JOIN dMesu dm ON dm.ativo_sn = 1 AND CAST(dm.juncao_gr AS CHAR) = CAST(mj.juncao AS CHAR) INNER JOIN dSegmento ss ON ss.id_segmento = dm.id_segmento AND ss.ativo_sn = 1 WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''GR'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND ss.segmento COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci) OR EXISTS (SELECT 1 FROM fMultiJuncao mj INNER JOIN dMesu dm ON dm.ativo_sn = 1 AND CAST(dm.juncao_dr AS CHAR) = CAST(mj.juncao AS CHAR) INNER JOIN dSegmento ss ON ss.id_segmento = dm.id_segmento AND ss.ativo_sn = 1 WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''DR'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND ss.segmento COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci))');
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND (EXISTS (SELECT 1 FROM fMultiJuncao mj WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''DR'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND mj.juncao COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_diretoria), ' USING utf8) COLLATE utf8_unicode_ci) OR EXISTS (SELECT 1 FROM fMultiJuncao mj INNER JOIN dMesu dm ON dm.ativo_sn = 1 AND CAST(dm.juncao_gr AS CHAR) = CAST(mj.juncao AS CHAR) WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''GR'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND dm.juncao_dr COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_diretoria), ' USING utf8) COLLATE utf8_unicode_ci) OR EXISTS (SELECT 1 FROM fMultiJuncao mj INNER JOIN dMesu dm ON dm.ativo_sn = 1 AND CAST(dm.juncao_ag AS CHAR) = CAST(mj.juncao AS CHAR) WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''AG'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND dm.juncao_dr COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_diretoria), ' USING utf8) COLLATE utf8_unicode_ci))');
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND (EXISTS (SELECT 1 FROM fMultiJuncao mj WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''GR'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND mj.juncao COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_regional), ' USING utf8) COLLATE utf8_unicode_ci) OR EXISTS (SELECT 1 FROM fMultiJuncao mj INNER JOIN dMesu dm ON dm.ativo_sn = 1 AND CAST(dm.juncao_ag AS CHAR) = CAST(mj.juncao AS CHAR) WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''AG'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND dm.juncao_gr COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_regional), ' USING utf8) COLLATE utf8_unicode_ci))');
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM fMultiJuncao mj WHERE mj.ativo_sn = 1 AND mj.tipo_juncao = ''AG'' AND CAST(mj.funcional AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND mj.juncao COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_agencia), ' USING utf8) COLLATE utf8_unicode_ci)');
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (', v_functional_field, ' = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = ', v_functional_field, ' AND gg.funcional_gerente_gestao = ', QUOTE(p_gerente_gestao), '))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND ', v_functional_field, ' = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND ', v_functional_field, ' = CONVERT(', QUOTE(p_gerente), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;

        SET @sp_pobj_get_variable_summary_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_get_variable_summary_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_pobj_count_semestral_visible_units;

DELIMITER $$

CREATE PROCEDURE sp_pobj_count_semestral_visible_units(
    IN p_table_name VARCHAR(64),
    IN p_anomes VARCHAR(16),
    IN p_scope_code VARCHAR(16),
    IN p_scope_functional VARCHAR(32),
    IN p_scope_allowed_csv TEXT,
    IN p_segmento VARCHAR(64),
    IN p_diretoria VARCHAR(64),
    IN p_regional VARCHAR(64),
    IN p_agencia VARCHAR(64),
    IN p_gerente_gestao VARCHAR(32),
    IN p_gerente VARCHAR(32)
)
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_has_management_table TINYINT DEFAULT 0;
    DECLARE v_table_sql TEXT;
    DECLARE v_sql LONGTEXT;

    IF p_table_name REGEXP '^[A-Za-z0-9_]+$' THEN
        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_unicode_ci = CONVERT(p_table_name USING utf8) COLLATE utf8_unicode_ci
        ) INTO v_has_table;
    END IF;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fGestaoGerente'
    ) INTO v_has_management_table;

    IF v_has_table = 0 THEN
        SELECT 0 AS visible_units;
    ELSE
        SET v_table_sql = CONCAT('`', REPLACE(p_table_name, '`', '``'), '`');
        SET v_sql = CONCAT(
            'SELECT COUNT(DISTINCT CAST(f.`COD_UNIDADE` AS CHAR)) AS visible_units ',
            'FROM ', v_table_sql, ' f ',
            'WHERE f.ativo_sn = 1 AND f.`ANOMES` = ', QUOTE(p_anomes)
        );

        IF COALESCE(p_scope_code, 'GLOBAL') = 'SELF' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_scope_functional), ' USING utf8) COLLATE utf8_unicode_ci');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'SG' THEN
            SET v_sql = CONCAT(v_sql, ' AND EXISTS (SELECT 1 FROM dMesu sm INNER JOIN dSegmento ss ON ss.id_segmento = sm.id_segmento AND ss.ativo_sn = 1 WHERE sm.ativo_sn = 1 AND CAST(sm.juncao_ag AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR) AND FIND_IN_SET(ss.segmento COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0)');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'DR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') = 'GR' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        ELSEIF COALESCE(p_scope_code, 'GLOBAL') <> 'GLOBAL' THEN
            SET v_sql = CONCAT(v_sql, ' AND FIND_IN_SET(CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci, CONVERT(', QUOTE(COALESCE(p_scope_allowed_csv, '')), ' USING utf8) COLLATE utf8_unicode_ci) > 0');
        END IF;

        IF COALESCE(p_segmento, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`ID_PROGRAMA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_segmento), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_diretoria, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_DIRETORIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_diretoria), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_regional, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_REGIONAL` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_regional), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_agencia, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_AGENCIA` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_agencia), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;
        IF COALESCE(p_gerente_gestao, '') <> '' THEN
            IF v_has_management_table = 1 THEN
                SET v_sql = CONCAT(v_sql, ' AND (CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci OR EXISTS (SELECT 1 FROM fGestaoGerente gg WHERE gg.ativo_sn = 1 AND CAST(gg.funcional_gerente AS CHAR) COLLATE utf8_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci AND gg.funcional_gerente_gestao COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci))');
            ELSE
                SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente_gestao), ' USING utf8) COLLATE utf8_unicode_ci');
            END IF;
        END IF;
        IF COALESCE(p_gerente, '') <> '' THEN
            SET v_sql = CONCAT(v_sql, ' AND CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8_unicode_ci = CONVERT(', QUOTE(p_gerente), ' USING utf8) COLLATE utf8_unicode_ci');
        END IF;

        SET @sp_pobj_count_semestral_visible_units_sql = v_sql;
        PREPARE stmt FROM @sp_pobj_count_semestral_visible_units_sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_omega_check_assignable_analyst;
DROP PROCEDURE IF EXISTS sp_omega_check_analyst_team_mapping;

DELIMITER $$

CREATE PROCEDURE sp_omega_check_assignable_analyst(
    IN p_functional VARCHAR(32)
)
BEGIN
    DECLARE v_has_hierarchy_table TINYINT DEFAULT 0;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'dHierarquia'
    ) INTO v_has_hierarchy_table;

    IF COALESCE(p_functional, '') = '' OR v_has_hierarchy_table = 0 THEN
        SELECT 0 AS is_assignable;
    ELSE
        SELECT EXISTS(
            SELECT 1
            FROM `dHierarquia`
            WHERE funcional COLLATE utf8_general_ci = CONVERT(COALESCE(p_functional, '') USING utf8) COLLATE utf8_general_ci
              AND ativo_sn = 1
              AND nivel IN ('AG', 'GG', 'TL', 'GC', 'PA', 'AS')
            LIMIT 1
        ) AS is_assignable;
    END IF;
END$$

CREATE PROCEDURE sp_omega_check_analyst_team_mapping(
    IN p_team_id INT,
    IN p_functional VARCHAR(32)
)
BEGIN
    DECLARE v_has_analyst_team_table TINYINT DEFAULT 0;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fomegaanalistatime'
    ) INTO v_has_analyst_team_table;

    IF COALESCE(p_team_id, 0) <= 0 OR COALESCE(p_functional, '') = '' OR v_has_analyst_team_table = 0 THEN
        SELECT 0 AS is_mapped;
    ELSE
        SELECT EXISTS(
            SELECT 1
            FROM `fomegaanalistatime`
            WHERE id_omega_time = p_team_id
              AND funcional_analista COLLATE utf8_general_ci = CONVERT(COALESCE(p_functional, '') USING utf8) COLLATE utf8_general_ci
              AND ativo_sn = 1
            LIMIT 1
        ) AS is_mapped;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_omega_list_mapped_team_ids;

DELIMITER $$

CREATE PROCEDURE sp_omega_list_mapped_team_ids(
    IN p_functional VARCHAR(32),
    IN p_role VARCHAR(16)
)
BEGIN
    DECLARE v_table_name VARCHAR(64);
    DECLARE v_column_name VARCHAR(64);
    DECLARE v_has_table TINYINT DEFAULT 0;
    DECLARE v_sql LONGTEXT;

    IF COALESCE(p_functional, '') = '' THEN
        SELECT 0 AS id_omega_time FROM DUAL WHERE 1 = 0;
    ELSE
        IF LOWER(COALESCE(p_role, '')) = 'analyst' THEN
            SET v_table_name = 'fomegaanalistatime';
            SET v_column_name = 'funcional_analista';
        ELSE
            SET v_table_name = 'fomegafocaltime';
            SET v_column_name = 'funcional_focal';
        END IF;

        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_general_ci = CONVERT(v_table_name USING utf8) COLLATE utf8_general_ci
        ) INTO v_has_table;

        IF v_has_table = 0 THEN
            SELECT 0 AS id_omega_time FROM DUAL WHERE 1 = 0;
        ELSE
            SET v_sql = CONCAT(
                'SELECT DISTINCT id_omega_time ',
                'FROM `', v_table_name, '` ',
                'WHERE ativo_sn = 1 ',
                'AND `', v_column_name, '` COLLATE utf8_general_ci = CONVERT(', QUOTE(COALESCE(p_functional, '')), ' USING utf8) COLLATE utf8_general_ci'
            );

            SET @sp_omega_list_mapped_team_ids_sql = v_sql;
            PREPARE stmt FROM @sp_omega_list_mapped_team_ids_sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;
        END IF;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_omega_list_status_options;

DELIMITER $$

CREATE PROCEDURE sp_omega_list_status_options()
BEGIN
    DECLARE v_has_table TINYINT DEFAULT 0;

    SELECT EXISTS(
        SELECT 1
        FROM information_schema.TABLES
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'domegastatuschamado'
    ) INTO v_has_table;

    IF v_has_table = 0 THEN
        SELECT
            CAST(NULL AS CHAR) AS codigo_status,
            CAST(NULL AS CHAR) AS nome_status,
            CAST(NULL AS CHAR) AS cor_hex
        FROM DUAL
        WHERE 1 = 0;
    ELSE
        SELECT codigo_status, nome_status, cor_hex
        FROM `domegastatuschamado`
        WHERE ativo_sn = 1
        ORDER BY ordem_fluxo, nome_status;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_omega_list_team_members;

DELIMITER $$

CREATE PROCEDURE sp_omega_list_team_members(
    IN p_team_id INT,
    IN p_role VARCHAR(16)
)
BEGIN
    DECLARE v_table_name VARCHAR(64);
    DECLARE v_column_name VARCHAR(64);
    DECLARE v_has_member_table TINYINT DEFAULT 0;
    DECLARE v_has_hierarchy_table TINYINT DEFAULT 0;
    DECLARE v_name_sql LONGTEXT;
    DECLARE v_join_sql LONGTEXT DEFAULT '';
    DECLARE v_sql LONGTEXT;

    IF COALESCE(p_team_id, 0) <= 0 THEN
        SELECT CAST(NULL AS CHAR) AS functional, CAST(NULL AS CHAR) AS name, CAST(NULL AS CHAR) AS level FROM DUAL WHERE 1 = 0;
    ELSE
        IF LOWER(COALESCE(p_role, '')) = 'analyst' THEN
            SET v_table_name = 'fomegaanalistatime';
            SET v_column_name = 'funcional_analista';
        ELSE
            SET v_table_name = 'fomegafocaltime';
            SET v_column_name = 'funcional_focal';
        END IF;

        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME COLLATE utf8_general_ci = CONVERT(v_table_name USING utf8) COLLATE utf8_general_ci
        ) INTO v_has_member_table;

        SELECT EXISTS(
            SELECT 1
            FROM information_schema.TABLES
            WHERE TABLE_SCHEMA = DATABASE()
              AND TABLE_NAME = 'dHierarquia'
        ) INTO v_has_hierarchy_table;

        IF v_has_member_table = 0 THEN
            SELECT CAST(NULL AS CHAR) AS functional, CAST(NULL AS CHAR) AS name, CAST(NULL AS CHAR) AS level FROM DUAL WHERE 1 = 0;
        ELSE
            IF v_has_hierarchy_table = 1 THEN
                SET v_join_sql = CONCAT(
                    'LEFT JOIN `dHierarquia` h ON h.funcional = m.`', v_column_name, '` AND h.ativo_sn = 1 '
                );
                SET v_name_sql = CONCAT(
                    'COALESCE(h.nome, m.`', v_column_name, '`) AS name, COALESCE(h.nivel, '''') AS level '
                );
            ELSE
                SET v_name_sql = CONCAT(
                    'm.`', v_column_name, '` AS name, '''' AS level '
                );
            END IF;

            SET v_sql = CONCAT(
                'SELECT ',
                    'm.`', v_column_name, '` AS functional, ',
                    v_name_sql,
                'FROM `', v_table_name, '` m ',
                v_join_sql,
                'WHERE m.id_omega_time = ', CAST(p_team_id AS UNSIGNED), ' ',
                  'AND m.ativo_sn = 1 ',
                'ORDER BY name'
            );

            SET @sp_omega_list_team_members_sql = v_sql;
            PREPARE stmt FROM @sp_omega_list_team_members_sql;
            EXECUTE stmt;
            DEALLOCATE PREPARE stmt;
        END IF;
    END IF;
END$$

DELIMITER ;




DROP PROCEDURE IF EXISTS sp_omega_list_source_rows;
DROP PROCEDURE IF EXISTS sp_omega_count_calls_by_view;
DROP PROCEDURE IF EXISTS sp_omega_get_call_by_id;
DROP PROCEDURE IF EXISTS sp_omega_get_status_record;
DROP PROCEDURE IF EXISTS sp_omega_list_teams_by_ids;
DROP PROCEDURE IF EXISTS sp_omega_list_all_active_teams;
DROP PROCEDURE IF EXISTS sp_omega_find_team_by_code;
DROP PROCEDURE IF EXISTS sp_omega_find_team_by_name;
DROP PROCEDURE IF EXISTS sp_omega_list_assignable_analyst_candidates;
DROP PROCEDURE IF EXISTS sp_omega_list_movements_by_call_ids;
DROP PROCEDURE IF EXISTS sp_omega_list_comments_by_call_ids;
DROP PROCEDURE IF EXISTS sp_omega_team_code_exists;

DELIMITER $$

CREATE PROCEDURE sp_omega_list_source_rows(
    IN p_view VARCHAR(16) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_functional VARCHAR(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_team_ids_csv TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci
)
BEGIN
    SELECT
        c.id_omega_chamado,
        c.titulo,
        c.descricao_abertura,
        c.solicitante_nome,
        c.solicitante_funcional,
        c.solicitante_segmento,
        c.funcional_analista_atual,
        c.dt_abertura,
        c.dt_ultimo_evento,
        c.dt_fechamento,
        c.resolucao_final,
        COALESCE(c.prioridade_label, '') AS priority_label,
        COALESCE(t.codigo_time, '') AS codigo_time,
        COALESCE(t.nome_time, '') AS nome_time,
        COALESCE(cat.nome_categoria, '') AS nome_categoria,
        COALESCE(h.nome, '') AS analyst_name,
        COALESCE(s.nome_status, 'Sem status') AS nome_status,
        COALESCE(s.codigo_status, 'SEM_STATUS') AS codigo_status,
        COALESCE(s.cor_hex, '#cbd5e1') AS cor_hex
    FROM `fomegachamado` c
    LEFT JOIN `domegastatuschamado` s
        ON s.id_omega_status = c.id_omega_status_atual
    LEFT JOIN `domegatimes` t
        ON t.id_omega_time = c.id_omega_time_atual
    LEFT JOIN `domegacategorias` cat
        ON cat.id_omega_categoria = c.id_omega_categoria_atual
    LEFT JOIN `dHierarquia` h
        ON h.funcional = c.funcional_analista_atual
       AND h.ativo_sn = 1
    WHERE c.ativo_sn = 1
      AND (
            (LOWER(TRIM(COALESCE(p_view, 'my-calls'))) = 'my-work'
                AND TRIM(COALESCE(p_functional, '')) <> ''
                AND REPLACE(TRIM(COALESCE(p_team_ids_csv, '')), ' ', '') <> ''
                AND c.funcional_analista_atual COLLATE utf8_unicode_ci = TRIM(COALESCE(p_functional, '')) COLLATE utf8_unicode_ci
                AND FIND_IN_SET(
                    CAST(c.id_omega_time_atual AS CHAR CHARACTER SET utf8) COLLATE utf8_unicode_ci,
                    REPLACE(TRIM(COALESCE(p_team_ids_csv, '')), ' ', '') COLLATE utf8_unicode_ci
                ) > 0)
            OR
            (LOWER(TRIM(COALESCE(p_view, 'my-calls'))) = 'team-queue'
                AND REPLACE(TRIM(COALESCE(p_team_ids_csv, '')), ' ', '') <> ''
                AND FIND_IN_SET(
                    CAST(c.id_omega_time_atual AS CHAR CHARACTER SET utf8) COLLATE utf8_unicode_ci,
                    REPLACE(TRIM(COALESCE(p_team_ids_csv, '')), ' ', '') COLLATE utf8_unicode_ci
                ) > 0)
            OR
            ((LOWER(TRIM(COALESCE(p_view, 'my-calls'))) NOT IN ('my-work', 'team-queue'))
                AND TRIM(COALESCE(p_functional, '')) <> ''
                AND c.solicitante_funcional COLLATE utf8_unicode_ci = TRIM(COALESCE(p_functional, '')) COLLATE utf8_unicode_ci)
          )
    ORDER BY COALESCE(c.dt_ultimo_evento, c.dt_abertura) DESC, c.id_omega_chamado DESC;
END$$

CREATE PROCEDURE sp_omega_count_calls_by_view(
    IN p_view VARCHAR(16) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_functional VARCHAR(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_team_ids_csv TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci
)
BEGIN
    SELECT
        COUNT(*) AS total_rows
    FROM `fomegachamado` c
    WHERE c.ativo_sn = 1
      AND (
            (LOWER(TRIM(COALESCE(p_view, 'my-calls'))) = 'my-work'
                AND TRIM(COALESCE(p_functional, '')) <> ''
                AND REPLACE(TRIM(COALESCE(p_team_ids_csv, '')), ' ', '') <> ''
                AND c.funcional_analista_atual COLLATE utf8_unicode_ci = TRIM(COALESCE(p_functional, '')) COLLATE utf8_unicode_ci
                AND FIND_IN_SET(
                    CAST(c.id_omega_time_atual AS CHAR CHARACTER SET utf8) COLLATE utf8_unicode_ci,
                    REPLACE(TRIM(COALESCE(p_team_ids_csv, '')), ' ', '') COLLATE utf8_unicode_ci
                ) > 0)
            OR
            (LOWER(TRIM(COALESCE(p_view, 'my-calls'))) = 'team-queue'
                AND REPLACE(TRIM(COALESCE(p_team_ids_csv, '')), ' ', '') <> ''
                AND FIND_IN_SET(
                    CAST(c.id_omega_time_atual AS CHAR CHARACTER SET utf8) COLLATE utf8_unicode_ci,
                    REPLACE(TRIM(COALESCE(p_team_ids_csv, '')), ' ', '') COLLATE utf8_unicode_ci
                ) > 0)
            OR
            ((LOWER(TRIM(COALESCE(p_view, 'my-calls'))) NOT IN ('my-work', 'team-queue'))
                AND TRIM(COALESCE(p_functional, '')) <> ''
                AND c.solicitante_funcional COLLATE utf8_unicode_ci = TRIM(COALESCE(p_functional, '')) COLLATE utf8_unicode_ci)
          );
END$$

CREATE PROCEDURE sp_omega_get_call_by_id(
    IN p_call_id BIGINT
)
BEGIN
    SELECT
        c.id_omega_chamado,
        c.solicitante_funcional,
        c.solicitante_nome,
        c.solicitante_nivel,
        c.solicitante_juncao_ag,
        c.solicitante_juncao_gr,
        c.solicitante_juncao_dr,
        c.solicitante_segmento,
        c.id_omega_time_abertura,
        c.id_omega_categoria_abertura,
        c.id_omega_time_atual,
        c.id_omega_categoria_atual,
        c.id_omega_status_atual,
        c.funcional_analista_atual,
        c.titulo,
        c.descricao_abertura,
        c.dt_abertura,
        c.dt_ultimo_evento,
        c.dt_fechamento,
        c.resolucao_final,
        COALESCE(c.prioridade_label, '') AS priority_label,
        COALESCE(t.codigo_time, '') AS codigo_time,
        COALESCE(t.nome_time, '') AS nome_time,
        COALESCE(cat.nome_categoria, '') AS nome_categoria,
        COALESCE(h.nome, '') AS analyst_name,
        COALESCE(s.nome_status, 'Sem status') AS nome_status,
        COALESCE(s.codigo_status, 'SEM_STATUS') AS codigo_status,
        COALESCE(s.cor_hex, '#cbd5e1') AS cor_hex
    FROM `fomegachamado` c
    LEFT JOIN `domegastatuschamado` s
        ON s.id_omega_status = c.id_omega_status_atual
    LEFT JOIN `domegatimes` t
        ON t.id_omega_time = c.id_omega_time_atual
    LEFT JOIN `domegacategorias` cat
        ON cat.id_omega_categoria = c.id_omega_categoria_atual
    LEFT JOIN `dHierarquia` h
        ON h.funcional = c.funcional_analista_atual
       AND h.ativo_sn = 1
    WHERE c.ativo_sn = 1
      AND c.id_omega_chamado = COALESCE(p_call_id, 0)
    LIMIT 1;
END$$

CREATE PROCEDURE sp_omega_get_status_record(
    IN p_status_code VARCHAR(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci
)
BEGIN
    SELECT
        s.id_omega_status,
        s.codigo_status,
        s.nome_status,
        s.cor_hex
    FROM `domegastatuschamado` s
    WHERE s.ativo_sn = 1
      AND s.codigo_status COLLATE utf8_unicode_ci = TRIM(COALESCE(p_status_code, '')) COLLATE utf8_unicode_ci
    LIMIT 1;
END$$

CREATE PROCEDURE sp_omega_list_teams_by_ids(
    IN p_team_ids_csv TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci
)
BEGIN
    SELECT
        t.id_omega_time,
        t.codigo_time,
        t.nome_time
    FROM `domegatimes` t
    WHERE t.ativo_sn = 1
      AND REPLACE(TRIM(COALESCE(p_team_ids_csv, '')), ' ', '') <> ''
      AND FIND_IN_SET(
            CAST(t.id_omega_time AS CHAR CHARACTER SET utf8) COLLATE utf8_unicode_ci,
            REPLACE(TRIM(COALESCE(p_team_ids_csv, '')), ' ', '') COLLATE utf8_unicode_ci
      ) > 0
    ORDER BY t.nome_time;
END$$

CREATE PROCEDURE sp_omega_list_all_active_teams()
BEGIN
    SELECT
        t.id_omega_time,
        t.codigo_time,
        t.nome_time
    FROM `domegatimes` t
    WHERE t.ativo_sn = 1
      AND t.codigo_time <> 'EQUIPE_MATRIZ'
    ORDER BY t.nome_time;
END$$

CREATE PROCEDURE sp_omega_find_team_by_code(
    IN p_team_code VARCHAR(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci
)
BEGIN
    SELECT
        t.id_omega_time,
        t.codigo_time,
        t.nome_time
    FROM `domegatimes` t
    WHERE t.codigo_time COLLATE utf8_unicode_ci = TRIM(COALESCE(p_team_code, '')) COLLATE utf8_unicode_ci
    LIMIT 1;
END$$

CREATE PROCEDURE sp_omega_find_team_by_name(
    IN p_team_name VARCHAR(180) CHARACTER SET utf8 COLLATE utf8_unicode_ci
)
BEGIN
    SELECT
        t.id_omega_time,
        t.codigo_time,
        t.nome_time
    FROM `domegatimes` t
    WHERE t.nome_time COLLATE utf8_unicode_ci = TRIM(COALESCE(p_team_name, '')) COLLATE utf8_unicode_ci
    LIMIT 1;
END$$

CREATE PROCEDURE sp_omega_list_assignable_analyst_candidates(
    IN p_team_id BIGINT
)
BEGIN
    SELECT
        h.funcional,
        h.nome,
        h.nivel
    FROM `dHierarquia` h
    LEFT JOIN `fomegaanalistatime` a
        ON a.funcional_analista = h.funcional
       AND a.id_omega_time = COALESCE(p_team_id, 0)
       AND a.ativo_sn = 1
    WHERE h.ativo_sn = 1
      AND h.nivel IN ('AG', 'GG', 'TL', 'GC', 'PA', 'AS')
      AND a.id_omega_analista_time IS NULL
    ORDER BY h.nome;
END$$

CREATE PROCEDURE sp_omega_list_movements_by_call_ids(
    IN p_call_ids_csv TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci
)
BEGIN
    SELECT
        m.id_omega_chamado,
        m.tipo_movimentacao,
        m.funcional_responsavel,
        m.funcional_analista_origem,
        m.funcional_analista_destino,
        m.observacao,
        m.dt_movimentacao,
        COALESCE(so.nome_status, '') AS status_origem_nome,
        COALESCE(sd.nome_status, '') AS status_destino_nome,
        COALESCE(to1.nome_time, '') AS time_origem_nome,
        COALESCE(td1.nome_time, '') AS time_destino_nome,
        COALESCE(co1.nome_categoria, '') AS category_origem_nome,
        COALESCE(cd1.nome_categoria, '') AS category_destino_nome
    FROM `fomegachamadomovimentacao` m
    LEFT JOIN `domegastatuschamado` so
        ON so.id_omega_status = m.id_omega_status_origem
    LEFT JOIN `domegastatuschamado` sd
        ON sd.id_omega_status = m.id_omega_status_destino
    LEFT JOIN `domegatimes` to1
        ON to1.id_omega_time = m.id_omega_time_origem
    LEFT JOIN `domegatimes` td1
        ON td1.id_omega_time = m.id_omega_time_destino
    LEFT JOIN `domegacategorias` co1
        ON co1.id_omega_categoria = m.id_omega_categoria_origem
    LEFT JOIN `domegacategorias` cd1
        ON cd1.id_omega_categoria = m.id_omega_categoria_destino
    WHERE m.ativo_sn = 1
      AND REPLACE(TRIM(COALESCE(p_call_ids_csv, '')), ' ', '') <> ''
      AND FIND_IN_SET(
            CAST(m.id_omega_chamado AS CHAR CHARACTER SET utf8) COLLATE utf8_unicode_ci,
            REPLACE(TRIM(COALESCE(p_call_ids_csv, '')), ' ', '') COLLATE utf8_unicode_ci
      ) > 0
    ORDER BY m.dt_movimentacao ASC, m.id_omega_chamado_movimentacao ASC;
END$$

CREATE PROCEDURE sp_omega_list_comments_by_call_ids(
    IN p_call_ids_csv TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci
)
BEGIN
    SELECT
        c.id_omega_chamado,
        c.funcional_autor,
        c.tipo_autor,
        c.comentario,
        c.dt_comentario
    FROM `fomegachamadocomentario` c
    WHERE c.ativo_sn = 1
      AND REPLACE(TRIM(COALESCE(p_call_ids_csv, '')), ' ', '') <> ''
      AND FIND_IN_SET(
            CAST(c.id_omega_chamado AS CHAR CHARACTER SET utf8) COLLATE utf8_unicode_ci,
            REPLACE(TRIM(COALESCE(p_call_ids_csv, '')), ' ', '') COLLATE utf8_unicode_ci
      ) > 0
    ORDER BY c.dt_comentario ASC, c.id_omega_chamado_comentario ASC;
END$$

CREATE PROCEDURE sp_omega_team_code_exists(
    IN p_team_code VARCHAR(64) CHARACTER SET utf8 COLLATE utf8_unicode_ci
)
BEGIN
    SELECT EXISTS(
        SELECT 1
        FROM `domegatimes`
        WHERE codigo_time COLLATE utf8_unicode_ci = TRIM(COALESCE(p_team_code, '')) COLLATE utf8_unicode_ci
        LIMIT 1
    ) AS team_code_exists;
END$$

DELIMITER ;





DROP PROCEDURE IF EXISTS sp_omega_upsert_analyst_team_mapping;
DROP PROCEDURE IF EXISTS sp_omega_add_comment;
DROP PROCEDURE IF EXISTS sp_omega_update_call;
DROP PROCEDURE IF EXISTS sp_omega_insert_call;
DROP PROCEDURE IF EXISTS sp_omega_insert_team;
DROP PROCEDURE IF EXISTS sp_omega_ensure_category;
DROP PROCEDURE IF EXISTS sp_omega_ensure_team_functional_mapping;
DROP PROCEDURE IF EXISTS sp_omega_insert_movement;
DROP PROCEDURE IF EXISTS sp_omega_ensure_comment_table;
DROP PROCEDURE IF EXISTS sp_omega_ensure_movement_table;
DROP PROCEDURE IF EXISTS sp_omega_ensure_call_priority_column;

DELIMITER $$

CREATE PROCEDURE sp_omega_upsert_analyst_team_mapping(
    IN p_team_id BIGINT,
    IN p_functional VARCHAR(7) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_active_flag TINYINT,
    IN p_origin VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci
)
BEGIN
    DECLARE v_mapping_id BIGINT DEFAULT 0;

    SELECT id_omega_analista_time
      INTO v_mapping_id
    FROM `fomegaanalistatime`
    WHERE id_omega_time = COALESCE(p_team_id, 0)
      AND funcional_analista COLLATE utf8_unicode_ci = TRIM(COALESCE(p_functional, '')) COLLATE utf8_unicode_ci
    LIMIT 1;

    IF COALESCE(v_mapping_id, 0) > 0 THEN
        UPDATE `fomegaanalistatime`
           SET ativo_sn = COALESCE(p_active_flag, 0),
               origem_carga = TRIM(COALESCE(p_origin, '')),
               dt_atualizacao = CURRENT_TIMESTAMP
         WHERE id_omega_analista_time = v_mapping_id;

        SELECT 1 AS ok_flag, v_mapping_id AS mapping_id;
    ELSEIF COALESCE(p_active_flag, 0) = 1 THEN
        INSERT INTO `fomegaanalistatime` (
            id_omega_time,
            funcional_analista,
            ativo_sn,
            origem_carga
        ) VALUES (
            COALESCE(p_team_id, 0),
            TRIM(COALESCE(p_functional, '')),
            1,
            TRIM(COALESCE(p_origin, ''))
        );

        SELECT 1 AS ok_flag, LAST_INSERT_ID() AS mapping_id;
    ELSE
        SELECT 1 AS ok_flag, 0 AS mapping_id;
    END IF;
END$$

CREATE PROCEDURE sp_omega_add_comment(
    IN p_call_id BIGINT,
    IN p_functional_author VARCHAR(7) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_author_role VARCHAR(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_comment_text TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_commented_at DATETIME,
    IN p_origin VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci
)
BEGIN
    INSERT INTO `fomegachamadocomentario` (
        id_omega_chamado,
        funcional_autor,
        tipo_autor,
        comentario,
        dt_comentario,
        ativo_sn,
        origem_carga
    ) VALUES (
        COALESCE(p_call_id, 0),
        TRIM(COALESCE(p_functional_author, '')),
        TRIM(COALESCE(p_author_role, 'SOLICITANTE')),
        COALESCE(p_comment_text, ''),
        COALESCE(p_commented_at, CURRENT_TIMESTAMP),
        1,
        TRIM(COALESCE(p_origin, ''))
    );

    IF UPPER(TRIM(COALESCE(p_author_role, ''))) = 'ANALISTA'
       AND TRIM(COALESCE(p_functional_author, '')) <> '' THEN
        UPDATE `fomegachamado`
           SET dt_ultimo_evento = COALESCE(p_commented_at, CURRENT_TIMESTAMP),
               funcional_analista_atual = TRIM(COALESCE(p_functional_author, '')),
               dt_atualizacao = CURRENT_TIMESTAMP
         WHERE id_omega_chamado = COALESCE(p_call_id, 0);
    ELSE
        UPDATE `fomegachamado`
           SET dt_ultimo_evento = COALESCE(p_commented_at, CURRENT_TIMESTAMP),
               dt_atualizacao = CURRENT_TIMESTAMP
         WHERE id_omega_chamado = COALESCE(p_call_id, 0);
    END IF;

    SELECT LAST_INSERT_ID() AS comment_id;
END$$

CREATE PROCEDURE sp_omega_update_call(
    IN p_call_id BIGINT,
    IN p_requester_name VARCHAR(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_requester_level VARCHAR(2) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_junction_ag VARCHAR(4) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_junction_gr VARCHAR(4) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_junction_dr VARCHAR(4) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_segment_label VARCHAR(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_team_id BIGINT,
    IN p_category_id BIGINT,
    IN p_status_id BIGINT,
    IN p_analyst_functional VARCHAR(7) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_priority_label VARCHAR(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_title VARCHAR(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_description TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_updated_at DATETIME,
    IN p_closed_at DATETIME,
    IN p_resolution_final VARCHAR(1000) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_origin VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci
)
BEGIN
    UPDATE `fomegachamado`
       SET solicitante_nome = COALESCE(p_requester_name, ''),
           solicitante_nivel = COALESCE(NULLIF(TRIM(COALESCE(p_requester_level, '')), ''), 'GC'),
           solicitante_juncao_ag = NULLIF(TRIM(COALESCE(p_junction_ag, '')), ''),
           solicitante_juncao_gr = NULLIF(TRIM(COALESCE(p_junction_gr, '')), ''),
           solicitante_juncao_dr = NULLIF(TRIM(COALESCE(p_junction_dr, '')), ''),
           solicitante_segmento = COALESCE(NULLIF(TRIM(COALESCE(p_segment_label, '')), ''), 'POBJ'),
           id_omega_time_atual = COALESCE(p_team_id, 0),
           id_omega_categoria_atual = p_category_id,
           id_omega_status_atual = COALESCE(p_status_id, 0),
           funcional_analista_atual = NULLIF(TRIM(COALESCE(p_analyst_functional, '')), ''),
           prioridade_label = COALESCE(p_priority_label, ''),
           titulo = COALESCE(p_title, ''),
           descricao_abertura = COALESCE(p_description, ''),
           dt_ultimo_evento = COALESCE(p_updated_at, CURRENT_TIMESTAMP),
           dt_fechamento = p_closed_at,
           resolucao_final = p_resolution_final,
           ativo_sn = 1,
           origem_carga = TRIM(COALESCE(p_origin, '')),
           dt_atualizacao = CURRENT_TIMESTAMP
     WHERE id_omega_chamado = COALESCE(p_call_id, 0);

    SELECT ROW_COUNT() AS affected_rows;
END$$

CREATE PROCEDURE sp_omega_insert_call(
    IN p_requester_functional VARCHAR(7) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_requester_name VARCHAR(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_requester_level VARCHAR(2) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_junction_ag VARCHAR(4) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_junction_gr VARCHAR(4) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_junction_dr VARCHAR(4) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_segment_label VARCHAR(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_team_id BIGINT,
    IN p_category_id BIGINT,
    IN p_status_id BIGINT,
    IN p_analyst_functional VARCHAR(7) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_priority_label VARCHAR(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_title VARCHAR(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_description TEXT CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_opened_at DATETIME,
    IN p_updated_at DATETIME,
    IN p_closed_at DATETIME,
    IN p_resolution_final VARCHAR(1000) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_origin VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci
)
BEGIN
    INSERT INTO `fomegachamado` (
        solicitante_funcional,
        solicitante_nome,
        solicitante_nivel,
        solicitante_juncao_ag,
        solicitante_juncao_gr,
        solicitante_juncao_dr,
        solicitante_segmento,
        id_omega_time_abertura,
        id_omega_categoria_abertura,
        id_omega_time_atual,
        id_omega_categoria_atual,
        id_omega_status_atual,
        funcional_analista_atual,
        prioridade_label,
        titulo,
        descricao_abertura,
        dt_abertura,
        dt_ultimo_evento,
        dt_fechamento,
        resolucao_final,
        ativo_sn,
        origem_carga
    ) VALUES (
        TRIM(COALESCE(p_requester_functional, '')),
        COALESCE(p_requester_name, ''),
        COALESCE(NULLIF(TRIM(COALESCE(p_requester_level, '')), ''), 'GC'),
        NULLIF(TRIM(COALESCE(p_junction_ag, '')), ''),
        NULLIF(TRIM(COALESCE(p_junction_gr, '')), ''),
        NULLIF(TRIM(COALESCE(p_junction_dr, '')), ''),
        COALESCE(NULLIF(TRIM(COALESCE(p_segment_label, '')), ''), 'POBJ'),
        COALESCE(p_team_id, 0),
        p_category_id,
        COALESCE(p_team_id, 0),
        p_category_id,
        COALESCE(p_status_id, 0),
        NULLIF(TRIM(COALESCE(p_analyst_functional, '')), ''),
        COALESCE(p_priority_label, ''),
        COALESCE(p_title, ''),
        COALESCE(p_description, ''),
        COALESCE(p_opened_at, CURRENT_TIMESTAMP),
        COALESCE(p_updated_at, CURRENT_TIMESTAMP),
        p_closed_at,
        p_resolution_final,
        1,
        TRIM(COALESCE(p_origin, ''))
    );

    SELECT LAST_INSERT_ID() AS call_id;
END$$

CREATE PROCEDURE sp_omega_insert_team(
    IN p_team_code VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_team_name VARCHAR(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_description VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_origin VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci
)
BEGIN
    INSERT INTO `domegatimes` (
        codigo_time,
        nome_time,
        descricao,
        ativo_sn,
        origem_carga
    ) VALUES (
        TRIM(COALESCE(p_team_code, '')),
        TRIM(COALESCE(p_team_name, '')),
        COALESCE(p_description, ''),
        1,
        TRIM(COALESCE(p_origin, ''))
    );

    SELECT LAST_INSERT_ID() AS team_id;
END$$

CREATE PROCEDURE sp_omega_ensure_category(
    IN p_team_id BIGINT,
    IN p_category_name VARCHAR(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_description VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_origin VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci
)
BEGIN
    DECLARE v_category_id BIGINT DEFAULT 0;
    DECLARE v_display_order INT DEFAULT 1;

    SELECT id_omega_categoria
      INTO v_category_id
    FROM `domegacategorias`
    WHERE id_omega_time = COALESCE(p_team_id, 0)
      AND id_omega_categoria_pai IS NULL
      AND nome_categoria COLLATE utf8_unicode_ci = TRIM(COALESCE(p_category_name, '')) COLLATE utf8_unicode_ci
    LIMIT 1;

    IF COALESCE(v_category_id, 0) = 0 THEN
        SELECT COALESCE(MAX(ordem_exibicao), 0) + 1
          INTO v_display_order
        FROM `domegacategorias`
        WHERE id_omega_time = COALESCE(p_team_id, 0)
          AND id_omega_categoria_pai IS NULL;

        INSERT INTO `domegacategorias` (
            id_omega_time,
            id_omega_categoria_pai,
            ordem_nivel,
            nome_categoria,
            descricao,
            selecao_final_sn,
            ordem_exibicao,
            ativo_sn,
            origem_carga
        ) VALUES (
            COALESCE(p_team_id, 0),
            NULL,
            1,
            TRIM(COALESCE(p_category_name, '')),
            COALESCE(p_description, ''),
            1,
            GREATEST(COALESCE(v_display_order, 1), 1),
            1,
            TRIM(COALESCE(p_origin, ''))
        );

        SET v_category_id = LAST_INSERT_ID();
    END IF;

    SELECT v_category_id AS category_id;
END$$

CREATE PROCEDURE sp_omega_ensure_team_functional_mapping(
    IN p_team_id BIGINT,
    IN p_functional VARCHAR(7) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_role VARCHAR(16) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_origin VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci
)
BEGIN
    DECLARE v_mapping_id BIGINT DEFAULT 0;

    IF LOWER(TRIM(COALESCE(p_role, ''))) = 'analyst' THEN
        SELECT id_omega_analista_time
          INTO v_mapping_id
        FROM `fomegaanalistatime`
        WHERE id_omega_time = COALESCE(p_team_id, 0)
          AND funcional_analista COLLATE utf8_unicode_ci = TRIM(COALESCE(p_functional, '')) COLLATE utf8_unicode_ci
        LIMIT 1;

        IF COALESCE(v_mapping_id, 0) = 0 THEN
            INSERT INTO `fomegaanalistatime` (
                id_omega_time,
                funcional_analista,
                ativo_sn,
                origem_carga
            ) VALUES (
                COALESCE(p_team_id, 0),
                TRIM(COALESCE(p_functional, '')),
                1,
                TRIM(COALESCE(p_origin, ''))
            );

            SET v_mapping_id = LAST_INSERT_ID();
        END IF;
    ELSE
        SELECT id_omega_focal_time
          INTO v_mapping_id
        FROM `fomegafocaltime`
        WHERE id_omega_time = COALESCE(p_team_id, 0)
          AND funcional_focal COLLATE utf8_unicode_ci = TRIM(COALESCE(p_functional, '')) COLLATE utf8_unicode_ci
        LIMIT 1;

        IF COALESCE(v_mapping_id, 0) = 0 THEN
            INSERT INTO `fomegafocaltime` (
                id_omega_time,
                funcional_focal,
                ativo_sn,
                origem_carga
            ) VALUES (
                COALESCE(p_team_id, 0),
                TRIM(COALESCE(p_functional, '')),
                1,
                TRIM(COALESCE(p_origin, ''))
            );

            SET v_mapping_id = LAST_INSERT_ID();
        END IF;
    END IF;

    SELECT v_mapping_id AS mapping_id;
END$$

CREATE PROCEDURE sp_omega_insert_movement(
    IN p_call_id BIGINT,
    IN p_movement_type VARCHAR(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_responsible_functional VARCHAR(7) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_status_origin_id BIGINT,
    IN p_status_destination_id BIGINT,
    IN p_time_origin_id BIGINT,
    IN p_time_destination_id BIGINT,
    IN p_category_origin_id BIGINT,
    IN p_category_destination_id BIGINT,
    IN p_analyst_origin VARCHAR(7) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_analyst_destination VARCHAR(7) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_observation VARCHAR(1000) CHARACTER SET utf8 COLLATE utf8_unicode_ci,
    IN p_moved_at DATETIME,
    IN p_origin VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci
)
BEGIN
    INSERT INTO `fomegachamadomovimentacao` (
        id_omega_chamado,
        tipo_movimentacao,
        funcional_responsavel,
        id_omega_status_origem,
        id_omega_status_destino,
        id_omega_time_origem,
        id_omega_time_destino,
        id_omega_categoria_origem,
        id_omega_categoria_destino,
        funcional_analista_origem,
        funcional_analista_destino,
        observacao,
        dt_movimentacao,
        ativo_sn,
        origem_carga
    ) VALUES (
        COALESCE(p_call_id, 0),
        COALESCE(p_movement_type, 'ATUALIZACAO'),
        TRIM(COALESCE(p_responsible_functional, '')),
        p_status_origin_id,
        p_status_destination_id,
        p_time_origin_id,
        p_time_destination_id,
        p_category_origin_id,
        p_category_destination_id,
        NULLIF(TRIM(COALESCE(p_analyst_origin, '')), ''),
        NULLIF(TRIM(COALESCE(p_analyst_destination, '')), ''),
        p_observation,
        COALESCE(p_moved_at, CURRENT_TIMESTAMP),
        1,
        TRIM(COALESCE(p_origin, ''))
    );

    SELECT LAST_INSERT_ID() AS movement_id;
END$$

CREATE PROCEDURE sp_omega_ensure_comment_table()
BEGIN
    CREATE TABLE IF NOT EXISTS `fomegachamadocomentario` (
        `id_omega_chamado_comentario` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        `id_omega_chamado` BIGINT(20) UNSIGNED NOT NULL,
        `funcional_autor` CHAR(7) NOT NULL DEFAULT '',
        `tipo_autor` VARCHAR(20) NOT NULL DEFAULT 'SOLICITANTE',
        `comentario` TEXT NOT NULL,
        `dt_comentario` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `ativo_sn` TINYINT(1) NOT NULL DEFAULT 1,
        `origem_carga` VARCHAR(50) DEFAULT NULL,
        `dt_inclusao` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `dt_atualizacao` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id_omega_chamado_comentario`),
        KEY `idx_omega_comentario_chamado` (`id_omega_chamado`),
        KEY `idx_omega_comentario_ativo` (`ativo_sn`, `dt_comentario`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    SELECT 1 AS ok_flag;
END$$

CREATE PROCEDURE sp_omega_ensure_movement_table()
BEGIN
    CREATE TABLE IF NOT EXISTS `fomegachamadomovimentacao` (
        `id_omega_chamado_movimentacao` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        `id_omega_chamado` BIGINT(20) UNSIGNED NOT NULL,
        `tipo_movimentacao` VARCHAR(30) NOT NULL,
        `funcional_responsavel` CHAR(7) NOT NULL,
        `id_omega_status_origem` BIGINT(20) UNSIGNED DEFAULT NULL,
        `id_omega_status_destino` BIGINT(20) UNSIGNED DEFAULT NULL,
        `id_omega_time_origem` BIGINT(20) UNSIGNED DEFAULT NULL,
        `id_omega_time_destino` BIGINT(20) UNSIGNED DEFAULT NULL,
        `id_omega_categoria_origem` BIGINT(20) UNSIGNED DEFAULT NULL,
        `id_omega_categoria_destino` BIGINT(20) UNSIGNED DEFAULT NULL,
        `funcional_analista_origem` CHAR(7) DEFAULT NULL,
        `funcional_analista_destino` CHAR(7) DEFAULT NULL,
        `observacao` VARCHAR(1000) DEFAULT NULL,
        `dt_movimentacao` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `ativo_sn` TINYINT(1) NOT NULL DEFAULT 1,
        `origem_carga` VARCHAR(50) DEFAULT NULL,
        `dt_inclusao` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        `dt_atualizacao` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY (`id_omega_chamado_movimentacao`),
        KEY `idx_omega_mov_call` (`id_omega_chamado`),
        KEY `idx_omega_mov_active` (`ativo_sn`, `dt_movimentacao`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

    SELECT 1 AS ok_flag;
END$$

CREATE PROCEDURE sp_omega_ensure_call_priority_column()
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE()
          AND TABLE_NAME = 'fomegachamado'
          AND COLUMN_NAME = 'prioridade_label'
    ) THEN
        ALTER TABLE `fomegachamado`
            ADD COLUMN `prioridade_label` VARCHAR(20) DEFAULT NULL
            AFTER `funcional_analista_atual`;
    END IF;

    SELECT 1 AS ok_flag;
END$$

DELIMITER ;





DROP PROCEDURE IF EXISTS sp_encantabra_list_month_options;
DROP PROCEDURE IF EXISTS sp_encantabra_list_segment_options;
DROP PROCEDURE IF EXISTS sp_encantabra_list_junction_options;
DROP PROCEDURE IF EXISTS sp_encantabra_list_functional_options;
DROP PROCEDURE IF EXISTS sp_encantabra_list_indicator_options;
DROP PROCEDURE IF EXISTS sp_encantabra_get_summary_metrics;
DROP PROCEDURE IF EXISTS sp_encantabra_get_status_summary;
DROP PROCEDURE IF EXISTS sp_encantabra_list_monthly_scores;
DROP PROCEDURE IF EXISTS sp_encantabra_list_trimester_rows;
DROP PROCEDURE IF EXISTS sp_encantabra_list_indicator_rows;
DROP PROCEDURE IF EXISTS sp_encantabra_list_indicator_heatmap_rows;
DROP PROCEDURE IF EXISTS sp_encantabra_lookup_junction_label;
DROP PROCEDURE IF EXISTS sp_encantabra_lookup_functional_label;
DROP PROCEDURE IF EXISTS sp_encantabra_count_analytic_rows;
DROP PROCEDURE IF EXISTS sp_encantabra_list_analytic_rows;
DROP PROCEDURE IF EXISTS sp_encantabra_list_ranking_by_indicator;
DROP PROCEDURE IF EXISTS sp_encantabra_list_ranking_by_junction;
DROP PROCEDURE IF EXISTS sp_encantabra_list_ranking_by_functional;

DELIMITER $$

CREATE PROCEDURE sp_encantabra_list_month_options()
BEGIN
    SELECT DISTINCT
        CAST(e.ANO_MES AS CHAR) AS value
    FROM `encantabra` e
    WHERE e.ANO_MES IS NOT NULL
      AND CAST(e.ANO_MES AS CHAR) <> ''
    ORDER BY e.ANO_MES DESC;
END$$

CREATE PROCEDURE sp_encantabra_list_segment_options()
BEGIN
    SELECT DISTINCT
        e.SEGMENTO_PAINEL AS value
    FROM `encantabra` e
    WHERE COALESCE(e.SEGMENTO_PAINEL, '') <> ''
    ORDER BY e.SEGMENTO_PAINEL ASC;
END$$

CREATE PROCEDURE sp_encantabra_list_junction_options(
    IN p_anomes VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_segmento VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
)
BEGIN
    SELECT DISTINCT
        CAST(e.COD_JUNC AS CHAR) AS value,
        e.NOME_JUNC AS label
    FROM `encantabra` e
    WHERE (COALESCE(TRIM(p_anomes), '') = '' OR CAST(e.ANO_MES AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_anomes) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_segmento), '') = '' OR e.SEGMENTO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_segmento) COLLATE utf8mb4_unicode_ci)
      AND COALESCE(CAST(e.COD_JUNC AS CHAR), '') <> ''
      AND COALESCE(e.NOME_JUNC, '') <> ''
    ORDER BY e.NOME_JUNC ASC;
END$$

CREATE PROCEDURE sp_encantabra_list_functional_options(
    IN p_anomes VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_segmento VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_juncao VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
)
BEGIN
    SELECT DISTINCT
        CAST(e.COD_FUNC AS CHAR) AS value,
        e.NOME_FUNC AS label
    FROM `encantabra` e
    WHERE (COALESCE(TRIM(p_anomes), '') = '' OR CAST(e.ANO_MES AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_anomes) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_segmento), '') = '' OR e.SEGMENTO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_segmento) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_juncao), '') = '' OR CAST(e.COD_JUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_juncao) COLLATE utf8mb4_unicode_ci)
      AND COALESCE(CAST(e.COD_FUNC AS CHAR), '') <> ''
      AND COALESCE(e.NOME_FUNC, '') <> ''
    ORDER BY e.NOME_FUNC ASC;
END$$

CREATE PROCEDURE sp_encantabra_list_indicator_options(
    IN p_anomes VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_perfil VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_segmento VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_juncao VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_funcional VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
)
BEGIN
    SELECT DISTINCT
        e.INDICADOR AS value
    FROM `encantabra` e
    WHERE (COALESCE(TRIM(p_anomes), '') = '' OR CAST(e.ANO_MES AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_anomes) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_perfil), '') = '' OR e.TIPO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_perfil) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_segmento), '') = '' OR e.SEGMENTO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_segmento) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_juncao), '') = '' OR CAST(e.COD_JUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_juncao) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_funcional), '') = '' OR CAST(e.COD_FUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_funcional) COLLATE utf8mb4_unicode_ci)
      AND COALESCE(e.INDICADOR, '') <> ''
    ORDER BY e.INDICADOR ASC;
END$$

CREATE PROCEDURE sp_encantabra_get_summary_metrics(
    IN p_anomes VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_perfil VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_segmento VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_juncao VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_funcional VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_indicador VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
)
BEGIN
    SELECT
        COUNT(*) AS rows_total,
        COUNT(DISTINCT e.INDICADOR) AS indicators_total,
        COUNT(DISTINCT
            CASE
                WHEN TRIM(COALESCE(p_perfil, 'SG')) = 'GC' THEN NULLIF(CAST(e.COD_FUNC AS CHAR), '')
                WHEN TRIM(COALESCE(p_perfil, 'SG')) = 'AG' THEN NULLIF(CAST(e.COD_JUNC AS CHAR), '')
                ELSE NULLIF(e.SEGMENTO_PAINEL, '')
            END
        ) AS entities_total,
        COALESCE(AVG(e.META), 0) AS meta_avg,
        COALESCE(AVG(e.REALIZADO), 0) AS real_avg,
        COALESCE(AVG(COALESCE(e.NOVA_PONTUACAO, e.PONTUACAO, e.ATINGIMENTO, e.REALIZADO, 0)), 0) AS score_avg
    FROM `encantabra` e
    WHERE (COALESCE(TRIM(p_anomes), '') = '' OR CAST(e.ANO_MES AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_anomes) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_perfil), '') = '' OR e.TIPO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_perfil) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_segmento), '') = '' OR e.SEGMENTO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_segmento) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_juncao), '') = '' OR CAST(e.COD_JUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_juncao) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_funcional), '') = '' OR CAST(e.COD_FUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_funcional) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_indicador), '') = '' OR e.INDICADOR COLLATE utf8mb4_unicode_ci = TRIM(p_indicador) COLLATE utf8mb4_unicode_ci);
END$$

CREATE PROCEDURE sp_encantabra_get_status_summary(
    IN p_anomes VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_perfil VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_segmento VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_juncao VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_funcional VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_indicador VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
)
BEGIN
    SELECT
        SUM(CASE WHEN COALESCE(e.NOVA_PONTUACAO, e.PONTUACAO, e.ATINGIMENTO, e.REALIZADO, 0) >= 110 THEN 1 ELSE 0 END) AS fan,
        SUM(CASE WHEN COALESCE(e.NOVA_PONTUACAO, e.PONTUACAO, e.ATINGIMENTO, e.REALIZADO, 0) >= 90 AND COALESCE(e.NOVA_PONTUACAO, e.PONTUACAO, e.ATINGIMENTO, e.REALIZADO, 0) < 110 THEN 1 ELSE 0 END) AS encantador,
        SUM(CASE WHEN COALESCE(e.NOVA_PONTUACAO, e.PONTUACAO, e.ATINGIMENTO, e.REALIZADO, 0) >= 70 AND COALESCE(e.NOVA_PONTUACAO, e.PONTUACAO, e.ATINGIMENTO, e.REALIZADO, 0) < 90 THEN 1 ELSE 0 END) AS expectativa,
        SUM(CASE WHEN COALESCE(e.NOVA_PONTUACAO, e.PONTUACAO, e.ATINGIMENTO, e.REALIZADO, 0) < 70 THEN 1 ELSE 0 END) AS critico
    FROM `encantabra` e
    WHERE (COALESCE(TRIM(p_anomes), '') = '' OR CAST(e.ANO_MES AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_anomes) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_perfil), '') = '' OR e.TIPO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_perfil) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_segmento), '') = '' OR e.SEGMENTO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_segmento) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_juncao), '') = '' OR CAST(e.COD_JUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_juncao) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_funcional), '') = '' OR CAST(e.COD_FUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_funcional) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_indicador), '') = '' OR e.INDICADOR COLLATE utf8mb4_unicode_ci = TRIM(p_indicador) COLLATE utf8mb4_unicode_ci);
END$$

CREATE PROCEDURE sp_encantabra_list_monthly_scores(
    IN p_months_csv TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_perfil VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_segmento VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_juncao VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_funcional VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_indicador VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
)
BEGIN
    SELECT
        CAST(e.ANO_MES AS CHAR) AS ANO_MES,
        COALESCE(AVG(COALESCE(e.NOVA_PONTUACAO, e.PONTUACAO, e.ATINGIMENTO, e.REALIZADO, 0)), 0) AS score_avg
    FROM `encantabra` e
    WHERE COALESCE(TRIM(p_months_csv), '') <> ''
      AND FIND_IN_SET(
            CAST(e.ANO_MES AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci,
            REPLACE(TRIM(p_months_csv), ' ', '') COLLATE utf8mb4_unicode_ci
      ) > 0
      AND (COALESCE(TRIM(p_perfil), '') = '' OR e.TIPO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_perfil) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_segmento), '') = '' OR e.SEGMENTO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_segmento) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_juncao), '') = '' OR CAST(e.COD_JUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_juncao) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_funcional), '') = '' OR CAST(e.COD_FUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_funcional) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_indicador), '') = '' OR e.INDICADOR COLLATE utf8mb4_unicode_ci = TRIM(p_indicador) COLLATE utf8mb4_unicode_ci)
    GROUP BY e.ANO_MES
    ORDER BY e.ANO_MES ASC;
END$$

CREATE PROCEDURE sp_encantabra_list_trimester_rows(
    IN p_year CHAR(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_perfil VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_segmento VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_juncao VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_funcional VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_indicador VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
)
BEGIN
    SELECT
        e.INDICADOR,
        e.COD_INDICADOR,
        CAST(e.ANO_MES AS CHAR) AS ANO_MES,
        COALESCE(AVG(e.PESO), 0) AS peso_avg,
        COALESCE(AVG(e.REALIZADO), 0) AS real_avg,
        COALESCE(AVG(e.ATINGIMENTO), 0) AS ating_avg,
        COALESCE(AVG(COALESCE(e.NOVA_PONTUACAO, e.PONTUACAO, e.ATINGIMENTO, e.REALIZADO, 0)), 0) AS pont_avg
    FROM `encantabra` e
    WHERE COALESCE(TRIM(p_year), '') <> ''
      AND FLOOR(e.ANO_MES / 100) = CAST(TRIM(p_year) AS UNSIGNED)
      AND (COALESCE(TRIM(p_perfil), '') = '' OR e.TIPO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_perfil) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_segmento), '') = '' OR e.SEGMENTO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_segmento) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_juncao), '') = '' OR CAST(e.COD_JUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_juncao) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_funcional), '') = '' OR CAST(e.COD_FUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_funcional) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_indicador), '') = '' OR e.INDICADOR COLLATE utf8mb4_unicode_ci = TRIM(p_indicador) COLLATE utf8mb4_unicode_ci)
    GROUP BY e.INDICADOR, e.COD_INDICADOR, e.ANO_MES
    HAVING COALESCE(e.INDICADOR, '') <> ''
    ORDER BY e.INDICADOR ASC, e.ANO_MES ASC;
END$$

CREATE PROCEDURE sp_encantabra_list_indicator_rows(
    IN p_anomes VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_perfil VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_segmento VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_juncao VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_funcional VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_indicador VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
)
BEGIN
    SELECT
        e.INDICADOR,
        COALESCE(AVG(e.META), 0) AS meta_avg,
        COALESCE(AVG(e.REALIZADO), 0) AS real_avg,
        COALESCE(AVG(COALESCE(e.NOVA_PONTUACAO, e.PONTUACAO, e.ATINGIMENTO, e.REALIZADO, 0)), 0) AS score_avg,
        COUNT(*) AS row_count
    FROM `encantabra` e
    WHERE (COALESCE(TRIM(p_anomes), '') = '' OR CAST(e.ANO_MES AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_anomes) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_perfil), '') = '' OR e.TIPO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_perfil) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_segmento), '') = '' OR e.SEGMENTO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_segmento) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_juncao), '') = '' OR CAST(e.COD_JUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_juncao) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_funcional), '') = '' OR CAST(e.COD_FUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_funcional) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_indicador), '') = '' OR e.INDICADOR COLLATE utf8mb4_unicode_ci = TRIM(p_indicador) COLLATE utf8mb4_unicode_ci)
    GROUP BY e.INDICADOR
    HAVING COALESCE(e.INDICADOR, '') <> ''
    ORDER BY score_avg DESC, e.INDICADOR ASC;
END$$

CREATE PROCEDURE sp_encantabra_list_indicator_heatmap_rows(
    IN p_months_csv TEXT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_perfil VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_segmento VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_juncao VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_funcional VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_indicador VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
)
BEGIN
    SELECT
        e.INDICADOR,
        CAST(e.ANO_MES AS CHAR) AS ANO_MES,
        COALESCE(AVG(COALESCE(e.NOVA_PONTUACAO, e.PONTUACAO, e.ATINGIMENTO, e.REALIZADO, 0)), 0) AS score_avg,
        COALESCE(AVG(e.META), 0) AS meta_avg,
        COALESCE(AVG(e.REALIZADO), 0) AS real_avg,
        COUNT(*) AS row_count
    FROM `encantabra` e
    WHERE COALESCE(TRIM(p_months_csv), '') <> ''
      AND FIND_IN_SET(
            CAST(e.ANO_MES AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci,
            REPLACE(TRIM(p_months_csv), ' ', '') COLLATE utf8mb4_unicode_ci
      ) > 0
      AND (COALESCE(TRIM(p_perfil), '') = '' OR e.TIPO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_perfil) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_segmento), '') = '' OR e.SEGMENTO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_segmento) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_juncao), '') = '' OR CAST(e.COD_JUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_juncao) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_funcional), '') = '' OR CAST(e.COD_FUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_funcional) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_indicador), '') = '' OR e.INDICADOR COLLATE utf8mb4_unicode_ci = TRIM(p_indicador) COLLATE utf8mb4_unicode_ci)
    GROUP BY e.INDICADOR, e.ANO_MES
    ORDER BY e.INDICADOR ASC, e.ANO_MES ASC;
END$$

CREATE PROCEDURE sp_encantabra_lookup_junction_label(
    IN p_juncao VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
)
BEGIN
    SELECT
        e.NOME_JUNC AS label
    FROM `encantabra` e
    WHERE CAST(e.COD_JUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(COALESCE(p_juncao, '')) COLLATE utf8mb4_unicode_ci
      AND COALESCE(e.NOME_JUNC, '') <> ''
    LIMIT 1;
END$$

CREATE PROCEDURE sp_encantabra_lookup_functional_label(
    IN p_funcional VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
)
BEGIN
    SELECT
        e.NOME_FUNC AS label
    FROM `encantabra` e
    WHERE CAST(e.COD_FUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(COALESCE(p_funcional, '')) COLLATE utf8mb4_unicode_ci
      AND COALESCE(e.NOME_FUNC, '') <> ''
    LIMIT 1;
END$$

CREATE PROCEDURE sp_encantabra_count_analytic_rows(
    IN p_anomes VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_year CHAR(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_perfil VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_segmento VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_juncao VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_funcional VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_indicador VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
)
BEGIN
    SELECT
        COUNT(*) AS total_rows
    FROM `encantabra` e
    WHERE (
            (COALESCE(TRIM(p_anomes), '') <> '' AND CAST(e.ANO_MES AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_anomes) COLLATE utf8mb4_unicode_ci)
            OR
            (COALESCE(TRIM(p_anomes), '') = '' AND COALESCE(TRIM(p_year), '') <> '' AND FLOOR(e.ANO_MES / 100) = CAST(TRIM(p_year) AS UNSIGNED))
          )
      AND (COALESCE(TRIM(p_perfil), '') = '' OR e.TIPO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_perfil) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_segmento), '') = '' OR e.SEGMENTO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_segmento) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_juncao), '') = '' OR CAST(e.COD_JUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_juncao) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_funcional), '') = '' OR CAST(e.COD_FUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_funcional) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_indicador), '') = '' OR e.INDICADOR COLLATE utf8mb4_unicode_ci = TRIM(p_indicador) COLLATE utf8mb4_unicode_ci);
END$$

CREATE PROCEDURE sp_encantabra_list_analytic_rows(
    IN p_anomes VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_year CHAR(4) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_perfil VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_segmento VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_juncao VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_funcional VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_indicador VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_limit_rows INT,
    IN p_offset_rows INT
)
BEGIN
    DECLARE v_limit_rows INT DEFAULT 20;
    DECLARE v_offset_rows INT DEFAULT 0;

    SET v_limit_rows = GREATEST(COALESCE(p_limit_rows, 20), 1);
    SET v_offset_rows = GREATEST(COALESCE(p_offset_rows, 0), 0);

    SELECT *
    FROM `encantabra` e
    WHERE (
            (COALESCE(TRIM(p_anomes), '') <> '' AND CAST(e.ANO_MES AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_anomes) COLLATE utf8mb4_unicode_ci)
            OR
            (COALESCE(TRIM(p_anomes), '') = '' AND COALESCE(TRIM(p_year), '') <> '' AND FLOOR(e.ANO_MES / 100) = CAST(TRIM(p_year) AS UNSIGNED))
          )
      AND (COALESCE(TRIM(p_perfil), '') = '' OR e.TIPO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_perfil) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_segmento), '') = '' OR e.SEGMENTO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_segmento) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_juncao), '') = '' OR CAST(e.COD_JUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_juncao) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_funcional), '') = '' OR CAST(e.COD_FUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_funcional) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_indicador), '') = '' OR e.INDICADOR COLLATE utf8mb4_unicode_ci = TRIM(p_indicador) COLLATE utf8mb4_unicode_ci)
    ORDER BY e.ANO_MES DESC, e.TIPO_PAINEL ASC, e.COD_JUNC ASC, e.COD_FUNC ASC, e.INDICADOR ASC
    LIMIT v_limit_rows OFFSET v_offset_rows;
END$$

CREATE PROCEDURE sp_encantabra_list_ranking_by_indicator(
    IN p_anomes VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_perfil VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_segmento VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_juncao VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_funcional VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_indicador VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
)
BEGIN
    SELECT
        TRIM(e.INDICADOR) AS display_label,
        COALESCE(AVG(COALESCE(e.NOVA_PONTUACAO, e.PONTUACAO, e.ATINGIMENTO, e.REALIZADO, 0)), 0) AS score_avg,
        COALESCE(AVG(e.META), 0) AS meta_avg,
        COALESCE(AVG(e.REALIZADO), 0) AS real_avg,
        COUNT(*) AS row_count
    FROM `encantabra` e
    WHERE (COALESCE(TRIM(p_anomes), '') = '' OR CAST(e.ANO_MES AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_anomes) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_perfil), '') = '' OR e.TIPO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_perfil) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_segmento), '') = '' OR e.SEGMENTO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_segmento) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_juncao), '') = '' OR CAST(e.COD_JUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_juncao) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_funcional), '') = '' OR CAST(e.COD_FUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_funcional) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_indicador), '') = '' OR e.INDICADOR COLLATE utf8mb4_unicode_ci = TRIM(p_indicador) COLLATE utf8mb4_unicode_ci)
      AND COALESCE(TRIM(e.INDICADOR), '') <> ''
    GROUP BY TRIM(e.INDICADOR)
    ORDER BY score_avg DESC, display_label ASC;
END$$

CREATE PROCEDURE sp_encantabra_list_ranking_by_junction(
    IN p_anomes VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_perfil VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_segmento VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_indicador VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
)
BEGIN
    SELECT
        TRIM(CONCAT(CAST(e.COD_JUNC AS CHAR), ' - ', e.NOME_JUNC)) AS display_label,
        COALESCE(AVG(COALESCE(e.NOVA_PONTUACAO, e.PONTUACAO, e.ATINGIMENTO, e.REALIZADO, 0)), 0) AS score_avg,
        COALESCE(AVG(e.META), 0) AS meta_avg,
        COALESCE(AVG(e.REALIZADO), 0) AS real_avg,
        COUNT(*) AS row_count
    FROM `encantabra` e
    WHERE (COALESCE(TRIM(p_anomes), '') = '' OR CAST(e.ANO_MES AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_anomes) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_perfil), '') = '' OR e.TIPO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_perfil) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_segmento), '') = '' OR e.SEGMENTO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_segmento) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_indicador), '') = '' OR e.INDICADOR COLLATE utf8mb4_unicode_ci = TRIM(p_indicador) COLLATE utf8mb4_unicode_ci)
      AND COALESCE(CAST(e.COD_JUNC AS CHAR), '') <> ''
      AND COALESCE(e.NOME_JUNC, '') <> ''
    GROUP BY e.COD_JUNC, e.NOME_JUNC
    ORDER BY score_avg DESC, display_label ASC;
END$$

CREATE PROCEDURE sp_encantabra_list_ranking_by_functional(
    IN p_anomes VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_perfil VARCHAR(16) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_segmento VARCHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_juncao VARCHAR(32) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
    IN p_indicador VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci
)
BEGIN
    SELECT
        TRIM(CONCAT(CAST(e.COD_FUNC AS CHAR), ' - ', e.NOME_FUNC)) AS display_label,
        COALESCE(AVG(COALESCE(e.NOVA_PONTUACAO, e.PONTUACAO, e.ATINGIMENTO, e.REALIZADO, 0)), 0) AS score_avg,
        COALESCE(AVG(e.META), 0) AS meta_avg,
        COALESCE(AVG(e.REALIZADO), 0) AS real_avg,
        COUNT(*) AS row_count
    FROM `encantabra` e
    WHERE (COALESCE(TRIM(p_anomes), '') = '' OR CAST(e.ANO_MES AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_anomes) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_perfil), '') = '' OR e.TIPO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_perfil) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_segmento), '') = '' OR e.SEGMENTO_PAINEL COLLATE utf8mb4_unicode_ci = TRIM(p_segmento) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_juncao), '') = '' OR CAST(e.COD_JUNC AS CHAR CHARACTER SET utf8mb4) COLLATE utf8mb4_unicode_ci = TRIM(p_juncao) COLLATE utf8mb4_unicode_ci)
      AND (COALESCE(TRIM(p_indicador), '') = '' OR e.INDICADOR COLLATE utf8mb4_unicode_ci = TRIM(p_indicador) COLLATE utf8mb4_unicode_ci)
      AND COALESCE(CAST(e.COD_FUNC AS CHAR), '') <> ''
      AND COALESCE(e.NOME_FUNC, '') <> ''
    GROUP BY e.COD_FUNC, e.NOME_FUNC
    ORDER BY score_avg DESC, display_label ASC;
END$$

DELIMITER ;



-- TRIGGERS
DROP TRIGGER IF EXISTS `bi_dhierarquia_validar`;
DROP TRIGGER IF EXISTS `bu_dhierarquia_validar`;
DROP TRIGGER IF EXISTS `bi_fmultijuncao_validar`;
DROP TRIGGER IF EXISTS `bu_fmultijuncao_validar`;

DELIMITER $$

CREATE TRIGGER `bi_dhierarquia_validar`
BEFORE INSERT ON `dhierarquia`
FOR EACH ROW
BEGIN
  SET NEW.email = LOWER(TRIM(NEW.email));
  SET NEW.nome = TRIM(NEW.nome);
  SET NEW.cargo = TRIM(NEW.cargo);
  IF NEW.nivel NOT IN ('AS','GC','PA','GG','TL','AG','GR','GE','DR','DP') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'nivel invalido em dHierarquia';
  END IF;
END$$

CREATE TRIGGER `bu_dhierarquia_validar`
BEFORE UPDATE ON `dhierarquia`
FOR EACH ROW
BEGIN
  SET NEW.email = LOWER(TRIM(NEW.email));
  SET NEW.nome = TRIM(NEW.nome);
  SET NEW.cargo = TRIM(NEW.cargo);
  IF NEW.nivel NOT IN ('AS','GC','PA','GG','TL','AG','GR','GE','DR','DP') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'nivel invalido em dHierarquia';
  END IF;
END$$

CREATE TRIGGER `bi_fmultijuncao_validar`
BEFORE INSERT ON `fmultijuncao`
FOR EACH ROW
BEGIN
  IF NEW.tipo_juncao NOT IN ('AG','GR','DR','DP') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'tipo_juncao invalido em fMultiJuncao';
  END IF;

  IF NEW.dt_inicio_vigencia IS NOT NULL AND NEW.dt_fim_vigencia IS NOT NULL AND NEW.dt_fim_vigencia < NEW.dt_inicio_vigencia THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'periodo de vigencia invalido em fMultiJuncao';
  END IF;

  IF NEW.principal_sn = TRUE AND NEW.ativo_sn = TRUE AND EXISTS (
    SELECT 1
      FROM fMultiJuncao
     WHERE funcional = NEW.funcional
       AND principal_sn = TRUE
       AND ativo_sn = TRUE
  ) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ja existe juncao principal ativa para a funcional informada';
  END IF;
END$$

CREATE TRIGGER `bu_fmultijuncao_validar`
BEFORE UPDATE ON `fmultijuncao`
FOR EACH ROW
BEGIN
  IF NEW.tipo_juncao NOT IN ('AG','GR','DR','DP') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'tipo_juncao invalido em fMultiJuncao';
  END IF;

  IF NEW.dt_inicio_vigencia IS NOT NULL AND NEW.dt_fim_vigencia IS NOT NULL AND NEW.dt_fim_vigencia < NEW.dt_inicio_vigencia THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'periodo de vigencia invalido em fMultiJuncao';
  END IF;

  IF NEW.principal_sn = TRUE AND NEW.ativo_sn = TRUE AND EXISTS (
    SELECT 1
      FROM fMultiJuncao
     WHERE funcional = NEW.funcional
       AND principal_sn = TRUE
       AND ativo_sn = TRUE
       AND id_multi_juncao <> NEW.id_multi_juncao
  ) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ja existe juncao principal ativa para a funcional informada';
  END IF;
END$$

DELIMITER ;

