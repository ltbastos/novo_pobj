<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

use App\Database;
use App\Services\EncantabraDashboardService;
use App\Services\PobjDashboardService;
use App\Services\PrimeBrandService;
use App\Services\ProfileSimulationService;

$connection = Database::connection();
$profileService = new ProfileSimulationService($connection);
$dashboardService = new PobjDashboardService($connection);
$brandService = new PrimeBrandService($connection);
$encantabraService = new EncantabraDashboardService($connection);

$requestMethod = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$requestAction = sanitize_request_token((string) ($_POST['action'] ?? ''));
$isAjaxRequest = strcasecmp(trim((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')), 'XMLHttpRequest') === 0;

$allowedTabs = ['resumo', 'detalhamento', 'rankings', 'visao-executiva', 'encantabra', 'simuladores', 'campanhas'];
$allowedAccumulatedViews = ['MENSAL', 'SEMESTRAL', 'ACUMULADO', 'ANUAL', 'MENSAL_ACUMULADO'];
$allowedEncantabraSections = ['resultado', 'regulamento', 'apoio'];
$allowedEncantabraProfiles = ['SG', 'AG', 'GC'];
$summaryFilterKeys = ['segmento', 'diretoria', 'regional', 'agencia', 'gerente_gestao', 'gerente', 'familia', 'indicadores', 'subindicador', 'status_indicadores'];
$dashboardScript = current_app_script('index.php');
$dashboardStateSessionKey = defined('POBJ_DASHBOARD_STATE_SESSION_KEY')
    ? trim((string) constant('POBJ_DASHBOARD_STATE_SESSION_KEY'))
    : 'pobj_dashboard_state';
$forcedDashboardTab = defined('POBJ_FORCED_ACTIVE_TAB')
    ? sanitize_request_choice((string) constant('POBJ_FORCED_ACTIVE_TAB'), $allowedTabs, '')
    : '';

if ($dashboardStateSessionKey === '') {
    $dashboardStateSessionKey = 'pobj_dashboard_state';
}
$dashboardDefaultSummaryFilters = [
    'segmento' => '',
    'diretoria' => '',
    'regional' => '',
    'agencia' => '',
    'gerente_gestao' => '',
    'gerente' => '',
    'familia' => '',
    'indicadores' => '',
    'subindicador' => '',
    'status_indicadores' => '',
];
$dashboardDefaultEncantabraFilters = [
    'anomes' => '',
    'perfil' => 'SG',
    'segmento' => '',
    'juncao' => '',
    'funcional' => '',
    'indicador' => '',
];

$normalizeDashboardState = static function ($state) use (
    $allowedTabs,
    $allowedAccumulatedViews,
    $allowedEncantabraSections,
    $allowedEncantabraProfiles,
    $dashboardDefaultSummaryFilters,
    $dashboardDefaultEncantabraFilters
): array {
    $state = is_array($state) ? $state : [];
    $summaryFilters = is_array($state['summary_filters'] ?? null) ? $state['summary_filters'] : [];
    $encantabraFilters = is_array($state['enc_filters'] ?? null) ? $state['enc_filters'] : [];

    return [
        'periodo' => sanitize_request_token((string) ($state['periodo'] ?? '')),
        'periodo_mes' => sanitize_request_token((string) ($state['periodo_mes'] ?? '')),
        'visao_acumulada' => sanitize_request_choice((string) ($state['visao_acumulada'] ?? 'MENSAL'), $allowedAccumulatedViews, 'MENSAL'),
        'tab' => sanitize_request_choice((string) ($state['tab'] ?? 'resumo'), $allowedTabs, 'resumo'),
        'advanced_filters' => sanitize_request_choice((string) ($state['advanced_filters'] ?? 'open'), ['open', 'closed'], 'open'),
        'detail_table_view' => sanitize_request_token((string) ($state['detail_table_view'] ?? '')),
        'detail_page' => max(1, (int) ($state['detail_page'] ?? 1)),
        'indicator_focus' => sanitize_request_token((string) ($state['indicator_focus'] ?? '')),
        'indicator_page' => max(1, (int) ($state['indicator_page'] ?? 1)),
        'grupo' => sanitize_request_token((string) ($state['grupo'] ?? '')),
        'summary_filters' => [
            'segmento' => sanitize_request_token((string) ($summaryFilters['segmento'] ?? $dashboardDefaultSummaryFilters['segmento'])),
            'diretoria' => sanitize_request_token((string) ($summaryFilters['diretoria'] ?? $dashboardDefaultSummaryFilters['diretoria'])),
            'regional' => sanitize_request_token((string) ($summaryFilters['regional'] ?? $dashboardDefaultSummaryFilters['regional'])),
            'agencia' => sanitize_request_token((string) ($summaryFilters['agencia'] ?? $dashboardDefaultSummaryFilters['agencia'])),
            'gerente_gestao' => sanitize_request_token((string) ($summaryFilters['gerente_gestao'] ?? $dashboardDefaultSummaryFilters['gerente_gestao'])),
            'gerente' => sanitize_request_token((string) ($summaryFilters['gerente'] ?? $dashboardDefaultSummaryFilters['gerente'])),
            'familia' => sanitize_request_token((string) ($summaryFilters['familia'] ?? $dashboardDefaultSummaryFilters['familia'])),
            'indicadores' => sanitize_request_token((string) ($summaryFilters['indicadores'] ?? $dashboardDefaultSummaryFilters['indicadores'])),
            'subindicador' => sanitize_request_token((string) ($summaryFilters['subindicador'] ?? $dashboardDefaultSummaryFilters['subindicador'])),
            'status_indicadores' => sanitize_request_choice((string) ($summaryFilters['status_indicadores'] ?? $dashboardDefaultSummaryFilters['status_indicadores']), ['', 'ATINGIDO', 'NAO_ATINGIDO'], ''),
        ],
        'enc_tab' => sanitize_request_choice((string) ($state['enc_tab'] ?? 'resultado'), $allowedEncantabraSections, 'resultado'),
        'enc_page' => max(1, (int) ($state['enc_page'] ?? 1)),
        'enc_filters' => [
            'anomes' => sanitize_request_token((string) ($encantabraFilters['anomes'] ?? $dashboardDefaultEncantabraFilters['anomes'])),
            'perfil' => sanitize_request_choice((string) ($encantabraFilters['perfil'] ?? $dashboardDefaultEncantabraFilters['perfil']), $allowedEncantabraProfiles, 'SG'),
            'segmento' => sanitize_request_token((string) ($encantabraFilters['segmento'] ?? $dashboardDefaultEncantabraFilters['segmento'])),
            'juncao' => sanitize_request_token((string) ($encantabraFilters['juncao'] ?? $dashboardDefaultEncantabraFilters['juncao'])),
            'funcional' => sanitize_request_token((string) ($encantabraFilters['funcional'] ?? $dashboardDefaultEncantabraFilters['funcional'])),
            'indicador' => sanitize_request_token((string) ($encantabraFilters['indicador'] ?? $dashboardDefaultEncantabraFilters['indicador'])),
        ],
    ];
};

$loadDashboardState = static function () use ($dashboardStateSessionKey, $normalizeDashboardState): array {
    return $normalizeDashboardState($_SESSION[$dashboardStateSessionKey] ?? []);
};

$saveDashboardState = static function (array $state) use ($dashboardStateSessionKey, $normalizeDashboardState): array {
    $normalizedState = $normalizeDashboardState($state);
    $_SESSION[$dashboardStateSessionKey] = $normalizedState;

    return $normalizedState;
};

$mergeDashboardRequestState = static function (array $state, array $source) use (
    $allowedTabs,
    $allowedAccumulatedViews,
    $allowedEncantabraSections
): array {
    $readString = static function (array $payload, string $key): ?string {
        if (!array_key_exists($key, $payload) || is_array($payload[$key])) {
            return null;
        }

        return (string) $payload[$key];
    };

    $stringFields = [
        'periodo' => static function (string $value): string {
            return sanitize_request_token($value);
        },
        'periodo_mes' => static function (string $value): string {
            return sanitize_request_token($value);
        },
        'advanced_filters' => static function (string $value): string {
            return sanitize_request_choice($value, ['open', 'closed'], 'open');
        },
        'detail_table_view' => static function (string $value): string {
            return sanitize_request_token($value);
        },
        'indicator_focus' => static function (string $value): string {
            return sanitize_request_token($value);
        },
        'grupo' => static function (string $value): string {
            return sanitize_request_token($value);
        },
        'tab' => static function (string $value) use ($allowedTabs, $state): string {
            return sanitize_request_choice($value, $allowedTabs, $state['tab'] ?? 'resumo');
        },
        'visao_acumulada' => static function (string $value) use ($allowedAccumulatedViews, $state): string {
            return sanitize_request_choice($value, $allowedAccumulatedViews, $state['visao_acumulada'] ?? 'MENSAL');
        },
        'enc_tab' => static function (string $value) use ($allowedEncantabraSections, $state): string {
            return sanitize_request_choice($value, $allowedEncantabraSections, $state['enc_tab'] ?? 'resultado');
        },
    ];

    foreach ($stringFields as $field => $sanitizer) {
        $rawValue = $readString($source, $field);

        if ($rawValue === null) {
            continue;
        }

        $state[$field] = $sanitizer($rawValue);
    }

    $integerFields = ['detail_page', 'indicator_page', 'enc_page'];

    foreach ($integerFields as $field) {
        if (!array_key_exists($field, $source) || is_array($source[$field])) {
            continue;
        }

        $state[$field] = max(1, (int) $source[$field]);
    }

    return $state;
};

$mergeSummaryFiltersFromSource = static function (array $state, array $source) use ($summaryFilterKeys, $dashboardDefaultSummaryFilters, $allowedAccumulatedViews): array {
    foreach ($summaryFilterKeys as $filterKey) {
        if (!array_key_exists($filterKey, $source) || is_array($source[$filterKey])) {
            continue;
        }

        if ($filterKey === 'status_indicadores') {
            $state['summary_filters'][$filterKey] = sanitize_request_choice((string) $source[$filterKey], ['', 'ATINGIDO', 'NAO_ATINGIDO'], $dashboardDefaultSummaryFilters[$filterKey]);
            continue;
        }

        $state['summary_filters'][$filterKey] = sanitize_request_token((string) $source[$filterKey]);
    }

    if (array_key_exists('visao_acumulada', $source) && !is_array($source['visao_acumulada'])) {
        $state['visao_acumulada'] = sanitize_request_choice((string) $source['visao_acumulada'], $allowedAccumulatedViews, $state['visao_acumulada'] ?? 'MENSAL');
    }

    return $state;
};

$mergeEncantabraFiltersFromSource = static function (array $state, array $source) use ($allowedEncantabraProfiles, $dashboardDefaultEncantabraFilters): array {
    foreach ($dashboardDefaultEncantabraFilters as $filterKey => $defaultValue) {
        $requestKey = 'enc_' . $filterKey;

        if (!array_key_exists($requestKey, $source) || is_array($source[$requestKey])) {
            continue;
        }

        if ($filterKey === 'perfil') {
            $state['enc_filters'][$filterKey] = sanitize_request_choice((string) $source[$requestKey], $allowedEncantabraProfiles, $defaultValue);
            continue;
        }

        $state['enc_filters'][$filterKey] = sanitize_request_token((string) $source[$requestKey]);
    }

    return $state;
};

if ($requestMethod === 'POST') {
    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        http_response_code(419);
        exit('Falha de validacao do formulario.');
    }

    $dashboardState = $mergeDashboardRequestState($loadDashboardState(), $_POST);
    $dashboardState = $mergeSummaryFiltersFromSource($dashboardState, $_POST);
    $dashboardState = $mergeEncantabraFiltersFromSource($dashboardState, $_POST);

    switch ($requestAction) {
        case 'select_profile':
            $selectedFunctional = trim((string) ($_POST['selected_functional'] ?? ''));

            if ($selectedFunctional !== '' && $profileService->profileExists($selectedFunctional)) {
                $_SESSION['selected_profile_functional'] = $selectedFunctional;
            }

            break;

        case 'apply_summary_filters':
            $dashboardState['detail_page'] = 1;
            $dashboardState['indicator_page'] = 1;
            break;

        case 'clear_summary_filters':
            $dashboardState['summary_filters'] = $dashboardDefaultSummaryFilters;
            $dashboardState['periodo'] = '';
            $dashboardState['periodo_mes'] = '';
            $dashboardState['visao_acumulada'] = 'MENSAL';
            $dashboardState['detail_page'] = 1;
            $dashboardState['indicator_page'] = 1;
            $dashboardState['detail_table_view'] = '';
            $dashboardState['indicator_focus'] = '';
            $dashboardState['grupo'] = '';
            break;

        case 'set_dashboard_tab':
            $dashboardState['indicator_focus'] = '';
            $dashboardState['indicator_page'] = 1;
            $dashboardState['detail_page'] = 1;
            break;

        case 'open_indicator_focus':
            $dashboardState['indicator_page'] = max(1, (int) ($dashboardState['indicator_page'] ?? 1));
            break;

        case 'close_indicator_focus':
            $dashboardState['indicator_focus'] = '';
            $dashboardState['indicator_page'] = 1;
            break;

        case 'set_indicator_page':
            $dashboardState['indicator_page'] = max(1, (int) ($dashboardState['indicator_page'] ?? 1));
            break;

        case 'set_ranking_group':
            $dashboardState['tab'] = 'rankings';
            $dashboardState['indicator_focus'] = '';
            $dashboardState['indicator_page'] = 1;
            break;

        case 'apply_encantabra_filters':
            $dashboardState['tab'] = 'encantabra';
            $dashboardState['enc_page'] = 1;
            break;

        case 'clear_encantabra_filters':
            $dashboardState['tab'] = 'encantabra';
            $dashboardState['enc_filters'] = $dashboardDefaultEncantabraFilters;
            $dashboardState['enc_page'] = 1;
            break;

        case 'set_encantabra_tab':
            $dashboardState['tab'] = 'encantabra';
            $dashboardState['enc_page'] = 1;
            break;

        case 'set_encantabra_page':
            $dashboardState['tab'] = 'encantabra';
            $dashboardState['enc_page'] = max(1, (int) ($dashboardState['enc_page'] ?? 1));
            break;
    }

    if ($forcedDashboardTab !== '') {
        $dashboardState['tab'] = $forcedDashboardTab;
    }

    $saveDashboardState($dashboardState);
    redirect_internal($dashboardScript);
}

$dashboardState = $loadDashboardState();

if ($forcedDashboardTab !== '') {
    $dashboardState['tab'] = $forcedDashboardTab;
}
$requestedTab = sanitize_request_choice((string) ($dashboardState['tab'] ?? 'resumo'), $allowedTabs, 'resumo');
$activeTab = in_array($requestedTab, $allowedTabs, true) ? $requestedTab : 'resumo';
$allowedAccumulatedViewsForTab = $activeTab === 'resumo'
    ? $allowedAccumulatedViews
    : ['MENSAL', 'SEMESTRAL', 'ACUMULADO'];
$tabsWithIndicatorStatusFilter = ['resumo', 'detalhamento'];

$profiles = $profileService->listProfiles();
$selectedProfileFunctional = $_SESSION['selected_profile_functional'] ?? ($profiles[0]['funcional'] ?? null);

if ($selectedProfileFunctional !== null && !$profileService->profileExists((string) $selectedProfileFunctional)) {
    $selectedProfileFunctional = $profiles[0]['funcional'] ?? null;
}

if ($selectedProfileFunctional !== null) {
    $_SESSION['selected_profile_functional'] = $selectedProfileFunctional;
}

$context = $selectedProfileFunctional !== null ? $profileService->getContext($selectedProfileFunctional) : null;

if ($context === null && $profiles !== []) {
    $selectedProfileFunctional = $profiles[0]['funcional'] ?? null;

    if ($selectedProfileFunctional !== null) {
        $_SESSION['selected_profile_functional'] = $selectedProfileFunctional;
        $context = $profileService->getContext($selectedProfileFunctional);
    }
}

$periods = $dashboardService->listPeriods();
$closedMonthOptions = build_closed_month_period_options($periods);
$requestedPeriodMonthRaw = (string) ($dashboardState['periodo_mes'] ?? '');
$requestedPeriodMonth = $requestedPeriodMonthRaw;
$requestedAccumulatedView = sanitize_request_choice((string) ($dashboardState['visao_acumulada'] ?? 'MENSAL'), $allowedAccumulatedViewsForTab, 'MENSAL');
$displayPeriodStart = '';
$displayPeriodEnd = '';
$selectedPeriodMonth = '';
$selectedClosedMonth = null;

foreach ($closedMonthOptions as $monthOption) {
    if ((string) ($monthOption['value'] ?? '') !== $requestedPeriodMonth) {
        continue;
    }

    $selectedClosedMonth = $monthOption;
    break;
}

if ($selectedClosedMonth === null) {
    $selectedClosedMonth = $closedMonthOptions[0] ?? null;
}

if ($selectedClosedMonth !== null) {
    $selectedPeriodMonth = trim((string) ($selectedClosedMonth['value'] ?? ''));
}

$selectedPeriodId = trim((string) ($dashboardState['periodo'] ?? ''));

if ($selectedPeriodId === '') {
    $selectedPeriodId = $periods[0]['id_periodo'] ?? null;
}

if ($selectedClosedMonth !== null) {
    $selectedPeriodId = trim((string) ($selectedClosedMonth['periodo'] ?? $selectedPeriodId));
    $accumulatedRange = resolve_accumulated_view_date_range(
        $requestedAccumulatedView,
        (string) ($selectedClosedMonth['end'] ?? '')
    );
    $displayPeriodStart = $accumulatedRange['start'];
    $displayPeriodEnd = $accumulatedRange['end'];
} else {
    $accumulatedRange = resolve_accumulated_view_date_range($requestedAccumulatedView);
    $displayPeriodStart = $accumulatedRange['start'];
    $displayPeriodEnd = $accumulatedRange['end'];
}

$availablePeriodIds = array_values(array_filter(array_map(static function (array $periodRow): string {
    return trim((string) ($periodRow['id_periodo'] ?? ''));
}, $periods)));

if ($selectedPeriodId !== null && !in_array($selectedPeriodId, $availablePeriodIds, true)) {
    $selectedPeriodId = $periods[0]['id_periodo'] ?? null;
}

if ($selectedClosedMonth === null && $context !== null && $selectedPeriodId !== null && !$dashboardService->periodHasVisibleData($context, $selectedPeriodId)) {
    foreach ($periods as $periodRow) {
        $candidatePeriodId = trim((string) ($periodRow['id_periodo'] ?? ''));

        if ($candidatePeriodId === '' || !$dashboardService->periodHasVisibleData($context, $candidatePeriodId)) {
            continue;
        }

        $selectedPeriodId = $candidatePeriodId;
        break;
    }
}
$requestedAdvancedFiltersState = sanitize_request_choice((string) ($dashboardState['advanced_filters'] ?? 'open'), ['open', 'closed'], 'open');
$advancedFiltersState = in_array($requestedAdvancedFiltersState, ['open', 'closed'], true)
    ? $requestedAdvancedFiltersState
    : 'open';
$requestedDetailTableView = $isAjaxRequest
    ? sanitize_request_token((string) ($_GET['detail_table_view'] ?? ($dashboardState['detail_table_view'] ?? '')))
    : sanitize_request_token((string) ($dashboardState['detail_table_view'] ?? ''));
$requestedDetailPage = $isAjaxRequest
    ? max(1, (int) ($_GET['detail_page'] ?? ($dashboardState['detail_page'] ?? 1)))
    : max(1, (int) ($dashboardState['detail_page'] ?? 1));

$requestedIndicatorFocus = sanitize_request_token((string) ($dashboardState['indicator_focus'] ?? ''));
$requestedIndicatorPage = max(1, (int) ($dashboardState['indicator_page'] ?? 1));
$requestedRankingGroup = sanitize_request_token((string) ($dashboardState['grupo'] ?? ''));

$requestedSummaryFilters = [
    'segmento' => sanitize_request_token((string) (($dashboardState['summary_filters']['segmento'] ?? ''))),
    'diretoria' => sanitize_request_token((string) (($dashboardState['summary_filters']['diretoria'] ?? ''))),
    'regional' => sanitize_request_token((string) (($dashboardState['summary_filters']['regional'] ?? ''))),
    'agencia' => sanitize_request_token((string) (($dashboardState['summary_filters']['agencia'] ?? ''))),
    'gerente_gestao' => sanitize_request_token((string) (($dashboardState['summary_filters']['gerente_gestao'] ?? ''))),
    'gerente' => sanitize_request_token((string) (($dashboardState['summary_filters']['gerente'] ?? ''))),
    'familia' => sanitize_request_token((string) (($dashboardState['summary_filters']['familia'] ?? ''))),
    'indicadores' => sanitize_request_token((string) (($dashboardState['summary_filters']['indicadores'] ?? ''))),
    'subindicador' => sanitize_request_token((string) (($dashboardState['summary_filters']['subindicador'] ?? ''))),
    'status_indicadores' => in_array($activeTab, $tabsWithIndicatorStatusFilter, true)
        ? sanitize_request_choice((string) (($dashboardState['summary_filters']['status_indicadores'] ?? '')), ['', 'ATINGIDO', 'NAO_ATINGIDO'], '')
        : '',
    'visao_acumulada' => $requestedAccumulatedView,
];

$summaryFilters = $context !== null && $selectedPeriodId !== null
    ? $dashboardService->prepareSummaryFilters($context, $selectedPeriodId, $requestedSummaryFilters, $displayPeriodEnd)
    : [
        'options' => [
            'segmento' => [],
            'diretoria' => [],
            'regional' => [],
            'agencia' => [],
            'gerente_gestao' => [],
            'gerente' => [],
            'familia' => [],
            'indicadores' => [],
            'subindicador' => [],
            'status_indicadores' => [],
            'visao_acumulada' => [
                ['value' => 'MENSAL', 'label' => 'Mensal'],
                ['value' => 'SEMESTRAL', 'label' => 'Semestral'],
                ['value' => 'ACUMULADO', 'label' => 'Acumulado'],
                ['value' => 'ANUAL', 'label' => 'Anual'],
                ['value' => 'MENSAL_ACUMULADO', 'label' => 'Mensal/Acumulado'],
            ],
        ],
        'values' => $requestedSummaryFilters,
        'states' => [
            'segmento' => ['enabled' => true, 'placeholder' => 'Todos'],
            'diretoria' => ['enabled' => false, 'placeholder' => 'Selecione os filtros anteriores'],
            'regional' => ['enabled' => false, 'placeholder' => 'Selecione os filtros anteriores'],
            'agencia' => ['enabled' => false, 'placeholder' => 'Selecione os filtros anteriores'],
            'gerente_gestao' => ['enabled' => false, 'placeholder' => 'Selecione os filtros anteriores'],
            'gerente' => ['enabled' => false, 'placeholder' => 'Selecione os filtros anteriores'],
        ],
    ];

$summaryFilterOptions = $summaryFilters['options'];
$summaryFilterValues = $summaryFilters['values'];
$summaryFilterStates = $summaryFilters['states'] ?? [];
$visualTheme = $brandService->resolveVisualTheme($context, $summaryFilterValues);

$profileLevel = strtoupper(trim((string) (($context['profile']['nivel'] ?? ''))));

$requestedEncantabraSection = sanitize_request_choice((string) ($dashboardState['enc_tab'] ?? 'resultado'), $allowedEncantabraSections, 'resultado');
$encantabraActiveSection = in_array($requestedEncantabraSection, $allowedEncantabraSections, true)
    ? $requestedEncantabraSection
    : 'resultado';
$requestedEncantabraPage = max(1, (int) ($dashboardState['enc_page'] ?? 1));
$requestedEncantabraFilters = [
    'anomes' => sanitize_request_token((string) ($dashboardState['enc_filters']['anomes'] ?? '')),
    'perfil' => sanitize_request_choice((string) ($dashboardState['enc_filters']['perfil'] ?? 'SG'), $allowedEncantabraProfiles, 'SG'),
    'segmento' => sanitize_request_token((string) ($dashboardState['enc_filters']['segmento'] ?? '')),
    'juncao' => sanitize_request_token((string) ($dashboardState['enc_filters']['juncao'] ?? '')),
    'funcional' => sanitize_request_token((string) ($dashboardState['enc_filters']['funcional'] ?? '')),
    'indicador' => sanitize_request_token((string) ($dashboardState['enc_filters']['indicador'] ?? '')),
];
$encantabraFilters = $encantabraService->prepareFilters($requestedEncantabraFilters);
$encantabraFilterOptions = $encantabraFilters['options'];
$encantabraFilterValues = $encantabraFilters['values'];

$dashboardData = $context !== null && $selectedPeriodId !== null
    ? $dashboardService->getDashboardData($context, $selectedPeriodId, $summaryFilterValues, $displayPeriodStart, $displayPeriodEnd)
    : ['summary' => [], 'indicators' => []];

$indicatorFocusId = '';

foreach (($dashboardData['indicators'] ?? []) as $indicatorRow) {
    if ((string) ($indicatorRow['id_indicador'] ?? '') !== $requestedIndicatorFocus) {
        continue;
    }

    $indicatorFocusId = $requestedIndicatorFocus;
    break;
}

$detailData = $context !== null && $selectedPeriodId !== null && $activeTab === 'detalhamento'
    ? $dashboardService->getDetailData(
        $context,
        $selectedPeriodId,
        $summaryFilterValues,
        $displayPeriodStart,
        $displayPeriodEnd,
        $requestedDetailTableView,
        $requestedDetailPage
    )
    : ['summary' => [], 'rows' => [], 'pagination' => ['page' => 1, 'per_page' => 20, 'total_rows' => 0, 'total_pages' => 1, 'from' => 0, 'to' => 0]];

$indicatorDetailData = $context !== null && $selectedPeriodId !== null && $indicatorFocusId !== ''
    ? $dashboardService->getIndicatorDetailData($context, $selectedPeriodId, $summaryFilterValues, $indicatorFocusId, $displayPeriodStart, $displayPeriodEnd, $requestedIndicatorPage)
    : [
        'indicator' => [],
        'summary' => [],
        'trend' => [],
        'distributions' => ['channels' => [], 'statuses' => []],
        'insights' => ['mode' => 'hierarchy', 'label' => '', 'title' => '', 'top' => [], 'bottom' => []],
        'transactions' => [],
        'analytic_pagination' => ['page' => 1, 'per_page' => 20, 'total_rows' => 0, 'total_pages' => 1, 'from' => 0, 'to' => 0],
    ];

$rankingGroupOptions = $context !== null && $selectedPeriodId !== null && $activeTab === 'rankings'
    ? $dashboardService->listRankingGroupOptions($context, $selectedPeriodId, $summaryFilterValues, $displayPeriodStart, $displayPeriodEnd)
    : [];

$rankingHasSingleGroup = count($rankingGroupOptions) === 1;
$rankingDefaultGroup = $rankingHasSingleGroup ? trim((string) ($rankingGroupOptions[0]['value'] ?? '')) : '';
$rankingShowAllGroups = $profileLevel === 'DP' || !$rankingHasSingleGroup;
$requestedRankingGroup = $dashboardService->sanitizeFilterSelection(
    $requestedRankingGroup,
    $rankingGroupOptions,
    $profileLevel !== 'DP' && $rankingHasSingleGroup ? $rankingDefaultGroup : ''
);
$rankingFilters = array_merge($summaryFilterValues, ['grupo' => $requestedRankingGroup]);

$rankingData = $context !== null && $selectedPeriodId !== null && $activeTab === 'rankings'
    ? $dashboardService->getRankingData($context, $selectedPeriodId, $rankingFilters, $displayPeriodStart, $displayPeriodEnd)
    : ['level' => 'gerente_gestao', 'level_label' => 'Gerente de gestão', 'rows' => []];

$executiveData = $context !== null && $selectedPeriodId !== null && $activeTab === 'visao-executiva'
    ? $dashboardService->getExecutiveViewData($context, $selectedPeriodId, $summaryFilterValues, $displayPeriodStart, $displayPeriodEnd)
    : [
        'focus' => ['level' => 'regional', 'label' => 'Regional', 'ranking_title' => 'Desempenho por Regional', 'status_title' => 'Status por Regional'],
        'reference' => ['period_label' => '', 'range_label' => '', 'month_label' => '', 'window_label' => 'Últimos 6 meses'],
        'kpis' => [],
        'chart' => ['labels' => [], 'series' => [], 'max_value' => 100.0],
        'ranking' => ['top' => [], 'bottom' => []],
        'status' => ['hit' => [], 'quase' => [], 'longe' => [], 'summary' => ['hit' => 0, 'quase' => 0, 'longe' => 0]],
        'heatmap' => [
            'default_mode' => 'secoes',
            'secoes' => ['title' => '', 'row_axis_label' => 'GR', 'row_axis_sublabel' => 'Famílias', 'rows' => [], 'columns' => [], 'data' => []],
            'meta' => ['title' => '', 'row_axis_label' => 'Hierarquia', 'row_axis_sublabel' => 'Mês', 'rows' => [], 'months' => [], 'data' => []],
        ],
    ];

$encantabraData = $activeTab === 'encantabra'
    ? $encantabraService->getDashboardData($encantabraFilterValues, $requestedEncantabraPage)
    : [
        'reference' => ['month_label' => '', 'scope_label' => '', 'profile_label' => '', 'segment_label' => ''],
        'summary' => ['score_avg' => 0.0, 'meta_avg' => 0.0, 'real_avg' => 0.0, 'rows_total' => 0, 'entities_total' => 0, 'indicators_total' => 0, 'best_indicator' => null, 'worst_indicator' => null, 'band' => ['label' => 'Sem dados', 'range' => 'Sem leitura', 'tone' => 'is-empty']],
        'status' => ['fan' => 0, 'encantador' => 0, 'expectativa' => 0, 'critico' => 0],
        'chart' => ['labels' => [], 'series' => [], 'max_value' => 150.0],
        'trimester_tables' => ['year' => '', 'tables' => []],
        'ranking' => ['title' => '', 'top' => [], 'bottom' => []],
        'heatmap' => ['title' => '', 'rows' => [], 'months' => [], 'data' => []],
        'table' => ['title' => '', 'subtitle' => '', 'columns' => [], 'rows' => [], 'total_rows' => 0, 'current_page' => 1, 'per_page' => 20, 'total_pages' => 1],
    ];

$annualPerformanceData = $context !== null
    && ($summaryFilterValues['visao_acumulada'] ?? 'MENSAL') === 'ANUAL'
    && $activeTab === 'resumo'
    ? $dashboardService->getAnnualPerformanceData($context, $summaryFilterValues, $displayPeriodEnd)
    : ['year' => (int) date('Y'), 'rows' => [], 'summary' => ['atingiu' => 0, 'quase' => 0, 'distante' => 0]];

$dashboardState['periodo'] = trim((string) ($selectedPeriodId ?? ''));
$dashboardState['periodo_mes'] = trim((string) $selectedPeriodMonth);
$dashboardState['visao_acumulada'] = (string) ($summaryFilterValues['visao_acumulada'] ?? $requestedAccumulatedView);
$dashboardState['tab'] = $activeTab;
$dashboardState['advanced_filters'] = $advancedFiltersState;
$dashboardState['detail_table_view'] = $requestedDetailTableView;
$dashboardState['detail_page'] = $requestedDetailPage;
$dashboardState['indicator_focus'] = $indicatorFocusId;
$dashboardState['indicator_page'] = $requestedIndicatorPage;
$dashboardState['grupo'] = $requestedRankingGroup;
$dashboardState['summary_filters'] = array_intersect_key($summaryFilterValues, array_flip($summaryFilterKeys));
$dashboardState['enc_tab'] = $encantabraActiveSection;
$dashboardState['enc_page'] = $requestedEncantabraPage;
$dashboardState['enc_filters'] = $encantabraFilterValues;
$dashboardState = $saveDashboardState($dashboardState);

$selectedPeriod = null;

foreach ($periods as $periodRow) {
    if (($periodRow['id_periodo'] ?? null) === $selectedPeriodId) {
        $selectedPeriod = $periodRow;
        break;
    }
}

$legacyBusinessSnapshot = resolve_business_day_snapshot(
    $displayPeriodStart !== '' ? $displayPeriodStart : ($selectedPeriod['dt_inicio_periodo'] ?? null),
    $displayPeriodEnd !== '' ? $displayPeriodEnd : ($selectedPeriod['dt_fim_periodo'] ?? null)
);

$pageTitle = $activeTab === 'encantabra'
    ? 'Encantabra'
    : 'POBJ';

$isDetailPaneRequest = $requestMethod === 'GET'
    && $activeTab === 'detalhamento'
    && $requestedDetailTableView !== ''
    && strcasecmp(trim((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')), 'XMLHttpRequest') === 0;

if ($isDetailPaneRequest) {
    $detailPaneOnlyMode = true;
    require __DIR__ . '/templates/detail_view.php';
    exit;
}

require __DIR__ . '/templates/layout.php';
