<?php

declare(strict_types=1);

if (($activeTab ?? 'resumo') !== 'resumo' || (($summaryFilterValues['visao_acumulada'] ?? 'MENSAL') === 'ANUAL')) {
    return;
}

$indicatorRows = $dashboardData['indicators'] ?? [];

if ($indicatorRows === []) {
    return;
}

$indicatorCardBaseQuery = [
    'page' => 'pobj-dashboard',
    'periodo' => $selectedPeriodId ?? '',
    'tab' => 'resumo',
    'advanced_filters' => $advancedFiltersState ?? 'open',
];

foreach (($summaryFilterValues ?? []) as $filterKey => $filterValue) {
    if (!is_string($filterValue) || $filterValue === '') {
        continue;
    }

    $indicatorCardBaseQuery[$filterKey] = $filterValue;
}

if (($hasManualDateRange ?? false) === true) {
    $indicatorCardBaseQuery['period_mode'] = 'manual';

    if (($requestedPeriodStart ?? '') !== '') {
        $indicatorCardBaseQuery['period_start'] = $requestedPeriodStart;
    }

    if (($requestedPeriodEnd ?? '') !== '') {
        $indicatorCardBaseQuery['period_end'] = $requestedPeriodEnd;
    }
}

$tooltipAnchorDate = trim((string) ($displayPeriodEnd ?? ''));

if ($tooltipAnchorDate === '') {
    $tooltipAnchorDate = trim((string) (($selectedPeriod['dt_fim_periodo'] ?? null) ?? ''));
}

try {
    $tooltipAnchor = new DateTimeImmutable(clamp_date_to_today($tooltipAnchorDate !== '' ? $tooltipAnchorDate : 'today'));
} catch (Throwable $exception) {
    $tooltipAnchor = new DateTimeImmutable('today');
}

$tooltipMonthSnapshot = resolve_business_day_snapshot(
    $tooltipAnchor->modify('first day of this month')->format('Y-m-d'),
    $tooltipAnchor->modify('last day of this month')->format('Y-m-d'),
    $tooltipAnchor->format('Y-m-d')
);

$calculateTooltipMetrics = static function (array $item, array $snapshot): array {
    $daysTotal = max(0, (int) ($snapshot['total'] ?? 0));
    $daysElapsed = max(0, (int) ($snapshot['elapsed'] ?? 0));
    $daysRemaining = max(0, (int) ($snapshot['remaining'] ?? 0));
    $meta = (float) ($item['meta'] ?? 0.0);
    $realizado = (float) ($item['realizado'] ?? 0.0);
    $gap = max(0.0, $meta - $realizado);
    $metaDiariaNecessaria = $daysRemaining > 0 ? ($gap / $daysRemaining) : 0.0;
    $forecast = $daysElapsed > 0 ? $realizado + (($realizado / $daysElapsed) * $daysRemaining) : $realizado;

    return [
        'days_total' => $daysTotal,
        'days_remaining' => $daysRemaining,
        'meta' => $meta,
        'realizado' => $realizado,
        'gap' => $gap,
        'meta_diaria_necessaria' => $metaDiariaNecessaria,
        'forecast' => $forecast,
    ];
};

$familyGroups = [];
$cardIndex = 0;

foreach ($indicatorRows as $row) {
    $familyLabel = trim((string) ($row['nome_familia'] ?? ''));
    $familyKey = $familyLabel !== '' ? $familyLabel : 'Sem família';

    if (!isset($familyGroups[$familyKey])) {
        $familyGroups[$familyKey] = [
            'label' => $familyKey,
            'pontos_atingidos' => 0.0,
            'pontos_total' => 0.0,
            'items' => [],
        ];
    }

    $cardIndex++;
    $familyGroups[$familyKey]['pontos_atingidos'] += (float) ($row['pontos'] ?? 0.0);
    $familyGroups[$familyKey]['pontos_total'] += (float) ($row['pontos_meta'] ?? 0.0);
    $familyGroups[$familyKey]['items'][] = array_merge($row, ['card_index' => $cardIndex]);
}

$resolveIndicatorBadgeClass = static function (float $percent): string {
    if ($percent < 50) {
        return 'summary-product-card__badge--low';
    }

    if ($percent < 100) {
        return 'summary-product-card__badge--warn';
    }

    return 'summary-product-card__badge--ok';
};

$resolveIndicatorBarClass = static function (float $percent): string {
    if ($percent < 50) {
        return 'summary-product-card__track--low';
    }

    if ($percent < 100) {
        return 'summary-product-card__track--warn';
    }

    return 'summary-product-card__track--ok';
};

$metricLabel = static function (string $metric): string {
    $metric = strtoupper(trim($metric));

    if ($metric === 'PERCENTUAL') {
        return 'Percentual';
    }

    if ($metric === 'QUANTIDADE') {
        return 'Quantidade';
    }

    return 'Valor';
};

$formatCssPercent = static function (float $percent): string {
    return number_format(max(0, min(100, $percent)), 2, '.', '') . '%';
};
?>
<section class="summary-products-section" aria-label="Cards de indicadores" data-resumo-pane="cards">
    <?php foreach ($familyGroups as $familyGroup): ?>
        <section class="summary-products-family">
            <header class="summary-products-family__header">
                <h2 class="summary-products-family__title">
                    <span><?= e($familyGroup['label']) ?></span>
                    <span class="summary-products-family__meta">Pontos: <?= e(format_points_readable((float) $familyGroup['pontos_atingidos'])) ?> / <?= e(format_points_readable((float) $familyGroup['pontos_total'])) ?></span>
                </h2>
            </header>

            <div class="summary-products-family__grid">
                <?php foreach ($familyGroup['items'] as $item): ?>
                    <?php
                    $progressPercent = (float) ($item['percentual_atingimento'] ?? 0.0);
                    $pointsAchieved = (float) ($item['pontos'] ?? 0.0);
                    $pointsTotal = (float) ($item['pontos_meta'] ?? 0.0);
                    $pointsPercent = $pointsTotal > 0 ? ($pointsAchieved / $pointsTotal) * 100 : 0.0;
                    $metaValue = format_metric((float) ($item['meta'] ?? 0.0), (string) ($item['id_tipo_indicador'] ?? 'VALOR'));
                    $metaValueReadable = format_metric_readable((float) ($item['meta'] ?? 0.0), (string) ($item['id_tipo_indicador'] ?? 'VALOR'));
                    $realizadoValue = format_metric((float) ($item['realizado'] ?? 0.0), (string) ($item['id_tipo_indicador'] ?? 'VALOR'));
                    $realizadoValueReadable = format_metric_readable((float) ($item['realizado'] ?? 0.0), (string) ($item['id_tipo_indicador'] ?? 'VALOR'));
                    $absoluteRatioValue = '';
                    $absoluteRatioLabel = '';

                    if (($item['id_tipo_indicador'] ?? '') === 'PERCENTUAL' && (bool) ($item['usa_base_absoluta'] ?? false)) {
                        $absoluteRatioValue = format_quantity_readable((float) ($item['realizado_absoluto'] ?? 0.0)) . ' / ' . format_quantity_readable((float) ($item['base_absoluta'] ?? 0.0));
                        $absoluteRatioLabel = trim((string) ($item['realizado_absoluto_label'] ?? 'Realizado')) . ' / ' . trim((string) ($item['base_absoluta_label'] ?? 'Base'));
                    }

                    $updatedAt = format_date_br($item['ultima_atualizacao'] ?? null);
                    $tooltipId = 'indicator-tooltip-' . (string) ($item['id_indicador'] ?? $item['card_index']);
                    $detailUrl = app_url(array_merge($indicatorCardBaseQuery, ['indicator_focus' => (string) ($item['id_indicador'] ?? '')]));
                    $tooltipMetrics = $calculateTooltipMetrics($item, $tooltipMonthSnapshot);
                    ?>
                    <article class="summary-product-card" style="--card-delay: <?= e((string) (max(0, ((int) $item['card_index'] - 1) * 70))) ?>ms; --bar-delay: <?= e((string) (200 + max(0, ((int) $item['card_index'] - 1) * 70))) ?>ms;" data-tip-card data-detail-url="<?= e($detailUrl) ?>" tabindex="0" role="link" aria-label="Abrir detalhamento do indicador <?= e((string) ($item['nome_indicador'] ?? '')) ?>">
                        <div class="summary-product-card__title">
                            <span class="summary-product-card__icon" aria-hidden="true">
                                <i data-lucide="chart-line"></i>
                            </span>
                            <span class="summary-product-card__name" title="<?= e((string) ($item['nome_indicador'] ?? '')) ?>"><?= e((string) ($item['nome_indicador'] ?? '')) ?></span>
                            <button class="summary-product-card__badge <?= e($resolveIndicatorBadgeClass($progressPercent)) ?>" type="button" aria-label="Atingimento do indicador: <?= e(number_format($progressPercent, 1, ',', '.')) ?>%" aria-describedby="<?= e($tooltipId) ?>" data-tip-trigger>
                                <?= e(number_format($progressPercent, $progressPercent >= 100 ? 0 : 1, ',', '.')) ?>%
                            </button>
                            <div class="summary-product-card__tooltip" id="<?= e($tooltipId) ?>" role="tooltip" data-tip>
                                <h3 class="summary-product-card__tooltip-title">Pulso do indicador no mês</h3>
                                <div class="summary-product-card__tooltip-row"><span>Dias úteis do mês</span><strong><?= e(format_int_readable((float) ($tooltipMetrics['days_total'] ?? 0))) ?></strong></div>
                                <div class="summary-product-card__tooltip-row"><span>Dias úteis restantes</span><strong><?= e(format_int_readable((float) ($tooltipMetrics['days_remaining'] ?? 0))) ?></strong></div>
                                <div class="summary-product-card__tooltip-row"><span>Meta</span><strong><?= e(format_metric((float) ($tooltipMetrics['meta'] ?? 0.0), (string) ($item['id_tipo_indicador'] ?? 'VALOR'))) ?></strong></div>
                                <div class="summary-product-card__tooltip-row"><span>Realizado</span><strong><?= e(format_metric((float) ($tooltipMetrics['realizado'] ?? 0.0), (string) ($item['id_tipo_indicador'] ?? 'VALOR'))) ?></strong></div>
                                <?php if ($absoluteRatioValue !== ''): ?>
                                    <div class="summary-product-card__tooltip-row"><span><?= e($absoluteRatioLabel) ?></span><strong><?= e($absoluteRatioValue) ?></strong></div>
                                <?php endif; ?>
                                <div class="summary-product-card__tooltip-row"><span>Falta para a meta</span><strong><?= e(format_metric((float) ($tooltipMetrics['gap'] ?? 0.0), (string) ($item['id_tipo_indicador'] ?? 'VALOR'))) ?></strong></div>
                                <div class="summary-product-card__tooltip-row"><span>Meta diária necessária</span><strong><?= e(format_metric((float) ($tooltipMetrics['meta_diaria_necessaria'] ?? 0.0), (string) ($item['id_tipo_indicador'] ?? 'VALOR'))) ?></strong></div>
                                <div class="summary-product-card__tooltip-row"><span>Forecast do mês</span><strong><?= e(format_metric((float) ($tooltipMetrics['forecast'] ?? 0.0), (string) ($item['id_tipo_indicador'] ?? 'VALOR'))) ?></strong></div>
                                <div class="summary-product-card__tooltip-row"><span>Atualizado em</span><strong><?= e($updatedAt !== '' ? $updatedAt : 'N/A') ?></strong></div>
                            </div>
                        </div>

                        <div class="summary-product-card__meta">
                            <span class="summary-product-card__pill">Pontos: <?= e(format_points_readable($pointsAchieved)) ?> / <?= e(format_points_readable($pointsTotal)) ?></span>
                            <span class="summary-product-card__pill">Peso: <?= e(format_points_readable((float) ($item['peso'] ?? 0.0))) ?></span>
                            <span class="summary-product-card__pill"><?= e($metricLabel((string) ($item['id_tipo_indicador'] ?? 'VALOR'))) ?></span>
                        </div>

                        <div class="summary-product-card__kpis">
                            <div class="summary-product-card__kv">
                                <small>Meta</small>
                                <strong title="<?= e($metaValue) ?>"><?= e($metaValueReadable) ?></strong>
                            </div>
                            <div class="summary-product-card__kv">
                                <small>Realizado</small>
                                <strong title="<?= e($realizadoValue) ?>"><?= e($realizadoValueReadable) ?></strong>
                            </div>
                        </div>

                        <div class="summary-product-card__progress">
                            <div class="summary-product-card__progress-head">
                                <small>Atingimento de pontos</small>
                            </div>

                            <div class="summary-product-card__progress-body">
                                <span class="summary-product-card__progress-goal"><?= e(format_points_readable($pointsTotal)) ?> pts</span>
                                <div class="summary-product-card__track <?= e($resolveIndicatorBarClass($pointsPercent)) ?>" role="progressbar" aria-valuenow="<?= e(number_format(max(0, min(100, $pointsPercent)), 1, '.', '')) ?>" aria-valuemin="0" aria-valuemax="100">
                                    <span class="summary-product-card__fill" style="--target: <?= e($formatCssPercent($pointsPercent)) ?>;"></span>
                                    <span class="summary-product-card__progress-label" style="--target: <?= e($formatCssPercent($pointsPercent)) ?>;">
                                        <span class="summary-product-card__progress-value"><?= e(number_format($pointsPercent, 1, ',', '.')) ?>%</span>
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div class="summary-product-card__foot">Atualizado em <?= e($updatedAt !== '' ? $updatedAt : 'N/A') ?></div>
                    </article>
                <?php endforeach; ?>
            </div>
        </section>
    <?php endforeach; ?>
</section>