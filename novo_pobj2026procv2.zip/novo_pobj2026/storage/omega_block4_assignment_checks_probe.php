<?php

declare(strict_types=1);

error_reporting(E_ERROR | E_PARSE);
ini_set('display_errors', '1');
$_SERVER['HTTPS'] = 'off';
$_SERVER['SERVER_PORT'] = 80;

require __DIR__ . '/../bootstrap.php';

$connection = \App\Database::connection();
$service = new \App\Services\OmegaDashboardService($connection);

$hasTableMethod = new ReflectionMethod($service, 'hasTable');
$hasTableMethod->setAccessible(true);
$assignableMethod = new ReflectionMethod($service, 'isAssignableAnalystFunctional');
$assignableMethod->setAccessible(true);
$mappedMethod = new ReflectionMethod($service, 'isAnalystMappedToTeam');
$mappedMethod->setAccessible(true);

$hierarchyExists = (bool) $hasTableMethod->invoke($service, 'dHierarquia');
$analystTeamExists = (bool) $hasTableMethod->invoke($service, 'fomegaanalistatime');

$assignableFunctional = '';
$assignableExpected = false;

if ($hierarchyExists) {
    $row = $connection->query(
        'SELECT funcional
         FROM `dHierarquia`
         WHERE ativo_sn = 1
           AND nivel IN ("AG", "GG", "TL", "GC", "PA", "AS")
           AND funcional IS NOT NULL
           AND funcional <> ""
         LIMIT 1'
    )->fetch(PDO::FETCH_ASSOC);
    $assignableFunctional = trim((string) ($row['funcional'] ?? ''));
    $assignableExpected = $assignableFunctional !== '';
}

$mappingFunctional = '';
$mappingTeamId = 0;
$mappingExpected = false;

if ($analystTeamExists) {
    $row = $connection->query(
        'SELECT id_omega_time, funcional_analista
         FROM `fomegaanalistatime`
         WHERE ativo_sn = 1
           AND funcional_analista IS NOT NULL
           AND funcional_analista <> ""
         LIMIT 1'
    )->fetch(PDO::FETCH_ASSOC);
    $mappingFunctional = substr(trim((string) ($row['funcional_analista'] ?? '')), 0, 7);
    $mappingTeamId = (int) ($row['id_omega_time'] ?? 0);
    $mappingExpected = $mappingFunctional !== '' && $mappingTeamId > 0;
}

$assignableActual = $assignableMethod->invoke($service, $assignableFunctional);
$mappingActual = $mappedMethod->invoke($service, $mappingFunctional, $mappingTeamId);

echo json_encode([
    'assignable' => [
        'hierarchy_exists' => $hierarchyExists,
        'functional' => $assignableFunctional,
        'matches' => $assignableExpected === $assignableActual,
        'actual' => $assignableActual,
    ],
    'mapping' => [
        'analyst_team_exists' => $analystTeamExists,
        'functional' => $mappingFunctional,
        'team_id' => $mappingTeamId,
        'matches' => $mappingExpected === $mappingActual,
        'actual' => $mappingActual,
    ],
], JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT), PHP_EOL;