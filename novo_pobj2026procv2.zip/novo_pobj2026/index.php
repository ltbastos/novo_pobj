<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

use App\Database;
use App\Services\EncantabraDashboardService;
use App\Services\PobjDashboardService;
use App\Services\PrimeBrandService;
use App\Services\ProfileSimulationService;

$connection = Database::connection();
$profileService = new ProfileSimulationService($connection);
$dashboardService = new PobjDashboardService($connection);
$brandService = new PrimeBrandService($connection);
$encantabraService = new EncantabraDashboardService($connection);

$requestMethod = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$requestAction = sanitize_request_token((string) ($_POST['action'] ?? $_GET['action'] ?? ''));

$allowedCanonicalKeys = [
    'tab',
    'advanced_filters',
    'detail_table_view',
    'detail_page',
    'indicator_focus',
    'indicator_page',
    'grupo',
    'segmento',
    'diretoria',
    'regional',
    'agencia',
    'gerente_gestao',
    'gerente',
    'familia',
    'indicadores',
    'subindicador',
    'status_indicadores',
    'visao_acumulada',
    'enc_tab',
    'enc_anomes',
    'enc_perfil',
    'enc_segmento',
    'enc_juncao',
    'enc_funcional',
    'enc_indicador',
    'enc_page',
];

if ($requestMethod === 'POST' && $requestAction === 'select_profile') {
    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        http_response_code(419);
        exit('Falha de validacao do formulario de perfil.');
    }

    $selectedFunctional = trim((string) ($_POST['selected_functional'] ?? ''));

    if ($selectedFunctional !== '' && $profileService->profileExists($selectedFunctional)) {
        $_SESSION['selected_profile_functional'] = $selectedFunctional;
    }

    $redirectQuery = [
        'page' => 'pobj-dashboard',
        'tab' => 'resumo',
    ];

    if (!isset($redirectQuery['periodo'])) {
        $redirectPeriod = sanitize_request_token((string) ($_POST['periodo'] ?? $_GET['periodo'] ?? ''));

        if ($redirectPeriod !== '') {
            $redirectQuery['periodo'] = $redirectPeriod;
        }
    }

    if (!isset($redirectQuery['periodo_mes'])) {
        $redirectPeriodMonth = sanitize_request_token((string) ($_POST['periodo_mes'] ?? $_GET['periodo_mes'] ?? ''));

        if ($redirectPeriodMonth !== '') {
            $redirectQuery['periodo_mes'] = $redirectPeriodMonth;
        }
    }

    redirect_internal('index.php', $redirectQuery);
}

$profiles = $profileService->listProfiles();
$selectedProfileFunctional = $_SESSION['selected_profile_functional'] ?? ($profiles[0]['funcional'] ?? null);

if ($selectedProfileFunctional !== null && !$profileService->profileExists((string) $selectedProfileFunctional)) {
    $selectedProfileFunctional = $profiles[0]['funcional'] ?? null;
}

if ($selectedProfileFunctional !== null) {
    $_SESSION['selected_profile_functional'] = $selectedProfileFunctional;
}

$context = $selectedProfileFunctional !== null ? $profileService->getContext($selectedProfileFunctional) : null;

if ($context === null && $profiles !== []) {
    $selectedProfileFunctional = $profiles[0]['funcional'] ?? null;

    if ($selectedProfileFunctional !== null) {
        $_SESSION['selected_profile_functional'] = $selectedProfileFunctional;
        $context = $profileService->getContext($selectedProfileFunctional);
    }
}
$periods = $dashboardService->listPeriods();
$closedMonthOptions = build_closed_month_period_options($periods);
$requestedPeriodStart = sanitize_request_date((string) ($_GET['period_start'] ?? ''));
$requestedPeriodEnd = sanitize_request_date((string) ($_GET['period_end'] ?? ''));
$requestedPeriodMode = sanitize_request_choice((string) ($_GET['period_mode'] ?? ''), ['manual'], '');
$requestedPeriodMonthRaw = sanitize_request_token((string) ($_GET['periodo_mes'] ?? ''));
$requestedPeriodMonth = $requestedPeriodMonthRaw;
$legacyRequestedPeriodMonth = $requestedPeriodMonth === ''
    ? resolve_closed_month_value_from_dates($requestedPeriodStart, $requestedPeriodEnd)
    : '';
$hasManualDateRange = false;
$hasLegacyAutoDateRange = $requestedPeriodMode !== '' || $requestedPeriodStart !== '' || $requestedPeriodEnd !== '';

if ($requestedPeriodMonth === '' && $legacyRequestedPeriodMonth !== '') {
    $requestedPeriodMonth = $legacyRequestedPeriodMonth;
}

$requestedAccumulatedView = sanitize_request_choice(
    (string) ($_GET['visao_acumulada'] ?? 'MENSAL'),
    ['MENSAL', 'SEMESTRAL', 'ACUMULADO', 'MENSAL_ACUMULADO'],
    'MENSAL'
);
$displayPeriodStart = '';
$displayPeriodEnd = '';
$selectedPeriodMonth = '';
$selectedClosedMonth = null;

foreach ($closedMonthOptions as $monthOption) {
    if ((string) ($monthOption['value'] ?? '') !== $requestedPeriodMonth) {
        continue;
    }

    $selectedClosedMonth = $monthOption;
    break;
}

if ($selectedClosedMonth === null) {
    $selectedClosedMonth = $closedMonthOptions[0] ?? null;
}

if ($selectedClosedMonth !== null) {
    $selectedPeriodMonth = trim((string) ($selectedClosedMonth['value'] ?? ''));
}

$selectedPeriodId = isset($_GET['periodo']) && is_string($_GET['periodo']) && $_GET['periodo'] !== ''
    ? sanitize_request_token($_GET['periodo'])
    : ($periods[0]['id_periodo'] ?? null);

if ($selectedClosedMonth !== null) {
    $selectedPeriodId = trim((string) ($selectedClosedMonth['periodo'] ?? $selectedPeriodId));
    $accumulatedRange = resolve_accumulated_view_date_range(
        $requestedAccumulatedView,
        (string) ($selectedClosedMonth['end'] ?? '')
    );
    $displayPeriodStart = $accumulatedRange['start'];
    $displayPeriodEnd = $accumulatedRange['end'];
} else {
    $accumulatedRange = resolve_accumulated_view_date_range($requestedAccumulatedView);
    $displayPeriodStart = $accumulatedRange['start'];
    $displayPeriodEnd = $accumulatedRange['end'];
}

$availablePeriodIds = array_values(array_filter(array_map(static function (array $periodRow): string {
    return trim((string) ($periodRow['id_periodo'] ?? ''));
}, $periods)));

if ($selectedPeriodId !== null && !in_array($selectedPeriodId, $availablePeriodIds, true)) {
    $selectedPeriodId = $periods[0]['id_periodo'] ?? null;
}

if ($selectedClosedMonth === null && $context !== null && $selectedPeriodId !== null && !$dashboardService->periodHasVisibleData($context, $selectedPeriodId)) {
    foreach ($periods as $periodRow) {
        $candidatePeriodId = trim((string) ($periodRow['id_periodo'] ?? ''));

        if ($candidatePeriodId === '' || !$dashboardService->periodHasVisibleData($context, $candidatePeriodId)) {
            continue;
        }

        $selectedPeriodId = $candidatePeriodId;
        break;
    }
}

if ($requestMethod === 'GET' && $selectedPeriodMonth !== '' && (
    $hasLegacyAutoDateRange
    || $requestedPeriodMonthRaw === ''
    || $requestedPeriodMonthRaw !== $selectedPeriodMonth
    || sanitize_request_token((string) ($_GET['periodo'] ?? '')) !== (string) ($selectedPeriodId ?? '')
)) {
    $canonicalQuery = ['page' => 'pobj-dashboard'];

    foreach ($_GET as $queryKey => $queryValue) {
        if (
            !is_string($queryKey)
            || !in_array($queryKey, $allowedCanonicalKeys, true)
            || in_array($queryKey, ['period_mode', 'period_start', 'period_end', 'periodo_mes'], true)
            || is_array($queryValue)
        ) {
            continue;
        }

        $trimmedValue = sanitize_redirect_value((string) $queryValue);

        if ($trimmedValue === '') {
            continue;
        }

        $canonicalQuery[$queryKey] = $trimmedValue;
    }

    if ($selectedPeriodId !== null) {
        $canonicalQuery['periodo'] = $selectedPeriodId;
    }

    $canonicalQuery['periodo_mes'] = $selectedPeriodMonth;

    redirect_internal('index.php', $canonicalQuery);
}

$requestedAdvancedFiltersState = sanitize_request_choice((string) ($_GET['advanced_filters'] ?? 'open'), ['open', 'closed'], 'open');
$advancedFiltersState = in_array($requestedAdvancedFiltersState, ['open', 'closed'], true)
    ? $requestedAdvancedFiltersState
    : 'open';
$requestedDetailTableView = sanitize_request_token((string) ($_GET['detail_table_view'] ?? ''));
$requestedDetailPage = max(1, (int) ($_GET['detail_page'] ?? 1));
$requestedIndicatorFocus = sanitize_request_token((string) ($_GET['indicator_focus'] ?? ''));
$requestedIndicatorPage = max(1, (int) ($_GET['indicator_page'] ?? 1));
$requestedRankingGroup = sanitize_request_token((string) ($_GET['grupo'] ?? ''));

$requestedSummaryFilters = [
    'segmento' => sanitize_request_token((string) ($_GET['segmento'] ?? '')),
    'diretoria' => sanitize_request_token((string) ($_GET['diretoria'] ?? '')),
    'regional' => sanitize_request_token((string) ($_GET['regional'] ?? '')),
    'agencia' => sanitize_request_token((string) ($_GET['agencia'] ?? '')),
    'gerente_gestao' => sanitize_request_token((string) ($_GET['gerente_gestao'] ?? '')),
    'gerente' => sanitize_request_token((string) ($_GET['gerente'] ?? '')),
    'familia' => sanitize_request_token((string) ($_GET['familia'] ?? '')),
    'indicadores' => sanitize_request_token((string) ($_GET['indicadores'] ?? '')),
    'subindicador' => sanitize_request_token((string) ($_GET['subindicador'] ?? '')),
    'status_indicadores' => sanitize_request_choice((string) ($_GET['status_indicadores'] ?? ''), ['', 'ATINGIDO', 'NAO_ATINGIDO'], ''),
    'visao_acumulada' => $requestedAccumulatedView,
];

$summaryFilters = $context !== null && $selectedPeriodId !== null
    ? $dashboardService->prepareSummaryFilters($context, $selectedPeriodId, $requestedSummaryFilters, $displayPeriodEnd)
    : [
        'options' => [
            'segmento' => [],
            'diretoria' => [],
            'regional' => [],
            'agencia' => [],
            'gerente_gestao' => [],
            'gerente' => [],
            'familia' => [],
            'indicadores' => [],
            'subindicador' => [],
            'status_indicadores' => [],
            'visao_acumulada' => [
                ['value' => 'MENSAL', 'label' => 'Mensal'],
                ['value' => 'SEMESTRAL', 'label' => 'Semestral'],
                ['value' => 'ACUMULADO', 'label' => 'Acumulado'],
                ['value' => 'MENSAL_ACUMULADO', 'label' => 'Mensal/Acumulado'],
            ],
        ],
        'values' => $requestedSummaryFilters,
        'states' => [
            'segmento' => ['enabled' => true, 'placeholder' => 'Todos'],
            'diretoria' => ['enabled' => false, 'placeholder' => 'Selecione os filtros anteriores'],
            'regional' => ['enabled' => false, 'placeholder' => 'Selecione os filtros anteriores'],
            'agencia' => ['enabled' => false, 'placeholder' => 'Selecione os filtros anteriores'],
            'gerente_gestao' => ['enabled' => false, 'placeholder' => 'Selecione os filtros anteriores'],
            'gerente' => ['enabled' => false, 'placeholder' => 'Selecione os filtros anteriores'],
        ],
    ];

$summaryFilterOptions = $summaryFilters['options'];
$summaryFilterValues = $summaryFilters['values'];
$summaryFilterStates = $summaryFilters['states'] ?? [];
$visualTheme = $brandService->resolveVisualTheme($context, $summaryFilterValues);

$allowedTabs = ['resumo', 'detalhamento', 'rankings', 'visao-executiva', 'encantabra', 'simuladores', 'campanhas'];
$requestedTab = sanitize_request_choice((string) ($_GET['tab'] ?? 'resumo'), $allowedTabs, 'resumo');
$activeTab = in_array($requestedTab, $allowedTabs, true) ? $requestedTab : 'resumo';
$profileLevel = strtoupper(trim((string) (($context['profile']['nivel'] ?? ''))));

$allowedEncantabraSections = ['resultado', 'regulamento', 'apoio'];
$requestedEncantabraSection = sanitize_request_choice((string) ($_GET['enc_tab'] ?? 'resultado'), $allowedEncantabraSections, 'resultado');
$encantabraActiveSection = in_array($requestedEncantabraSection, $allowedEncantabraSections, true)
    ? $requestedEncantabraSection
    : 'resultado';
$requestedEncantabraPage = max(1, (int) ($_GET['enc_page'] ?? 1));
$requestedEncantabraFilters = [
    'anomes' => sanitize_request_token((string) ($_GET['enc_anomes'] ?? '')),
    'perfil' => sanitize_request_choice((string) ($_GET['enc_perfil'] ?? 'SG'), ['SG', 'AG', 'GC'], 'SG'),
    'segmento' => sanitize_request_token((string) ($_GET['enc_segmento'] ?? '')),
    'juncao' => sanitize_request_token((string) ($_GET['enc_juncao'] ?? '')),
    'funcional' => sanitize_request_token((string) ($_GET['enc_funcional'] ?? '')),
    'indicador' => sanitize_request_token((string) ($_GET['enc_indicador'] ?? '')),
];
$encantabraFilters = $encantabraService->prepareFilters($requestedEncantabraFilters);
$encantabraFilterOptions = $encantabraFilters['options'];
$encantabraFilterValues = $encantabraFilters['values'];
$encantabraQueryState = ['enc_tab' => $encantabraActiveSection];

foreach ($encantabraFilterValues as $filterKey => $filterValue) {
    if (!is_string($filterValue) || $filterValue === '') {
        continue;
    }

    $encantabraQueryState['enc_' . $filterKey] = $filterValue;
}

if ($requestedEncantabraPage > 1) {
    $encantabraQueryState['enc_page'] = (string) $requestedEncantabraPage;
}

$dashboardData = $context !== null && $selectedPeriodId !== null
    ? $dashboardService->getDashboardData($context, $selectedPeriodId, $summaryFilterValues, $displayPeriodStart, $displayPeriodEnd)
    : ['summary' => [], 'indicators' => []];

$indicatorFocusId = '';

foreach (($dashboardData['indicators'] ?? []) as $indicatorRow) {
    if ((string) ($indicatorRow['id_indicador'] ?? '') !== $requestedIndicatorFocus) {
        continue;
    }

    $indicatorFocusId = $requestedIndicatorFocus;
    break;
}

$detailData = $context !== null && $selectedPeriodId !== null && $activeTab === 'detalhamento'
    ? $dashboardService->getDetailData(
        $context,
        $selectedPeriodId,
        $summaryFilterValues,
        $displayPeriodStart,
        $displayPeriodEnd,
        $requestedDetailTableView,
        $requestedDetailPage
    )
    : ['summary' => [], 'rows' => [], 'pagination' => ['page' => 1, 'per_page' => 20, 'total_rows' => 0, 'total_pages' => 1, 'from' => 0, 'to' => 0]];

$indicatorDetailData = $context !== null && $selectedPeriodId !== null && $indicatorFocusId !== ''
    ? $dashboardService->getIndicatorDetailData($context, $selectedPeriodId, $summaryFilterValues, $indicatorFocusId, $displayPeriodStart, $displayPeriodEnd, $requestedIndicatorPage)
    : [
        'indicator' => [],
        'summary' => [],
        'trend' => [],
        'distributions' => ['channels' => [], 'statuses' => []],
        'insights' => ['mode' => 'hierarchy', 'label' => '', 'title' => '', 'top' => [], 'bottom' => []],
        'transactions' => [],
        'analytic_pagination' => ['page' => 1, 'per_page' => 20, 'total_rows' => 0, 'total_pages' => 1, 'from' => 0, 'to' => 0],
    ];

$rankingGroupOptions = $context !== null && $selectedPeriodId !== null && $activeTab === 'rankings'
    ? $dashboardService->listRankingGroupOptions($context, $selectedPeriodId, $summaryFilterValues, $displayPeriodStart, $displayPeriodEnd)
    : [];

$rankingHasSingleGroup = count($rankingGroupOptions) === 1;
$rankingDefaultGroup = $rankingHasSingleGroup ? trim((string) ($rankingGroupOptions[0]['value'] ?? '')) : '';
$rankingShowAllGroups = $profileLevel === 'DP' || !$rankingHasSingleGroup;
$requestedRankingGroup = $dashboardService->sanitizeFilterSelection(
    $requestedRankingGroup,
    $rankingGroupOptions,
    $profileLevel !== 'DP' && $rankingHasSingleGroup ? $rankingDefaultGroup : ''
);
$rankingFilters = array_merge($summaryFilterValues, ['grupo' => $requestedRankingGroup]);

$rankingData = $context !== null && $selectedPeriodId !== null && $activeTab === 'rankings'
    ? $dashboardService->getRankingData($context, $selectedPeriodId, $rankingFilters, $displayPeriodStart, $displayPeriodEnd)
    : ['level' => 'gerente_gestao', 'level_label' => 'Gerente de gestão', 'rows' => []];

$executiveData = $context !== null && $selectedPeriodId !== null && $activeTab === 'visao-executiva'
    ? $dashboardService->getExecutiveViewData($context, $selectedPeriodId, $summaryFilterValues, $displayPeriodStart, $displayPeriodEnd)
    : [
        'focus' => ['level' => 'regional', 'label' => 'Regional', 'ranking_title' => 'Desempenho por Regional', 'status_title' => 'Status por Regional'],
        'reference' => ['period_label' => '', 'range_label' => '', 'month_label' => '', 'window_label' => 'Últimos 6 meses'],
        'kpis' => [],
        'chart' => ['labels' => [], 'series' => [], 'max_value' => 100.0],
        'ranking' => ['top' => [], 'bottom' => []],
        'status' => ['hit' => [], 'quase' => [], 'longe' => [], 'summary' => ['hit' => 0, 'quase' => 0, 'longe' => 0]],
        'heatmap' => [
            'default_mode' => 'secoes',
            'secoes' => ['title' => '', 'row_axis_label' => 'GR', 'row_axis_sublabel' => 'Famílias', 'rows' => [], 'columns' => [], 'data' => []],
            'meta' => ['title' => '', 'row_axis_label' => 'Hierarquia', 'row_axis_sublabel' => 'Mês', 'rows' => [], 'months' => [], 'data' => []],
        ],
    ];

$encantabraData = $activeTab === 'encantabra'
    ? $encantabraService->getDashboardData($encantabraFilterValues, $requestedEncantabraPage)
    : [
        'reference' => ['month_label' => '', 'scope_label' => '', 'profile_label' => '', 'segment_label' => ''],
        'summary' => ['score_avg' => 0.0, 'meta_avg' => 0.0, 'real_avg' => 0.0, 'rows_total' => 0, 'entities_total' => 0, 'indicators_total' => 0, 'best_indicator' => null, 'worst_indicator' => null, 'band' => ['label' => 'Sem dados', 'range' => 'Sem leitura', 'tone' => 'is-empty']],
        'status' => ['fan' => 0, 'encantador' => 0, 'expectativa' => 0, 'critico' => 0],
        'chart' => ['labels' => [], 'series' => [], 'max_value' => 150.0],
        'trimester_tables' => ['year' => '', 'tables' => []],
        'ranking' => ['title' => '', 'top' => [], 'bottom' => []],
        'heatmap' => ['title' => '', 'rows' => [], 'months' => [], 'data' => []],
        'table' => ['title' => '', 'subtitle' => '', 'columns' => [], 'rows' => [], 'total_rows' => 0, 'current_page' => 1, 'per_page' => 20, 'total_pages' => 1],
    ];

$annualPerformanceData = $context !== null
    && ($summaryFilterValues['visao_acumulada'] ?? 'MENSAL') === 'ANUAL'
    && $activeTab === 'resumo'
    ? $dashboardService->getAnnualPerformanceData($context, $summaryFilterValues, $displayPeriodEnd)
    : ['year' => (int) date('Y'), 'rows' => [], 'summary' => ['atingiu' => 0, 'quase' => 0, 'distante' => 0]];

$selectedPeriod = null;

foreach ($periods as $periodRow) {
    if (($periodRow['id_periodo'] ?? null) === $selectedPeriodId) {
        $selectedPeriod = $periodRow;
        break;
    }
}

$legacyBusinessSnapshot = resolve_business_day_snapshot(
    $displayPeriodStart !== '' ? $displayPeriodStart : ($selectedPeriod['dt_inicio_periodo'] ?? null),
    $displayPeriodEnd !== '' ? $displayPeriodEnd : ($selectedPeriod['dt_fim_periodo'] ?? null)
);

$pageTitle = $activeTab === 'encantabra'
    ? 'Encantabra'
    : 'POBJ';

$isDetailPaneRequest = $requestMethod === 'GET'
    && $activeTab === 'detalhamento'
    && $requestedDetailTableView !== ''
    && strcasecmp(trim((string) ($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')), 'XMLHttpRequest') === 0;

if ($isDetailPaneRequest) {
    $detailPaneOnlyMode = true;
    require __DIR__ . '/templates/detail_view.php';
    exit;
}

require __DIR__ . '/templates/layout.php';
