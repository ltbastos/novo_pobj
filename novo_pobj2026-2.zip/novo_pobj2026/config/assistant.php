<?php

declare(strict_types=1);

return [
    'openai_api_key' => '',
    'openai_model' => 'gpt-4.1-mini',
];