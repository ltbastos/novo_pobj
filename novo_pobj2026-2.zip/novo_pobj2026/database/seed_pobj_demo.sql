USE novo_pobj;

CREATE TABLE IF NOT EXISTS dSegmento (
    id_segmento BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    segmento VARCHAR(20) NOT NULL,
    juncao_segmento CHAR(4) NOT NULL,
    nome_segmento VARCHAR(150) NOT NULL,
    ativo_sn TINYINT(1) NOT NULL DEFAULT 1,
    origem_carga VARCHAR(50) NOT NULL DEFAULT 'SEED',
    dt_inclusao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dt_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_segmento),
    UNIQUE KEY uk_dsegmento_segmento (segmento),
    UNIQUE KEY uk_dsegmento_juncao (juncao_segmento)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS dGrupo (
    id_grupo CHAR(4) NOT NULL,
    nome_grupo VARCHAR(150) NOT NULL,
    ativo_sn TINYINT(1) NOT NULL DEFAULT 1,
    origem_carga VARCHAR(50) NOT NULL DEFAULT 'SEED',
    dt_inclusao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dt_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_grupo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS fGrupoFuncional (
    id_grupo_funcional BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    funcional CHAR(7) NOT NULL,
    id_grupo CHAR(4) NOT NULL,
    ativo_sn TINYINT(1) NOT NULL DEFAULT 1,
    origem_carga VARCHAR(50) NOT NULL DEFAULT 'SEED',
    dt_inclusao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dt_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_grupo_funcional),
    UNIQUE KEY uk_fgrupofuncional_funcional (funcional),
    KEY idx_fgrupofuncional_grupo (id_grupo)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS fGestaoGerente (
    id_gestao_gerente BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    funcional_gerente CHAR(7) NOT NULL,
    funcional_gerente_gestao CHAR(7) NOT NULL,
    ativo_sn TINYINT(1) NOT NULL DEFAULT 1,
    origem_carga VARCHAR(50) NOT NULL DEFAULT 'SEED',
    dt_inclusao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dt_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_gestao_gerente),
    UNIQUE KEY uk_fgestaogerente_gerente (funcional_gerente),
    KEY idx_fgestaogerente_gestao (funcional_gerente_gestao)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

ALTER TABLE dMesu
    ADD COLUMN IF NOT EXISTS id_segmento BIGINT UNSIGNED NULL AFTER nome_diretoria,
    ADD COLUMN IF NOT EXISTS subsegmento VARCHAR(20) NOT NULL DEFAULT 'Classic' AFTER id_segmento;

DELETE FROM fDetalhe
WHERE origem_carga = 'SEED';

DELETE FROM fVariavel
WHERE origem_carga = 'SEED';

DELETE FROM fPontos
WHERE origem_carga = 'SEED';

DELETE FROM fRealizado
WHERE origem_carga = 'SEED';

DELETE FROM fMeta
WHERE origem_carga = 'SEED';

DELETE FROM fIndicadorSegmentoPeriodo
WHERE origem_carga = 'SEED';

DELETE FROM fIndicadorPeriodo
WHERE origem_carga = 'SEED';

DELETE FROM fEncarteiramento
WHERE origem_carga = 'SEED';

DELETE FROM fGrupoFuncional
WHERE origem_carga = 'SEED';

DELETE FROM fGestaoGerente
WHERE origem_carga = 'SEED';

DELETE FROM fMultiJuncao
WHERE origem_carga = 'SEED';

DELETE FROM dHierarquia
WHERE origem_carga = 'SEED';

DELETE FROM dMesu
WHERE origem_carga = 'SEED';

UPDATE dPeriodoApuracao
SET ativo_sn = FALSE,
        origem_carga = 'SEED'
WHERE origem_carga = 'SEED'
    AND id_periodo LIKE '2026%';

INSERT INTO dSegmento (
    segmento,
    juncao_segmento,
    nome_segmento,
    ativo_sn,
    origem_carga
) VALUES
    ('NEGOCIOS', '8607', 'Empresas', TRUE, 'SEED'),
    ('DIGITAL', '8608', 'Digital', TRUE, 'SEED')
ON DUPLICATE KEY UPDATE
    nome_segmento = VALUES(nome_segmento),
    ativo_sn = VALUES(ativo_sn),
    origem_carga = VALUES(origem_carga);

INSERT INTO dGrupo (
    id_grupo,
    nome_grupo,
    ativo_sn,
    origem_carga
) VALUES
    ('G001', 'Grupo Norte', TRUE, 'SEED'),
    ('G002', 'Grupo Sul', TRUE, 'SEED')
ON DUPLICATE KEY UPDATE
    nome_grupo = VALUES(nome_grupo),
    ativo_sn = VALUES(ativo_sn),
    origem_carga = VALUES(origem_carga);

INSERT IGNORE INTO dPeriodoApuracao (
    id_periodo,
    descricao_periodo,
    dt_inicio_periodo,
    dt_fim_periodo,
    ativo_sn,
    origem_carga
) VALUES
    ('2026T1', '1o Trimestre 2026', '2026-01-01', '2026-03-31', TRUE, 'SEED'),
    ('2026T2', '2o Trimestre 2026', '2026-04-01', '2026-06-30', TRUE, 'SEED');

INSERT IGNORE INTO dFamiliaProduto (
    id_familia,
    nome_familia,
    ordem_exibicao,
    ativo_sn,
    origem_carga
) VALUES
    (1, 'Credito', 1, TRUE, 'SEED'),
    (2, 'Relacionamento', 2, TRUE, 'SEED'),
    (3, 'Seguros', 3, TRUE, 'SEED');

INSERT IGNORE INTO dTipoIndicador (
    id_tipo_indicador,
    nome_tipo_indicador,
    formato_exibicao,
    casas_decimais,
    prefixo,
    sufixo,
    ativo_sn,
    origem_carga
) VALUES
    ('VALOR', 'Valor', 'currency', 2, 'R$', NULL, TRUE, 'SEED'),
    ('PERCENTUAL', 'Percentual', 'percent', 2, NULL, '%', TRUE, 'SEED'),
    ('QUANTIDADE', 'Quantidade', 'number', 0, NULL, NULL, TRUE, 'SEED');

INSERT IGNORE INTO dIndicador (
    id_indicador,
    id_familia,
    id_tipo_indicador,
    nome_indicador,
    descricao,
    possui_subindicador_sn,
    ordem_exibicao,
    ativo_sn,
    origem_carga
) VALUES
    (101, 1, 'VALOR', 'Credito Total', 'Volume de credito produzido no periodo.', FALSE, 1, TRUE, 'SEED'),
    (102, 1, 'VALOR', 'Capital de Giro', 'Volume de capital de giro desembolsado no periodo.', FALSE, 2, TRUE, 'SEED'),
    (201, 2, 'PERCENTUAL', 'Giro de Carteira', 'Percentual de clientes com contato realizado sobre a base da carteira.', TRUE, 3, TRUE, 'SEED'),
    (301, 3, 'QUANTIDADE', 'Seguro Vida', 'Quantidade de seguros de vida vendidos no periodo.', FALSE, 4, TRUE, 'SEED');

INSERT IGNORE INTO dSubindicador (
    id_subindicador,
    id_indicador,
    nome_subindicador,
    descricao,
    ordem_exibicao,
    ativo_sn,
    origem_carga
) VALUES
    (2101, 201, 'Base da carteira', 'Quantidade de clientes elegiveis na carteira do gerente.', 1, TRUE, 'SEED'),
    (2102, 201, 'Clientes com contato', 'Quantidade de clientes com contato registrado no periodo.', 2, TRUE, 'SEED');

INSERT IGNORE INTO dMesu (
    juncao_ag,
    juncao_gr,
    juncao_dr,
    nome_agencia,
    nome_regional,
    nome_diretoria,
    ativo_sn,
    origem_carga
) VALUES
    ('1101', '2101', '3101', 'Agencia Centro', 'Regional Capital', 'Diretoria Norte', TRUE, 'SEED'),
    ('1102', '2101', '3101', 'Agencia Jardim', 'Regional Capital', 'Diretoria Norte', TRUE, 'SEED'),
    ('1201', '2201', '3201', 'Agencia Litoral', 'Regional Costa', 'Diretoria Sul', TRUE, 'SEED');

UPDATE dMesu
SET id_segmento = CASE
        WHEN LOWER(COALESCE(nome_diretoria, '')) LIKE '%norte%' THEN (SELECT id_segmento FROM dSegmento WHERE segmento = 'NEGOCIOS' LIMIT 1)
        ELSE (SELECT id_segmento FROM dSegmento WHERE segmento = 'DIGITAL' LIMIT 1)
    END,
    subsegmento = CASE
        WHEN LOWER(COALESCE(nome_diretoria, '')) LIKE '%norte%'
          OR LOWER(COALESCE(nome_regional, '')) LIKE '%norte%'
          OR LOWER(COALESCE(nome_agencia, '')) LIKE '%norte%'
        THEN 'Prime'
        ELSE 'Classic'
    END
WHERE origem_carga = 'SEED';

INSERT IGNORE INTO dHierarquia (
    funcional,
    nome,
    email,
    cargo,
    nivel,
    ativo_sn,
    origem_carga
) VALUES
    ('9000001', 'Elaine Departamento', 'elaine.departamento@teste.local', 'Diretoria Departamental', 'DP', TRUE, 'SEED'),
    ('8000001', 'Renato Diretor Norte', 'renato.diretor@teste.local', 'Diretor Regional', 'DR', TRUE, 'SEED'),
    ('8000002', 'Sonia Diretora Sul', 'sonia.diretora@teste.local', 'Diretor Regional', 'DR', TRUE, 'SEED'),
    ('7000001', 'Marta Regional Capital', 'marta.regional@teste.local', 'Gerente Regional', 'GR', TRUE, 'SEED'),
    ('7000002', 'Paulo Regional Costa', 'paulo.regional@teste.local', 'Gerente Regional', 'GR', TRUE, 'SEED'),
    ('6000001', 'Lara Agencia Centro', 'lara.agencia@teste.local', 'Gerente de Agencia', 'AG', TRUE, 'SEED'),
    ('6000002', 'Davi Agencia Jardim', 'davi.agencia@teste.local', 'Gerente de Agencia', 'AG', TRUE, 'SEED'),
    ('6000003', 'Nina Agencia Litoral', 'nina.agencia@teste.local', 'Gerente de Agencia', 'AG', TRUE, 'SEED'),
    ('4000001', 'Bruno GC Centro', 'bruno.gc@teste.local', 'Gerente de Contas', 'GC', TRUE, 'SEED'),
    ('4000002', 'Carla GC Jardim', 'carla.gc@teste.local', 'Gerente de Contas', 'GC', TRUE, 'SEED'),
    ('4000003', 'Diego GC Litoral', 'diego.gc@teste.local', 'Gerente de Contas', 'GC', TRUE, 'SEED');

INSERT IGNORE INTO fMultiJuncao (
    funcional,
    juncao,
    tipo_juncao,
    principal_sn,
    ativo_sn,
    origem_carga
) VALUES
    ('9000001', '4000', 'DP', TRUE, TRUE, 'SEED'),
    ('8000001', '3101', 'DR', TRUE, TRUE, 'SEED'),
    ('8000002', '3201', 'DR', TRUE, TRUE, 'SEED'),
    ('7000001', '2101', 'GR', TRUE, TRUE, 'SEED'),
    ('7000002', '2201', 'GR', TRUE, TRUE, 'SEED'),
    ('6000001', '1101', 'AG', TRUE, TRUE, 'SEED'),
    ('6000002', '1102', 'AG', TRUE, TRUE, 'SEED'),
    ('6000003', '1201', 'AG', TRUE, TRUE, 'SEED'),
    ('4000001', '1101', 'AG', TRUE, TRUE, 'SEED'),
    ('4000002', '1102', 'AG', TRUE, TRUE, 'SEED'),
    ('4000003', '1201', 'AG', TRUE, TRUE, 'SEED');

INSERT INTO fGrupoFuncional (
    funcional,
    id_grupo,
    ativo_sn,
    origem_carga
) VALUES
    ('9000001', 'G001', TRUE, 'SEED'),
    ('8000001', 'G001', TRUE, 'SEED'),
    ('8000002', 'G002', TRUE, 'SEED'),
    ('7000001', 'G001', TRUE, 'SEED'),
    ('7000002', 'G002', TRUE, 'SEED'),
    ('6000001', 'G001', TRUE, 'SEED'),
    ('6000002', 'G001', TRUE, 'SEED'),
    ('6000003', 'G002', TRUE, 'SEED'),
    ('4000001', 'G001', TRUE, 'SEED'),
    ('4000002', 'G001', TRUE, 'SEED'),
    ('4000003', 'G002', TRUE, 'SEED')
ON DUPLICATE KEY UPDATE
    id_grupo = VALUES(id_grupo),
    ativo_sn = VALUES(ativo_sn),
    origem_carga = VALUES(origem_carga);

INSERT IGNORE INTO fEncarteiramento (
    juncao_ag,
    conta,
    cnpj,
    funcional,
    ativo_sn,
    origem_carga,
    tipo_origem,
    dt_referencia_carga
) VALUES
    ('1101', '0001234', '012345678901234', '4000001', TRUE, 'SEED', 'REDE', '2026-04-05'),
    ('1102', '0002234', '023456789012345', '4000002', TRUE, 'SEED', 'REDE', '2026-04-05'),
    ('1201', '0003234', '034567890123456', '4000003', TRUE, 'SEED', 'REDE', '2026-04-05');

INSERT IGNORE INTO fIndicadorPeriodo (
    id_periodo,
    id_indicador,
    peso,
    ordem_exibicao,
    ativo_sn,
    origem_carga
) VALUES
    ('2026T1', 101, 32.0000, 1, TRUE, 'SEED'),
    ('2026T1', 102, 18.0000, 2, TRUE, 'SEED'),
    ('2026T1', 201, 28.0000, 3, TRUE, 'SEED'),
    ('2026T1', 301, 22.0000, 4, TRUE, 'SEED'),
    ('2026T2', 101, 32.0000, 1, TRUE, 'SEED'),
    ('2026T2', 102, 18.0000, 2, TRUE, 'SEED'),
    ('2026T2', 201, 28.0000, 3, TRUE, 'SEED'),
    ('2026T2', 301, 22.0000, 4, TRUE, 'SEED');

INSERT IGNORE INTO fIndicadorSegmentoPeriodo (
    id_periodo,
    segmento,
    id_indicador,
    ativo_sn,
    origem_carga
) VALUES
    ('2026T1', 'NEGOCIOS', 101, TRUE, 'SEED'),
    ('2026T1', 'NEGOCIOS', 102, TRUE, 'SEED'),
    ('2026T1', 'NEGOCIOS', 201, TRUE, 'SEED'),
    ('2026T1', 'NEGOCIOS', 301, TRUE, 'SEED'),
    ('2026T1', 'DIGITAL', 101, TRUE, 'SEED'),
    ('2026T1', 'DIGITAL', 102, TRUE, 'SEED'),
    ('2026T1', 'DIGITAL', 201, TRUE, 'SEED'),
    ('2026T1', 'DIGITAL', 301, TRUE, 'SEED'),
    ('2026T2', 'NEGOCIOS', 101, TRUE, 'SEED'),
    ('2026T2', 'NEGOCIOS', 102, TRUE, 'SEED'),
    ('2026T2', 'NEGOCIOS', 201, TRUE, 'SEED'),
    ('2026T2', 'NEGOCIOS', 301, TRUE, 'SEED'),
    ('2026T2', 'DIGITAL', 101, TRUE, 'SEED'),
    ('2026T2', 'DIGITAL', 102, TRUE, 'SEED'),
    ('2026T2', 'DIGITAL', 201, TRUE, 'SEED'),
    ('2026T2', 'DIGITAL', 301, TRUE, 'SEED');

INSERT IGNORE INTO fMeta (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    valor_meta,
    dt_meta,
    ativo_sn,
    origem_carga
) VALUES
    ('2026T2', '4000001', '1101', '2101', '3101', 'NEGOCIOS', 101, 120000.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000001', '1101', '2101', '3101', 'NEGOCIOS', 102, 60000.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000001', '1101', '2101', '3101', 'NEGOCIOS', 201, 90.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000001', '1101', '2101', '3101', 'NEGOCIOS', 301, 15.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000002', '1102', '2101', '3101', 'NEGOCIOS', 101, 150000.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000002', '1102', '2101', '3101', 'NEGOCIOS', 102, 55000.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000002', '1102', '2101', '3101', 'NEGOCIOS', 201, 90.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000002', '1102', '2101', '3101', 'NEGOCIOS', 301, 10.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000003', '1201', '2201', '3201', 'DIGITAL', 101, 90000.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000003', '1201', '2201', '3201', 'DIGITAL', 102, 50000.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000003', '1201', '2201', '3201', 'DIGITAL', 201, 85.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000003', '1201', '2201', '3201', 'DIGITAL', 301, 12.0000, '2026-04-05', TRUE, 'SEED');

INSERT IGNORE INTO fMeta (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    valor_meta,
    dt_meta,
    ativo_sn,
    origem_carga
)
SELECT
    '2026T1',
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    ROUND(
        CASE
            WHEN id_indicador = 201 THEN GREATEST(75, valor_meta - CASE funcional WHEN '4000001' THEN 2 WHEN '4000002' THEN 4 ELSE 1 END)
            WHEN funcional = '4000001' THEN valor_meta * 0.92
            WHEN funcional = '4000002' THEN valor_meta * 0.90
            ELSE valor_meta * 0.95
        END,
        4
    ),
    '2026-03-05',
    ativo_sn,
    origem_carga
FROM fMeta
WHERE id_periodo = '2026T2'
  AND dt_meta = '2026-04-05';

INSERT IGNORE INTO fRealizado (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    id_subindicador,
    valor_realizado,
    dt_realizado,
    ativo_sn,
    origem_carga
) VALUES
    ('2026T2', '4000001', '1101', '2101', '3101', 'NEGOCIOS', 101, 0, 135000.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000001', '1101', '2101', '3101', 'NEGOCIOS', 102, 0, 65000.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000001', '1101', '2101', '3101', 'NEGOCIOS', 201, 2101, 100.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000001', '1101', '2101', '3101', 'NEGOCIOS', 201, 2102, 92.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000001', '1101', '2101', '3101', 'NEGOCIOS', 301, 0, 18.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000002', '1102', '2101', '3101', 'NEGOCIOS', 101, 0, 100000.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000002', '1102', '2101', '3101', 'NEGOCIOS', 102, 0, 50000.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000002', '1102', '2101', '3101', 'NEGOCIOS', 201, 2101, 120.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000002', '1102', '2101', '3101', 'NEGOCIOS', 201, 2102, 80.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000002', '1102', '2101', '3101', 'NEGOCIOS', 301, 0, 8.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000003', '1201', '2201', '3201', 'DIGITAL', 101, 0, 95000.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000003', '1201', '2201', '3201', 'DIGITAL', 102, 0, 45000.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000003', '1201', '2201', '3201', 'DIGITAL', 201, 2101, 90.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000003', '1201', '2201', '3201', 'DIGITAL', 201, 2102, 88.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000003', '1201', '2201', '3201', 'DIGITAL', 301, 0, 10.0000, '2026-04-05', TRUE, 'SEED');

INSERT IGNORE INTO fRealizado (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    id_subindicador,
    valor_realizado,
    dt_realizado,
    ativo_sn,
    origem_carga
)
SELECT
    '2026T1',
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    id_subindicador,
    ROUND(
        CASE
            WHEN id_indicador = 201 AND id_subindicador = 2101 THEN valor_realizado * 0.95
            WHEN id_indicador = 201 AND id_subindicador = 2102 THEN valor_realizado * 0.89
            WHEN funcional = '4000001' THEN valor_realizado * 0.90
            WHEN funcional = '4000002' THEN valor_realizado * 0.87
            ELSE valor_realizado * 0.93
        END,
        4
    ),
    '2026-03-05',
    ativo_sn,
    origem_carga
FROM fRealizado
WHERE id_periodo = '2026T2'
  AND dt_realizado = '2026-04-05';

INSERT IGNORE INTO fPontos (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    pontos_meta,
    pontos_realizado,
    data_realizado,
    ativo_sn,
    origem_carga
) VALUES
    ('2026T2', '4000001', '1101', '2101', '3101', 'NEGOCIOS', 101, 32.0000, 36.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000001', '1101', '2101', '3101', 'NEGOCIOS', 102, 18.0000, 19.5000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000001', '1101', '2101', '3101', 'NEGOCIOS', 201, 28.0000, 28.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000001', '1101', '2101', '3101', 'NEGOCIOS', 301, 22.0000, 26.4000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000002', '1102', '2101', '3101', 'NEGOCIOS', 101, 32.0000, 21.3333, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000002', '1102', '2101', '3101', 'NEGOCIOS', 102, 18.0000, 16.3636, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000002', '1102', '2101', '3101', 'NEGOCIOS', 201, 28.0000, 24.8889, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000002', '1102', '2101', '3101', 'NEGOCIOS', 301, 22.0000, 17.6000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000003', '1201', '2201', '3201', 'DIGITAL', 101, 32.0000, 33.7778, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000003', '1201', '2201', '3201', 'DIGITAL', 102, 18.0000, 16.2000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000003', '1201', '2201', '3201', 'DIGITAL', 201, 28.0000, 28.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000003', '1201', '2201', '3201', 'DIGITAL', 301, 22.0000, 18.3333, '2026-04-05', TRUE, 'SEED');

INSERT IGNORE INTO fPontos (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    pontos_meta,
    pontos_realizado,
    data_realizado,
    ativo_sn,
    origem_carga
)
SELECT
    '2026T1',
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    pontos_meta,
    ROUND(
        CASE
            WHEN funcional = '4000001' THEN pontos_realizado * 0.91
            WHEN funcional = '4000002' THEN pontos_realizado * 0.88
            ELSE pontos_realizado * 0.94
        END,
        4
    ),
    DATE_SUB(data_realizado, INTERVAL 1 MONTH),
    ativo_sn,
    origem_carga
FROM fPontos
WHERE id_periodo = '2026T2'
  AND data_realizado = '2026-04-05';

INSERT IGNORE INTO fVariavel (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    variavel_meta,
    variavel_realizada,
    data_realizado,
    ativo_sn,
    origem_carga
) VALUES
    ('2026T2', '4000001', '1101', '2101', '3101', 'NEGOCIOS', 101, 8000.0000, 8600.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000001', '1101', '2101', '3101', 'NEGOCIOS', 102, 2500.0000, 2700.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000001', '1101', '2101', '3101', 'NEGOCIOS', 201, 3000.0000, 3200.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000001', '1101', '2101', '3101', 'NEGOCIOS', 301, 1500.0000, 1800.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000002', '1102', '2101', '3101', 'NEGOCIOS', 101, 8000.0000, 5200.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000002', '1102', '2101', '3101', 'NEGOCIOS', 102, 2500.0000, 2300.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000002', '1102', '2101', '3101', 'NEGOCIOS', 201, 3000.0000, 2700.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000002', '1102', '2101', '3101', 'NEGOCIOS', 301, 1500.0000, 900.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000003', '1201', '2201', '3201', 'DIGITAL', 101, 8000.0000, 7700.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000003', '1201', '2201', '3201', 'DIGITAL', 102, 2500.0000, 2400.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000003', '1201', '2201', '3201', 'DIGITAL', 201, 3000.0000, 2900.0000, '2026-04-05', TRUE, 'SEED'),
    ('2026T2', '4000003', '1201', '2201', '3201', 'DIGITAL', 301, 1500.0000, 1300.0000, '2026-04-05', TRUE, 'SEED');

INSERT IGNORE INTO fVariavel (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    variavel_meta,
    variavel_realizada,
    data_realizado,
    ativo_sn,
    origem_carga
)
SELECT
    '2026T1',
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    ROUND(variavel_meta * 0.95, 4),
    ROUND(
        CASE
            WHEN funcional = '4000001' THEN variavel_realizada * 0.90
            WHEN funcional = '4000002' THEN variavel_realizada * 0.86
            ELSE variavel_realizada * 0.92
        END,
        4
    ),
    DATE_SUB(data_realizado, INTERVAL 1 MONTH),
    ativo_sn,
    origem_carga
FROM fVariavel
WHERE id_periodo = '2026T2'
  AND data_realizado = '2026-04-05';

INSERT IGNORE INTO fDetalhe (
    id_periodo,
    id_indicador,
    id_subindicador,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_transacao,
    numero_contrato,
    conta,
    canal_venda,
    data_transacao,
    status_transacao,
    observacao,
    cnpj,
    nome_cliente,
    valor_realizado,
    ativo_sn,
    origem_carga
) VALUES
    ('2026T2', 101, 0, '4000001', '1101', '2101', '3101', 'NEGOCIOS', 'TX1001', 'CTR-0000001', '0001234', 'AGENCIA', '2026-04-03', 'APROVADO', 'Credito aprovado na primeira analise.', '012345678901234', 'Cliente Centro', 45000.0000, TRUE, 'SEED'),
    ('2026T2', 102, 0, '4000001', '1101', '2101', '3101', 'NEGOCIOS', 'TX1002', 'CTR-0000002', '0001234', 'AGENCIA', '2026-04-04', 'APROVADO', 'Operacao de capital de giro liberada.', '012345678901234', 'Cliente Centro', 65000.0000, TRUE, 'SEED'),
    ('2026T2', 201, 2101, '4000001', '1101', '2101', '3101', 'NEGOCIOS', 'TX1003', 'CTR-0000012', '0001234', 'CRM', '2026-04-04', 'BASE', 'Base da carteira considerada para o giro.', '012345678901234', 'Carteira Centro', 100.0000, TRUE, 'SEED'),
    ('2026T2', 201, 2102, '4000001', '1101', '2101', '3101', 'NEGOCIOS', 'TX1004', 'CTR-0000013', '0001234', 'APP', '2026-04-04', 'CONCLUIDO', 'Contato de carteira registrado.', '012345678901234', 'Carteira Centro', 92.0000, TRUE, 'SEED'),
    ('2026T2', 101, 0, '4000002', '1102', '2101', '3101', 'NEGOCIOS', 'TX2001', 'CTR-0000003', '0002234', 'AGENCIA', '2026-04-03', 'PENDENTE', 'Cliente solicitou ajuste documental.', '023456789012345', 'Cliente Jardim', 30000.0000, TRUE, 'SEED'),
    ('2026T2', 102, 0, '4000002', '1102', '2101', '3101', 'NEGOCIOS', 'TX2002', 'CTR-0000005', '0002234', 'AGENCIA', '2026-04-04', 'APROVADO', 'Capital de giro contratado com garantia de recebiveis.', '023456789012345', 'Cliente Jardim', 50000.0000, TRUE, 'SEED'),
    ('2026T2', 201, 2101, '4000002', '1102', '2101', '3101', 'NEGOCIOS', 'TX2003', 'CTR-0000014', '0002234', 'CRM', '2026-04-04', 'BASE', 'Base da carteira considerada para o giro.', '023456789012345', 'Carteira Jardim', 120.0000, TRUE, 'SEED'),
    ('2026T2', 201, 2102, '4000002', '1102', '2101', '3101', 'NEGOCIOS', 'TX2004', 'CTR-0000015', '0002234', 'APP', '2026-04-04', 'CONCLUIDO', 'Contato de carteira registrado.', '023456789012345', 'Carteira Jardim', 80.0000, TRUE, 'SEED'),
    ('2026T2', 301, 0, '4000003', '1201', '2201', '3201', 'DIGITAL', 'TX3001', 'CTR-0000008', '0003234', 'DIGITAL', '2026-04-05', 'CONCLUIDO', 'Venda concluida por canal digital.', '034567890123456', 'Cliente Litoral', 1.0000, TRUE, 'SEED'),
    ('2026T2', 102, 0, '4000003', '1201', '2201', '3201', 'DIGITAL', 'TX3002', 'CTR-0000009', '0003234', 'DIGITAL', '2026-04-05', 'APROVADO', 'Capital de giro contratado em jornada digital.', '034567890123456', 'Cliente Litoral', 45000.0000, TRUE, 'SEED'),
    ('2026T2', 201, 2101, '4000003', '1201', '2201', '3201', 'DIGITAL', 'TX3003', 'CTR-0000016', '0003234', 'CRM', '2026-04-05', 'BASE', 'Base da carteira considerada para o giro.', '034567890123456', 'Carteira Litoral', 90.0000, TRUE, 'SEED'),
    ('2026T2', 201, 2102, '4000003', '1201', '2201', '3201', 'DIGITAL', 'TX3004', 'CTR-0000017', '0003234', 'DIGITAL', '2026-04-05', 'CONCLUIDO', 'Contato de carteira registrado.', '034567890123456', 'Carteira Litoral', 88.0000, TRUE, 'SEED');

INSERT INTO fDetalhe (
    id_periodo,
    id_indicador,
    id_subindicador,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_transacao,
    numero_contrato,
    conta,
    canal_venda,
    data_transacao,
    status_transacao,
    observacao,
    cnpj,
    nome_cliente,
    valor_realizado,
    ativo_sn,
    origem_carga
)
SELECT
    '2026T1',
    id_indicador,
    id_subindicador,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    CONCAT('TM', SUBSTRING(id_transacao, 3)),
    CONCAT('MAR-', numero_contrato),
    conta,
    canal_venda,
    DATE_SUB(data_transacao, INTERVAL 1 MONTH),
    status_transacao,
    CONCAT('Fechamento de março. ', observacao),
    cnpj,
    nome_cliente,
    ROUND(
        CASE
            WHEN funcional = '4000001' THEN valor_realizado * 0.88
            WHEN funcional = '4000002' THEN valor_realizado * 0.85
            ELSE valor_realizado * 0.92
        END,
        4
    ),
    ativo_sn,
    origem_carga
FROM fDetalhe base
WHERE base.id_periodo = '2026T2'
  AND NOT EXISTS (
      SELECT 1
      FROM fDetalhe existing
      WHERE existing.id_periodo = '2026T1'
        AND existing.id_transacao = CONCAT('TM', SUBSTRING(base.id_transacao, 3))
  );

DELETE FROM fDetalhe
WHERE origem_carga = 'SEED';

DELETE FROM fVariavel
WHERE origem_carga = 'SEED';

DELETE FROM fPontos
WHERE origem_carga = 'SEED';

DELETE FROM fRealizado
WHERE origem_carga = 'SEED';

DELETE FROM fMeta
WHERE origem_carga = 'SEED';

DELETE FROM fIndicadorSegmentoPeriodo
WHERE origem_carga = 'SEED';

DELETE FROM fIndicadorPeriodo
WHERE origem_carga = 'SEED';

DELETE FROM fEncarteiramento
WHERE origem_carga = 'SEED';

DELETE FROM fGrupoFuncional
WHERE origem_carga = 'SEED';

DELETE FROM fGestaoGerente
WHERE origem_carga = 'SEED';

DELETE FROM fMultiJuncao
WHERE origem_carga = 'SEED';

DELETE FROM dHierarquia
WHERE origem_carga = 'SEED';

DELETE FROM dMesu
WHERE origem_carga = 'SEED';

UPDATE dPeriodoApuracao
SET ativo_sn = FALSE,
    origem_carga = 'SEED'
WHERE origem_carga = 'SEED'
  AND id_periodo LIKE '2026%';

INSERT INTO dSegmento (
    segmento,
    juncao_segmento,
    nome_segmento,
    ativo_sn,
    origem_carga
) VALUES
    ('NEGOCIOS', '8607', 'Empresas', TRUE, 'SEED'),
    ('DIGITAL', '8608', 'Digital', TRUE, 'SEED')
ON DUPLICATE KEY UPDATE
    nome_segmento = VALUES(nome_segmento),
    ativo_sn = VALUES(ativo_sn),
    origem_carga = VALUES(origem_carga);

INSERT INTO dGrupo (
    id_grupo,
    nome_grupo,
    ativo_sn,
    origem_carga
) VALUES
    ('G001', 'Grupo Norte', TRUE, 'SEED'),
    ('G002', 'Grupo Sul', TRUE, 'SEED'),
    ('G003', 'Grupo Sudeste', TRUE, 'SEED')
ON DUPLICATE KEY UPDATE
    nome_grupo = VALUES(nome_grupo),
    ativo_sn = VALUES(ativo_sn),
    origem_carga = VALUES(origem_carga);

INSERT INTO dPeriodoApuracao (
    id_periodo,
    descricao_periodo,
    dt_inicio_periodo,
    dt_fim_periodo,
    ativo_sn,
    origem_carga
) VALUES
    ('2026C1', 'Ciclo Fev-Abr 2026', '2026-02-01', '2026-04-30', TRUE, 'SEED')
ON DUPLICATE KEY UPDATE
    descricao_periodo = VALUES(descricao_periodo),
    dt_inicio_periodo = VALUES(dt_inicio_periodo),
    dt_fim_periodo = VALUES(dt_fim_periodo),
    ativo_sn = VALUES(ativo_sn),
    origem_carga = VALUES(origem_carga);

DROP TEMPORARY TABLE IF EXISTS tmp_seed_months;
DROP TEMPORARY TABLE IF EXISTS tmp_seed_directorates;
DROP TEMPORARY TABLE IF EXISTS tmp_seed_regionals;
DROP TEMPORARY TABLE IF EXISTS tmp_seed_agencies;
DROP TEMPORARY TABLE IF EXISTS tmp_seed_management;
DROP TEMPORARY TABLE IF EXISTS tmp_seed_gc;
DROP TEMPORARY TABLE IF EXISTS tmp_seed_gc_month;

CREATE TEMPORARY TABLE tmp_seed_months (
    month_code CHAR(2) NOT NULL,
    month_order TINYINT UNSIGNED NOT NULL,
    snapshot_date DATE NOT NULL,
    PRIMARY KEY (month_code)
);

INSERT INTO tmp_seed_months (month_code, month_order, snapshot_date) VALUES
    ('02', 1, '2026-02-05'),
    ('03', 2, '2026-03-05'),
    ('04', 3, '2026-04-05');

CREATE TEMPORARY TABLE tmp_seed_directorates (
    group_id CHAR(4) NOT NULL,
    regiao_label VARCHAR(20) NOT NULL,
    regiao_slug VARCHAR(20) NOT NULL,
    juncao_dr CHAR(4) NOT NULL,
    funcional_dr CHAR(7) NOT NULL,
    nome_dr VARCHAR(150) NOT NULL,
    nome_diretoria VARCHAR(150) NOT NULL,
    PRIMARY KEY (juncao_dr),
    UNIQUE KEY uk_tmp_seed_directorates_funcional (funcional_dr)
);

INSERT INTO tmp_seed_directorates (
    group_id,
    regiao_label,
    regiao_slug,
    juncao_dr,
    funcional_dr,
    nome_dr,
    nome_diretoria
) VALUES
    ('G001', 'Norte', 'norte', '3101', '8000001', 'DR Renato - Norte', 'Diretoria Norte'),
    ('G002', 'Sul', 'sul', '3201', '8000002', 'DR Sonia - Sul', 'Diretoria Sul'),
    ('G003', 'Sudeste', 'sudeste', '3301', '8000003', 'DR Caio - Sudeste', 'Diretoria Sudeste');

CREATE TEMPORARY TABLE tmp_seed_regionals (
    group_id CHAR(4) NOT NULL,
    regiao_label VARCHAR(20) NOT NULL,
    regiao_slug VARCHAR(20) NOT NULL,
    juncao_dr CHAR(4) NOT NULL,
    juncao_gr CHAR(4) NOT NULL,
    funcional_gr CHAR(7) NOT NULL,
    nome_gr VARCHAR(150) NOT NULL,
    nome_regional VARCHAR(150) NOT NULL,
    PRIMARY KEY (juncao_gr),
    UNIQUE KEY uk_tmp_seed_regionals_funcional (funcional_gr)
);

INSERT INTO tmp_seed_regionals (
    group_id,
    regiao_label,
    regiao_slug,
    juncao_dr,
    juncao_gr,
    funcional_gr,
    nome_gr,
    nome_regional
) VALUES
    ('G001', 'Norte', 'norte', '3101', '2101', '7000001', 'GR Marta - Norte Capital', 'Regional Norte Capital'),
    ('G001', 'Norte', 'norte', '3101', '2102', '7000002', 'GR Paulo - Norte Interior', 'Regional Norte Interior'),
    ('G002', 'Sul', 'sul', '3201', '2201', '7000003', 'GR Silvia - Sul Capital', 'Regional Sul Capital'),
    ('G002', 'Sul', 'sul', '3201', '2202', '7000004', 'GR Leandro - Sul Interior', 'Regional Sul Interior'),
    ('G003', 'Sudeste', 'sudeste', '3301', '2301', '7000005', 'GR Bianca - Sudeste Capital', 'Regional Sudeste Capital'),
    ('G003', 'Sudeste', 'sudeste', '3301', '2302', '7000006', 'GR Heitor - Sudeste Interior', 'Regional Sudeste Interior');

CREATE TEMPORARY TABLE tmp_seed_agencies (
    group_id CHAR(4) NOT NULL,
    regiao_label VARCHAR(20) NOT NULL,
    regiao_slug VARCHAR(20) NOT NULL,
    segmento VARCHAR(20) NOT NULL,
    agency_order TINYINT UNSIGNED NOT NULL,
    juncao_dr CHAR(4) NOT NULL,
    juncao_gr CHAR(4) NOT NULL,
    juncao_ag CHAR(4) NOT NULL,
    ag_funcional CHAR(7) NOT NULL,
    ag_manager_name VARCHAR(100) NOT NULL,
    ag_name VARCHAR(150) NOT NULL,
    nome_agencia VARCHAR(150) NOT NULL,
    PRIMARY KEY (juncao_ag),
    UNIQUE KEY uk_tmp_seed_agencies_funcional (ag_funcional)
);

INSERT INTO tmp_seed_agencies (
    group_id,
    regiao_label,
    regiao_slug,
    segmento,
    agency_order,
    juncao_dr,
    juncao_gr,
    juncao_ag,
    ag_funcional,
    ag_manager_name,
    ag_name,
    nome_agencia
) VALUES
    ('G001', 'Norte', 'norte', 'NEGOCIOS', 1, '3101', '2101', '1101', '6000001', 'Lara', 'AG Lara - Norte', 'Agencia 1101 Norte'),
    ('G001', 'Norte', 'norte', 'NEGOCIOS', 2, '3101', '2101', '1102', '6000002', 'Davi', 'AG Davi - Norte', 'Agencia 1102 Norte'),
    ('G001', 'Norte', 'norte', 'DIGITAL', 3, '3101', '2102', '1103', '6000003', 'Nilo', 'AG Nilo - Norte', 'Agencia 1103 Norte'),
    ('G001', 'Norte', 'norte', 'DIGITAL', 4, '3101', '2102', '1104', '6000004', 'Iara', 'AG Iara - Norte', 'Agencia 1104 Norte'),
    ('G002', 'Sul', 'sul', 'NEGOCIOS', 5, '3201', '2201', '1201', '6000005', 'Nina', 'AG Nina - Sul', 'Agencia 1201 Sul'),
    ('G002', 'Sul', 'sul', 'NEGOCIOS', 6, '3201', '2201', '1202', '6000006', 'Otavio', 'AG Otavio - Sul', 'Agencia 1202 Sul'),
    ('G002', 'Sul', 'sul', 'DIGITAL', 7, '3201', '2202', '1203', '6000007', 'Paula', 'AG Paula - Sul', 'Agencia 1203 Sul'),
    ('G002', 'Sul', 'sul', 'DIGITAL', 8, '3201', '2202', '1204', '6000008', 'Rafael', 'AG Rafael - Sul', 'Agencia 1204 Sul'),
    ('G003', 'Sudeste', 'sudeste', 'NEGOCIOS', 9, '3301', '2301', '1301', '6000009', 'Talita', 'AG Talita - Sudeste', 'Agencia 1301 Sudeste'),
    ('G003', 'Sudeste', 'sudeste', 'NEGOCIOS', 10, '3301', '2301', '1302', '6000010', 'Ulisses', 'AG Ulisses - Sudeste', 'Agencia 1302 Sudeste'),
    ('G003', 'Sudeste', 'sudeste', 'DIGITAL', 11, '3301', '2302', '1303', '6000011', 'Vanessa', 'AG Vanessa - Sudeste', 'Agencia 1303 Sudeste'),
    ('G003', 'Sudeste', 'sudeste', 'DIGITAL', 12, '3301', '2302', '1304', '6000012', 'Yuri', 'AG Yuri - Sudeste', 'Agencia 1304 Sudeste');

CREATE TEMPORARY TABLE tmp_seed_management AS
SELECT
    a.group_id,
    a.regiao_label,
    a.regiao_slug,
    a.segmento,
    a.agency_order,
    a.juncao_dr,
    a.juncao_gr,
    a.juncao_ag,
    a.ag_funcional,
    a.ag_name,
    seq.gg_seq,
    CONCAT('5', a.juncao_ag, LPAD(seq.gg_seq, 2, '0')) AS gg_funcional,
    CONCAT('GG ', CASE seq.gg_seq WHEN 1 THEN 'Marina' ELSE 'Rafael' END, ' - ', a.regiao_label, ' ', a.juncao_ag) AS gg_name
FROM tmp_seed_agencies a
CROSS JOIN (
    SELECT 1 AS gg_seq
    UNION ALL
    SELECT 2 AS gg_seq
) seq;

CREATE TEMPORARY TABLE tmp_seed_gc AS
SELECT
    base.*,
    CONCAT('9', SUBSTRING(base.funcional, 2, 6)) AS conta,
    CONCAT(base.funcional, '00000000') AS cnpj_base,
    CONCAT('Cliente ', base.regiao_label, ' ', RIGHT(base.juncao_ag, 2), '-', base.manager_seq) AS client_label,
    CONCAT('Carteira ', base.regiao_label, ' ', RIGHT(base.juncao_ag, 2), '-', base.manager_seq) AS carteira_label
FROM (
    SELECT
        m.group_id,
        m.regiao_label,
        m.regiao_slug,
        m.segmento,
        m.agency_order,
        m.juncao_dr,
        m.juncao_gr,
        m.juncao_ag,
        m.ag_funcional,
        m.ag_name,
        m.gg_seq,
        m.gg_funcional,
        m.gg_name,
        seq.manager_seq,
        CASE
            WHEN m.juncao_ag = '1101' AND m.gg_seq = 1 AND seq.manager_seq = 1 THEN '4000001'
            WHEN m.juncao_ag = '1102' AND m.gg_seq = 1 AND seq.manager_seq = 1 THEN '4000002'
            WHEN m.juncao_ag = '1201' AND m.gg_seq = 1 AND seq.manager_seq = 1 THEN '4000003'
            ELSE CONCAT('4', m.juncao_ag, m.gg_seq, seq.manager_seq)
        END AS funcional,
        CASE
            WHEN m.juncao_ag = '1101' AND m.gg_seq = 1 AND seq.manager_seq = 1 THEN 'Gerente Bruno - Norte'
            WHEN m.juncao_ag = '1102' AND m.gg_seq = 1 AND seq.manager_seq = 1 THEN 'Gerente Carla - Norte'
            WHEN m.juncao_ag = '1201' AND m.gg_seq = 1 AND seq.manager_seq = 1 THEN 'Gerente Diego - Sul'
            ELSE CONCAT(
                'Gerente ',
                CASE seq.manager_seq
                    WHEN 1 THEN 'Ana'
                    WHEN 2 THEN 'Bruno'
                    WHEN 3 THEN 'Caio'
                    WHEN 4 THEN 'Denise'
                    ELSE 'Enzo'
                END,
                ' - ',
                m.regiao_label,
                ' ',
                m.juncao_ag,
                '-',
                m.gg_seq
            )
        END AS nome_gc
    FROM tmp_seed_management m
    CROSS JOIN (
        SELECT 1 AS manager_seq
        UNION ALL SELECT 2
        UNION ALL SELECT 3
        UNION ALL SELECT 4
        UNION ALL SELECT 5
    ) seq
) base;

CREATE TEMPORARY TABLE tmp_seed_gc_month AS
SELECT
    calc.*,
    ROUND(calc.meta_101 * calc.perf_factor, 4) AS real_101,
    ROUND(calc.meta_102 * LEAST(1.18, GREATEST(0.68, calc.perf_factor - 0.04 + CASE WHEN calc.segmento = 'NEGOCIOS' THEN 0.02 ELSE 0.00 END)), 4) AS real_102,
    LEAST(calc.base_201, ROUND(calc.base_201 * LEAST(1.00, GREATEST(0.58, calc.perf_factor - 0.03)), 0)) AS contacts_201,
    ROUND(calc.meta_301 * LEAST(1.18, GREATEST(0.70, calc.perf_factor - 0.02)), 0) AS real_301
FROM (
    SELECT
        base.*,
        ROUND(92000 + (base.agency_order * 4800) + (base.gg_seq * 2800) + (base.manager_seq * 4300) + (base.month_order * 2100) + CASE WHEN base.segmento = 'DIGITAL' THEN 8500 ELSE 0 END, 4) AS meta_101,
        ROUND(34000 + (base.agency_order * 2100) + (base.gg_seq * 1500) + (base.manager_seq * 1850) + (base.month_order * 1100) + CASE WHEN base.segmento = 'NEGOCIOS' THEN 2500 ELSE 0 END, 4) AS meta_102,
        ROUND(86 + base.gg_seq + CASE WHEN base.segmento = 'DIGITAL' THEN 2 ELSE 0 END + CASE WHEN base.manager_seq IN (1, 2) THEN 1 ELSE 0 END, 4) AS meta_201,
        ROUND(9 + base.manager_seq + (base.gg_seq - 1) + CASE WHEN base.segmento = 'DIGITAL' THEN 1 ELSE 0 END + (base.month_order * 0.5), 0) AS meta_301,
        ROUND(118 + (base.agency_order * 7) + (base.manager_seq * 6) + (base.month_order * 5) + CASE WHEN base.segmento = 'DIGITAL' THEN 10 ELSE 0 END, 0) AS base_201
    FROM (
        SELECT
            gc.*,
            '2026C1' AS period_id,
            m.month_code,
            m.month_order,
            m.snapshot_date,
            LEAST(
                1.20,
                GREATEST(
                    0.72,
                    (CASE gc.manager_seq WHEN 1 THEN 1.16 WHEN 2 THEN 1.07 WHEN 3 THEN 0.98 WHEN 4 THEN 0.89 ELSE 0.79 END)
                    + (CASE gc.gg_seq WHEN 1 THEN 0.04 ELSE -0.02 END)
                    + (CASE gc.segmento WHEN 'DIGITAL' THEN 0.03 ELSE 0.00 END)
                    + (CASE m.month_code WHEN '02' THEN -0.08 WHEN '03' THEN -0.02 ELSE 0.05 END)
                )
            ) AS perf_factor
        FROM tmp_seed_gc gc
        CROSS JOIN tmp_seed_months m
    ) base
) calc;

INSERT INTO dMesu (
    juncao_ag,
    juncao_gr,
    juncao_dr,
    nome_agencia,
    nome_regional,
    nome_diretoria,
    ativo_sn,
    origem_carga
)
SELECT
    a.juncao_ag,
    a.juncao_gr,
    a.juncao_dr,
    a.nome_agencia,
    r.nome_regional,
    d.nome_diretoria,
    TRUE,
    'SEED'
FROM tmp_seed_agencies a
INNER JOIN tmp_seed_regionals r
    ON r.juncao_gr = a.juncao_gr
INNER JOIN tmp_seed_directorates d
    ON d.juncao_dr = a.juncao_dr;

INSERT INTO dHierarquia (
    funcional,
    nome,
    email,
    cargo,
    nivel,
    ativo_sn,
    origem_carga
) VALUES
    ('9000001', 'Elaine Departamento', 'elaine.departamento@teste.local', 'Diretoria Departamental', 'DP', TRUE, 'SEED');

INSERT INTO dHierarquia (
    funcional,
    nome,
    email,
    cargo,
    nivel,
    ativo_sn,
    origem_carga
)
SELECT
    d.funcional_dr,
    d.nome_dr,
    CONCAT('dr.', d.regiao_slug, '@teste.local'),
    'Diretor Regional',
    'DR',
    TRUE,
    'SEED'
FROM tmp_seed_directorates d;

INSERT INTO dHierarquia (
    funcional,
    nome,
    email,
    cargo,
    nivel,
    ativo_sn,
    origem_carga
)
SELECT
    r.funcional_gr,
    r.nome_gr,
    CONCAT('gr.', RIGHT(r.juncao_gr, 2), '.', r.regiao_slug, '@teste.local'),
    'Gerente Regional',
    'GR',
    TRUE,
    'SEED'
FROM tmp_seed_regionals r;

INSERT INTO dHierarquia (
    funcional,
    nome,
    email,
    cargo,
    nivel,
    ativo_sn,
    origem_carga
)
SELECT
    a.ag_funcional,
    a.ag_name,
    CONCAT('ag.', a.juncao_ag, '@teste.local'),
    'Gerente de Agencia',
    'AG',
    TRUE,
    'SEED'
FROM tmp_seed_agencies a;

INSERT INTO dHierarquia (
    funcional,
    nome,
    email,
    cargo,
    nivel,
    ativo_sn,
    origem_carga
)
SELECT
    m.gg_funcional,
    m.gg_name,
    CONCAT('gg.', m.gg_funcional, '@teste.local'),
    'Gerente de Gestao',
    'GG',
    TRUE,
    'SEED'
FROM tmp_seed_management m;

INSERT INTO dHierarquia (
    funcional,
    nome,
    email,
    cargo,
    nivel,
    ativo_sn,
    origem_carga
)
SELECT
    gc.funcional,
    gc.nome_gc,
    CONCAT('gc.', gc.funcional, '@teste.local'),
    'Gerente Comercial',
    'GC',
    TRUE,
    'SEED'
FROM tmp_seed_gc gc;

INSERT INTO fMultiJuncao (
    funcional,
    juncao,
    tipo_juncao,
    principal_sn,
    ativo_sn,
    origem_carga
) VALUES
    ('9000001', '4000', 'DP', TRUE, TRUE, 'SEED');

INSERT INTO fMultiJuncao (
    funcional,
    juncao,
    tipo_juncao,
    principal_sn,
    ativo_sn,
    origem_carga
)
SELECT funcional_dr, juncao_dr, 'DR', TRUE, TRUE, 'SEED'
FROM tmp_seed_directorates;

INSERT INTO fMultiJuncao (
    funcional,
    juncao,
    tipo_juncao,
    principal_sn,
    ativo_sn,
    origem_carga
)
SELECT funcional_gr, juncao_gr, 'GR', TRUE, TRUE, 'SEED'
FROM tmp_seed_regionals;

INSERT INTO fMultiJuncao (
    funcional,
    juncao,
    tipo_juncao,
    principal_sn,
    ativo_sn,
    origem_carga
)
SELECT ag_funcional, juncao_ag, 'AG', TRUE, TRUE, 'SEED'
FROM tmp_seed_agencies;

INSERT INTO fMultiJuncao (
    funcional,
    juncao,
    tipo_juncao,
    principal_sn,
    ativo_sn,
    origem_carga
)
SELECT gg_funcional, juncao_ag, 'AG', TRUE, TRUE, 'SEED'
FROM tmp_seed_management;

INSERT INTO fMultiJuncao (
    funcional,
    juncao,
    tipo_juncao,
    principal_sn,
    ativo_sn,
    origem_carga
)
SELECT funcional, juncao_ag, 'AG', TRUE, TRUE, 'SEED'
FROM tmp_seed_gc;

INSERT INTO fGestaoGerente (
    funcional_gerente,
    funcional_gerente_gestao,
    ativo_sn,
    origem_carga
)
SELECT funcional, gg_funcional, TRUE, 'SEED'
FROM tmp_seed_gc;

INSERT INTO fGrupoFuncional (
    funcional,
    id_grupo,
    ativo_sn,
    origem_carga
) VALUES
    ('9000001', 'G001', TRUE, 'SEED');

INSERT INTO fGrupoFuncional (
    funcional,
    id_grupo,
    ativo_sn,
    origem_carga
)
SELECT funcional_dr, group_id, TRUE, 'SEED'
FROM tmp_seed_directorates;

INSERT INTO fGrupoFuncional (
    funcional,
    id_grupo,
    ativo_sn,
    origem_carga
)
SELECT funcional_gr, group_id, TRUE, 'SEED'
FROM tmp_seed_regionals;

INSERT INTO fGrupoFuncional (
    funcional,
    id_grupo,
    ativo_sn,
    origem_carga
)
SELECT ag_funcional, group_id, TRUE, 'SEED'
FROM tmp_seed_agencies;

INSERT INTO fGrupoFuncional (
    funcional,
    id_grupo,
    ativo_sn,
    origem_carga
)
SELECT gg_funcional, group_id, TRUE, 'SEED'
FROM tmp_seed_management;

INSERT INTO fGrupoFuncional (
    funcional,
    id_grupo,
    ativo_sn,
    origem_carga
)
SELECT funcional, group_id, TRUE, 'SEED'
FROM tmp_seed_gc;

INSERT INTO fEncarteiramento (
    juncao_ag,
    conta,
    cnpj,
    funcional,
    ativo_sn,
    origem_carga,
    tipo_origem,
    dt_referencia_carga
)
SELECT
    gc.juncao_ag,
    gc.conta,
    gc.cnpj_base,
    gc.funcional,
    TRUE,
    'SEED',
    'REDE',
    '2026-04-05'
FROM tmp_seed_gc gc;

INSERT INTO fIndicadorPeriodo (
    id_periodo,
    id_indicador,
    peso,
    ordem_exibicao,
    ativo_sn,
    origem_carga
)
SELECT
    '2026C1',
    seed.id_indicador,
    seed.peso,
    seed.ordem_exibicao,
    TRUE,
    'SEED'
FROM (
    SELECT 101 AS id_indicador, 32.0000 AS peso, 1 AS ordem_exibicao
    UNION ALL SELECT 102, 18.0000, 2
    UNION ALL SELECT 201, 28.0000, 3
    UNION ALL SELECT 301, 22.0000, 4
) seed;

INSERT INTO fIndicadorSegmentoPeriodo (
    id_periodo,
    segmento,
    id_indicador,
    ativo_sn,
    origem_carga
)
SELECT
    '2026C1',
    segment_seed.segmento,
    indicator_seed.id_indicador,
    TRUE,
    'SEED'
FROM (
    SELECT 'NEGOCIOS' AS segmento
    UNION ALL
    SELECT 'DIGITAL' AS segmento
) segment_seed
CROSS JOIN (
    SELECT 101 AS id_indicador
    UNION ALL SELECT 102
    UNION ALL SELECT 201
    UNION ALL SELECT 301
) indicator_seed;

INSERT INTO fMeta (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    valor_meta,
    dt_meta,
    ativo_sn,
    origem_carga
)
SELECT period_id, funcional, juncao_ag, juncao_gr, juncao_dr, segmento, 101, meta_101, snapshot_date, TRUE, 'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fMeta (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    valor_meta,
    dt_meta,
    ativo_sn,
    origem_carga
)
SELECT period_id, funcional, juncao_ag, juncao_gr, juncao_dr, segmento, 102, meta_102, snapshot_date, TRUE, 'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fMeta (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    valor_meta,
    dt_meta,
    ativo_sn,
    origem_carga
)
SELECT period_id, funcional, juncao_ag, juncao_gr, juncao_dr, segmento, 201, meta_201, snapshot_date, TRUE, 'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fMeta (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    valor_meta,
    dt_meta,
    ativo_sn,
    origem_carga
)
SELECT period_id, funcional, juncao_ag, juncao_gr, juncao_dr, segmento, 301, meta_301, snapshot_date, TRUE, 'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fRealizado (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    id_subindicador,
    valor_realizado,
    dt_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, funcional, juncao_ag, juncao_gr, juncao_dr, segmento, 101, 0, real_101, snapshot_date, TRUE, 'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fRealizado (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    id_subindicador,
    valor_realizado,
    dt_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, funcional, juncao_ag, juncao_gr, juncao_dr, segmento, 102, 0, real_102, snapshot_date, TRUE, 'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fRealizado (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    id_subindicador,
    valor_realizado,
    dt_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, funcional, juncao_ag, juncao_gr, juncao_dr, segmento, 201, 2101, base_201, snapshot_date, TRUE, 'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fRealizado (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    id_subindicador,
    valor_realizado,
    dt_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, funcional, juncao_ag, juncao_gr, juncao_dr, segmento, 201, 2102, contacts_201, snapshot_date, TRUE, 'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fRealizado (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    id_subindicador,
    valor_realizado,
    dt_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, funcional, juncao_ag, juncao_gr, juncao_dr, segmento, 301, 0, real_301, snapshot_date, TRUE, 'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fPontos (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    pontos_meta,
    pontos_realizado,
    data_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, funcional, juncao_ag, juncao_gr, juncao_dr, segmento, 101, 32.0000, ROUND(32.0000 * LEAST(1.22, GREATEST(0.62, real_101 / meta_101)), 4), snapshot_date, TRUE, 'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fPontos (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    pontos_meta,
    pontos_realizado,
    data_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, funcional, juncao_ag, juncao_gr, juncao_dr, segmento, 102, 18.0000, ROUND(18.0000 * LEAST(1.20, GREATEST(0.60, real_102 / meta_102)), 4), snapshot_date, TRUE, 'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fPontos (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    pontos_meta,
    pontos_realizado,
    data_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, funcional, juncao_ag, juncao_gr, juncao_dr, segmento, 201, 28.0000, ROUND(28.0000 * LEAST(1.20, GREATEST(0.60, ((contacts_201 / base_201) * 100) / meta_201)), 4), snapshot_date, TRUE, 'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fPontos (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    pontos_meta,
    pontos_realizado,
    data_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, funcional, juncao_ag, juncao_gr, juncao_dr, segmento, 301, 22.0000, ROUND(22.0000 * LEAST(1.20, GREATEST(0.60, real_301 / meta_301)), 4), snapshot_date, TRUE, 'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fVariavel (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    variavel_meta,
    variavel_realizada,
    data_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, funcional, juncao_ag, juncao_gr, juncao_dr, segmento, 101,
       ROUND(6800 + (agency_order * 220) + (manager_seq * 150) + (month_order * 90), 4),
       ROUND((6800 + (agency_order * 220) + (manager_seq * 150) + (month_order * 90)) * LEAST(1.18, GREATEST(0.68, perf_factor + 0.02)), 4),
       snapshot_date, TRUE, 'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fVariavel (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    variavel_meta,
    variavel_realizada,
    data_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, funcional, juncao_ag, juncao_gr, juncao_dr, segmento, 102,
       ROUND(2400 + (agency_order * 80) + (manager_seq * 60) + (month_order * 50), 4),
       ROUND((2400 + (agency_order * 80) + (manager_seq * 60) + (month_order * 50)) * LEAST(1.16, GREATEST(0.64, perf_factor - 0.02)), 4),
       snapshot_date, TRUE, 'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fVariavel (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    variavel_meta,
    variavel_realizada,
    data_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, funcional, juncao_ag, juncao_gr, juncao_dr, segmento, 201,
       ROUND(2600 + (agency_order * 90) + (month_order * 70), 4),
       ROUND((2600 + (agency_order * 90) + (month_order * 70)) * LEAST(1.15, GREATEST(0.66, perf_factor - 0.01)), 4),
       snapshot_date, TRUE, 'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fVariavel (
    id_periodo,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_indicador,
    variavel_meta,
    variavel_realizada,
    data_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, funcional, juncao_ag, juncao_gr, juncao_dr, segmento, 301,
       ROUND(1500 + (agency_order * 55) + (month_order * 40), 4),
       ROUND((1500 + (agency_order * 55) + (month_order * 40)) * LEAST(1.14, GREATEST(0.62, perf_factor - 0.05)), 4),
       snapshot_date, TRUE, 'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fDetalhe (
    id_periodo,
    id_indicador,
    id_subindicador,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_transacao,
    numero_contrato,
    conta,
    canal_venda,
    data_transacao,
    status_transacao,
    observacao,
    cnpj,
    nome_cliente,
    valor_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, 101, 0, funcional, juncao_ag, juncao_gr, juncao_dr, segmento,
       CONCAT('TX', month_code, RIGHT(funcional, 4), '11'),
       CONCAT('CTR-', month_code, '-', RIGHT(funcional, 4), '-11'),
       conta,
       CASE WHEN segmento = 'DIGITAL' THEN 'DIGITAL' ELSE 'AGENCIA' END,
       DATE_SUB(snapshot_date, INTERVAL 2 DAY),
       CASE WHEN perf_factor >= 1 THEN 'APROVADO' ELSE 'PENDENTE' END,
       'Credito principal desembolsado no ciclo atual.',
       cnpj_base,
       client_label,
       ROUND(real_101 * 0.58, 4),
       TRUE,
       'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fDetalhe (
    id_periodo,
    id_indicador,
    id_subindicador,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_transacao,
    numero_contrato,
    conta,
    canal_venda,
    data_transacao,
    status_transacao,
    observacao,
    cnpj,
    nome_cliente,
    valor_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, 101, 0, funcional, juncao_ag, juncao_gr, juncao_dr, segmento,
       CONCAT('TX', month_code, RIGHT(funcional, 4), '12'),
       CONCAT('CTR-', month_code, '-', RIGHT(funcional, 4), '-12'),
       conta,
       CASE WHEN segmento = 'DIGITAL' THEN 'APP' ELSE 'PARCEIRO' END,
       DATE_SUB(snapshot_date, INTERVAL 1 DAY),
       'APROVADO',
       'Complemento de desembolso para fechamento da operacao.',
       cnpj_base,
       client_label,
       ROUND(real_101 - ROUND(real_101 * 0.58, 4), 4),
       TRUE,
       'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fDetalhe (
    id_periodo,
    id_indicador,
    id_subindicador,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_transacao,
    numero_contrato,
    conta,
    canal_venda,
    data_transacao,
    status_transacao,
    observacao,
    cnpj,
    nome_cliente,
    valor_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, 102, 0, funcional, juncao_ag, juncao_gr, juncao_dr, segmento,
       CONCAT('TX', month_code, RIGHT(funcional, 4), '21'),
       CONCAT('CTR-', month_code, '-', RIGHT(funcional, 4), '-21'),
       conta,
       CASE WHEN segmento = 'DIGITAL' THEN 'DIGITAL' ELSE 'AGENCIA' END,
       DATE_SUB(snapshot_date, INTERVAL 1 DAY),
       'APROVADO',
       'Capital de giro contratado dentro do periodo selecionado.',
       cnpj_base,
       client_label,
       real_102,
       TRUE,
       'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fDetalhe (
    id_periodo,
    id_indicador,
    id_subindicador,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_transacao,
    numero_contrato,
    conta,
    canal_venda,
    data_transacao,
    status_transacao,
    observacao,
    cnpj,
    nome_cliente,
    valor_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, 201, 2101, funcional, juncao_ag, juncao_gr, juncao_dr, segmento,
       CONCAT('TX', month_code, RIGHT(funcional, 4), '31'),
       CONCAT('CTR-', month_code, '-', RIGHT(funcional, 4), '-31'),
       conta,
       'CRM',
       DATE_SUB(snapshot_date, INTERVAL 1 DAY),
       'BASE',
       'Base elegivel considerada para o giro da carteira.',
       cnpj_base,
       carteira_label,
       base_201,
       TRUE,
       'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fDetalhe (
    id_periodo,
    id_indicador,
    id_subindicador,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_transacao,
    numero_contrato,
    conta,
    canal_venda,
    data_transacao,
    status_transacao,
    observacao,
    cnpj,
    nome_cliente,
    valor_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, 201, 2102, funcional, juncao_ag, juncao_gr, juncao_dr, segmento,
       CONCAT('TX', month_code, RIGHT(funcional, 4), '32'),
       CONCAT('CTR-', month_code, '-', RIGHT(funcional, 4), '-32'),
       conta,
       CASE WHEN segmento = 'DIGITAL' THEN 'DIGITAL' ELSE 'APP' END,
       snapshot_date,
       'CONCLUIDO',
       'Contato com cliente registrado no fechamento do periodo.',
       cnpj_base,
       carteira_label,
       contacts_201,
       TRUE,
       'SEED'
FROM tmp_seed_gc_month;

INSERT INTO fDetalhe (
    id_periodo,
    id_indicador,
    id_subindicador,
    funcional,
    juncao_ag,
    juncao_gr,
    juncao_dr,
    segmento,
    id_transacao,
    numero_contrato,
    conta,
    canal_venda,
    data_transacao,
    status_transacao,
    observacao,
    cnpj,
    nome_cliente,
    valor_realizado,
    ativo_sn,
    origem_carga
)
SELECT period_id, 301, 0, funcional, juncao_ag, juncao_gr, juncao_dr, segmento,
       CONCAT('TX', month_code, RIGHT(funcional, 4), '41'),
       CONCAT('CTR-', month_code, '-', RIGHT(funcional, 4), '-41'),
       conta,
       CASE WHEN segmento = 'DIGITAL' THEN 'DIGITAL' ELSE 'AGENCIA' END,
       snapshot_date,
       'CONCLUIDO',
       'Venda de seguro concluida no periodo.',
       cnpj_base,
       client_label,
       real_301,
       TRUE,
       'SEED'
FROM tmp_seed_gc_month;

DROP TEMPORARY TABLE IF EXISTS tmp_seed_gc_month;
DROP TEMPORARY TABLE IF EXISTS tmp_seed_gc;
DROP TEMPORARY TABLE IF EXISTS tmp_seed_management;
DROP TEMPORARY TABLE IF EXISTS tmp_seed_agencies;
DROP TEMPORARY TABLE IF EXISTS tmp_seed_regionals;
DROP TEMPORARY TABLE IF EXISTS tmp_seed_directorates;
DROP TEMPORARY TABLE IF EXISTS tmp_seed_months;

CREATE TABLE IF NOT EXISTS domegastatuschamado (
    id_omega_status BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    codigo_status VARCHAR(30) NOT NULL,
    nome_status VARCHAR(50) NOT NULL,
    ordem_fluxo TINYINT UNSIGNED NOT NULL DEFAULT 1,
    encerra_chamado_sn TINYINT(1) NOT NULL DEFAULT 0,
    cor_hex CHAR(7) NOT NULL DEFAULT '#CBD5E1',
    ativo_sn TINYINT(1) NOT NULL DEFAULT 1,
    origem_carga VARCHAR(50) NOT NULL DEFAULT 'SEED',
    dt_inclusao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dt_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_omega_status),
    UNIQUE KEY uk_domegastatus_codigo (codigo_status),
    UNIQUE KEY uk_domegastatus_nome (nome_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS domegatimes (
    id_omega_time BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    codigo_time VARCHAR(50) NOT NULL,
    nome_time VARCHAR(150) NOT NULL,
    descricao VARCHAR(255) DEFAULT NULL,
    ativo_sn TINYINT(1) NOT NULL DEFAULT 1,
    origem_carga VARCHAR(50) NOT NULL DEFAULT 'SEED',
    dt_inclusao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dt_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_omega_time),
    UNIQUE KEY uk_domegatimes_codigo (codigo_time),
    UNIQUE KEY uk_domegatimes_nome (nome_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS domegacategorias (
    id_omega_categoria BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_omega_time BIGINT UNSIGNED NOT NULL,
    id_omega_categoria_pai BIGINT UNSIGNED DEFAULT NULL,
    ordem_nivel TINYINT UNSIGNED NOT NULL DEFAULT 1,
    nome_categoria VARCHAR(150) NOT NULL,
    descricao VARCHAR(255) DEFAULT NULL,
    selecao_final_sn TINYINT(1) NOT NULL DEFAULT 1,
    ordem_exibicao SMALLINT UNSIGNED NOT NULL DEFAULT 1,
    ativo_sn TINYINT(1) NOT NULL DEFAULT 1,
    origem_carga VARCHAR(50) NOT NULL DEFAULT 'SEED',
    dt_inclusao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dt_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_omega_categoria),
    UNIQUE KEY uk_domegacategorias_time_pai_nome (id_omega_time, id_omega_categoria_pai, nome_categoria)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS fomegaanalistatime (
    id_omega_analista_time BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_omega_time BIGINT UNSIGNED NOT NULL,
    funcional_analista CHAR(7) NOT NULL,
    ativo_sn TINYINT(1) NOT NULL DEFAULT 1,
    origem_carga VARCHAR(50) NOT NULL DEFAULT 'SEED',
    dt_inclusao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dt_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_omega_analista_time),
    UNIQUE KEY uk_fomegaanalistatime_time_funcional (id_omega_time, funcional_analista)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS fomegafocaltime (
    id_omega_focal_time BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_omega_time BIGINT UNSIGNED NOT NULL,
    funcional_focal CHAR(7) NOT NULL,
    ativo_sn TINYINT(1) NOT NULL DEFAULT 1,
    origem_carga VARCHAR(50) NOT NULL DEFAULT 'SEED',
    dt_inclusao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dt_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_omega_focal_time),
    UNIQUE KEY uk_fomegafocaltime_time_funcional (id_omega_time, funcional_focal)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS fomegachamado (
    id_omega_chamado BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    solicitante_funcional CHAR(7) NOT NULL,
    solicitante_nome VARCHAR(150) NOT NULL,
    solicitante_nivel CHAR(2) NOT NULL,
    solicitante_juncao_ag CHAR(4) DEFAULT NULL,
    solicitante_juncao_gr CHAR(4) DEFAULT NULL,
    solicitante_juncao_dr CHAR(4) DEFAULT NULL,
    solicitante_segmento VARCHAR(20) DEFAULT NULL,
    id_omega_time_abertura BIGINT UNSIGNED DEFAULT NULL,
    id_omega_categoria_abertura BIGINT UNSIGNED DEFAULT NULL,
    id_omega_time_atual BIGINT UNSIGNED DEFAULT NULL,
    id_omega_categoria_atual BIGINT UNSIGNED DEFAULT NULL,
    id_omega_status_atual BIGINT UNSIGNED DEFAULT NULL,
    funcional_analista_atual CHAR(7) DEFAULT NULL,
    prioridade_label VARCHAR(20) DEFAULT NULL,
    titulo VARCHAR(200) NOT NULL,
    descricao_abertura TEXT NOT NULL,
    dt_abertura DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dt_ultimo_evento DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dt_fechamento DATETIME DEFAULT NULL,
    resolucao_final VARCHAR(1000) DEFAULT NULL,
    ativo_sn TINYINT(1) NOT NULL DEFAULT 1,
    origem_carga VARCHAR(50) DEFAULT NULL,
    dt_inclusao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dt_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_omega_chamado),
    KEY idx_omegachamado_solicitante (solicitante_funcional),
    KEY idx_omegachamado_analista (funcional_analista_atual),
    KEY idx_omegachamado_time (id_omega_time_atual),
    KEY idx_omegachamado_status (id_omega_status_atual),
    KEY idx_omegachamado_ativo_evento (ativo_sn, dt_ultimo_evento)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS fomegachamadocomentario (
    id_omega_chamado_comentario BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_omega_chamado BIGINT UNSIGNED NOT NULL,
    funcional_autor CHAR(7) NOT NULL DEFAULT '',
    tipo_autor VARCHAR(20) NOT NULL DEFAULT 'SOLICITANTE',
    comentario TEXT NOT NULL,
    dt_comentario DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ativo_sn TINYINT(1) NOT NULL DEFAULT 1,
    origem_carga VARCHAR(50) DEFAULT NULL,
    dt_inclusao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dt_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_omega_chamado_comentario),
    KEY idx_omega_comentario_chamado (id_omega_chamado),
    KEY idx_omega_comentario_ativo (ativo_sn, dt_comentario)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

CREATE TABLE IF NOT EXISTS fomegachamadomovimentacao (
    id_omega_chamado_movimentacao BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    id_omega_chamado BIGINT UNSIGNED NOT NULL,
    tipo_movimentacao VARCHAR(30) NOT NULL,
    funcional_responsavel CHAR(7) NOT NULL,
    id_omega_status_origem BIGINT UNSIGNED DEFAULT NULL,
    id_omega_status_destino BIGINT UNSIGNED DEFAULT NULL,
    id_omega_time_origem BIGINT UNSIGNED DEFAULT NULL,
    id_omega_time_destino BIGINT UNSIGNED DEFAULT NULL,
    id_omega_categoria_origem BIGINT UNSIGNED DEFAULT NULL,
    id_omega_categoria_destino BIGINT UNSIGNED DEFAULT NULL,
    funcional_analista_origem CHAR(7) DEFAULT NULL,
    funcional_analista_destino CHAR(7) DEFAULT NULL,
    observacao VARCHAR(1000) DEFAULT NULL,
    dt_movimentacao DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ativo_sn TINYINT(1) NOT NULL DEFAULT 1,
    origem_carga VARCHAR(50) DEFAULT NULL,
    dt_inclusao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    dt_atualizacao TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id_omega_chamado_movimentacao),
    KEY idx_omega_mov_call (id_omega_chamado),
    KEY idx_omega_mov_active (ativo_sn, dt_movimentacao)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO domegastatuschamado (
    codigo_status,
    nome_status,
    ordem_fluxo,
    encerra_chamado_sn,
    cor_hex,
    ativo_sn,
    origem_carga
) VALUES
    ('ABERTO', 'Aberto', 1, 0, '#6CC7BE', TRUE, 'SEED_OMEGA'),
    ('AGUARDANDO', 'Aguardando', 2, 0, '#7BB9F0', TRUE, 'SEED_OMEGA'),
    ('EM_ATENDIMENTO', 'Em atendimento', 3, 0, '#9ED8A1', TRUE, 'SEED_OMEGA'),
    ('REJEITADO', 'Rejeitado', 4, 1, '#F28B82', TRUE, 'SEED_OMEGA'),
    ('FECHADO', 'Fechado', 5, 1, '#CBD5E1', TRUE, 'SEED_OMEGA')
ON DUPLICATE KEY UPDATE
    nome_status = VALUES(nome_status),
    ordem_fluxo = VALUES(ordem_fluxo),
    encerra_chamado_sn = VALUES(encerra_chamado_sn),
    cor_hex = VALUES(cor_hex),
    ativo_sn = VALUES(ativo_sn),
    origem_carga = VALUES(origem_carga);

INSERT INTO domegatimes (
    codigo_time,
    nome_time,
    descricao,
    ativo_sn,
    origem_carga
) VALUES
    ('POBJ', 'POBJ', 'Fila operacional padrao do Omega.', TRUE, 'SEED_OMEGA'),
    ('METAS', 'Metas', 'Fila dedicada a ajustes e redistribuicao de metas.', TRUE, 'SEED_OMEGA')
ON DUPLICATE KEY UPDATE
    nome_time = VALUES(nome_time),
    descricao = VALUES(descricao),
    ativo_sn = VALUES(ativo_sn),
    origem_carga = VALUES(origem_carga);

UPDATE domegatimes
SET ativo_sn = FALSE,
    origem_carga = 'SEED_OMEGA'
WHERE codigo_time = 'EQUIPE_MATRIZ';

UPDATE domegacategorias existing
INNER JOIN domegatimes t
    ON t.id_omega_time = existing.id_omega_time
INNER JOIN (
    SELECT 'POBJ' AS codigo_time, 1 AS ordem_exibicao, 'Contestar Realizado' AS nome_categoria, 'Contestacoes de realizado para a fila POBJ.' AS descricao
    UNION ALL SELECT 'POBJ', 2, 'Outros', 'Demais tratativas operacionais da fila POBJ.'
    UNION ALL SELECT 'METAS', 1, 'Contestar Meta', 'Contestacoes relacionadas a metas cadastradas.'
    UNION ALL SELECT 'METAS', 2, 'Redistribuir Meta', 'Redistribuicoes e ajustes de meta entre carteiras.'
) seed
    ON seed.codigo_time = t.codigo_time
   AND seed.nome_categoria = existing.nome_categoria
SET existing.ordem_nivel = 1,
    existing.descricao = seed.descricao,
    existing.selecao_final_sn = TRUE,
    existing.ordem_exibicao = seed.ordem_exibicao,
    existing.ativo_sn = TRUE,
    existing.origem_carga = 'SEED_OMEGA'
WHERE existing.id_omega_categoria_pai IS NULL;

INSERT INTO domegacategorias (
    id_omega_time,
    id_omega_categoria_pai,
    ordem_nivel,
    nome_categoria,
    descricao,
    selecao_final_sn,
    ordem_exibicao,
    ativo_sn,
    origem_carga
)
SELECT
    t.id_omega_time,
    NULL,
    1,
    seed.nome_categoria,
    seed.descricao,
    TRUE,
    seed.ordem_exibicao,
    TRUE,
    'SEED_OMEGA'
FROM domegatimes t
INNER JOIN (
    SELECT 'POBJ' AS codigo_time, 1 AS ordem_exibicao, 'Contestar Realizado' AS nome_categoria, 'Contestacoes de realizado para a fila POBJ.' AS descricao
    UNION ALL SELECT 'POBJ', 2, 'Outros', 'Demais tratativas operacionais da fila POBJ.'
    UNION ALL SELECT 'METAS', 1, 'Contestar Meta', 'Contestacoes relacionadas a metas cadastradas.'
    UNION ALL SELECT 'METAS', 2, 'Redistribuir Meta', 'Redistribuicoes e ajustes de meta entre carteiras.'
) seed
    ON seed.codigo_time = t.codigo_time
WHERE NOT EXISTS (
    SELECT 1
    FROM domegacategorias existing
    WHERE existing.id_omega_time = t.id_omega_time
      AND existing.id_omega_categoria_pai IS NULL
      AND existing.nome_categoria = seed.nome_categoria
);

UPDATE domegacategorias c
INNER JOIN (
    SELECT
        id_omega_time,
        nome_categoria,
        MIN(id_omega_categoria) AS id_omega_categoria_keep
    FROM domegacategorias
    WHERE id_omega_categoria_pai IS NULL
    GROUP BY id_omega_time, nome_categoria
    HAVING COUNT(*) > 1
) duplicates
    ON duplicates.id_omega_time = c.id_omega_time
   AND duplicates.nome_categoria = c.nome_categoria
SET c.ativo_sn = FALSE,
    c.origem_carga = 'SEED_OMEGA'
WHERE c.id_omega_categoria_pai IS NULL
  AND c.id_omega_categoria <> duplicates.id_omega_categoria_keep;

UPDATE domegacategorias c
INNER JOIN domegatimes t
    ON t.id_omega_time = c.id_omega_time
SET c.ativo_sn = FALSE,
    c.origem_carga = 'SEED_OMEGA'
WHERE c.id_omega_categoria_pai IS NULL
  AND (
      (t.codigo_time = 'POBJ' AND c.nome_categoria NOT IN ('Contestar Realizado', 'Outros'))
      OR (t.codigo_time = 'METAS' AND c.nome_categoria NOT IN ('Contestar Meta', 'Redistribuir Meta'))
      OR t.codigo_time = 'EQUIPE_MATRIZ'
  );

INSERT INTO fomegaanalistatime (
    id_omega_time,
    funcional_analista,
    ativo_sn,
    origem_carga
)
SELECT t.id_omega_time, seed.funcional_analista, TRUE, 'SEED_OMEGA'
FROM domegatimes t
INNER JOIN (
    SELECT 'POBJ' AS codigo_time, '6000001' AS funcional_analista
    UNION ALL SELECT 'POBJ', '6000003'
    UNION ALL SELECT 'METAS', '6000002'
) seed
    ON seed.codigo_time = t.codigo_time
ON DUPLICATE KEY UPDATE
    ativo_sn = VALUES(ativo_sn),
    origem_carga = VALUES(origem_carga);

UPDATE fomegaanalistatime a
INNER JOIN domegatimes t
    ON t.id_omega_time = a.id_omega_time
SET a.ativo_sn = FALSE,
    a.origem_carga = 'SEED_OMEGA'
WHERE (t.codigo_time = 'POBJ' AND a.funcional_analista NOT IN ('6000001', '6000003'))
   OR (t.codigo_time = 'METAS' AND a.funcional_analista NOT IN ('6000002'))
   OR t.codigo_time = 'EQUIPE_MATRIZ';

INSERT INTO fomegafocaltime (
    id_omega_time,
    funcional_focal,
    ativo_sn,
    origem_carga
)
SELECT t.id_omega_time, seed.funcional_focal, TRUE, 'SEED_OMEGA'
FROM domegatimes t
INNER JOIN (
    SELECT 'POBJ' AS codigo_time, '9000001' AS funcional_focal
    UNION ALL SELECT 'METAS', '8000001'
    UNION ALL SELECT 'METAS', '7000002'
) seed
    ON seed.codigo_time = t.codigo_time
ON DUPLICATE KEY UPDATE
    ativo_sn = VALUES(ativo_sn),
    origem_carga = VALUES(origem_carga);

UPDATE fomegafocaltime f
INNER JOIN domegatimes t
    ON t.id_omega_time = f.id_omega_time
SET f.ativo_sn = FALSE,
    f.origem_carga = 'SEED_OMEGA'
WHERE (t.codigo_time = 'POBJ' AND f.funcional_focal NOT IN ('9000001'))
   OR (t.codigo_time = 'METAS' AND f.funcional_focal NOT IN ('8000001', '7000002'))
   OR t.codigo_time = 'EQUIPE_MATRIZ';

INSERT INTO fomegachamado (
    solicitante_funcional,
    solicitante_nome,
    solicitante_nivel,
    solicitante_juncao_ag,
    solicitante_juncao_gr,
    solicitante_juncao_dr,
    solicitante_segmento,
    id_omega_time_abertura,
    id_omega_categoria_abertura,
    id_omega_time_atual,
    id_omega_categoria_atual,
    id_omega_status_atual,
    funcional_analista_atual,
    prioridade_label,
    titulo,
    descricao_abertura,
    dt_abertura,
    dt_ultimo_evento,
    dt_fechamento,
    resolucao_final,
    ativo_sn,
    origem_carga
)
SELECT
    h.funcional,
    h.nome,
    h.nivel,
    ag.juncao,
    gr.juncao,
    dr.juncao,
    seed.departamento_label,
    t.id_omega_time,
    cat.id_omega_categoria,
    t.id_omega_time,
    cat.id_omega_categoria,
    st.id_omega_status,
    seed.funcional_analista,
    seed.prioridade_label,
    seed.titulo,
    seed.descricao_abertura,
    seed.dt_abertura,
    seed.dt_ultimo_evento,
    seed.dt_fechamento,
    seed.resolucao_final,
    TRUE,
    'SEED_OMEGA'
FROM (
    SELECT '4000001' AS solicitante_funcional, 'POBJ' AS codigo_time, 'POBJ' AS departamento_label, 'Contestar Realizado' AS nome_categoria, '6000001' AS funcional_analista, 'Alta' AS prioridade_label, 'EM_ATENDIMENTO' AS codigo_status, 'Contestacao de realizado abril - Agencia Centro' AS titulo, 'Cliente solicitou revisao do realizado de abril por divergencia na consolidacao final.' AS descricao_abertura, '2026-04-05 09:15:00' AS dt_abertura, '2026-04-07 11:40:00' AS dt_ultimo_evento, NULL AS dt_fechamento, NULL AS resolucao_final
    UNION ALL SELECT '4000002', 'POBJ', 'POBJ', 'Contestar Realizado', '6000003', 'Média', 'AGUARDANDO', 'Contestacao de realizado abril - Agencia Jardim', 'Carteira da Agencia Jardim ficou com realizado inferior ao painel legado e exige conferencia.' , '2026-04-04 08:20:00', '2026-04-06 14:10:00', NULL, NULL
    UNION ALL SELECT '7000001', 'POBJ', 'POBJ', 'Outros', '6000001', 'Baixa', 'ABERTO', 'Ajuste operacional de consolidacao POBJ', 'Solicitacao de ajuste manual na consolidacao apos reprocessamento da carga mensal.' , '2026-04-08 10:05:00', '2026-04-08 10:05:00', NULL, NULL
    UNION ALL SELECT '6000001', 'METAS', 'Metas', 'Contestar Meta', '6000002', 'Alta', 'EM_ATENDIMENTO', 'Contestacao de meta trimestral - Centro', 'Gerente da agencia Centro contestou a meta do trimestre por desalinhamento com a carteira ativa.' , '2026-04-03 13:30:00', '2026-04-07 09:25:00', NULL, NULL
    UNION ALL SELECT '8000001', 'METAS', 'Metas', 'Redistribuir Meta', '6000002', 'Média', 'AGUARDANDO', 'Redistribuicao de meta regional Norte', 'Solicitada redistribuicao de meta entre agencias da regional Norte apos reorganizacao da carteira.' , '2026-04-02 15:00:00', '2026-04-07 16:45:00', NULL, NULL
    UNION ALL SELECT '4000003', 'METAS', 'Metas', 'Redistribuir Meta', '6000002', 'Baixa', 'FECHADO', 'Redistribuicao de meta carteira Litoral', 'Chamado para redistribuir meta da carteira Litoral apos migracao de clientes.' , '2026-04-01 09:10:00', '2026-04-05 18:20:00', '2026-04-05 18:20:00', 'Redistribuicao concluida e carteira atualizada no fechamento diario.'
) seed
INNER JOIN dHierarquia h
    ON h.funcional = seed.solicitante_funcional
   AND h.ativo_sn = TRUE
INNER JOIN domegatimes t
    ON t.codigo_time = seed.codigo_time
   AND t.ativo_sn = TRUE
INNER JOIN domegacategorias cat
    ON cat.id_omega_time = t.id_omega_time
   AND cat.id_omega_categoria_pai IS NULL
   AND cat.nome_categoria = seed.nome_categoria
   AND cat.ativo_sn = TRUE
INNER JOIN domegastatuschamado st
    ON st.codigo_status = seed.codigo_status
   AND st.ativo_sn = TRUE
LEFT JOIN fMultiJuncao ag
    ON ag.funcional = h.funcional
   AND ag.tipo_juncao = 'AG'
   AND ag.principal_sn = TRUE
   AND ag.ativo_sn = TRUE
LEFT JOIN fMultiJuncao gr
    ON gr.funcional = h.funcional
   AND gr.tipo_juncao = 'GR'
   AND gr.principal_sn = TRUE
   AND gr.ativo_sn = TRUE
LEFT JOIN fMultiJuncao dr
    ON dr.funcional = h.funcional
   AND dr.tipo_juncao = 'DR'
   AND dr.principal_sn = TRUE
   AND dr.ativo_sn = TRUE
WHERE NOT EXISTS (
    SELECT 1
    FROM fomegachamado existing
    WHERE existing.origem_carga = 'SEED_OMEGA'
      AND existing.solicitante_funcional = h.funcional
      AND existing.titulo = seed.titulo
);

INSERT INTO fomegachamadocomentario (
    id_omega_chamado,
    funcional_autor,
    tipo_autor,
    comentario,
    dt_comentario,
    ativo_sn,
    origem_carga
)
SELECT
    c.id_omega_chamado,
    seed.funcional_autor,
    seed.tipo_autor,
    seed.comentario,
    seed.dt_comentario,
    TRUE,
    'SEED_OMEGA'
FROM (
    SELECT 'Contestacao de realizado abril - Agencia Centro' AS titulo, '4000001' AS funcional_autor, 'SOLICITANTE' AS tipo_autor, 'Enviei os comprovantes do realizado e preciso de reprocessamento da leitura.' AS comentario, '2026-04-05 09:20:00' AS dt_comentario
    UNION ALL SELECT 'Contestacao de realizado abril - Agencia Centro', '6000001', 'ANALISTA', 'Recebido. Vou confrontar a carga com o consolidado legado antes de responder.' , '2026-04-07 11:40:00'
    UNION ALL SELECT 'Contestacao de meta trimestral - Centro', '6000001', 'SOLICITANTE', 'Meta veio acima da carteira atual e precisa de revisao.' , '2026-04-03 13:35:00'
    UNION ALL SELECT 'Contestacao de meta trimestral - Centro', '6000002', 'ANALISTA', 'Analise em andamento com base na redistribuicao mais recente da agencia.' , '2026-04-07 09:25:00'
    UNION ALL SELECT 'Redistribuicao de meta carteira Litoral', '6000002', 'ANALISTA', 'Redistribuicao concluida e validada com a regional.' , '2026-04-05 18:18:00'
) seed
INNER JOIN fomegachamado c
    ON c.titulo = seed.titulo
   AND c.origem_carga = 'SEED_OMEGA'
WHERE NOT EXISTS (
    SELECT 1
    FROM fomegachamadocomentario existing
    WHERE existing.id_omega_chamado = c.id_omega_chamado
      AND existing.funcional_autor = seed.funcional_autor
      AND existing.dt_comentario = seed.dt_comentario
);

INSERT INTO fomegachamadomovimentacao (
    id_omega_chamado,
    tipo_movimentacao,
    funcional_responsavel,
    id_omega_status_origem,
    id_omega_status_destino,
    id_omega_time_origem,
    id_omega_time_destino,
    id_omega_categoria_origem,
    id_omega_categoria_destino,
    funcional_analista_origem,
    funcional_analista_destino,
    observacao,
    dt_movimentacao,
    ativo_sn,
    origem_carga
)
SELECT
    c.id_omega_chamado,
    seed.tipo_movimentacao,
    seed.funcional_responsavel,
    so.id_omega_status,
    sd.id_omega_status,
    tor.id_omega_time,
    tde.id_omega_time,
    corg.id_omega_categoria,
    cde.id_omega_categoria,
    NULLIF(seed.funcional_analista_origem, ''),
    NULLIF(seed.funcional_analista_destino, ''),
    seed.observacao,
    seed.dt_movimentacao,
    TRUE,
    'SEED_OMEGA'
FROM (
    SELECT 'Contestacao de realizado abril - Agencia Centro' AS titulo, 'ABERTURA' AS tipo_movimentacao, '4000001' AS funcional_responsavel, NULL AS status_origem, 'EM_ATENDIMENTO' AS status_destino, NULL AS time_origem, 'POBJ' AS time_destino, NULL AS categoria_origem, 'Contestar Realizado' AS categoria_destino, '' AS funcional_analista_origem, '6000001' AS funcional_analista_destino, 'Chamado aberto pelo solicitante e direcionado para a fila POBJ.' AS observacao, '2026-04-05 09:15:00' AS dt_movimentacao
    UNION ALL SELECT 'Contestacao de meta trimestral - Centro', 'ABERTURA', '6000001', NULL, 'EM_ATENDIMENTO', NULL, 'METAS', NULL, 'Contestar Meta', '', '6000002', 'Chamado aberto na fila Metas para revisao da meta trimestral.', '2026-04-03 13:30:00'
    UNION ALL SELECT 'Redistribuicao de meta carteira Litoral', 'FECHAMENTO', '6000002', 'AGUARDANDO', 'FECHADO', 'METAS', 'METAS', 'Redistribuir Meta', 'Redistribuir Meta', '6000002', '6000002', 'Chamado encerrado apos redistribuicao confirmada pela regional.', '2026-04-05 18:20:00'
) seed
INNER JOIN fomegachamado c
    ON c.titulo = seed.titulo
   AND c.origem_carga = 'SEED_OMEGA'
LEFT JOIN domegastatuschamado so
    ON so.codigo_status = seed.status_origem
LEFT JOIN domegastatuschamado sd
    ON sd.codigo_status = seed.status_destino
LEFT JOIN domegatimes tor
    ON tor.codigo_time = seed.time_origem
LEFT JOIN domegatimes tde
    ON tde.codigo_time = seed.time_destino
LEFT JOIN domegacategorias corg
    ON corg.id_omega_time = tor.id_omega_time
   AND corg.id_omega_categoria_pai IS NULL
   AND corg.nome_categoria = seed.categoria_origem
LEFT JOIN domegacategorias cde
    ON cde.id_omega_time = tde.id_omega_time
   AND cde.id_omega_categoria_pai IS NULL
   AND cde.nome_categoria = seed.categoria_destino
WHERE NOT EXISTS (
    SELECT 1
    FROM fomegachamadomovimentacao existing
    WHERE existing.id_omega_chamado = c.id_omega_chamado
      AND existing.tipo_movimentacao = seed.tipo_movimentacao
      AND existing.dt_movimentacao = seed.dt_movimentacao
);