<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

use App\Services\PrimeAssistantService;

$assistantService = new PrimeAssistantService();
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

try {
    if ($requestMethod === 'GET') {
        json_response([
            'ok' => true,
            'guides' => $assistantService->listGuides(),
        ]);
    }

    $contentType = strtolower(trim((string) ($_SERVER['CONTENT_TYPE'] ?? '')));
    $requestData = $_POST;

    if (strpos($contentType, 'application/json') !== false) {
        $decoded = json_decode((string) file_get_contents('php://input'), true);
        $requestData = is_array($decoded) ? $decoded : [];
    }

    if (!verify_csrf($requestData['csrf_token'] ?? null)) {
        json_response([
            'ok' => false,
            'message' => 'Sessao expirada. Recarregue a tela antes de usar a IA.',
        ], 419);
    }

    $action = trim((string) ($requestData['action'] ?? ''));

    if ($action === 'upload-guides') {
        json_response([
            'ok' => true,
            'guides' => $assistantService->storeUploadedGuides($_FILES['guides'] ?? []),
            'message' => 'Guias atualizados. A IA ja pode usar os PDFs enviados.',
        ]);
    }

    if ($action === 'ask') {
        $response = $assistantService->answerQuestion(
            (string) ($requestData['question'] ?? ''),
            is_array($requestData['history'] ?? null) ? $requestData['history'] : []
        );

        json_response([
            'ok' => true,
            'answer' => $response['answer'],
            'sources' => $response['sources'],
            'guides' => $assistantService->listGuides(),
        ]);
    }

    json_response([
        'ok' => false,
        'message' => 'Acao de chat nao reconhecida.',
    ], 422);
} catch (Throwable $exception) {
    $status = 500;
    $message = trim($exception->getMessage()) !== '' ? trim($exception->getMessage()) : 'Falha interna ao processar a IA.';

    if ($message !== '' && (
        stripos($message, 'Selecione') !== false
        || stripos($message, 'Envie') !== false
        || stripos($message, 'Informe') !== false
        || stripos($message, 'Nao encontrei') !== false
        || stripos($message, 'PDF') !== false
        || stripos($message, 'OpenAI') !== false
        || stripos($message, 'Sessao') !== false
    )) {
        $status = 422;
    }

    json_response([
        'ok' => false,
        'message' => $message,
    ], $status);
}