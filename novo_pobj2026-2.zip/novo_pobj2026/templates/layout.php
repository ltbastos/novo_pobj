<?php

declare(strict_types=1);

$layoutProfile = $context['profile'] ?? null;
$headerName = prime_label($layoutProfile['nome'] ?? 'Usuario de teste');
$headerFirstName = first_name($headerName);
$headerInitials = user_initials($headerName);
$headerFunctional = trim((string) ($layoutProfile['funcional'] ?? $selectedProfileFunctional ?? ''));
$visualTheme = is_array($visualTheme ?? null) ? $visualTheme : ['code' => 'classic', 'is_prime' => false, 'logo_path' => 'assets/img/logo-bradesco-white.svg', 'logo_alt' => 'Bradesco', 'reference_path' => 'assets/img/prime-reference.svg', 'bubble_label' => 'IA POBJ', 'badge_copy' => 'Modo POBJ'];
$assistantGuides = array_values((array) ($assistantGuides ?? []));
$themeCode = trim((string) ($visualTheme['code'] ?? 'classic'));
$brandLogoPath = trim((string) ($visualTheme['logo_path'] ?? 'assets/img/logo-bradesco-white.svg'));
$brandLogoAlt = trim((string) ($visualTheme['logo_alt'] ?? 'Bradesco'));
$assistantInitialGuidesJson = e((string) json_encode($assistantGuides, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
$assistantConfigStartsOpen = false;
$hasIndicatorDetailModal = (($indicatorFocusId ?? '') !== '');
$watermarkIdentity = $headerFunctional;

if ($watermarkIdentity === '') {
    $watermarkIdentity = 'Acesso interno monitorado';
}

$dashboardUrl = app_url(['page' => 'pobj-dashboard', 'periodo' => $selectedPeriodId ?? '']);
$encantabraMenuUrl = app_url(array_merge(['page' => 'pobj-dashboard', 'tab' => 'encantabra'], $encantabraQueryState ?? []));
$omegaUrl = 'omega.php';
$profileSwitchQuery = [
    'periodo' => (string) ($selectedPeriodId ?? ''),
    'tab' => $activeTab ?? 'resumo',
    'advanced_filters' => $advancedFiltersState ?? 'open',
];

if (($indicatorFocusId ?? '') !== '') {
    $profileSwitchQuery['indicator_focus'] = $indicatorFocusId;
}

foreach (($summaryFilterValues ?? []) as $filterKey => $filterValue) {
    if (!is_string($filterValue) || $filterValue === '') {
        continue;
    }

    $profileSwitchQuery[$filterKey] = $filterValue;
}

if (($requestedRankingGroup ?? '') !== '') {
    $profileSwitchQuery['grupo'] = $requestedRankingGroup;
}

foreach (($encantabraQueryState ?? []) as $queryKey => $queryValue) {
    if (!is_string($queryValue) || $queryValue === '') {
        continue;
    }

    $profileSwitchQuery[$queryKey] = $queryValue;
}

if (($hasManualDateRange ?? false) === true) {
    $profileSwitchQuery['period_mode'] = 'manual';

    if (($requestedPeriodStart ?? '') !== '') {
        $profileSwitchQuery['period_start'] = $requestedPeriodStart;
    }

    if (($requestedPeriodEnd ?? '') !== '') {
        $profileSwitchQuery['period_end'] = $requestedPeriodEnd;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle ?? 'Novo POBJ') ?></title>
    <link rel="stylesheet" href="assets/css/app.css">
    <noscript><style>.global-loading-overlay{display:none !important;}</style></noscript>
</head>
<body class="is-booting<?= ($visualTheme['is_prime'] ?? false) ? ' theme-prime' : '' ?><?= $hasIndicatorDetailModal ? ' has-modal-open' : '' ?>" data-visual-theme="<?= e($themeCode) ?>">
    <header class="topbar" role="banner">
        <nav id="main-navigation" class="topbar__left" aria-label="Navegacao principal">
            <a href="<?= e($dashboardUrl) ?>" class="brand">
                <img class="brand__logo" src="<?= e($brandLogoPath) ?>" alt="<?= e($brandLogoAlt) ?>">
            </a>
        </nav>

        <nav class="topbar__right" aria-label="Menu do usuario">
            <?php if (($profiles ?? []) !== []): ?>
                <form class="topbar-profile" method="post" action="index.php" aria-label="Selecionar usuario logado temporario">
                    <input type="hidden" name="action" value="select_profile">
                    <?= csrf_field() ?>
                    <?php foreach ($profileSwitchQuery as $queryKey => $queryValue): ?>
                        <?php if ($queryValue === '') {
                            continue;
                        } ?>
                        <input type="hidden" name="redirect_query[<?= e((string) $queryKey) ?>]" value="<?= e((string) $queryValue) ?>">
                    <?php endforeach; ?>

                    <label class="topbar-profile__label" for="topbar-profile-functional">Usuario logado</label>
                    <div class="topbar-profile__field">
                        <select id="topbar-profile-functional" name="selected_functional" class="topbar-profile__select" data-autosubmit aria-label="Selecionar usuario logado temporario">
                            <?php foreach ($profiles as $profileItem): ?>
                                <?php
                                $profileOptionName = trim((string) ($profileItem['nome'] ?? ''));
                                $profileOptionLevel = trim((string) ($profileItem['nivel'] ?? ''));
                                $profileOptionJunction = trim((string) ($profileItem['juncao_principal'] ?? ''));
                                $profileOptionMeta = $profileOptionLevel;

                                if ($profileOptionJunction !== '') {
                                    $profileOptionMeta .= ' • ' . $profileOptionJunction;
                                }

                                $profileOptionLabel = $profileOptionMeta !== ''
                                    ? $profileOptionName . ' • ' . $profileOptionMeta
                                    : $profileOptionName;
                                ?>
                                <option value="<?= e((string) ($profileItem['funcional'] ?? '')) ?>"<?= selected_attr((string) ($profileItem['funcional'] ?? ''), $selectedProfileFunctional ?? null) ?>><?= e(prime_label($profileOptionLabel)) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </form>
            <?php endif; ?>

            <div class="userbox" data-userbox>
                <button class="userbox__trigger" id="btn-user-menu" type="button" aria-haspopup="true" aria-expanded="false" aria-controls="user-menu" aria-label="Menu do usuario: <?= e($headerName) ?>" data-userbox-trigger>
                    <span class="userbox__avatar"><?= e($headerInitials) ?></span>
                    <span class="userbox__identity">
                        <span class="userbox__name"><?= e($headerFirstName) ?></span>
                    </span>
                    <span class="userbox__chevron" aria-hidden="true"></span>
                </button>

                <div class="userbox__menu" id="user-menu" hidden data-userbox-menu>
                    <div class="userbox__menu-header">
                        <span class="userbox__menu-title">Links uteis</span>
                    </div>

                    <div class="userbox__menu-section">
                        <button class="userbox__menu-item" type="button" data-userbox-dismiss>Portal PJ</button>

                        <div class="userbox__submenu">
                            <button class="userbox__menu-item userbox__menu-item--has-sub" type="button" aria-expanded="false" aria-controls="user-submenu-manuais" data-userbox-submenu-trigger>
                                <span>Manuais</span>
                                <span class="userbox__submenu-chevron" aria-hidden="true"></span>
                            </button>

                            <div class="userbox__submenu-list" id="user-submenu-manuais" hidden data-userbox-submenu>
                                <button class="userbox__menu-item" type="button" data-userbox-dismiss>Manual do POBJ</button>
                                <button class="userbox__menu-item" type="button" data-userbox-dismiss>Manual do Omega</button>
                            </div>
                        </div>

                        <button class="userbox__menu-item" type="button" data-userbox-dismiss>Mapao de Oportunidades</button>
                        <a class="userbox__menu-item" href="<?= e($omegaUrl) ?>" target="_blank" rel="noopener" data-userbox-dismiss>Omega</a>
                        <a class="userbox__menu-item" href="<?= e($encantabraMenuUrl) ?>" target="_blank" rel="noopener" data-userbox-dismiss>EncantaBra</a>
                    </div>
                    <div class="userbox__divider"></div>
                    <button class="userbox__menu-item userbox__menu-item--logout" type="button" data-userbox-dismiss>
                        <span class="userbox__logout-icon" aria-hidden="true"></span>
                        <span>Sair</span>
                    </button>
                </div>
            </div>
        </nav>
    </header>

    <div class="app-shell">
        <div class="app-watermark" aria-hidden="true">
            <?php for ($watermarkRow = 0; $watermarkRow < 8; $watermarkRow++): ?>
                <div class="app-watermark__row" style="top: <?= e((string) (6 + ($watermarkRow * 13))) ?>%;">
                    <?php for ($watermarkItem = 0; $watermarkItem < 5; $watermarkItem++): ?>
                        <span><?= e($watermarkIdentity) ?></span>
                    <?php endfor; ?>
                </div>
            <?php endfor; ?>
        </div>

        <main id="main-content" class="main-content" aria-label="Area principal do painel">
            <?php include __DIR__ . '/summary_filters.php'; ?>
            <?php include __DIR__ . '/summary_tabs.php'; ?>
            <?php include __DIR__ . '/summary_mode_toggle.php'; ?>
            <?php include __DIR__ . '/summary_cards.php'; ?>
            <?php include __DIR__ . '/summary_indicator_cards.php'; ?>
            <?php include __DIR__ . '/summary_legacy.php'; ?>
            <?php include __DIR__ . '/summary_annual.php'; ?>
            <?php include __DIR__ . '/rankings.php'; ?>
            <?php include __DIR__ . '/detail_view.php'; ?>
            <?php include __DIR__ . '/executive_view.php'; ?>
            <?php include __DIR__ . '/encantabra_view.php'; ?>
            <?php include __DIR__ . '/coming_soon.php'; ?>
        </main>
    </div>

    <?php include __DIR__ . '/indicator_detail_view.php'; ?>

    <div class="assistant-widget" data-assistant-root data-chat-endpoint="chat.php" data-chat-csrf="<?= e(csrf_token()) ?>" data-initial-guides="<?= $assistantInitialGuidesJson ?>">
        <section class="assistant-widget__panel" id="assistant-panel" aria-label="Assistente com IA">
            <header class="assistant-widget__header">
                <div>
                    <span class="assistant-widget__eyebrow"><?= e((string) ($visualTheme['badge_copy'] ?? 'Modo POBJ')) ?></span>
                    <strong class="assistant-widget__title"><?= e((string) ($visualTheme['bubble_label'] ?? 'IA POBJ')) ?></strong>
                    <p class="assistant-widget__copy">Pergunte direto. Eu respondo apenas com base na base já carregada.</p>
                </div>
                <button class="assistant-widget__close" type="button" aria-label="Fechar assistente" data-assistant-close>
                    <i data-lucide="x"></i>
                </button>
            </header>

            <button class="assistant-widget__config-toggle<?= $assistantConfigStartsOpen ? ' is-open' : '' ?>" type="button" aria-expanded="<?= $assistantConfigStartsOpen ? 'true' : 'false' ?>" data-assistant-config-toggle>
                Base de PDFs
            </button>

            <div class="assistant-widget__config<?= $assistantConfigStartsOpen ? ' is-open' : '' ?>" data-assistant-config-panel>
                <form class="assistant-widget__upload" method="post" action="chat.php" enctype="multipart/form-data" data-assistant-upload-form>
                    <input type="hidden" name="action" value="upload-guides">
                    <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">

                    <label class="assistant-widget__upload-picker">
                        <input type="file" name="guides[]" accept="application/pdf,.pdf" multiple data-assistant-guides-input>
                        <span>Selecionar PDF(s)</span>
                    </label>

                    <button class="assistant-widget__upload-button" type="submit" data-assistant-upload-button>Atualizar base</button>
                </form>

                <div class="assistant-widget__guide-list" data-assistant-guide-list>
                    <?php if ($assistantGuides === []): ?>
                        <div class="assistant-widget__guide-empty">Nenhum PDF carregado ainda.</div>
                    <?php else: ?>
                        <?php foreach ($assistantGuides as $guideItem): ?>
                            <article class="assistant-widget__guide-item">
                                <strong><?= e((string) ($guideItem['name'] ?? 'Guia')) ?></strong>
                                <span><?= e(format_int_readable((float) ($guideItem['chars'] ?? 0))) ?> caracteres úteis</span>
                            </article>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="assistant-widget__messages" data-assistant-messages>
                <article class="assistant-widget__message assistant-widget__message--assistant">
                    <p>Pergunte o que quiser sobre o programa. Se a resposta não estiver nos PDFs da base, eu vou dizer isso sem rodeios.</p>
                </article>
            </div>

            <form class="assistant-widget__composer" method="post" action="chat.php" data-assistant-chat-form>
                <input type="hidden" name="action" value="ask">
                <input type="hidden" name="csrf_token" value="<?= e(csrf_token()) ?>">
                <textarea class="assistant-widget__input" name="question" rows="2" placeholder="Ex.: qual regra vale para reaproveitar produção no mês?" data-assistant-input></textarea>
                <button class="assistant-widget__send" type="submit" data-assistant-send>Enviar</button>
            </form>

            <p class="assistant-widget__hint" data-assistant-status>Chat pronto. Use Base de PDFs apenas quando precisar atualizar a referência.</p>
        </section>

        <button class="assistant-widget__bubble" type="button" aria-controls="assistant-panel" aria-expanded="false" aria-label="Abrir assistente com IA" data-assistant-toggle>
            <span class="assistant-widget__bubble-icon" aria-hidden="true"><i data-lucide="message-square"></i></span>
            <span class="assistant-widget__bubble-label"><?= e((string) ($visualTheme['bubble_label'] ?? 'IA POBJ')) ?></span>
        </button>
    </div>

    <div class="global-loading-overlay" aria-live="polite" aria-busy="true" data-loading-overlay>
        <div class="global-loading-overlay__panel">
            <div class="global-loading-overlay__mark" aria-hidden="true">
                <span class="global-loading-overlay__ring global-loading-overlay__ring--outer"></span>
                <span class="global-loading-overlay__ring global-loading-overlay__ring--inner"></span>
                <span class="global-loading-overlay__core"></span>
            </div>
            <strong class="global-loading-overlay__title">Atualizando painel</strong>
            <span class="global-loading-overlay__copy" data-loading-text>Carregando dados do POBJ...</span>
        </div>
    </div>

    <script src="assets/vendor/lucide.min.js"></script>
    <script src="assets/js/app.js"></script>
</body>
</html>