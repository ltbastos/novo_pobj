<?php

declare(strict_types=1);

namespace App\Services;

use DateTimeImmutable;
use RuntimeException;
use Throwable;

final class PrimeAssistantService
{
    private const MAX_GUIDE_BYTES = 15728640;

    /** @var PdfGuideExtractor */
    private $extractor;

    /** @var string */
    private $storageRoot;

    /** @var array */
    private $config;

    public function __construct(?PdfGuideExtractor $extractor = null, ?string $storageRoot = null)
    {
        $this->extractor = $extractor ?? new PdfGuideExtractor();
        $this->storageRoot = $storageRoot ?? storage_path('assistant');
        $this->config = $this->loadConfig();

        ensure_directory($this->storageRoot);
        ensure_directory($this->guideDirectory());
        ensure_directory($this->textDirectory());
    }

    public function listGuides(): array
    {
        $guides = [];

        foreach ($this->readManifest() as $item) {
            $guides[] = [
                'id' => (string) ($item['id'] ?? ''),
                'name' => (string) ($item['name'] ?? 'Guia'),
                'uploaded_at' => (string) ($item['uploaded_at'] ?? ''),
                'chars' => (int) ($item['chars'] ?? 0),
                'excerpt' => (string) ($item['excerpt'] ?? ''),
            ];
        }

        return $guides;
    }

    public function storeUploadedGuides(array $uploadedFiles): array
    {
        $files = $this->normalizeUploadedFiles($uploadedFiles);

        if ($files === []) {
            throw new RuntimeException('Selecione pelo menos um PDF para montar a base da IA.');
        }

        $manifest = $this->readManifest();

        foreach ($files as $file) {
            $originalName = trim((string) ($file['name'] ?? 'guia.pdf'));
            $extension = strtolower((string) pathinfo($originalName, PATHINFO_EXTENSION));

            if ($extension !== 'pdf') {
                throw new RuntimeException('Envie apenas arquivos PDF.');
            }

            $size = (int) ($file['size'] ?? 0);

            if ($size <= 0 || $size > self::MAX_GUIDE_BYTES) {
                throw new RuntimeException('Cada PDF precisa ter ate 15 MB e nao pode estar vazio.');
            }

            $tmpName = (string) ($file['tmp_name'] ?? '');

            if ($tmpName === '' || !is_uploaded_file($tmpName)) {
                throw new RuntimeException('Nao foi possivel receber o PDF enviado.');
            }

            $safeName = $this->sanitizeFileName($originalName);
            $documentId = date('YmdHis') . '-' . bin2hex(random_bytes(4));
            $pdfFileName = $documentId . '-' . $safeName;
            $pdfPath = $this->guideDirectory() . DIRECTORY_SEPARATOR . $pdfFileName;

            if (!move_uploaded_file($tmpName, $pdfPath)) {
                throw new RuntimeException('Falha ao salvar o PDF no servidor local.');
            }

            try {
                $extractedText = $this->extractor->extractText($pdfPath);
            } catch (Throwable $exception) {
                @unlink($pdfPath);
                throw $exception;
            }

            $textFileName = $documentId . '.txt';
            $textPath = $this->textDirectory() . DIRECTORY_SEPARATOR . $textFileName;
            file_put_contents($textPath, $extractedText);

            $manifest[] = [
                'id' => $documentId,
                'name' => $safeName,
                'pdf_file' => $pdfFileName,
                'text_file' => $textFileName,
                'uploaded_at' => (new DateTimeImmutable())->format(DATE_ATOM),
                'chars' => $this->stringLength($extractedText),
                'excerpt' => $this->truncateSingleLine($extractedText, 180),
            ];
        }

        $this->writeManifest($manifest);

        return $this->listGuides();
    }

    public function answerQuestion(string $question, array $history = []): array
    {
        $question = trim($question);

        if ($question === '') {
            throw new RuntimeException('Digite a duvida antes de chamar a IA.');
        }

        $apiKey = $this->configuredApiKey();
        $model = $this->configuredModel();

        $guides = $this->readManifest();

        if ($guides === []) {
            throw new RuntimeException('Envie pelo menos um PDF com regras ou guias antes de perguntar.');
        }

        $contextChunks = $this->selectRelevantChunks($question, $guides);

        if ($contextChunks === []) {
            throw new RuntimeException('Nao encontrei trechos suficientes nos PDFs enviados para responder com seguranca.');
        }

        $answer = $this->requestOpenAi($question, $apiKey, $contextChunks, $history, $model);

        return [
            'answer' => $answer,
            'sources' => array_values(array_map(static function (array $chunk): array {
                return [
                    'name' => (string) ($chunk['name'] ?? 'Guia'),
                    'excerpt' => (string) ($chunk['excerpt'] ?? ''),
                ];
            }, $contextChunks)),
        ];
    }

    private function requestOpenAi(string $question, string $apiKey, array $contextChunks, array $history, string $model): string
    {
        if (!function_exists('curl_init')) {
            throw new RuntimeException('A extensao cURL do PHP precisa estar habilitada para chamar a OpenAI.');
        }

        $contextLines = [];

        foreach ($contextChunks as $index => $chunk) {
            $contextLines[] = sprintf(
                "[%d] %s\n%s",
                $index + 1,
                (string) ($chunk['name'] ?? 'Guia'),
                trim((string) ($chunk['excerpt'] ?? ''))
            );
        }

        $messages = [[
            'role' => 'system',
            'content' => 'Voce responde em pt-BR, de forma direta e sem rodeios. Use somente os trechos dos guias enviados. Se a resposta nao estiver clara nesses trechos, diga exatamente: "Nao encontrei isso nos guias enviados." Nunca invente regra, excecao, prazo ou criterio.',
        ]];

        foreach (array_slice($this->sanitizeHistory($history), -6) as $historyRow) {
            $messages[] = $historyRow;
        }

        $messages[] = [
            'role' => 'user',
            'content' => "Pergunta do usuario:\n{$question}\n\nTrechos dos guias:\n" . implode("\n\n", $contextLines),
        ];

        $payload = [
            'model' => trim($model) !== '' ? trim($model) : 'gpt-4.1-mini',
            'temperature' => 0.2,
            'messages' => $messages,
        ];

        $ch = curl_init('https://api.openai.com/v1/chat/completions');

        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => [
                'Authorization: Bearer ' . $apiKey,
                'Content-Type: application/json',
            ],
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            CURLOPT_TIMEOUT => 60,
        ]);

        $responseBody = curl_exec($ch);

        if ($responseBody === false) {
            $error = curl_error($ch);
            curl_close($ch);
            throw new RuntimeException('Falha ao conectar com a OpenAI: ' . ($error !== '' ? $error : 'erro desconhecido.'));
        }

        $statusCode = (int) curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
        curl_close($ch);

        $payload = json_decode($responseBody, true);

        if ($statusCode >= 400) {
            $message = trim((string) ($payload['error']['message'] ?? 'Nao foi possivel concluir a chamada para a OpenAI.'));
            throw new RuntimeException($message);
        }

        $content = $payload['choices'][0]['message']['content'] ?? '';

        if (is_array($content)) {
            $content = implode("\n", array_values(array_filter(array_map(static function ($item): string {
                return trim((string) ($item['text'] ?? $item['content'] ?? ''));
            }, $content))));
        }

        $content = trim((string) $content);

        if ($content === '') {
            throw new RuntimeException('A OpenAI nao retornou texto na resposta.');
        }

        return $content;
    }

    private function sanitizeHistory(array $history): array
    {
        $sanitized = [];

        foreach ($history as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            $role = trim((string) ($entry['role'] ?? ''));
            $content = trim((string) ($entry['content'] ?? ''));

            if (!in_array($role, ['user', 'assistant'], true) || $content === '') {
                continue;
            }

            $sanitized[] = [
                'role' => $role,
                'content' => $this->truncateSingleLine($content, 1200),
            ];
        }

        return $sanitized;
    }

    private function selectRelevantChunks(string $question, array $guides): array
    {
        $keywords = $this->extractKeywords($question);
        $candidates = [];

        foreach ($guides as $guide) {
            $textFile = trim((string) ($guide['text_file'] ?? ''));

            if ($textFile === '') {
                continue;
            }

            $textPath = $this->textDirectory() . DIRECTORY_SEPARATOR . $textFile;

            if (!is_file($textPath)) {
                continue;
            }

            $text = file_get_contents($textPath);

            if (!is_string($text) || trim($text) === '') {
                continue;
            }

            foreach ($this->chunkText($text, 1500, 260) as $chunkIndex => $chunk) {
                $score = $this->scoreChunk($chunk, $keywords, (string) ($guide['name'] ?? ''));

                if ($score <= 0) {
                    continue;
                }

                $candidates[] = [
                    'score' => $score,
                    'name' => (string) ($guide['name'] ?? 'Guia'),
                    'excerpt' => trim($chunk),
                    'index' => $chunkIndex,
                ];
            }
        }

        if ($candidates === []) {
            return [];
        }

        usort($candidates, static function (array $left, array $right): int {
            return ((float) ($right['score'] ?? 0.0) <=> (float) ($left['score'] ?? 0.0))
                ?: strcmp((string) ($left['name'] ?? ''), (string) ($right['name'] ?? ''))
                ?: ((int) ($left['index'] ?? 0) <=> (int) ($right['index'] ?? 0));
        });

        return array_slice($candidates, 0, 6);
    }

    private function extractKeywords(string $question): array
    {
        $normalized = preg_replace('/[^\p{L}\p{N}\s]+/u', ' ', $this->toLower($question));
        $tokens = preg_split('/\s+/', trim((string) $normalized)) ?: [];
        $stopWords = ['a', 'o', 'e', 'de', 'da', 'do', 'das', 'dos', 'para', 'por', 'com', 'sem', 'como', 'qual', 'quais', 'quando', 'onde', 'isso', 'essa', 'esse', 'uma', 'um', 'que', 'na', 'no', 'nas', 'nos'];

        $keywords = array_values(array_unique(array_filter($tokens, static function (string $token) use ($stopWords): bool {
            $tokenLength = function_exists('mb_strlen') ? (int) mb_strlen($token, 'UTF-8') : strlen($token);

            return $tokenLength >= 3 && !in_array($token, $stopWords, true);
        })));

        return $keywords !== [] ? $keywords : array_slice($tokens, 0, 5);
    }

    private function chunkText(string $text, int $maxLength, int $overlap): array
    {
        $text = trim(preg_replace('/\s+/u', ' ', $text) ?? $text);

        if ($text === '') {
            return [];
        }

        $chunks = [];
        $length = $this->stringLength($text);
        $cursor = 0;

        while ($cursor < $length) {
            $chunk = $this->stringSlice($text, $cursor, $maxLength);

            if ($chunk === '') {
                break;
            }

            $chunks[] = trim($chunk);
            $cursor += max(1, $maxLength - $overlap);
        }

        return $chunks;
    }

    private function scoreChunk(string $chunk, array $keywords, string $guideName): float
    {
        $normalizedChunk = $this->toLower($chunk);
        $normalizedGuide = $this->toLower($guideName);
        $score = 0.0;

        foreach ($keywords as $keyword) {
            $occurrences = substr_count($normalizedChunk, $keyword);

            if ($occurrences > 0) {
                $score += min(5, $occurrences) * 3;
            }

            if ($keyword !== '' && strpos($normalizedGuide, $keyword) !== false) {
                $score += 2;
            }
        }

        if ($score === 0.0 && $chunk !== '') {
            $score = 0.5;
        }

        return $score;
    }

    private function normalizeUploadedFiles(array $files): array
    {
        if (($files['name'] ?? null) === null) {
            return [];
        }

        if (!is_array($files['name'])) {
            return [$files];
        }

        $normalized = [];

        foreach ($files['name'] as $index => $name) {
            $error = (int) ($files['error'][$index] ?? UPLOAD_ERR_NO_FILE);

            if ($error === UPLOAD_ERR_NO_FILE) {
                continue;
            }

            if ($error !== UPLOAD_ERR_OK) {
                throw new RuntimeException('Falha no upload do PDF enviado.');
            }

            $normalized[] = [
                'name' => $name,
                'type' => $files['type'][$index] ?? '',
                'tmp_name' => $files['tmp_name'][$index] ?? '',
                'error' => $error,
                'size' => $files['size'][$index] ?? 0,
            ];
        }

        return $normalized;
    }

    private function sanitizeFileName(string $name): string
    {
        $baseName = preg_replace('/[^A-Za-z0-9._-]+/', '-', trim($name)) ?? 'guia.pdf';
        $baseName = trim($baseName, '-.');

        return $baseName !== '' ? $baseName : 'guia.pdf';
    }

    private function truncateSingleLine(string $value, int $limit): string
    {
        $value = trim(preg_replace('/\s+/u', ' ', $value) ?? $value);

        if ($this->stringLength($value) <= $limit) {
            return $value;
        }

        return rtrim($this->stringSlice($value, 0, max(0, $limit - 1))) . '…';
    }

    private function stringLength(string $value): int
    {
        return function_exists('mb_strlen') ? (int) mb_strlen($value, 'UTF-8') : strlen($value);
    }

    private function stringSlice(string $value, int $start, int $length): string
    {
        if (function_exists('mb_substr')) {
            return (string) mb_substr($value, $start, $length, 'UTF-8');
        }

        return substr($value, $start, $length);
    }

    private function toLower(string $value): string
    {
        return function_exists('mb_strtolower') ? (string) mb_strtolower($value, 'UTF-8') : strtolower($value);
    }

    private function loadConfig(): array
    {
        $configPath = project_path('config/assistant.php');

        if (!is_file($configPath)) {
            return [];
        }

        $config = require $configPath;

        return is_array($config) ? $config : [];
    }

    private function configuredApiKey(): string
    {
        $apiKey = trim((string) ($this->config['openai_api_key'] ?? ''));

        if ($apiKey === '') {
            throw new RuntimeException('Configure a chave da OpenAI em config/assistant.php para usar o chat.');
        }

        return $apiKey;
    }

    private function configuredModel(): string
    {
        $model = trim((string) ($this->config['openai_model'] ?? 'gpt-4.1-mini'));

        return $model !== '' ? $model : 'gpt-4.1-mini';
    }

    private function manifestPath(): string
    {
        return $this->storageRoot . DIRECTORY_SEPARATOR . 'guides.json';
    }

    private function guideDirectory(): string
    {
        return $this->storageRoot . DIRECTORY_SEPARATOR . 'guides';
    }

    private function textDirectory(): string
    {
        return $this->storageRoot . DIRECTORY_SEPARATOR . 'texts';
    }

    private function readManifest(): array
    {
        $manifestPath = $this->manifestPath();

        if (!is_file($manifestPath)) {
            return [];
        }

        $contents = file_get_contents($manifestPath);

        if (!is_string($contents) || trim($contents) === '') {
            return [];
        }

        $decoded = json_decode($contents, true);

        return is_array($decoded) ? $decoded : [];
    }

    private function writeManifest(array $manifest): void
    {
        file_put_contents(
            $this->manifestPath(),
            json_encode(array_values($manifest), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)
        );
    }
}