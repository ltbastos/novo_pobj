<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

use App\Database;
use App\Services\EncantabraDashboardService;
use App\Services\PobjDashboardService;
use App\Services\PrimeAssistantService;
use App\Services\PrimeBrandService;
use App\Services\ProfileSimulationService;

$connection = Database::connection();
$profileService = new ProfileSimulationService($connection);
$dashboardService = new PobjDashboardService($connection);
$brandService = new PrimeBrandService($connection);
$assistantService = new PrimeAssistantService();
$encantabraService = new EncantabraDashboardService($connection);

$requestMethod = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$profileRedirectKeys = [
    'periodo',
    'tab',
    'advanced_filters',
    'indicator_focus',
    'grupo',
    'period_mode',
    'period_start',
    'period_end',
    'segmento',
    'diretoria',
    'regional',
    'agencia',
    'gerente_gestao',
    'gerente',
    'familia',
    'indicadores',
    'subindicador',
    'status_indicadores',
    'visao_acumulada',
    'enc_tab',
    'enc_anomes',
    'enc_perfil',
    'enc_segmento',
    'enc_juncao',
    'enc_funcional',
    'enc_indicador',
    'enc_page',
];

if ($requestMethod === 'POST' && ($_POST['action'] ?? '') === 'select_profile') {
    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        http_response_code(419);
        exit('Falha de validacao do formulario de perfil.');
    }

    $selectedFunctional = trim((string) ($_POST['selected_functional'] ?? ''));

    if ($selectedFunctional !== '' && $profileService->profileExists($selectedFunctional)) {
        $_SESSION['selected_profile_functional'] = $selectedFunctional;
    }

    $redirectQuery = ['page' => 'pobj-dashboard'];
    $requestedRedirectQuery = $_POST['redirect_query'] ?? null;

    if (is_array($requestedRedirectQuery)) {
        foreach ($requestedRedirectQuery as $queryKey => $queryValue) {
            if (!is_string($queryKey) || !in_array($queryKey, $profileRedirectKeys, true) || is_array($queryValue)) {
                continue;
            }

            $queryValue = trim((string) $queryValue);

            if ($queryValue === '') {
                continue;
            }

            $redirectQuery[$queryKey] = $queryValue;
        }
    }

    if (!isset($redirectQuery['periodo'])) {
        $redirectPeriod = trim((string) ($_POST['periodo'] ?? $_GET['periodo'] ?? ''));

        if ($redirectPeriod !== '') {
            $redirectQuery['periodo'] = $redirectPeriod;
        }
    }

    if (!isset($redirectQuery['tab'])) {
        $redirectQuery['tab'] = 'resumo';
    }

    header('Location: ' . app_url($redirectQuery));
    exit;
}

$profiles = $profileService->listProfiles();
$selectedProfileFunctional = $_SESSION['selected_profile_functional'] ?? ($profiles[0]['funcional'] ?? null);

if ($selectedProfileFunctional !== null) {
    $_SESSION['selected_profile_functional'] = $selectedProfileFunctional;
}

$context = $selectedProfileFunctional !== null ? $profileService->getContext($selectedProfileFunctional) : null;
$periods = $dashboardService->listPeriods();
$requestedPeriodStart = trim((string) ($_GET['period_start'] ?? ''));
$requestedPeriodEnd = trim((string) ($_GET['period_end'] ?? ''));
$requestedPeriodMode = trim((string) ($_GET['period_mode'] ?? ''));
$hasManualDateRange = $requestedPeriodMode === 'manual' && ($requestedPeriodStart !== '' || $requestedPeriodEnd !== '');
$hasLegacyAutoDateRange = !$hasManualDateRange && ($requestedPeriodStart !== '' || $requestedPeriodEnd !== '');
$requestedAccumulatedView = trim((string) ($_GET['visao_acumulada'] ?? 'MENSAL'));
$displayPeriodStart = $requestedPeriodStart;
$displayPeriodEnd = $requestedPeriodEnd;

if (!$hasManualDateRange) {
    $accumulatedRange = resolve_accumulated_view_date_range($requestedAccumulatedView);
    $displayPeriodStart = $accumulatedRange['start'];
    $displayPeriodEnd = $accumulatedRange['end'];
}

$selectedPeriodId = isset($_GET['periodo']) && is_string($_GET['periodo']) && $_GET['periodo'] !== ''
    ? $_GET['periodo']
    : ($periods[0]['id_periodo'] ?? null);

if ($hasManualDateRange) {
    $selectedPeriodId = resolve_period_id_by_date_range($periods, $requestedPeriodStart, $requestedPeriodEnd, $selectedPeriodId);
}

$availablePeriodIds = array_values(array_filter(array_map(static function (array $periodRow): string {
    return trim((string) ($periodRow['id_periodo'] ?? ''));
}, $periods)));

if ($selectedPeriodId !== null && !in_array($selectedPeriodId, $availablePeriodIds, true)) {
    $selectedPeriodId = $periods[0]['id_periodo'] ?? null;
}

if ($hasLegacyAutoDateRange && $context !== null && $selectedPeriodId !== null && !$dashboardService->periodHasVisibleData($context, $selectedPeriodId)) {
    foreach ($periods as $periodRow) {
        $candidatePeriodId = trim((string) ($periodRow['id_periodo'] ?? ''));

        if ($candidatePeriodId === '' || !$dashboardService->periodHasVisibleData($context, $candidatePeriodId)) {
            continue;
        }

        $selectedPeriodId = $candidatePeriodId;
        break;
    }
}

if ($requestMethod === 'GET' && $hasLegacyAutoDateRange) {
    $canonicalQuery = ['page' => trim((string) ($_GET['page'] ?? 'pobj-dashboard'))];

    foreach ($_GET as $queryKey => $queryValue) {
        if (!is_string($queryKey) || in_array($queryKey, ['period_mode', 'period_start', 'period_end'], true) || is_array($queryValue)) {
            continue;
        }

        $trimmedValue = trim((string) $queryValue);

        if ($trimmedValue === '') {
            continue;
        }

        $canonicalQuery[$queryKey] = $trimmedValue;
    }

    if ($selectedPeriodId !== null) {
        $canonicalQuery['periodo'] = $selectedPeriodId;
    }

    header('Location: ' . app_url($canonicalQuery));
    exit;
}

$requestedAdvancedFiltersState = trim((string) ($_GET['advanced_filters'] ?? 'open'));
$advancedFiltersState = in_array($requestedAdvancedFiltersState, ['open', 'closed'], true)
    ? $requestedAdvancedFiltersState
    : 'open';
$requestedIndicatorFocus = trim((string) ($_GET['indicator_focus'] ?? ''));
$requestedRankingGroup = trim((string) ($_GET['grupo'] ?? ''));

$requestedSummaryFilters = [
    'segmento' => trim((string) ($_GET['segmento'] ?? '')),
    'diretoria' => trim((string) ($_GET['diretoria'] ?? '')),
    'regional' => trim((string) ($_GET['regional'] ?? '')),
    'agencia' => trim((string) ($_GET['agencia'] ?? '')),
    'gerente_gestao' => trim((string) ($_GET['gerente_gestao'] ?? '')),
    'gerente' => trim((string) ($_GET['gerente'] ?? '')),
    'familia' => trim((string) ($_GET['familia'] ?? '')),
    'indicadores' => trim((string) ($_GET['indicadores'] ?? '')),
    'subindicador' => trim((string) ($_GET['subindicador'] ?? '')),
    'status_indicadores' => trim((string) ($_GET['status_indicadores'] ?? '')),
    'visao_acumulada' => trim((string) ($_GET['visao_acumulada'] ?? 'MENSAL')),
];

$summaryFilters = $context !== null && $selectedPeriodId !== null
    ? $dashboardService->prepareSummaryFilters($context, $selectedPeriodId, $requestedSummaryFilters)
    : [
        'options' => [
            'segmento' => [],
            'diretoria' => [],
            'regional' => [],
            'agencia' => [],
            'gerente_gestao' => [],
            'gerente' => [],
            'familia' => [],
            'indicadores' => [],
            'subindicador' => [],
            'status_indicadores' => [],
            'visao_acumulada' => [
                ['value' => 'MENSAL', 'label' => 'Mensal'],
                ['value' => 'SEMESTRAL', 'label' => 'Semestral'],
                ['value' => 'ANUAL', 'label' => 'Anual'],
            ],
        ],
        'values' => $requestedSummaryFilters,
    ];

$summaryFilterOptions = $summaryFilters['options'];
$summaryFilterValues = $summaryFilters['values'];
$visualTheme = $brandService->resolveVisualTheme($context, $summaryFilterValues);
$assistantGuides = $assistantService->listGuides();

$allowedTabs = ['resumo', 'detalhamento', 'rankings', 'visao-executiva', 'encantabra', 'simuladores', 'campanhas'];
$requestedTab = trim((string) ($_GET['tab'] ?? 'resumo'));
$activeTab = in_array($requestedTab, $allowedTabs, true) ? $requestedTab : 'resumo';

$allowedEncantabraSections = ['resultado', 'regulamento', 'apoio'];
$requestedEncantabraSection = trim((string) ($_GET['enc_tab'] ?? 'resultado'));
$encantabraActiveSection = in_array($requestedEncantabraSection, $allowedEncantabraSections, true)
    ? $requestedEncantabraSection
    : 'resultado';
$requestedEncantabraPage = max(1, (int) ($_GET['enc_page'] ?? 1));
$requestedEncantabraFilters = [
    'anomes' => trim((string) ($_GET['enc_anomes'] ?? '')),
    'perfil' => trim((string) ($_GET['enc_perfil'] ?? 'SG')),
    'segmento' => trim((string) ($_GET['enc_segmento'] ?? '')),
    'juncao' => trim((string) ($_GET['enc_juncao'] ?? '')),
    'funcional' => trim((string) ($_GET['enc_funcional'] ?? '')),
    'indicador' => trim((string) ($_GET['enc_indicador'] ?? '')),
];
$encantabraFilters = $encantabraService->prepareFilters($requestedEncantabraFilters);
$encantabraFilterOptions = $encantabraFilters['options'];
$encantabraFilterValues = $encantabraFilters['values'];
$encantabraQueryState = ['enc_tab' => $encantabraActiveSection];

foreach ($encantabraFilterValues as $filterKey => $filterValue) {
    if (!is_string($filterValue) || $filterValue === '') {
        continue;
    }

    $encantabraQueryState['enc_' . $filterKey] = $filterValue;
}

if ($requestedEncantabraPage > 1) {
    $encantabraQueryState['enc_page'] = (string) $requestedEncantabraPage;
}

$dashboardData = $context !== null && $selectedPeriodId !== null
    ? $dashboardService->getDashboardData($context, $selectedPeriodId, $summaryFilterValues, $displayPeriodStart, $displayPeriodEnd)
    : ['summary' => [], 'indicators' => []];

$indicatorFocusId = '';

foreach (($dashboardData['indicators'] ?? []) as $indicatorRow) {
    if ((string) ($indicatorRow['id_indicador'] ?? '') !== $requestedIndicatorFocus) {
        continue;
    }

    $indicatorFocusId = $requestedIndicatorFocus;
    break;
}

$detailData = $context !== null && $selectedPeriodId !== null && $activeTab === 'detalhamento'
    ? $dashboardService->getDetailData($context, $selectedPeriodId, $summaryFilterValues, $displayPeriodStart, $displayPeriodEnd)
    : ['summary' => [], 'rows' => []];

$indicatorDetailData = $context !== null && $selectedPeriodId !== null && $indicatorFocusId !== ''
    ? $dashboardService->getIndicatorDetailData($context, $selectedPeriodId, $summaryFilterValues, $indicatorFocusId, $displayPeriodStart, $displayPeriodEnd)
    : [
        'indicator' => [],
        'summary' => [],
        'trend' => [],
        'distributions' => ['channels' => [], 'statuses' => []],
        'insights' => ['mode' => 'hierarchy', 'label' => '', 'title' => '', 'top' => [], 'bottom' => []],
        'transactions' => [],
    ];

$rankingGroupOptions = $context !== null && $selectedPeriodId !== null && $activeTab === 'rankings'
    ? $dashboardService->listRankingGroupOptions($context, $selectedPeriodId, $summaryFilterValues, $displayPeriodStart, $displayPeriodEnd)
    : [];

$requestedRankingGroup = $dashboardService->sanitizeFilterSelection($requestedRankingGroup, $rankingGroupOptions);
$rankingFilters = array_merge($summaryFilterValues, ['grupo' => $requestedRankingGroup]);

$rankingData = $context !== null && $selectedPeriodId !== null && $activeTab === 'rankings'
    ? $dashboardService->getRankingData($context, $selectedPeriodId, $rankingFilters, $displayPeriodStart, $displayPeriodEnd)
    : ['level' => 'gerente_gestao', 'level_label' => 'Gerente de gestão', 'rows' => []];

$executiveData = $context !== null && $selectedPeriodId !== null && $activeTab === 'visao-executiva'
    ? $dashboardService->getExecutiveViewData($context, $selectedPeriodId, $summaryFilterValues, $displayPeriodStart, $displayPeriodEnd)
    : [
        'focus' => ['level' => 'regional', 'label' => 'Regional', 'ranking_title' => 'Desempenho por Regional', 'status_title' => 'Status por Regional'],
        'reference' => ['period_label' => '', 'range_label' => '', 'month_label' => '', 'window_label' => 'Últimos 6 meses'],
        'kpis' => [],
        'chart' => ['labels' => [], 'series' => [], 'max_value' => 100.0],
        'ranking' => ['top' => [], 'bottom' => []],
        'status' => ['hit' => [], 'quase' => [], 'longe' => [], 'summary' => ['hit' => 0, 'quase' => 0, 'longe' => 0]],
        'heatmap' => [
            'default_mode' => 'secoes',
            'secoes' => ['title' => '', 'row_axis_label' => 'GR', 'row_axis_sublabel' => 'Famílias', 'rows' => [], 'columns' => [], 'data' => []],
            'meta' => ['title' => '', 'row_axis_label' => 'Hierarquia', 'row_axis_sublabel' => 'Mês', 'rows' => [], 'months' => [], 'data' => []],
        ],
    ];

$encantabraData = $activeTab === 'encantabra'
    ? $encantabraService->getDashboardData($encantabraFilterValues, $requestedEncantabraPage)
    : [
        'reference' => ['month_label' => '', 'scope_label' => '', 'profile_label' => '', 'segment_label' => ''],
        'summary' => ['score_avg' => 0.0, 'meta_avg' => 0.0, 'real_avg' => 0.0, 'rows_total' => 0, 'entities_total' => 0, 'indicators_total' => 0, 'best_indicator' => null, 'worst_indicator' => null, 'band' => ['label' => 'Sem dados', 'range' => 'Sem leitura', 'tone' => 'is-empty']],
        'status' => ['fan' => 0, 'encantador' => 0, 'expectativa' => 0, 'critico' => 0],
        'chart' => ['labels' => [], 'series' => [], 'max_value' => 150.0],
        'trimester_tables' => ['year' => '', 'tables' => []],
        'ranking' => ['title' => '', 'top' => [], 'bottom' => []],
        'heatmap' => ['title' => '', 'rows' => [], 'months' => [], 'data' => []],
        'table' => ['title' => '', 'subtitle' => '', 'columns' => [], 'rows' => [], 'total_rows' => 0, 'current_page' => 1, 'per_page' => 20, 'total_pages' => 1],
    ];

$annualPerformanceData = $context !== null
    && ($summaryFilterValues['visao_acumulada'] ?? 'MENSAL') === 'ANUAL'
    && $activeTab === 'resumo'
    ? $dashboardService->getAnnualPerformanceData($context, $summaryFilterValues, $displayPeriodEnd)
    : ['year' => (int) date('Y'), 'rows' => [], 'summary' => ['atingiu' => 0, 'quase' => 0, 'distante' => 0]];

$selectedPeriod = null;

foreach ($periods as $periodRow) {
    if (($periodRow['id_periodo'] ?? null) === $selectedPeriodId) {
        $selectedPeriod = $periodRow;
        break;
    }
}

$legacyBusinessSnapshot = resolve_business_day_snapshot(
    $displayPeriodStart !== '' ? $displayPeriodStart : ($selectedPeriod['dt_inicio_periodo'] ?? null),
    $displayPeriodEnd !== '' ? $displayPeriodEnd : ($selectedPeriod['dt_fim_periodo'] ?? null)
);

$pageTitle = $activeTab === 'encantabra'
    ? 'Encantabra'
    : 'POBJ';

require __DIR__ . '/templates/layout.php';