const pageBody = document.body;
const loadingOverlay = document.querySelector('[data-loading-overlay]');
const loadingText = loadingOverlay ? loadingOverlay.querySelector('[data-loading-text]') : null;
const themeStorageKey = 'novo-pobj:visual-theme';

const hideLoadingOverlay = () => {
    if (!pageBody) {
        return;
    }

    pageBody.classList.remove('is-booting', 'is-loading');

    if (loadingOverlay) {
        loadingOverlay.setAttribute('aria-hidden', 'true');
    }
};

const showLoadingOverlay = (message = 'Carregando dados do POBJ...') => {
    if (!pageBody) {
        return;
    }

    pageBody.classList.remove('is-booting');
    pageBody.classList.add('is-loading');

    if (loadingText) {
        loadingText.textContent = message;
    }

    if (loadingOverlay) {
        loadingOverlay.setAttribute('aria-hidden', 'false');
    }
};

const readThemeStorage = (key, fallback = '') => {
    try {
        return window.localStorage.getItem(key) || fallback;
    } catch (error) {
        return fallback;
    }
};

const writeThemeStorage = (key, value) => {
    try {
        window.localStorage.setItem(key, value);
    } catch (error) {
        // Ignore storage failures and keep the UI working.
    }
};

const currentThemeCode = pageBody instanceof HTMLElement ? (pageBody.dataset.visualTheme || 'classic') : 'classic';
const previousThemeCode = readThemeStorage(themeStorageKey, '');

if (pageBody instanceof HTMLElement && previousThemeCode !== '' && previousThemeCode !== currentThemeCode) {
    pageBody.classList.add('is-theme-transitioning');
    window.setTimeout(() => {
        pageBody.classList.remove('is-theme-transitioning');
    }, 620);
}

writeThemeStorage(themeStorageKey, currentThemeCode);

const indicatorDetailModal = document.querySelector('[data-indicator-detail-modal]');

if (indicatorDetailModal instanceof HTMLElement) {
    const closeUrl = indicatorDetailModal.dataset.closeUrl || '';

    document.addEventListener('keydown', (event) => {
        if (event.key !== 'Escape' || closeUrl === '') {
            return;
        }

        const assistantRootNode = document.querySelector('[data-assistant-root]');

        if (assistantRootNode instanceof HTMLElement && assistantRootNode.classList.contains('is-open')) {
            return;
        }

        window.location.href = closeUrl;
    });
}

const transactionToggle = document.querySelector('[data-indicator-transaction-toggle]');

if (transactionToggle) {
    const hiddenRows = Array.from(document.querySelectorAll('[data-indicator-transaction-row]'));
    let expanded = false;

    const syncTransactionToggle = () => {
        hiddenRows.forEach((row) => {
            row.hidden = !expanded;
        });

        transactionToggle.textContent = expanded
            ? (transactionToggle.dataset.collapseLabel || 'Recolher base')
            : (transactionToggle.dataset.expandLabel || 'Ver base completa');
        transactionToggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
    };

    transactionToggle.addEventListener('click', () => {
        expanded = !expanded;
        syncTransactionToggle();
    });

    syncTransactionToggle();
}

const assistantRoot = document.querySelector('[data-assistant-root]');

if (assistantRoot) {
    const assistantToggle = assistantRoot.querySelector('[data-assistant-toggle]');
    const assistantClose = assistantRoot.querySelector('[data-assistant-close]');
    const assistantConfigToggle = assistantRoot.querySelector('[data-assistant-config-toggle]');
    const assistantConfigPanel = assistantRoot.querySelector('[data-assistant-config-panel]');
    const assistantGuideList = assistantRoot.querySelector('[data-assistant-guide-list]');
    const assistantUploadForm = assistantRoot.querySelector('[data-assistant-upload-form]');
    const assistantGuidesInput = assistantRoot.querySelector('[data-assistant-guides-input]');
    const assistantMessages = assistantRoot.querySelector('[data-assistant-messages]');
    const assistantChatForm = assistantRoot.querySelector('[data-assistant-chat-form]');
    const assistantInput = assistantRoot.querySelector('[data-assistant-input]');
    const assistantStatus = assistantRoot.querySelector('[data-assistant-status]');
    const assistantEndpoint = assistantRoot.dataset.chatEndpoint || 'chat.php';
    const assistantCsrf = assistantRoot.dataset.chatCsrf || '';

    let guides = [];
    let history = [];

    try {
        guides = JSON.parse(assistantRoot.dataset.initialGuides || '[]');
    } catch (error) {
        guides = [];
    }

    const setAssistantStatus = (message, tone = 'default') => {
        if (!(assistantStatus instanceof HTMLElement)) {
            return;
        }

        assistantStatus.textContent = message;
        assistantStatus.classList.toggle('is-error', tone === 'error');
        assistantStatus.classList.toggle('is-success', tone === 'success');
    };

    const setConfigOpen = (open) => {
        if (!(assistantConfigToggle instanceof HTMLButtonElement) || !(assistantConfigPanel instanceof HTMLElement)) {
            return;
        }

        assistantConfigToggle.classList.toggle('is-open', open);
        assistantConfigToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        assistantConfigPanel.classList.toggle('is-open', open);
    };

    const setAssistantOpen = (open) => {
        assistantRoot.classList.toggle('is-open', open);

        if (assistantToggle instanceof HTMLButtonElement) {
            assistantToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        }

        if (open) {
            if (assistantInput instanceof HTMLTextAreaElement) {
                window.requestAnimationFrame(() => assistantInput.focus());
            }
        }
    };

    const renderGuides = () => {
        if (!(assistantGuideList instanceof HTMLElement)) {
            return;
        }

        assistantGuideList.innerHTML = '';

        if (!Array.isArray(guides) || guides.length === 0) {
            const emptyState = document.createElement('div');
            emptyState.className = 'assistant-widget__guide-empty';
            emptyState.textContent = 'Nenhum PDF carregado ainda.';
            assistantGuideList.appendChild(emptyState);
            return;
        }

        guides.forEach((guide) => {
            const item = document.createElement('article');
            item.className = 'assistant-widget__guide-item';

            const title = document.createElement('strong');
            title.textContent = guide.name || 'Guia';

            const meta = document.createElement('span');
            meta.textContent = `${new Intl.NumberFormat('pt-BR').format(Number(guide.chars || 0))} caracteres úteis`;

            item.append(title, meta);
            assistantGuideList.appendChild(item);
        });
    };

    const buildMessageElement = (role, content, sources = [], typing = false) => {
        const article = document.createElement('article');
        article.className = `assistant-widget__message assistant-widget__message--${role === 'user' ? 'user' : 'assistant'}`;

        const paragraph = document.createElement('p');

        if (typing) {
            article.classList.add('assistant-widget__message--typing');
            paragraph.innerHTML = '<span class="assistant-widget__typing" aria-label="Digitando"><span class="assistant-widget__typing-dot"></span><span class="assistant-widget__typing-dot"></span><span class="assistant-widget__typing-dot"></span></span>';
        } else {
            paragraph.textContent = content;
        }

        article.appendChild(paragraph);

        if (!typing && Array.isArray(sources) && sources.length > 0) {
            const sourceList = document.createElement('div');
            sourceList.className = 'assistant-widget__message-sources';

            sources.forEach((source) => {
                const chip = document.createElement('span');
                chip.textContent = source.name || 'Guia';

                if (source.excerpt) {
                    chip.title = source.excerpt;
                }

                sourceList.appendChild(chip);
            });

            article.appendChild(sourceList);
        }

        return article;
    };

    const appendMessage = (role, content, sources = [], pushToHistory = true) => {
        if (!(assistantMessages instanceof HTMLElement)) {
            return null;
        }

        const article = buildMessageElement(role, content, sources, false);

        assistantMessages.appendChild(article);
        assistantMessages.scrollTop = assistantMessages.scrollHeight;

        if (pushToHistory) {
            history.push({ role, content });
            history = history.slice(-12);
        }

        return article;
    };

    const appendTypingMessage = () => {
        if (!(assistantMessages instanceof HTMLElement)) {
            return null;
        }

        const article = buildMessageElement('assistant', '', [], true);
        assistantMessages.appendChild(article);
        assistantMessages.scrollTop = assistantMessages.scrollHeight;

        return article;
    };

    const replaceMessage = (target, role, content, sources = []) => {
        const nextMessage = buildMessageElement(role, content, sources, false);

        if (target instanceof HTMLElement && target.parentNode) {
            target.parentNode.replaceChild(nextMessage, target);
        } else if (assistantMessages instanceof HTMLElement) {
            assistantMessages.appendChild(nextMessage);
        }

        if (assistantMessages instanceof HTMLElement) {
            assistantMessages.scrollTop = assistantMessages.scrollHeight;
        }

        history.push({ role, content });
        history = history.slice(-12);
    };

    const toggleAssistantBusy = (busy, label) => {
        const sendButton = assistantChatForm ? assistantChatForm.querySelector('[data-assistant-send]') : null;
        const uploadButton = assistantUploadForm ? assistantUploadForm.querySelector('[data-assistant-upload-button]') : null;

        if (sendButton instanceof HTMLButtonElement) {
            sendButton.disabled = busy;
        }

        if (uploadButton instanceof HTMLButtonElement) {
            uploadButton.disabled = busy;
        }

        if (busy && label) {
            setAssistantStatus(label);
        }
    };

    const fetchAssistantPayload = async (payload, useFormData = false) => {
        const response = await window.fetch(assistantEndpoint, {
            method: 'POST',
            headers: useFormData ? undefined : {
                'Content-Type': 'application/json',
            },
            body: useFormData ? payload : JSON.stringify(payload),
        });
        const data = await response.json();

        if (!response.ok || !data.ok) {
            throw new Error(data.message || 'Falha ao conversar com a IA.');
        }

        return data;
    };

    renderGuides();
    setAssistantStatus(guides.length > 0
        ? 'Base pronta. Envie a pergunta quando quiser.'
        : 'Base vazia. Use Base de PDFs para carregar os arquivos de referência.');

    if (assistantToggle instanceof HTMLButtonElement) {
        assistantToggle.addEventListener('click', () => {
            setAssistantOpen(!assistantRoot.classList.contains('is-open'));
        });
    }

    if (assistantClose instanceof HTMLButtonElement) {
        assistantClose.addEventListener('click', () => {
            setAssistantOpen(false);
        });
    }

    if (assistantConfigToggle instanceof HTMLButtonElement) {
        assistantConfigToggle.addEventListener('click', () => {
            setConfigOpen(!assistantConfigToggle.classList.contains('is-open'));
        });
    }

    if (assistantUploadForm instanceof HTMLFormElement) {
        assistantUploadForm.addEventListener('submit', async (event) => {
            event.preventDefault();

            if (!(assistantGuidesInput instanceof HTMLInputElement) || !assistantGuidesInput.files || assistantGuidesInput.files.length === 0) {
                setAssistantStatus('Selecione ao menos um PDF antes de atualizar a base.', 'error');
                return;
            }

            toggleAssistantBusy(true, 'Lendo os PDFs e montando a base da IA...');

            try {
                const formData = new FormData(assistantUploadForm);
                formData.set('csrf_token', assistantCsrf);
                const data = await fetchAssistantPayload(formData, true);
                guides = Array.isArray(data.guides) ? data.guides : [];
                renderGuides();
                setAssistantStatus(data.message || 'Base atualizada com sucesso.', 'success');
                assistantGuidesInput.value = '';
            } catch (error) {
                setAssistantStatus(error instanceof Error ? error.message : 'Falha ao atualizar a base da IA.', 'error');
            } finally {
                toggleAssistantBusy(false);
            }
        });
    }

    if (assistantChatForm instanceof HTMLFormElement && assistantInput instanceof HTMLTextAreaElement) {
        assistantChatForm.addEventListener('submit', async (event) => {
            event.preventDefault();

            const question = assistantInput.value.trim();

            if (question === '') {
                assistantInput.focus();
                return;
            }

            if (!Array.isArray(guides) || guides.length === 0) {
                setConfigOpen(true);
                setAssistantStatus('Envie pelo menos um PDF antes de perguntar.', 'error');
                return;
            }

            appendMessage('user', question);
            assistantInput.value = '';
            toggleAssistantBusy(true, 'Consultando os guias e preparando a resposta...');
            const typingMessage = appendTypingMessage();

            try {
                const data = await fetchAssistantPayload({
                    action: 'ask',
                    csrf_token: assistantCsrf,
                    question,
                    history,
                });

                replaceMessage(typingMessage, 'assistant', data.answer || 'Nao recebi texto da IA.', Array.isArray(data.sources) ? data.sources : []);
                guides = Array.isArray(data.guides) ? data.guides : guides;
                renderGuides();
                setAssistantStatus('Resposta pronta.', 'success');
            } catch (error) {
                const message = error instanceof Error ? error.message : 'Falha ao conversar com a IA.';
                replaceMessage(typingMessage, 'assistant', message);
                setAssistantStatus(message, 'error');
            } finally {
                toggleAssistantBusy(false);
                assistantInput.focus();
            }
        });
    }

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && assistantRoot.classList.contains('is-open')) {
            setAssistantOpen(false);
        }
    });
}

window.NovoPobjLoading = {
    show: showLoadingOverlay,
    hide: hideLoadingOverlay,
};

window.addEventListener('load', hideLoadingOverlay);
window.addEventListener('pageshow', hideLoadingOverlay);
window.setTimeout(hideLoadingOverlay, 1800);

document.addEventListener('submit', (event) => {
    if (event.target instanceof HTMLFormElement) {
        showLoadingOverlay('Atualizando painel...');
    }
}, true);

document.addEventListener('click', (event) => {
    const link = event.target.closest('a[href]');

    if (!link) {
        return;
    }

    if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) {
        return;
    }

    if (link.target === '_blank' || link.hasAttribute('download') || link.hasAttribute('data-no-loading')) {
        return;
    }

    const href = (link.getAttribute('href') || '').trim();

    if (href === '' || href.startsWith('#') || href.startsWith('javascript:') || href.startsWith('mailto:')) {
        return;
    }

    try {
        const targetUrl = new URL(link.href, window.location.href);

        if (targetUrl.origin !== window.location.origin) {
            return;
        }

        showLoadingOverlay('Abrindo tela...');
    } catch (error) {
        console.warn('Nao foi possivel interpretar o link clicado.', error);
    }
}, true);

const submitManagedForm = (form, message = 'Atualizando painel...') => {
    if (!(form instanceof HTMLFormElement)) {
        return;
    }

    showLoadingOverlay(message);

    if (typeof form.requestSubmit === 'function') {
        form.requestSubmit();
        return;
    }

    form.submit();
};

document.querySelectorAll('[data-autosubmit]').forEach((element) => {
    element.addEventListener('change', () => {
        submitManagedForm(element.form, 'Aplicando filtros...');
    });
});

document.querySelectorAll('[data-filter-cascade]').forEach((element) => {
    element.addEventListener('change', () => {
        submitManagedForm(element.form, 'Atualizando filtros em cascata...');
    });
});

if (window.lucide && typeof window.lucide.createIcons === 'function') {
    window.lucide.createIcons();
}

const simplifyFilterText = (value) => (value || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .trim();

const initEnhancedFilterSelects = () => {
    const enhancedSelects = document.querySelectorAll('[data-enhanced-select]');

    if (enhancedSelects.length === 0) {
        return;
    }

    const closeOtherEnhancedSelects = (currentSelectRoot = null) => {
        document.querySelectorAll('.filter-select.is-open').forEach((selectRoot) => {
            if (selectRoot === currentSelectRoot) {
                return;
            }

            selectRoot.classList.remove('is-open');

            const panel = selectRoot.querySelector('.filter-select__panel');
            if (panel) {
                panel.hidden = true;
            }
        });
    };

    enhancedSelects.forEach((nativeSelect) => {
        if (!(nativeSelect instanceof HTMLSelectElement) || nativeSelect.dataset.enhancedReady === 'true') {
            return;
        }

        const mode = nativeSelect.dataset.enhancedSelect || 'search';
        const label = nativeSelect.dataset.enhancedLabel || nativeSelect.name || 'opção';
        const placeholder = nativeSelect.dataset.enhancedPlaceholder || nativeSelect.options[0]?.textContent?.trim() || 'Selecione...';
        const wrapper = document.createElement('div');
        wrapper.className = 'filter-select';
        wrapper.dataset.mode = mode;

        const trigger = document.createElement('button');
        trigger.type = 'button';
        trigger.className = 'filter-select__trigger';
        trigger.setAttribute('aria-haspopup', 'listbox');
        trigger.setAttribute('aria-expanded', 'false');
        trigger.setAttribute('aria-label', label);

        const triggerText = document.createElement('span');
        triggerText.className = 'filter-select__trigger-text';

        const triggerIcon = document.createElement('span');
        triggerIcon.className = 'filter-select__icon';
        triggerIcon.setAttribute('aria-hidden', 'true');

        trigger.append(triggerText, triggerIcon);

        const panel = document.createElement('div');
        panel.className = 'filter-select__panel';
        panel.hidden = true;
        panel.setAttribute('role', 'listbox');
        panel.setAttribute('aria-label', label);

        let searchInput = null;

        if (mode === 'search') {
            searchInput = document.createElement('input');
            searchInput.type = 'search';
            searchInput.className = 'filter-select__search';
            searchInput.placeholder = `Pesquisar ${label.toLowerCase()}`;
            searchInput.setAttribute('aria-label', `Pesquisar ${label}`);
            panel.appendChild(searchInput);
        }

        const results = document.createElement('div');
        results.className = 'filter-select__results';
        panel.appendChild(results);

        nativeSelect.classList.add('filter-field__control--native');
        nativeSelect.insertAdjacentElement('afterend', wrapper);
        wrapper.append(trigger, panel);

        const syncTriggerState = () => {
            const selectedOption = nativeSelect.options[nativeSelect.selectedIndex] || null;
            const selectedLabel = selectedOption && selectedOption.value !== ''
                ? (selectedOption.textContent || '').trim()
                : placeholder;

            triggerText.textContent = selectedLabel;
            triggerText.classList.toggle('is-placeholder', !selectedOption || selectedOption.value === '');
            trigger.classList.toggle('is-disabled', nativeSelect.disabled);
            trigger.disabled = nativeSelect.disabled;
        };

        const renderOptions = () => {
            const searchValue = searchInput ? simplifyFilterText(searchInput.value) : '';
            const options = Array.from(nativeSelect.options).filter((option) => {
                if (searchValue === '') {
                    return true;
                }

                return simplifyFilterText(option.textContent || '').includes(searchValue);
            });

            results.innerHTML = '';

            if (options.length === 0) {
                const emptyState = document.createElement('div');
                emptyState.className = 'filter-select__empty';
                emptyState.textContent = 'Nenhum resultado encontrado';
                results.appendChild(emptyState);
                return;
            }

            options.forEach((option) => {
                const item = document.createElement('button');
                item.type = 'button';
                item.className = 'filter-select__item';
                item.textContent = (option.textContent || '').trim();
                item.classList.toggle('is-selected', option.value === nativeSelect.value);
                item.setAttribute('role', 'option');
                item.setAttribute('aria-selected', option.value === nativeSelect.value ? 'true' : 'false');
                item.addEventListener('click', () => {
                    if (nativeSelect.value !== option.value) {
                        nativeSelect.value = option.value;
                        nativeSelect.dispatchEvent(new Event('change', { bubbles: true }));
                    }

                    wrapper.classList.remove('is-open');
                    panel.hidden = true;
                    trigger.setAttribute('aria-expanded', 'false');
                    syncTriggerState();
                });

                results.appendChild(item);
            });
        };

        const setOpen = (open) => {
            if (nativeSelect.disabled) {
                return;
            }

            if (open) {
                closeOtherEnhancedSelects(wrapper);
                renderOptions();
            }

            wrapper.classList.toggle('is-open', open);
            panel.hidden = !open;
            trigger.setAttribute('aria-expanded', open ? 'true' : 'false');

            if (open && searchInput) {
                searchInput.value = '';
                renderOptions();
                window.requestAnimationFrame(() => {
                    searchInput.focus();
                });
            }
        };

        trigger.addEventListener('click', () => {
            setOpen(!wrapper.classList.contains('is-open'));
        });

        trigger.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') {
                setOpen(false);
                return;
            }

            if (['Enter', ' ', 'ArrowDown', 'ArrowUp'].includes(event.key)) {
                event.preventDefault();
                setOpen(true);
            }
        });

        if (searchInput) {
            searchInput.addEventListener('input', renderOptions);
            searchInput.addEventListener('keydown', (event) => {
                if (event.key === 'Escape') {
                    setOpen(false);
                    trigger.focus();
                }
            });
        }

        nativeSelect.addEventListener('change', syncTriggerState);

        document.addEventListener('click', (event) => {
            if (!wrapper.contains(event.target) && event.target !== nativeSelect) {
                setOpen(false);
            }
        });

        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') {
                setOpen(false);
            }
        });

        nativeSelect.dataset.enhancedReady = 'true';
        syncTriggerState();
    });
};

initEnhancedFilterSelects();

const userbox = document.querySelector('[data-userbox]');

if (userbox) {
    const trigger = userbox.querySelector('[data-userbox-trigger]');
    const menu = userbox.querySelector('[data-userbox-menu]');
    const dismissElements = userbox.querySelectorAll('[data-userbox-dismiss]');
    const submenuTrigger = userbox.querySelector('[data-userbox-submenu-trigger]');
    const submenu = userbox.querySelector('[data-userbox-submenu]');

    const setExpanded = (expanded) => {
        userbox.classList.toggle('userbox--open', expanded);

        if (trigger) {
            trigger.setAttribute('aria-expanded', expanded ? 'true' : 'false');
        }

        if (menu) {
            menu.hidden = !expanded;
        }

        if (!expanded && submenuTrigger && submenu) {
            submenuTrigger.setAttribute('aria-expanded', 'false');
            submenu.hidden = true;
        }
    };

    const setSubmenuExpanded = (expanded) => {
        if (!submenuTrigger || !submenu) {
            return;
        }

        submenuTrigger.setAttribute('aria-expanded', expanded ? 'true' : 'false');
        submenu.hidden = !expanded;
    };

    if (trigger && menu) {
        setExpanded(false);
        setSubmenuExpanded(false);

        trigger.addEventListener('click', (event) => {
            event.stopPropagation();
            setExpanded(menu.hidden);
        });

        if (submenuTrigger && submenu) {
            submenuTrigger.addEventListener('click', (event) => {
                event.stopPropagation();

                if (menu.hidden) {
                    setExpanded(true);
                }

                setSubmenuExpanded(submenu.hidden);
            });
        }

        dismissElements.forEach((element) => {
            element.addEventListener('click', () => {
                setExpanded(false);
            });
        });

        document.addEventListener('click', (event) => {
            if (!userbox.contains(event.target)) {
                setExpanded(false);
            }
        });

        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') {
                setExpanded(false);
            }
        });
    }
}

const filtersToggle = document.querySelector('[data-filters-toggle]');
const advancedFiltersShell = document.querySelector('[data-filters-shell]');
const filtersStateInput = document.querySelector('[data-filters-state]');
const filtersStateLinks = document.querySelectorAll('[data-preserve-filters-state]');

if (filtersToggle && advancedFiltersShell) {
    const storageKey = 'novo-pobj:advanced-filters-state';

    const persistState = (state) => {
        if (filtersStateInput) {
            filtersStateInput.value = state;
        }

        filtersStateLinks.forEach((link) => {
            try {
                const url = new URL(link.href, window.location.href);
                url.searchParams.set('advanced_filters', state);
                link.href = url.toString();
            } catch (error) {
                console.warn('Nao foi possivel atualizar o estado dos filtros na URL.', error);
            }
        });

        try {
            window.localStorage.setItem(storageKey, state);

            const nextUrl = new URL(window.location.href);
            nextUrl.searchParams.set('advanced_filters', state);
            window.history.replaceState({}, '', nextUrl);
        } catch (error) {
            console.warn('Nao foi possivel persistir o estado dos filtros.', error);
        }
    };

    const setFiltersExpanded = (expanded) => {
        const state = expanded ? 'open' : 'closed';

        advancedFiltersShell.classList.toggle('is-collapsed', !expanded);
        filtersToggle.classList.toggle('is-open', expanded);
        filtersToggle.setAttribute('aria-expanded', expanded ? 'true' : 'false');
        filtersToggle.textContent = expanded ? 'Fechar filtros avançados' : 'Abrir filtros avançados';
        persistState(state);
    };

    let storedState = null;

    try {
        storedState = window.localStorage.getItem(storageKey);
    } catch (error) {
        storedState = null;
    }

    const initialExpanded = storedState !== null
        ? storedState !== 'closed'
        : !advancedFiltersShell.classList.contains('is-collapsed');

    setFiltersExpanded(initialExpanded);

    filtersToggle.addEventListener('click', () => {
        setFiltersExpanded(advancedFiltersShell.classList.contains('is-collapsed'));
    });
}

const periodPicker = document.querySelector('[data-period-picker]');

if (periodPicker) {
    const trigger = periodPicker.querySelector('[data-period-trigger]');
    const popover = periodPicker.querySelector('[data-period-popover]');
    const cancelButton = periodPicker.querySelector('[data-period-cancel]');
    const form = periodPicker.querySelector('[data-period-form]');
    const startInput = periodPicker.querySelector('[data-period-start]');
    const endInput = periodPicker.querySelector('[data-period-end]');
    const periodIdInput = periodPicker.querySelector('[data-period-id]');
    const maxDate = startInput ? startInput.max : '';

    const setOpen = (open) => {
        if (!trigger || !popover) {
            return;
        }

        trigger.setAttribute('aria-expanded', open ? 'true' : 'false');
        popover.hidden = !open;
        periodPicker.classList.toggle('is-open', open);
    };

    const parseDate = (value) => {
        if (!value) {
            return null;
        }

        const parsed = new Date(`${value}T00:00:00`);
        return Number.isNaN(parsed.getTime()) ? null : parsed;
    };

    const clampDate = (value) => {
        if (!value) {
            return '';
        }

        if (maxDate && value > maxDate) {
            return maxDate;
        }

        return value;
    };

    const dayDistance = (left, right) => Math.abs(left.getTime() - right.getTime()) / 86400000;

    const findBestPeriodId = (periods, startValue, endValue, fallbackId) => {
        const startDate = parseDate(startValue);
        const endDate = parseDate(endValue);

        if (!startDate || !endDate || !Array.isArray(periods) || periods.length === 0) {
            return fallbackId;
        }

        let bestId = fallbackId;
        let bestScore = -Infinity;

        periods.forEach((period) => {
            const periodStart = parseDate(period.start);
            const periodEnd = parseDate(period.end);

            if (!periodStart || !periodEnd || !period.id) {
                return;
            }

            if (period.start === startValue && period.end === endValue) {
                bestId = period.id;
                bestScore = Number.POSITIVE_INFINITY;
                return;
            }

            const overlapStart = Math.max(startDate.getTime(), periodStart.getTime());
            const overlapEnd = Math.min(endDate.getTime(), periodEnd.getTime());
            const overlapDays = Math.max(0, (overlapEnd - overlapStart) / 86400000);
            const distancePenalty = dayDistance(startDate, periodStart) + dayDistance(endDate, periodEnd);
            const score = overlapDays > 0 ? overlapDays - distancePenalty * 0.01 : -distancePenalty;

            if (score > bestScore) {
                bestScore = score;
                bestId = period.id;
            }
        });

        return bestId;
    };

    if (trigger && popover) {
        setOpen(false);

        trigger.addEventListener('click', (event) => {
            event.stopPropagation();
            setOpen(popover.hidden);
        });

        if (cancelButton) {
            cancelButton.addEventListener('click', () => {
                setOpen(false);
            });
        }

        if (form && periodIdInput && startInput && endInput) {
            const syncDateRange = () => {
                startInput.value = clampDate(startInput.value);
                endInput.value = clampDate(endInput.value);

                if (startInput.value && endInput.value && startInput.value > endInput.value) {
                    if (document.activeElement === startInput) {
                        endInput.value = startInput.value;
                    } else {
                        startInput.value = endInput.value;
                    }
                }
            };

            startInput.addEventListener('change', syncDateRange);
            endInput.addEventListener('change', syncDateRange);

            form.addEventListener('submit', () => {
                let periods = [];

                syncDateRange();

                try {
                    periods = JSON.parse(form.dataset.periodOptions || '[]');
                } catch (error) {
                    periods = [];
                }

                periodIdInput.value = findBestPeriodId(periods, startInput.value, endInput.value, periodIdInput.value);
            });
        }

        document.addEventListener('click', (event) => {
            if (!periodPicker.contains(event.target)) {
                setOpen(false);
            }
        });

        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') {
                setOpen(false);
            }
        });
    }
}

const indicatorCards = document.querySelectorAll('[data-tip-card]');

if (indicatorCards.length > 0) {
    const closeAllIndicatorTips = () => {
        indicatorCards.forEach((card) => {
            card.classList.remove('is-tip-open');

            const trigger = card.querySelector('[data-tip-trigger]');

            if (trigger) {
                trigger.setAttribute('aria-expanded', 'false');
            }
        });
    };

    indicatorCards.forEach((card) => {
        const trigger = card.querySelector('[data-tip-trigger]');
        const detailUrl = card.dataset.detailUrl || '';

        if (!trigger) {
            return;
        }

        const openTip = () => {
            closeAllIndicatorTips();
            card.classList.add('is-tip-open');
            trigger.setAttribute('aria-expanded', 'true');
        };

        const closeTip = () => {
            card.classList.remove('is-tip-open');
            trigger.setAttribute('aria-expanded', 'false');
        };

        trigger.addEventListener('mouseenter', openTip);
        trigger.addEventListener('focus', openTip);
        trigger.addEventListener('click', (event) => {
            event.stopPropagation();

            if (card.classList.contains('is-tip-open')) {
                closeTip();
                return;
            }

            openTip();
        });

        card.addEventListener('mouseleave', closeTip);
        card.addEventListener('blur', (event) => {
            if (!card.contains(event.relatedTarget)) {
                closeTip();
            }
        }, true);

        if (detailUrl !== '') {
            const shouldIgnoreDrilldown = (target) => target.closest('[data-tip-trigger], [data-tip]');

            card.addEventListener('click', (event) => {
                if (shouldIgnoreDrilldown(event.target)) {
                    return;
                }

                window.location.href = detailUrl;
            });

            card.addEventListener('keydown', (event) => {
                if ((event.key !== 'Enter' && event.key !== ' ') || shouldIgnoreDrilldown(event.target)) {
                    return;
                }

                event.preventDefault();
                window.location.href = detailUrl;
            });
        }
    });

    document.addEventListener('click', (event) => {
        if (!event.target.closest('[data-tip-card]')) {
            closeAllIndicatorTips();
        }
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            closeAllIndicatorTips();
        }
    });
}

const resumoModeRoot = document.querySelector('[data-resumo-mode-root]');

if (resumoModeRoot) {
    const storageKey = 'novo-pobj:resumo-mode';
    const buttons = resumoModeRoot.querySelectorAll('[data-resumo-mode-button]');
    const panes = document.querySelectorAll('[data-resumo-pane]');
    const allowedModes = ['cards', 'legacy'];

    const setMode = (mode) => {
        if (!allowedModes.includes(mode)) {
            return;
        }

        panes.forEach((pane) => {
            pane.hidden = pane.dataset.resumoPane !== mode;
        });

        buttons.forEach((button) => {
            const isActive = button.dataset.mode === mode;
            button.classList.toggle('is-active', isActive);
            button.setAttribute('aria-pressed', isActive ? 'true' : 'false');
        });

        try {
            window.localStorage.setItem(storageKey, mode);
        } catch (error) {
            console.warn('Nao foi possivel persistir a visao do resumo.', error);
        }
    };

    let initialMode = resumoModeRoot.dataset.defaultMode || 'cards';

    try {
        const storedMode = window.localStorage.getItem(storageKey);

        if (storedMode && allowedModes.includes(storedMode)) {
            initialMode = storedMode;
        }
    } catch (error) {
        initialMode = resumoModeRoot.dataset.defaultMode || 'cards';
    }

    setMode(initialMode);

    buttons.forEach((button) => {
        button.addEventListener('click', () => {
            const nextMode = button.dataset.mode || 'cards';

            if (button.classList.contains('is-active')) {
                return;
            }

            showLoadingOverlay('Alternando visao...');

            window.requestAnimationFrame(() => {
                setMode(nextMode);
                window.requestAnimationFrame(() => {
                    hideLoadingOverlay();
                });
            });
        });
    });
}

const legacySections = document.querySelectorAll('[data-legacy-section]');

if (legacySections.length > 0) {
    legacySections.forEach((section) => {
        const groups = Array.from(section.querySelectorAll('[data-legacy-group]'));
        const toggleAllButton = section.querySelector('[data-legacy-toggle-all]');

        const setGroupOpen = (group, expanded) => {
            group.classList.toggle('is-open', expanded);

            const trigger = group.querySelector('[data-legacy-toggle-row]');

            if (trigger) {
                trigger.setAttribute('aria-expanded', expanded ? 'true' : 'false');
            }

            group.querySelectorAll('[data-legacy-child-row]').forEach((row) => {
                row.hidden = !expanded;
            });
        };

        const syncSectionToggle = () => {
            if (!toggleAllButton) {
                return;
            }

            const expandableGroups = groups.filter((group) => group.querySelector('[data-legacy-toggle-row]'));
            const allOpen = expandableGroups.length > 0 && expandableGroups.every((group) => group.classList.contains('is-open'));

            toggleAllButton.textContent = allOpen ? 'Fechar todos os filtros' : 'Abrir todos os filtros';
            toggleAllButton.setAttribute('aria-expanded', allOpen ? 'true' : 'false');
        };

        groups.forEach((group) => {
            const trigger = group.querySelector('[data-legacy-toggle-row]');

            setGroupOpen(group, false);

            if (!trigger) {
                return;
            }

            trigger.addEventListener('click', () => {
                setGroupOpen(group, !group.classList.contains('is-open'));
                syncSectionToggle();
            });
        });

        if (toggleAllButton) {
            toggleAllButton.addEventListener('click', () => {
                const expandableGroups = groups.filter((group) => group.querySelector('[data-legacy-toggle-row]'));
                const shouldOpen = expandableGroups.some((group) => !group.classList.contains('is-open'));

                expandableGroups.forEach((group) => {
                    setGroupOpen(group, shouldOpen);
                });

                syncSectionToggle();
            });
        }

        syncSectionToggle();
    });
}

const legacySimulationRoot = document.querySelector('[data-legacy-simulation-root]');

if (legacySimulationRoot) {
    const toggle = legacySimulationRoot.querySelector('[data-legacy-simulation-toggle]');
    const resetButton = legacySimulationRoot.querySelector('[data-legacy-simulation-reset]');
    const itemRows = Array.from(document.querySelectorAll('[data-legacy-item-row]'));
    const sections = Array.from(document.querySelectorAll('[data-legacy-sim-section]'));
    const summaryKpiRoot = document.querySelector('[data-summary-kpi-root]');
    const simulationOverrides = new Map();

    let businessDays = { total: 0, elapsed: 0, remaining: 0 };

    try {
        businessDays = JSON.parse(legacySimulationRoot.dataset.legacyBusinessDays || '{}');
    } catch (error) {
        businessDays = { total: 0, elapsed: 0, remaining: 0 };
    }

    const toSafeNumber = (value) => {
        const parsed = Number.parseFloat(String(value || ''));
        return Number.isFinite(parsed) ? parsed : 0;
    };

    const formatDecimal = (value, decimals = 2) => new Intl.NumberFormat('pt-BR', {
        minimumFractionDigits: decimals,
        maximumFractionDigits: decimals,
    }).format(Number.isFinite(value) ? value : 0);

    const formatInteger = (value) => new Intl.NumberFormat('pt-BR', {
        minimumFractionDigits: 0,
        maximumFractionDigits: 0,
    }).format(Math.round(Number.isFinite(value) ? value : 0));

    const formatCompactNumber = (value, baseDecimals = 2) => {
        const safeValue = Number.isFinite(value) ? value : 0;
        const absolute = Math.abs(safeValue);
        const scales = [
            { divisor: 1000000000000, suffix: ' tri' },
            { divisor: 1000000000, suffix: ' bi' },
            { divisor: 1000000, suffix: ' mi' },
            { divisor: 1000, suffix: ' mil' },
        ];

        for (const scale of scales) {
            if (absolute < scale.divisor) {
                continue;
            }

            const scaled = safeValue / scale.divisor;
            const scaledAbsolute = Math.abs(scaled);
            let decimals = scaledAbsolute >= 100 ? 0 : 1;

            if (Math.abs(scaled - Math.round(scaled)) < 0.05) {
                decimals = 0;
            }

            return `${new Intl.NumberFormat('pt-BR', {
                minimumFractionDigits: decimals,
                maximumFractionDigits: decimals,
            }).format(scaled)}${scale.suffix}`;
        }

        let decimals = baseDecimals;
        const rounded = Number(safeValue.toFixed(baseDecimals));

        if (baseDecimals > 0 && Math.abs(rounded - Math.round(rounded)) < 0.005) {
            decimals = 0;
        }

        return new Intl.NumberFormat('pt-BR', {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals,
        }).format(rounded);
    };

    const formatPointsReadable = (value) => {
        const safeValue = Number.isFinite(value) ? value : 0;
        const rounded = Number(safeValue.toFixed(2));
        const decimals = Math.abs(rounded - Math.round(rounded)) < 0.005 || Math.abs(rounded) >= 1000 ? 0 : 2;

        return new Intl.NumberFormat('pt-BR', {
            minimumFractionDigits: decimals,
            maximumFractionDigits: decimals,
        }).format(rounded);
    };

    const formatMetricReadable = (metricType, value) => {
        const upperMetric = String(metricType || 'VALOR').toUpperCase();
        const safeValue = Number.isFinite(value) ? value : 0;

        if (upperMetric === 'PERCENTUAL') {
            return `${formatDecimal(safeValue, 2)}%`;
        }

        if (upperMetric === 'QUANTIDADE') {
            return formatCompactNumber(safeValue, 0);
        }

        return `R$ ${formatCompactNumber(safeValue, 2)}`;
    };

    const formatPercent = (value) => `${formatDecimal(Math.max(0, Math.min(200, Number.isFinite(value) ? value : 0)), 1)}%`;

    const formatInputValue = (value) => {
        const safeValue = Number.isFinite(value) ? value : 0;
        const rendered = safeValue.toFixed(4).replace(/\.0+$/, '').replace(/(\.\d*?)0+$/, '$1');
        return rendered === '' ? '0' : rendered;
    };

    const resolveMeterClass = (percent) => {
        if (percent >= 100) {
            return 'is-ok';
        }

        if (percent >= 50) {
            return 'is-warn';
        }

        return 'is-low';
    };

    const getCurrentValues = (row) => {
        const itemId = row.dataset.legacyItemId || '';
        const override = simulationOverrides.get(itemId) || {};
        const meta = override.meta ?? toSafeNumber(row.dataset.legacyOriginalMeta);
        const realizado = override.realizado ?? toSafeNumber(row.dataset.legacyOriginalRealizado);
        const pontosTotal = toSafeNumber(row.dataset.legacyPointsTotal);
        const variavelTotal = toSafeNumber(row.dataset.legacyVariableTotal);
        const variavelOriginal = toSafeNumber(row.dataset.legacyVariableOriginal);

        return { itemId, meta, realizado, pontosTotal, variavelTotal, variavelOriginal };
    };

    const calculateRowMetrics = (row) => {
        const { meta, realizado, pontosTotal, variavelTotal, variavelOriginal } = getCurrentValues(row);
        const totalDays = Math.max(0, Number.parseInt(String(businessDays.total || 0), 10));
        const elapsedDays = Math.max(0, Number.parseInt(String(businessDays.elapsed || 0), 10));
        const remainingDays = Math.max(0, Number.parseInt(String(businessDays.remaining || 0), 10));
        const referencia = totalDays > 0 ? (meta / totalDays) * elapsedDays : 0;
        const faltaParaMeta = Math.max(0, meta - realizado);
        const metaDiaria = remainingDays > 0 ? faltaParaMeta / remainingDays : 0;
        const forecast = elapsedDays > 0 ? realizado + ((realizado / elapsedDays) * remainingDays) : realizado;
        const atingimento = meta > 0 ? (realizado / meta) * 100 : 0;
        const pontos = meta > 0 ? (realizado / meta) * pontosTotal : 0;
        const variavel = meta > 0 ? (realizado / meta) * variavelTotal : variavelOriginal;

        return {
            meta,
            realizado,
            pontosTotal,
            variavelTotal,
            variavel,
            referencia,
            metaDiaria,
            forecast,
            atingimento,
            pontos,
        };
    };

    const setEditingState = (row, active) => {
        row.querySelectorAll('[data-legacy-edit]').forEach((editField) => {
            editField.hidden = !active;
        });

        row.querySelectorAll('[data-legacy-display]').forEach((displayField) => {
            displayField.hidden = active;
        });
    };

    const updateRow = (row) => {
        const metricType = row.dataset.legacyMetricType || 'VALOR';
        const metrics = calculateRowMetrics(row);
        const simulationActive = toggle instanceof HTMLInputElement && toggle.checked;
        const metaDisplay = row.querySelector('[data-legacy-display="meta"]');
        const realizadoDisplay = row.querySelector('[data-legacy-display="realizado"]');
        const metaPreview = row.querySelector('[data-legacy-preview="meta"]');
        const realizadoPreview = row.querySelector('[data-legacy-preview="realizado"]');
        const referenciaNode = row.querySelector('[data-legacy-value="referencia"]');
        const forecastNode = row.querySelector('[data-legacy-value="forecast"]');
        const metaDiaNode = row.querySelector('[data-legacy-value="meta-dia"]');
        const pontosNode = row.querySelector('[data-legacy-value="pontos"]');
        const atingimentoNode = row.querySelector('[data-legacy-value="atingimento"]');
        const meter = row.querySelector('[data-legacy-meter]');
        const metaInput = row.querySelector('[data-legacy-input="meta"]');
        const realizadoInput = row.querySelector('[data-legacy-input="realizado"]');
        const formattedMeta = formatMetricReadable(metricType, metrics.meta);
        const formattedRealizado = formatMetricReadable(metricType, metrics.realizado);

        if (metaDisplay) {
            metaDisplay.textContent = formattedMeta;
        }

        if (realizadoDisplay) {
            realizadoDisplay.textContent = formattedRealizado;
        }

        if (metaPreview) {
            metaPreview.textContent = formattedMeta;
        }

        if (realizadoPreview) {
            realizadoPreview.textContent = formattedRealizado;
        }

        if (referenciaNode) {
            referenciaNode.textContent = formatMetricReadable(metricType, metrics.referencia);
        }

        if (forecastNode) {
            forecastNode.textContent = formatMetricReadable(metricType, metrics.forecast);
        }

        if (metaDiaNode) {
            metaDiaNode.textContent = formatMetricReadable(metricType, metrics.metaDiaria);
        }

        if (pontosNode) {
            pontosNode.textContent = `${formatPointsReadable(metrics.pontos)} pts`;
        }

        if (atingimentoNode) {
            atingimentoNode.textContent = metrics.meta > 0 ? formatPercent(metrics.atingimento) : '—';
        }

        if (meter) {
            meter.classList.remove('is-low', 'is-warn', 'is-ok');
            meter.classList.add(resolveMeterClass(metrics.atingimento));
            meter.style.setProperty('--fill', `${Math.max(0, Math.min(100, metrics.atingimento))}%`);
            meter.setAttribute('aria-valuenow', String(Math.max(0, Math.min(200, metrics.atingimento)).toFixed(1)));
        }

        if (metaInput && document.activeElement !== metaInput) {
            metaInput.value = formatInputValue(metrics.meta);
        }

        if (realizadoInput && document.activeElement !== realizadoInput) {
            realizadoInput.value = formatInputValue(metrics.realizado);
        }

        setEditingState(row, simulationActive);
    };

    const updateSection = (section) => {
        const rows = Array.from(section.querySelectorAll('[data-legacy-item-row]'));
        let pointsHit = 0;
        let pointsTotal = 0;
        let percentSum = 0;
        let percentCount = 0;

        rows.forEach((row) => {
            const metrics = calculateRowMetrics(row);
            pointsHit += metrics.pontos;
            pointsTotal += metrics.pontosTotal;
            percentSum += metrics.atingimento;
            percentCount += 1;
        });

        const pointsHitNode = section.querySelector('[data-legacy-section-points-hit]');
        const pointsTotalNode = section.querySelector('[data-legacy-section-points-total]');
        const atingimentoNode = section.querySelector('[data-legacy-section-atingimento]');

        if (pointsHitNode) {
            pointsHitNode.textContent = formatPointsReadable(pointsHit);
        }

        if (pointsTotalNode) {
            pointsTotalNode.textContent = formatPointsReadable(pointsTotal);
        }

        if (atingimentoNode) {
            atingimentoNode.textContent = percentCount > 0 ? formatPercent(percentSum / percentCount) : '0,0%';
        }
    };

    const resolveKpiBarClass = (percent) => {
        if (percent < 50) {
            return 'summary-kpi__hitbar--low';
        }

        if (percent < 100) {
            return 'summary-kpi__hitbar--warn';
        }

        return 'summary-kpi__hitbar--ok';
    };

    const applyKpiCardState = (card, achieved, total, percent, formatter) => {
        const achievedNode = card.querySelector('[data-summary-kpi-achieved]');
        const totalNode = card.querySelector('[data-summary-kpi-total]');
        const percentNode = card.querySelector('[data-summary-kpi-percent]');
        const progressNode = card.querySelector('[data-summary-kpi-progress]');
        const trackNode = card.querySelector('[data-summary-kpi-track]');
        const boundedPercent = Math.max(0, Math.min(100, Number.isFinite(percent) ? percent : 0));

        if (achievedNode) {
            achievedNode.textContent = formatter(achieved);
        }

        if (totalNode) {
            totalNode.textContent = formatter(total);
        }

        if (percentNode) {
            percentNode.textContent = `${formatDecimal(percent, 1)}%`;
        }

        if (progressNode) {
            progressNode.classList.remove('summary-kpi__hitbar--low', 'summary-kpi__hitbar--warn', 'summary-kpi__hitbar--ok');
            progressNode.classList.add(resolveKpiBarClass(percent));
            progressNode.setAttribute('aria-valuenow', String(Number.isFinite(percent) ? percent.toFixed(1) : '0.0'));
        }

        if (trackNode) {
            trackNode.style.setProperty('--target', `${boundedPercent.toFixed(2)}%`);
            trackNode.style.setProperty('--thumb', `${boundedPercent.toFixed(2)}%`);
        }
    };

    const updateSummaryKpis = () => {
        if (!summaryKpiRoot) {
            return;
        }

        const cards = Array.from(summaryKpiRoot.querySelectorAll('[data-summary-kpi-card]'));
        const simulationActive = toggle instanceof HTMLInputElement && toggle.checked;

        if (!simulationActive) {
            cards.forEach((card) => {
                const achieved = toSafeNumber(card.dataset.summaryKpiOriginalAchieved);
                const total = toSafeNumber(card.dataset.summaryKpiOriginalTotal);
                const percent = toSafeNumber(card.dataset.summaryKpiOriginalPercent);
                const key = card.dataset.summaryKpiCard || '';
                const formatter = key === 'indicadores'
                    ? formatInteger
                    : (key === 'variavel' ? ((value) => `R$ ${formatCompactNumber(value, 2)}`) : formatPointsReadable);

                applyKpiCardState(card, achieved, total, percent, formatter);
            });

            return;
        }

        const rowMetrics = itemRows.map(calculateRowMetrics);
        const indicatorsTotal = rowMetrics.length;
        const indicatorsAchieved = rowMetrics.filter((metrics) => metrics.meta > 0 && metrics.realizado >= metrics.meta).length;
        const indicatorsPercent = indicatorsTotal > 0 ? (indicatorsAchieved / indicatorsTotal) * 100 : 0;
        const pointsAchieved = rowMetrics.reduce((carry, metrics) => carry + metrics.pontos, 0);
        const pointsTotal = rowMetrics.reduce((carry, metrics) => carry + metrics.pontosTotal, 0);
        const pointsPercent = pointsTotal > 0 ? (pointsAchieved / pointsTotal) * 100 : 0;
        const variableAchieved = rowMetrics.reduce((carry, metrics) => carry + metrics.variavel, 0);
        const variableTotal = rowMetrics.reduce((carry, metrics) => carry + metrics.variavelTotal, 0);
        const variablePercent = variableTotal > 0 ? (variableAchieved / variableTotal) * 100 : 0;

        cards.forEach((card) => {
            switch (card.dataset.summaryKpiCard || '') {
                case 'indicadores':
                    applyKpiCardState(card, indicatorsAchieved, indicatorsTotal, indicatorsPercent, formatInteger);
                    break;

                case 'variavel':
                    applyKpiCardState(card, variableAchieved, variableTotal, variablePercent, (value) => `R$ ${formatCompactNumber(value, 2)}`);
                    break;

                case 'pontos':
                default:
                    applyKpiCardState(card, pointsAchieved, pointsTotal, pointsPercent, formatPointsReadable);
                    break;
            }
        });
    };

    const syncResetState = () => {
        if (!(resetButton instanceof HTMLButtonElement)) {
            return;
        }

        resetButton.disabled = simulationOverrides.size === 0;
    };

    const refreshSimulationState = () => {
        legacySimulationRoot.classList.toggle('is-active', toggle instanceof HTMLInputElement && toggle.checked);
        itemRows.forEach(updateRow);
        sections.forEach(updateSection);
        updateSummaryKpis();
        syncResetState();
    };

    itemRows.forEach((row) => {
        const itemId = row.dataset.legacyItemId || '';
        const metaInput = row.querySelector('[data-legacy-input="meta"]');
        const realizadoInput = row.querySelector('[data-legacy-input="realizado"]');

        const bindInput = (input, key) => {
            if (!(input instanceof HTMLInputElement) || itemId === '') {
                return;
            }

            input.addEventListener('input', () => {
                const nextValue = input.value.trim();
                const current = simulationOverrides.get(itemId) || {};

                if (nextValue === '') {
                    delete current[key];
                } else {
                    current[key] = toSafeNumber(nextValue);
                }

                if (current.meta === undefined && current.realizado === undefined) {
                    simulationOverrides.delete(itemId);
                } else {
                    simulationOverrides.set(itemId, current);
                }

                refreshSimulationState();
            });
        };

        bindInput(metaInput, 'meta');
        bindInput(realizadoInput, 'realizado');
    });

    if (toggle instanceof HTMLInputElement) {
        toggle.addEventListener('change', () => {
            if (!toggle.checked) {
                simulationOverrides.clear();
            }

            refreshSimulationState();
        });
    }

    if (resetButton instanceof HTMLButtonElement) {
        resetButton.addEventListener('click', () => {
            simulationOverrides.clear();
            refreshSimulationState();
        });
    }

    refreshSimulationState();
}

const executiveHeatmapRoots = document.querySelectorAll('[data-executive-heatmap]');

if (executiveHeatmapRoots.length > 0) {
    executiveHeatmapRoots.forEach((root) => {
        const buttons = Array.from(root.querySelectorAll('[data-executive-heatmap-button]'));
        const panes = Array.from(root.querySelectorAll('[data-executive-heatmap-pane]'));
        const defaultMode = (root.dataset.defaultMode || '').trim() || (buttons[0]?.dataset.executiveHeatmapButton || 'secoes');

        const setMode = (mode) => {
            const nextMode = (mode || '').trim() || defaultMode;

            buttons.forEach((button) => {
                const isActive = button.dataset.executiveHeatmapButton === nextMode;
                button.classList.toggle('is-active', isActive);
                button.setAttribute('aria-pressed', isActive ? 'true' : 'false');
            });

            panes.forEach((pane) => {
                pane.hidden = pane.dataset.executiveHeatmapPane !== nextMode;
            });
        };

        buttons.forEach((button) => {
            button.addEventListener('click', () => {
                setMode(button.dataset.executiveHeatmapButton || defaultMode);
            });
        });

        setMode(defaultMode);
    });
}

const executiveViewRoots = document.querySelectorAll('[data-executive-view]');

if (executiveViewRoots.length > 0) {
    executiveViewRoots.forEach((root) => {
        const charts = Array.from(root.querySelectorAll('[data-executive-chart]'));
        const meters = Array.from(root.querySelectorAll('[data-executive-meter]'));
        let hasAnimated = false;

        const prepareChart = (chart) => {
            if (!(chart instanceof HTMLElement)) {
                return;
            }

            const legendItems = Array.from(chart.querySelectorAll('.executive-chart__legend-item'));
            let hasGeometry = false;

            legendItems.forEach((item, index) => {
                if (!(item instanceof HTMLElement)) {
                    return;
                }

                item.style.setProperty('--legend-delay', `${index * 70}ms`);
            });

            chart.querySelectorAll('[data-executive-line]').forEach((line, index) => {
                if (!(line instanceof SVGElement) || typeof line.getTotalLength !== 'function') {
                    return;
                }

                try {
                    const length = line.getTotalLength();
                    line.style.setProperty('--line-length', `${length.toFixed(2)}`);
                    line.style.setProperty('--line-delay', `${index * 140}ms`);
                    hasGeometry = true;
                } catch (error) {
                    // Ignore browsers that cannot calculate SVG path length reliably.
                }
            });

            if (hasGeometry || chart.querySelector('[data-executive-point]')) {
                chart.setAttribute('data-chart-ready', 'true');
            }
        };

        const reveal = () => {
            if (hasAnimated) {
                return;
            }

            hasAnimated = true;

            charts.forEach((chart) => {
                if (chart instanceof HTMLElement) {
                    chart.classList.add('is-visible');
                }
            });

            window.requestAnimationFrame(() => {
                meters.forEach((meter, index) => {
                    if (!(meter instanceof HTMLElement)) {
                        return;
                    }

                    meter.style.setProperty('--meter-delay', `${Math.min(index * 45, 360)}ms`);
                    meter.classList.add('is-visible');
                });
            });
        };

        charts.forEach(prepareChart);

        if ('IntersectionObserver' in window) {
            const observer = new IntersectionObserver((entries) => {
                entries.forEach((entry) => {
                    if (!entry.isIntersecting) {
                        return;
                    }

                    reveal();
                    observer.disconnect();
                });
            }, {
                threshold: 0.22,
            });

            observer.observe(root);
        } else {
            reveal();
        }
    });
}

const detailRoot = document.querySelector('[data-detail-root]');

if (detailRoot) {
    const modal = detailRoot.querySelector('[data-detail-modal]');
    const openModalButton = detailRoot.querySelector('[data-detail-open-modal]');
    const closeModalButtons = Array.from(detailRoot.querySelectorAll('[data-detail-close-modal]'));
    const cancelModalButton = detailRoot.querySelector('[data-detail-cancel-modal]');
    const applyColumnsButton = detailRoot.querySelector('[data-detail-apply-columns]');
    const saveViewButton = detailRoot.querySelector('[data-detail-save-view-modal]');
    const searchInput = detailRoot.querySelector('[data-detail-search]');
    const viewHosts = Array.from(detailRoot.querySelectorAll('[data-detail-views-host]'));
    const defaultViewButtons = Array.from(detailRoot.querySelectorAll('[data-detail-default-view-trigger]'));
    const availableColumnsHost = detailRoot.querySelector('[data-detail-available-columns]');
    const selectedColumnsHost = detailRoot.querySelector('[data-detail-selected-columns]');
    const viewNameInput = detailRoot.querySelector('[data-detail-view-name]');
    const tableViewButtons = Array.from(detailRoot.querySelectorAll('[data-detail-table-view]'));
    const tablePanes = Array.from(detailRoot.querySelectorAll('[data-detail-table-pane]'));
    const tables = Array.from(detailRoot.querySelectorAll('[data-detail-table]'));
    const expandAllButton = detailRoot.querySelector('[data-detail-expand-all]');
    const collapseAllButton = detailRoot.querySelector('[data-detail-collapse-all]');
    const storageColumnsKey = 'novo-pobj:detail-visible-columns';
    const storageViewsKey = 'novo-pobj:detail-saved-views';
    const maxSavedViews = 5;

    let columnsConfig = [];
    let allColumnKeys = [];
    let appliedColumns = [];
    let draftColumns = [];
    let activeViewId = '__default__';
    let defaultColumns = [];
    let activeTableViewId = tableViewButtons.find((button) => button.classList.contains('is-active'))?.dataset.detailTableView
        || tablePanes[0]?.dataset.detailTablePane
        || 'diretoria';

    try {
        columnsConfig = JSON.parse(detailRoot.dataset.detailColumnsConfig || '[]');
        allColumnKeys = columnsConfig
            .map((column) => column.key)
            .filter((value) => typeof value === 'string' && value !== '');
    } catch (error) {
        columnsConfig = [];
        allColumnKeys = [];
    }

    try {
        defaultColumns = JSON.parse(detailRoot.dataset.detailDefaultColumns || '[]');
    } catch (error) {
        defaultColumns = [];
    }

    const columnLabels = columnsConfig.reduce((map, column) => {
        map[column.key] = column.label;
        return map;
    }, {});

    const arraysEqual = (left, right) => left.length === right.length && left.every((value, index) => value === right[index]);

    const slugify = (value) => value
        .toLowerCase()
        .normalize('NFD')
        .replace(/[\u0300-\u036f]/g, '')
        .replace(/[^a-z0-9]+/g, '-')
        .replace(/^-+|-+$/g, '');

    const normalizeColumns = (columns) => {
        const uniqueColumns = [];

        (Array.isArray(columns) ? columns : []).forEach((columnKey) => {
            if (allColumnKeys.includes(columnKey) && !uniqueColumns.includes(columnKey)) {
                uniqueColumns.push(columnKey);
            }
        });

        return uniqueColumns.length > 0
            ? uniqueColumns
            : defaultColumns.filter((columnKey) => allColumnKeys.includes(columnKey));
    };

    defaultColumns = normalizeColumns(defaultColumns);

    const readSavedViews = () => {
        try {
            const parsed = JSON.parse(window.localStorage.getItem(storageViewsKey) || '[]');
            return Array.isArray(parsed) ? parsed : [];
        } catch (error) {
            return [];
        }
    };

    const writeSavedViews = (views) => {
        window.localStorage.setItem(storageViewsKey, JSON.stringify(views));
    };

    const persistVisibleColumns = (columns) => {
        window.localStorage.setItem(storageColumnsKey, JSON.stringify(columns));
    };

    const readStoredColumns = () => {
        try {
            const parsed = JSON.parse(window.localStorage.getItem(storageColumnsKey) || '[]');
            return normalizeColumns(parsed);
        } catch (error) {
            return normalizeColumns(defaultColumns);
        }
    };

    const resolveActiveViewId = (columns) => {
        if (arraysEqual(columns, defaultColumns)) {
            return '__default__';
        }

        const matchedView = readSavedViews().find((view) => arraysEqual(normalizeColumns(view.columns), columns));
        return matchedView ? matchedView.id : '__custom__';
    };

    const getActivePane = () => tablePanes.find((pane) => pane.dataset.detailTablePane === activeTableViewId) || null;

    const paneCaches = new WeakMap();

    tablePanes.forEach((pane) => {
        const rows = Array.from(pane.querySelectorAll('[data-tree-row]'));
        const detailRows = Array.from(pane.querySelectorAll('[data-tree-detail-row]'));
        const rowById = new Map();
        const childrenByParentId = new Map();
        const detailByParentId = new Map();

        rows.forEach((row) => {
            const nodeId = row.dataset.treeId || '';
            const parentId = row.dataset.treeParentId || '';

            if (nodeId !== '') {
                rowById.set(nodeId, row);
            }

            if (!childrenByParentId.has(parentId)) {
                childrenByParentId.set(parentId, []);
            }

            childrenByParentId.get(parentId).push(row);
        });

        detailRows.forEach((row) => {
            const parentId = row.dataset.parentId || '';

            if (parentId !== '') {
                detailByParentId.set(parentId, row);
            }
        });

        paneCaches.set(pane, {
            rows,
            detailRows,
            rowById,
            childrenByParentId,
            detailByParentId,
        });
    });

    const getPaneCache = (pane) => paneCaches.get(pane) || {
        rows: [],
        detailRows: [],
        rowById: new Map(),
        childrenByParentId: new Map(),
        detailByParentId: new Map(),
    };

    const findTreeRow = (pane, nodeId) => getPaneCache(pane).rowById.get(nodeId) || null;

    const findTreeDetailRow = (pane, nodeId) => getPaneCache(pane).detailByParentId.get(nodeId) || null;

    const findChildRows = (pane, nodeId) => getPaneCache(pane).childrenByParentId.get(nodeId) || [];

    const setToggleState = (row, expanded) => {
        row.classList.toggle('tree-row--expanded', expanded);

        const trigger = row.querySelector('[data-tree-toggle]');

        if (trigger) {
            trigger.setAttribute('aria-expanded', expanded ? 'true' : 'false');
            trigger.classList.toggle('is-expanded', expanded);
        }
    };

    const collapseBranch = (pane, nodeId) => {
        const row = findTreeRow(pane, nodeId);

        if (row) {
            setToggleState(row, false);
        }

        const detailRow = findTreeDetailRow(pane, nodeId);

        if (detailRow) {
            detailRow.hidden = true;
        }

        const stack = [...findChildRows(pane, nodeId)];

        while (stack.length > 0) {
            const childRow = stack.pop();

            if (!childRow) {
                continue;
            }

            childRow.hidden = true;
            setToggleState(childRow, false);

            const childId = childRow.dataset.treeId || '';
            const childDetailRow = findTreeDetailRow(pane, childId);

            if (childDetailRow) {
                childDetailRow.hidden = true;
            }

            findChildRows(pane, childId).forEach((nestedChild) => {
                stack.push(nestedChild);
            });
        }
    };

    const setNodeExpanded = (pane, nodeId, expanded) => {
        const row = findTreeRow(pane, nodeId);

        if (!row) {
            return;
        }

        setToggleState(row, expanded);

        const detailRow = findTreeDetailRow(pane, nodeId);
        if (detailRow) {
            detailRow.hidden = !expanded;
        }

        findChildRows(pane, nodeId).forEach((childRow) => {
            childRow.hidden = !expanded;

            if (!expanded) {
                collapseBranch(pane, childRow.dataset.treeId || '');
            }
        });
    };

    const collapseAllInPane = (pane) => {
        const { rows, detailRows } = getPaneCache(pane);

        rows.forEach((row) => {
            const isRoot = !row.dataset.treeParentId;
            row.hidden = !isRoot;
            setToggleState(row, false);
        });

        detailRows.forEach((row) => {
            row.hidden = true;
        });
    };

    const expandAllInPane = (pane) => {
        const { rows, detailRows } = getPaneCache(pane);

        rows.forEach((row) => {
            row.hidden = false;

            if (row.querySelector('[data-tree-toggle]')) {
                setToggleState(row, true);
            }
        });

        detailRows.forEach((row) => {
            row.hidden = false;
        });
    };

    const updateTreeDetailColspan = (visibleColumns) => {
        detailRoot.querySelectorAll('[data-tree-detail-colspan]').forEach((cell) => {
            cell.colSpan = visibleColumns.length + 1;
        });
    };

    const reorderTables = (visibleColumns) => {
        tables.forEach((table) => {
            table.querySelectorAll('tr').forEach((row) => {
                const cells = Array.from(row.querySelectorAll('[data-detail-column]'));

                if (cells.length === 0) {
                    return;
                }

                const cellMap = new Map(cells.map((cell) => [cell.dataset.detailColumn, cell]));
                const orderedKeys = [...visibleColumns, ...allColumnKeys.filter((columnKey) => !visibleColumns.includes(columnKey))];

                orderedKeys.forEach((columnKey) => {
                    const cell = cellMap.get(columnKey);

                    if (cell) {
                        row.appendChild(cell);
                    }
                });
            });
        });
    };

    const renderColumnLists = () => {
        if (!availableColumnsHost || !selectedColumnsHost) {
            return;
        }

        availableColumnsHost.innerHTML = '';
        selectedColumnsHost.innerHTML = '';

        const selectedKeys = normalizeColumns(draftColumns);
        const availableKeys = allColumnKeys.filter((columnKey) => !selectedKeys.includes(columnKey));

        if (availableKeys.length === 0) {
            const emptyState = document.createElement('p');
            emptyState.className = 'detail-designer__empty';
            emptyState.textContent = 'Todas as colunas já estão na tabela.';
            availableColumnsHost.appendChild(emptyState);
        }

        availableKeys.forEach((columnKey) => {
            const item = document.createElement('div');
            item.className = 'detail-item detail-item--available';

            const handle = document.createElement('span');
            handle.className = 'detail-item__handle';
            handle.setAttribute('aria-hidden', 'true');
            handle.textContent = '⋮⋮';

            const label = document.createElement('span');
            label.className = 'detail-item__label';
            label.textContent = columnLabels[columnKey] || columnKey;

            const addButton = document.createElement('button');
            addButton.type = 'button';
            addButton.className = 'detail-item__add';
            addButton.textContent = '+';
            addButton.setAttribute('aria-label', `Adicionar ${label.textContent}`);
            addButton.addEventListener('click', () => {
                draftColumns = [...selectedKeys, columnKey];
                renderColumnLists();
            });

            item.append(handle, label, addButton);
            availableColumnsHost.appendChild(item);
        });

        if (selectedKeys.length === 0) {
            const emptyState = document.createElement('p');
            emptyState.className = 'detail-designer__empty';
            emptyState.textContent = 'Escolha ao menos uma coluna.';
            selectedColumnsHost.appendChild(emptyState);
        }

        selectedKeys.forEach((columnKey, index) => {
            const item = document.createElement('div');
            item.className = 'detail-item';

            const handle = document.createElement('span');
            handle.className = 'detail-item__handle';
            handle.setAttribute('aria-hidden', 'true');
            handle.textContent = '⋮⋮';

            const label = document.createElement('span');
            label.className = 'detail-item__label';
            label.textContent = columnLabels[columnKey] || columnKey;

            const controls = document.createElement('div');
            controls.className = 'detail-modal__column-controls';

            const removeButton = document.createElement('button');
            removeButton.type = 'button';
            removeButton.className = 'detail-item__remove';
            removeButton.textContent = '×';
            removeButton.disabled = selectedKeys.length === 1;
            removeButton.setAttribute('aria-label', `Remover ${label.textContent}`);
            removeButton.addEventListener('click', () => {
                if (selectedKeys.length === 1) {
                    return;
                }

                draftColumns = selectedKeys.filter((currentKey) => currentKey !== columnKey);
                renderColumnLists();
            });

            controls.append(removeButton);
            item.append(handle, label, controls);
            selectedColumnsHost.appendChild(item);
        });
    };

    const renderSavedViews = () => {
        const savedViews = readSavedViews();

        viewHosts.forEach((host) => {
            host.querySelectorAll('[data-detail-view-item]').forEach((item) => {
                item.remove();
            });

            const hostType = host.dataset.detailViewsHost || 'inline';
            const defaultButton = host.querySelector('[data-detail-default-view-trigger]');

            if (defaultButton) {
                defaultButton.classList.toggle('is-active', activeViewId === '__default__');
            }

            savedViews.forEach((view) => {
                const item = document.createElement(hostType === 'modal' ? 'div' : 'span');
                item.setAttribute('data-detail-view-item', 'true');
                item.className = hostType === 'modal' ? 'detail-view-chip-wrapper' : 'detail-view-bar__item';

                const applyButton = document.createElement('button');
                applyButton.type = 'button';
                applyButton.className = hostType === 'modal' ? 'detail-view-chip' : 'detail-chip';
                applyButton.textContent = view.name;
                applyButton.classList.toggle('is-active', activeViewId === view.id);
                applyButton.addEventListener('click', () => {
                    if (hostType === 'modal') {
                        activeViewId = view.id;
                        draftColumns = normalizeColumns(view.columns);
                        renderSavedViews();
                        renderColumnLists();
                        return;
                    }

                    applyVisibleColumns(view.columns);
                });

                item.appendChild(applyButton);

                if (hostType === 'modal') {
                    const removeButton = document.createElement('button');
                    removeButton.type = 'button';
                    removeButton.className = 'detail-view-chip__delete';
                    removeButton.setAttribute('aria-label', `Excluir visao ${view.name}`);
                    removeButton.textContent = '×';
                    removeButton.addEventListener('click', () => {
                        const remainingViews = savedViews.filter((entry) => entry.id !== view.id);
                        writeSavedViews(remainingViews);

                        if (activeViewId === view.id) {
                            activeViewId = '__default__';
                            draftColumns = [...defaultColumns];
                            applyVisibleColumns(defaultColumns);
                        }

                        renderSavedViews();
                        renderColumnLists();
                    });

                    item.appendChild(removeButton);
                }

                host.appendChild(item);
            });
        });
    };

    const applyVisibleColumns = (columns, persist = true) => {
        const visibleColumns = normalizeColumns(columns);

        appliedColumns = [...visibleColumns];
        reorderTables(visibleColumns);
        updateTreeDetailColspan(visibleColumns);

        allColumnKeys.forEach((columnKey) => {
            detailRoot.querySelectorAll(`[data-detail-column="${columnKey}"]`).forEach((cell) => {
                cell.hidden = !visibleColumns.includes(columnKey);
            });
        });

        if (persist) {
            persistVisibleColumns(visibleColumns);
        }

        activeViewId = resolveActiveViewId(visibleColumns);
        renderSavedViews();
    };

    const applyTreeSearch = () => {
        const pane = getActivePane();

        if (!pane) {
            return;
        }

        const query = (searchInput ? searchInput.value : '').trim().toLowerCase();

        if (query === '') {
            collapseAllInPane(pane);
            return;
        }

        const { rows, detailRows } = getPaneCache(pane);

        rows.forEach((row) => {
            const matches = (row.dataset.treeSearchText || '').toLowerCase().includes(query);
            row.hidden = !matches;

            if (matches && row.querySelector('[data-tree-toggle]')) {
                setToggleState(row, true);
            } else {
                setToggleState(row, false);
            }
        });

        detailRows.forEach((detailRow) => {
            const parentRow = findTreeRow(pane, detailRow.dataset.parentId || '');
            detailRow.hidden = !parentRow || parentRow.hidden || !parentRow.classList.contains('tree-row--expanded');
        });
    };

    const setActiveTableView = (viewId) => {
        activeTableViewId = viewId;

        tableViewButtons.forEach((button) => {
            const isActive = button.dataset.detailTableView === viewId;
            button.classList.toggle('is-active', isActive);
            button.setAttribute('aria-pressed', isActive ? 'true' : 'false');
        });

        tablePanes.forEach((pane) => {
            pane.hidden = pane.dataset.detailTablePane !== viewId;
        });

        applyTreeSearch();
    };

    const openModal = () => {
        if (!modal) {
            return;
        }

        draftColumns = [...appliedColumns];
        renderSavedViews();
        renderColumnLists();
        modal.hidden = false;
        modal.classList.add('is-open');
        modal.setAttribute('aria-hidden', 'false');
        document.body.classList.add('has-modal-open');

        if (openModalButton) {
            openModalButton.setAttribute('aria-expanded', 'true');
        }

        if (viewNameInput) {
            viewNameInput.value = '';
        }
    };

    const closeModal = () => {
        if (!modal) {
            return;
        }

        modal.hidden = true;
        modal.classList.remove('is-open');
        modal.setAttribute('aria-hidden', 'true');
        document.body.classList.remove('has-modal-open');

        if (openModalButton) {
            openModalButton.setAttribute('aria-expanded', 'false');
        }
    };

    tableViewButtons.forEach((button) => {
        button.addEventListener('click', () => {
            const viewId = button.dataset.detailTableView;

            if (!viewId) {
                return;
            }

            setActiveTableView(viewId);
        });
    });

    detailRoot.querySelectorAll('[data-tree-toggle]').forEach((button) => {
        button.addEventListener('click', () => {
            const row = button.closest('[data-tree-row]');
            const pane = button.closest('[data-detail-table-pane]');

            if (!row || !pane) {
                return;
            }

            const nodeId = row.dataset.treeId || '';
            const expanded = button.getAttribute('aria-expanded') === 'true';
            setNodeExpanded(pane, nodeId, !expanded);
        });
    });

    if (expandAllButton) {
        expandAllButton.addEventListener('click', () => {
            const pane = getActivePane();

            if (pane) {
                expandAllInPane(pane);
            }
        });
    }

    if (collapseAllButton) {
        collapseAllButton.addEventListener('click', () => {
            const pane = getActivePane();

            if (pane) {
                collapseAllInPane(pane);
            }
        });
    }

    if (openModalButton) {
        openModalButton.addEventListener('click', openModal);
    }

    closeModalButtons.forEach((button) => {
        button.addEventListener('click', closeModal);
    });

    if (cancelModalButton) {
        cancelModalButton.addEventListener('click', closeModal);
    }

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && modal && !modal.hidden) {
            closeModal();
        }
    });

    defaultViewButtons.forEach((button) => {
        button.addEventListener('click', () => {
            if (button.closest('[data-detail-views-host="modal"]')) {
                activeViewId = '__default__';
                draftColumns = [...defaultColumns];
                renderSavedViews();
                renderColumnLists();
                return;
            }

            applyVisibleColumns(defaultColumns);
        });
    });

    if (applyColumnsButton) {
        applyColumnsButton.addEventListener('click', () => {
            applyVisibleColumns(draftColumns);
            closeModal();
        });
    }

    if (saveViewButton && viewNameInput) {
        saveViewButton.addEventListener('click', () => {
            const trimmedName = viewNameInput.value.trim();

            if (trimmedName === '') {
                viewNameInput.focus();
                return;
            }

            const viewId = slugify(trimmedName) || `view-${Date.now()}`;
            const savedViews = readSavedViews();
            const existingView = savedViews.find((view) => view.id === viewId);

            if (!existingView && savedViews.length >= maxSavedViews) {
                window.alert('Voce pode guardar ate 5 visoes personalizadas.');
                return;
            }

            const nextViews = savedViews.filter((view) => view.id !== viewId);
            nextViews.push({
                id: viewId,
                name: trimmedName,
                columns: normalizeColumns(draftColumns),
            });

            writeSavedViews(nextViews);
            activeViewId = viewId;
            viewNameInput.value = '';
            renderSavedViews();
        });
    }

    if (searchInput) {
        searchInput.addEventListener('input', applyTreeSearch);
    }

    appliedColumns = readStoredColumns();
    draftColumns = [...appliedColumns];
    applyVisibleColumns(appliedColumns, false);
    renderSavedViews();
    setActiveTableView(activeTableViewId);
}

const omegaLayout = document.querySelector('[data-omega-layout]');

if (omegaLayout) {
    const sidebarToggle = omegaLayout.querySelector('[data-omega-sidebar-toggle]');
    const filtersToggle = omegaLayout.querySelector('[data-omega-filters-toggle]');
    const registerToggle = omegaLayout.querySelector('[data-omega-register-toggle]');
    const selectionBar = omegaLayout.querySelector('[data-omega-selection-bar]');
    const selectionCount = omegaLayout.querySelector('[data-omega-selection-count]');
    const visibleLinesPill = omegaLayout.querySelector('[data-omega-visible-lines-pill]');
    const listSummary = omegaLayout.querySelector('[data-omega-list-summary]');
    const paginationSummary = omegaLayout.querySelector('[data-omega-pagination-summary]');
    const listShell = omegaLayout.querySelector('.omega-list-shell');
    const emptyState = listShell ? listShell.querySelector('.omega-empty-state') : null;
    const toolbarSearchInput = omegaLayout.querySelector('#omega-search-input');
    const filtersModal = omegaLayout.querySelector('[data-omega-filters-modal]');
    const filtersCloseButtons = Array.from(omegaLayout.querySelectorAll('[data-omega-filters-close]'));
    const filterForm = filtersModal ? filtersModal.querySelector('form') : null;
    const filterSearchInput = filterForm ? filterForm.querySelector('input[name="omega_search"]') : null;
    const filterDepartmentField = filterForm ? filterForm.querySelector('[data-omega-filter-department]') : null;
    const filterTypeField = filterForm ? filterForm.querySelector('[data-omega-filter-type]') : null;
    const filterStatusInput = filterForm ? filterForm.querySelector('[data-omega-status-input]') : null;
    const statusPicker = filterForm ? filterForm.querySelector('[data-omega-status-picker]') : null;
    const statusChips = Array.from(omegaLayout.querySelectorAll('[data-omega-status-chip]'));
    const detailPanel = omegaLayout.querySelector('[data-omega-detail-panel]');
    const detailCloseButtons = Array.from(omegaLayout.querySelectorAll('[data-omega-detail-close]'));
    const detailEditButton = omegaLayout.querySelector('[data-omega-detail-edit]');
    const detailProgressSteps = detailPanel ? Array.from(detailPanel.querySelectorAll('[data-omega-progress-step]')) : [];
    const detailThreadHost = detailPanel ? detailPanel.querySelector('[data-omega-detail-thread]') : null;
    const detailThreadForm = detailPanel ? detailPanel.querySelector('[data-omega-thread-form]') : null;
    const detailThreadInput = detailPanel ? detailPanel.querySelector('[data-omega-thread-input]') : null;
    const detailThreadSubmitButton = detailThreadForm ? detailThreadForm.querySelector('[type="submit"]') : null;
    const detailThreadFeedback = detailPanel ? detailPanel.querySelector('[data-omega-thread-feedback]') : null;
    const detailThreadHint = detailPanel ? detailPanel.querySelector('[data-omega-thread-hint]') : null;
    const detailThreadRoleButtons = detailPanel ? Array.from(detailPanel.querySelectorAll('[data-omega-thread-role]')) : [];
    const detailThreadCallIdInput = detailPanel ? detailPanel.querySelector('[data-omega-thread-call-id]') : null;
    const detailThreadRoleInput = detailPanel ? detailPanel.querySelector('[data-omega-thread-role-input]') : null;
    const detailThreadAuthorFunctionalInput = detailPanel ? detailPanel.querySelector('[data-omega-thread-author-functional]') : null;
    const editorPanel = omegaLayout.querySelector('[data-omega-editor-panel]');
    const editorCloseButtons = Array.from(omegaLayout.querySelectorAll('[data-omega-editor-close]'));
    const editorForm = editorPanel ? editorPanel.querySelector('[data-omega-editor-form]') : null;
    const editorSubmitButton = editorForm ? editorForm.querySelector('[type="submit"]') : null;
    const editorFeedback = editorPanel ? editorPanel.querySelector('[data-omega-editor-feedback]') : null;
    const activeViewCount = omegaLayout.querySelector('.omega-sidebar__item.is-active .omega-sidebar__item-count');
    const storageKey = 'novo-pobj:omega-sidebar-collapsed';
    const initialFiltersButtonActive = Boolean(filtersToggle && filtersToggle.classList.contains('is-active'));
    const currentUserName = (omegaLayout.dataset.omegaCurrentName || 'Usuario').trim();
    const currentFunctional = (omegaLayout.dataset.omegaCurrentFunctional || '').trim();
    const currentView = (omegaLayout.dataset.omegaCurrentView || 'my-calls').trim();
    const canAccessDashboard = detailThreadRoleButtons.some((button) => (button.getAttribute('data-omega-thread-role') || 'user') === 'analyst');
    const canViewPriority = omegaLayout.dataset.omegaCanViewPriority === '1';
    const terminalStatusCodes = new Set(['FECHADO', 'FINALIZADO', 'REJEITADO', 'CANCELADO', 'RESOLVIDO']);
    const defaultThreadHint = detailThreadHint instanceof HTMLElement
        ? String(detailThreadHint.textContent || '').replace(/\s+/g, ' ').trim() || 'O comentario passa a fazer parte do historico oficial do chamado.'
        : 'O comentario passa a fazer parte do historico oficial do chamado.';
    const defaultThreadPlaceholder = detailThreadInput instanceof HTMLTextAreaElement
        ? String(detailThreadInput.getAttribute('placeholder') || '').trim()
        : '';
    const countsState = {
        total: Number.parseInt(omegaLayout.dataset.omegaTotalRows || '0', 10) || 0,
        visible: Number.parseInt(omegaLayout.dataset.omegaVisibleRows || '0', 10) || 0,
        pageStart: Number.parseInt(omegaLayout.dataset.omegaPageStart || '0', 10) || 0,
        pageEnd: Number.parseInt(omegaLayout.dataset.omegaPageEnd || '0', 10) || 0,
    };
    const editorFields = {};
    let selectedStatuses = [];
    let activeDetailRecord = null;
    let activeThreadRole = 'user';
    let commentRequestInFlight = false;
    let editorRequestInFlight = false;
    let editorSourceRecord = null;

    if (editorPanel) {
        editorPanel.querySelectorAll('[data-omega-editor-field]').forEach((field) => {
            const fieldName = field.getAttribute('data-omega-editor-field');

            if (fieldName) {
                editorFields[fieldName] = field;
            }
        });
    }

    const departmentTypeMap = (() => {
        const sourceElement = editorForm || filterForm;

        if (!sourceElement) {
            return {};
        }

        try {
            const parsedMap = JSON.parse(sourceElement.getAttribute('data-omega-department-type-map') || '{}');
            return parsedMap && typeof parsedMap === 'object' ? parsedMap : {};
        } catch (error) {
            return {};
        }
    })();

    const queueDepartmentMap = (() => {
        if (!editorForm) {
            return {};
        }

        try {
            const parsedMap = JSON.parse(editorForm.getAttribute('data-omega-queue-department-map') || '{}');
            return parsedMap && typeof parsedMap === 'object' ? parsedMap : {};
        } catch (error) {
            return {};
        }
    })();

    const queueAnalystMap = (() => {
        if (!editorForm) {
            return {};
        }

        try {
            const parsedMap = JSON.parse(editorForm.getAttribute('data-omega-queue-analyst-map') || '{}');
            return parsedMap && typeof parsedMap === 'object' ? parsedMap : {};
        } catch (error) {
            return {};
        }
    })();

    const allTypeOptions = (() => {
        const indexedOptions = new Map();
        const normalizeOptionText = (value) => String(value || '').replace(/\s+/g, ' ').trim();

        Object.values(departmentTypeMap).forEach((departmentOptions) => {
            if (!Array.isArray(departmentOptions)) {
                return;
            }

            departmentOptions.forEach((option) => {
                if (!option || typeof option !== 'object') {
                    return;
                }

                const value = normalizeOptionText(option.value || '');
                const label = normalizeOptionText(option.label || value);

                if (value === '' || label === '' || indexedOptions.has(value)) {
                    return;
                }

                indexedOptions.set(value, { value, label });
            });
        });

        return Array.from(indexedOptions.values());
    })();

    const editorDefaults = {
        title: editorFields.title && 'value' in editorFields.title ? String(editorFields.title.value || '') : 'Novo chamado Omega',
        user: editorFields.user && 'value' in editorFields.user ? String(editorFields.user.value || currentUserName) : currentUserName,
        user_code: editorFields.user_code && 'value' in editorFields.user_code ? String(editorFields.user_code.value || currentFunctional) : currentFunctional,
        department: editorFields.department instanceof HTMLSelectElement ? editorFields.department.value : '',
        type: editorFields.type instanceof HTMLSelectElement ? editorFields.type.value : '',
        queue: editorFields.queue && 'value' in editorFields.queue ? String(editorFields.queue.value || 'POBJ') : 'POBJ',
        analyst_functional: editorFields.analyst_functional && 'value' in editorFields.analyst_functional ? String(editorFields.analyst_functional.value || '') : '',
        priority: editorFields.priority && 'value' in editorFields.priority ? String(editorFields.priority.value || 'Média') : 'Média',
        status_code: editorFields.status_code instanceof HTMLSelectElement ? editorFields.status_code.value : '',
        description: editorFields.description && 'value' in editorFields.description ? String(editorFields.description.value || '') : '',
    };

    const getDepartmentForQueue = (queueValue) => collapseWhitespace(queueDepartmentMap[collapseWhitespace(queueValue)] || '');

    const getDepartmentTypeOptions = (departmentValue) => {
        const normalizedDepartment = collapseWhitespace(departmentValue);
        const rawOptions = departmentTypeMap[normalizedDepartment];

        if (!Array.isArray(rawOptions)) {
            return [];
        }

        return rawOptions
            .map((option) => {
                if (!option || typeof option !== 'object') {
                    return null;
                }

                const value = collapseWhitespace(option.value || '');
                const label = collapseWhitespace(option.label || value);

                if (value === '' || label === '') {
                    return null;
                }

                return { value, label };
            })
            .filter((option) => option !== null);
    };

    const resolveQueueForDepartment = (departmentValue, preferredQueue = '') => {
        if (!(editorFields.queue instanceof HTMLSelectElement)) {
            return collapseWhitespace(preferredQueue || editorDefaults.queue || '');
        }

        const normalizedDepartment = collapseWhitespace(departmentValue);
        const requestedQueue = collapseWhitespace(preferredQueue || editorFields.queue.value || '');

        if (requestedQueue !== '' && getDepartmentForQueue(requestedQueue) === normalizedDepartment) {
            return requestedQueue;
        }

        const matchingOption = Array.from(editorFields.queue.options).find((option) => getDepartmentForQueue(option.value) === normalizedDepartment);

        if (matchingOption) {
            return matchingOption.value;
        }

        return requestedQueue || editorFields.queue.options[0]?.value || '';
    };

    const syncEditorAnalystState = (preferredAnalyst = '') => {
        if (!(editorFields.analyst_functional instanceof HTMLSelectElement) || !(editorFields.queue instanceof HTMLSelectElement)) {
            return;
        }

        const selectedQueue = collapseWhitespace(editorFields.queue.value || '');
        const rawOptions = Array.isArray(queueAnalystMap[selectedQueue]) ? queueAnalystMap[selectedQueue] : [];
        const fragment = document.createDocumentFragment();
        const placeholderOption = document.createElement('option');
        placeholderOption.value = '';
        placeholderOption.textContent = rawOptions.length > 0 ? 'Sem analista' : 'Sem analistas disponíveis';
        fragment.appendChild(placeholderOption);

        let resolvedValue = '';
        const targetAnalyst = collapseWhitespace(preferredAnalyst || editorFields.analyst_functional.value || '');

        rawOptions.forEach((option) => {
            if (!option || typeof option !== 'object') {
                return;
            }

            const optionValue = collapseWhitespace(option.value || option.functional || '');
            const optionLabel = collapseWhitespace(option.label || option.name || optionValue);

            if (optionValue === '' || optionLabel === '') {
                return;
            }

            const optionElement = document.createElement('option');
            optionElement.value = optionValue;
            optionElement.textContent = optionLabel;

            if (optionValue === targetAnalyst) {
                resolvedValue = optionValue;
            }

            fragment.appendChild(optionElement);
        });

        editorFields.analyst_functional.replaceChildren(fragment);
        editorFields.analyst_functional.value = resolvedValue;
    };

    const syncEditorDepartmentState = (preferredType = '', preferredQueue = '', preferredAnalyst = '') => {
        if (!(editorFields.department instanceof HTMLSelectElement) || !(editorFields.type instanceof HTMLSelectElement)) {
            return;
        }

        const selectedDepartment = collapseWhitespace(editorFields.department.value || 'POBJ') || 'POBJ';
        const typeOptions = getDepartmentTypeOptions(selectedDepartment);
        const targetType = collapseWhitespace(preferredType || editorFields.type.value || '');

        if (editorFields.queue && 'value' in editorFields.queue) {
            editorFields.queue.value = resolveQueueForDepartment(selectedDepartment, preferredQueue);
        }

        if (typeOptions.length === 0) {
            syncEditorAnalystState(preferredAnalyst);
            return;
        }

        const fragment = document.createDocumentFragment();
        let resolvedValue = typeOptions[0].value;

        typeOptions.forEach((option) => {
            const optionElement = document.createElement('option');
            optionElement.value = option.value;
            optionElement.textContent = option.label;

            if (option.value === targetType) {
                resolvedValue = option.value;
            }

            fragment.appendChild(optionElement);
        });

        editorFields.type.replaceChildren(fragment);
        editorFields.type.value = resolvedValue;
        syncEditorAnalystState(preferredAnalyst);
    };

    const syncEditorQueueState = (preferredAnalyst = '') => {
        if (!(editorFields.queue instanceof HTMLSelectElement)) {
            return;
        }

        const selectedQueue = collapseWhitespace(editorFields.queue.value || '');
        const resolvedDepartment = getDepartmentForQueue(selectedQueue)
            || collapseWhitespace(editorFields.department instanceof HTMLSelectElement ? editorFields.department.value : editorDefaults.department)
            || 'POBJ';
        const preferredType = editorFields.type instanceof HTMLSelectElement ? editorFields.type.value : editorDefaults.type;

        if (editorFields.department instanceof HTMLSelectElement && editorFields.department.value !== resolvedDepartment) {
            setFieldValue(editorFields.department, resolvedDepartment);
        }

        syncEditorDepartmentState(preferredType, selectedQueue, preferredAnalyst);
    };

    const syncFilterDepartmentState = () => {
        if (!(filterDepartmentField instanceof HTMLSelectElement) || !(filterTypeField instanceof HTMLSelectElement)) {
            return;
        }

        const selectedDepartment = collapseWhitespace(filterDepartmentField.value || '');
        const currentType = collapseWhitespace(filterTypeField.value || '');
        const options = selectedDepartment === '' ? allTypeOptions : getDepartmentTypeOptions(selectedDepartment);
        const placeholderLabel = selectedDepartment === '' ? 'Todos os assuntos' : 'Todos os assuntos';
        const fragment = document.createDocumentFragment();
        const placeholderOption = document.createElement('option');
        placeholderOption.value = '';
        placeholderOption.textContent = placeholderLabel;
        fragment.appendChild(placeholderOption);
        let resolvedValue = '';

        options.forEach((option) => {
            const optionElement = document.createElement('option');
            optionElement.value = option.value;
            optionElement.textContent = option.label;

            if (option.value === currentType) {
                resolvedValue = option.value;
            }

            fragment.appendChild(optionElement);
        });

        filterTypeField.replaceChildren(fragment);
        filterTypeField.value = resolvedValue;
    };

    const setSidebarCollapsed = (collapsed) => {
        omegaLayout.classList.toggle('is-sidebar-collapsed', collapsed);

        if (sidebarToggle) {
            sidebarToggle.setAttribute('aria-label', collapsed ? 'Expandir menu lateral' : 'Recolher menu lateral');
        }

        try {
            window.localStorage.setItem(storageKey, collapsed ? '1' : '0');
        } catch (error) {
            console.warn('Nao foi possivel persistir o estado da sidebar do Omega.', error);
        }
    };

    const escapeHtml = (value) => String(value ?? '').replace(/[&<>"']/g, (character) => {
        switch (character) {
            case '&':
                return '&amp;';
            case '<':
                return '&lt;';
            case '>':
                return '&gt;';
            case '"':
                return '&quot;';
            case '\'':
                return '&#39;';
            default:
                return character;
        }
    });

    const collapseWhitespace = (value) => String(value ?? '').replace(/\s+/g, ' ').trim();

    const truncateText = (value, limit = 88) => {
        const normalized = collapseWhitespace(value);

        if (normalized.length <= limit) {
            return normalized;
        }

        return `${normalized.slice(0, Math.max(0, limit - 3)).trim()}...`;
    };

    const parseDate = (value) => {
        const normalized = String(value || '').trim();

        if (normalized === '') {
            return null;
        }

        const parsed = new Date(normalized.replace(' ', 'T'));
        return Number.isNaN(parsed.getTime()) ? null : parsed;
    };

    const formatDate = (value) => {
        const parsed = parseDate(value);

        if (!parsed) {
            return String(value || '').trim() || '-';
        }

        return parsed.toLocaleDateString('pt-BR');
    };

    const formatDateTime = (value) => {
        const parsed = parseDate(value);

        if (!parsed) {
            return String(value || '').trim() || '-';
        }

        return parsed.toLocaleString('pt-BR');
    };

    const toOmegaDateTime = (date = new Date()) => date.toISOString().slice(0, 19).replace('T', ' ');

    const resolvePriorityTone = (label) => {
        switch (collapseWhitespace(label).toLowerCase()) {
            case 'alta':
                return 'is-high';
            case 'baixa':
                return 'is-low';
            default:
                return 'is-medium';
        }
    };

    const formatIdDisplay = (value) => {
        const digits = String(value ?? '').replace(/\D+/g, '');

        if (digits === '') {
            return '000000';
        }

        return digits.padStart(6, '0');
    };

    const getRowElements = () => Array.from(omegaLayout.querySelectorAll('[data-omega-detail-row]'));
    const getRowCheckboxes = () => Array.from(omegaLayout.querySelectorAll('[data-omega-row-select]')).filter((checkbox) => checkbox instanceof HTMLInputElement);
    const getSelectAllCheckbox = () => {
        const checkbox = omegaLayout.querySelector('[data-omega-select-all]');
        return checkbox instanceof HTMLInputElement ? checkbox : null;
    };

    const isPanelOpen = (panel) => panel instanceof HTMLElement && !panel.hidden;

    const setPanelOpen = (panel, open) => {
        if (!(panel instanceof HTMLElement)) {
            return;
        }

        panel.hidden = !open;
        panel.classList.toggle('is-open', open);
    };

    const syncScrollLock = () => {
        const hasOpenLayer = [filtersModal, detailPanel, editorPanel].some((panel) => isPanelOpen(panel));
        document.documentElement.style.overflow = hasOpenLayer ? 'hidden' : '';
    };

    const syncSelectionState = () => {
        const rowCheckboxes = getRowCheckboxes();
        const selectedCount = rowCheckboxes.filter((checkbox) => checkbox.checked).length;
        const selectAllCheckbox = getSelectAllCheckbox();

        if (selectionBar) {
            selectionBar.hidden = selectedCount === 0;
        }

        if (selectionCount) {
            selectionCount.textContent = String(selectedCount);
        }

        if (selectAllCheckbox instanceof HTMLInputElement) {
            selectAllCheckbox.checked = rowCheckboxes.length > 0 && selectedCount === rowCheckboxes.length;
            selectAllCheckbox.indeterminate = selectedCount > 0 && selectedCount < rowCheckboxes.length;
        }
    };

    const getPageStart = () => {
        if (countsState.pageStart > 0) {
            return countsState.pageStart;
        }

        return countsState.visible > 0 ? 1 : 0;
    };

    const updateListMetrics = () => {
        countsState.visible = getRowElements().length;

        if (countsState.visible > 0 && countsState.pageStart === 0) {
            countsState.pageStart = 1;
        }

        if (countsState.total < countsState.visible) {
            countsState.total = countsState.visible;
        }

        const pageStart = getPageStart();
        const pageEnd = countsState.visible > 0 ? pageStart + countsState.visible - 1 : 0;
        countsState.pageEnd = pageEnd;
        omegaLayout.dataset.omegaTotalRows = String(countsState.total);
        omegaLayout.dataset.omegaVisibleRows = String(countsState.visible);
        omegaLayout.dataset.omegaPageStart = String(countsState.pageStart);
        omegaLayout.dataset.omegaPageEnd = String(countsState.pageEnd);

        if (visibleLinesPill) {
            visibleLinesPill.textContent = `Chamados no recorte: ${countsState.total}`;
        }

        if (listSummary) {
            listSummary.textContent = countsState.visible > 0
                ? `Exibindo ${pageStart} a ${pageEnd} de ${countsState.total} chamados.`
                : 'Nenhum chamado encontrado neste recorte.';
        }

        if (paginationSummary) {
            paginationSummary.textContent = countsState.visible > 0
                ? `${pageStart} - ${pageEnd} de ${countsState.total} chamados`
                : '0 chamados';
        }

        if (activeViewCount) {
            activeViewCount.textContent = String(countsState.total);
        }
    };

    const normalizeThreadEntries = (thread, recordContext = {}) => {
        let rawEntries = [];

        if (Array.isArray(thread)) {
            rawEntries = thread;
        } else if (typeof thread === 'string' && thread.trim() !== '') {
            try {
                const parsedThread = JSON.parse(thread);
                rawEntries = Array.isArray(parsedThread) ? parsedThread : [];
            } catch (error) {
                rawEntries = [];
            }
        }

        const fallbackUser = collapseWhitespace(recordContext.userLabel || recordContext.user || currentUserName) || currentUserName;
        const fallbackAnalyst = collapseWhitespace(recordContext.analystLabel || recordContext.analyst || 'Sem analista') || 'Sem analista';
        const fallbackDescription = String(recordContext.description || '').trim();
        const fallbackOpenedAt = String(recordContext.openedAt || recordContext.opened_at || '').trim();
        const fallbackUpdatedAt = String(recordContext.updatedAt || recordContext.updated_at || fallbackOpenedAt).trim();
        const fallbackStatus = collapseWhitespace(recordContext.statusLabel || recordContext.status || 'Sem status') || 'Sem status';
        const hasMeaningfulDescription = fallbackDescription !== '' && fallbackDescription !== 'Sem observacoes registradas.';

        const normalizedEntries = rawEntries
            .map((entry) => {
                if (!entry || typeof entry !== 'object') {
                    return null;
                }

                const role = collapseWhitespace(entry.role || 'user').toLowerCase() === 'analyst' ? 'analyst' : 'user';
                const author = collapseWhitespace(entry.author || (role === 'analyst' ? fallbackAnalyst : fallbackUser))
                    || (role === 'analyst' ? fallbackAnalyst : fallbackUser);
                const message = String(entry.message || '').trim();
                const timestamp = String(entry.timestamp || '').trim();

                if (message === '') {
                    return null;
                }

                return {
                    role,
                    author,
                    timestamp,
                    message,
                };
            })
            .filter((entry) => entry !== null);

        if (normalizedEntries.length > 0) {
            return normalizedEntries;
        }

        const fallbackEntries = [];

        if (hasMeaningfulDescription) {
            fallbackEntries.push({
                role: 'user',
                author: fallbackUser,
                timestamp: fallbackOpenedAt,
                message: fallbackDescription,
            });
        }

        if (fallbackUpdatedAt !== '' && fallbackUpdatedAt !== fallbackOpenedAt) {
            fallbackEntries.push({
                role: 'analyst',
                author: fallbackAnalyst,
                timestamp: fallbackUpdatedAt,
                message: `Status atualizado para ${fallbackStatus}.`,
            });
        }

        return fallbackEntries;
    };

    const normalizeRecord = (record) => {
        const openedAt = String(record.openedAt || record.opened_at || record.opened || '').trim();
        const updatedAt = String(record.updatedAt || record.updated_at || record.updated || openedAt).trim();
        const description = String(record.description || '').trim() || 'Sem observacoes registradas.';
        const previewTitle = collapseWhitespace(record.previewTitle || record.title || 'Chamado Omega') || 'Chamado Omega';
        const previewCopy = collapseWhitespace(record.previewCopy || truncateText(description, 96)) || 'Sem detalhes adicionais.';
        const departmentLabel = collapseWhitespace(record.departmentLabel || record.department || 'POBJ') || 'POBJ';
        const typeLabel = collapseWhitespace(record.typeLabel || record.type || 'Outros') || 'Outros';
        const priorityLabel = collapseWhitespace(record.priorityLabel || record.priority || 'Media') || 'Media';
        const statusLabel = collapseWhitespace(record.statusLabel || record.status || 'Sem status') || 'Sem status';
        const userLabel = collapseWhitespace(record.userLabel || record.user || currentUserName) || currentUserName;
        const userCode = collapseWhitespace(record.userCode || record.user_code || currentFunctional);
        const analystLabel = collapseWhitespace(record.analystLabel || record.analyst || 'Sem analista') || 'Sem analista';
        const analystCode = collapseWhitespace(record.analystCode || record.analyst_code || '');

        const normalizedRecord = {
            idDisplay: formatIdDisplay(record.idDisplay || record.id || '000000'),
            previewTitle,
            previewCopy,
            description,
            userLabel,
            userCode,
            analystLabel,
            analystCode,
            departmentLabel,
            typeLabel,
            priorityLabel,
            productLabel: collapseWhitespace(record.productLabel || record.product || typeLabel) || typeLabel,
            queueCode: collapseWhitespace(record.queueCode || record.queue_code || ''),
            queueLabel: collapseWhitespace(record.queueLabel || record.queue || departmentLabel) || departmentLabel,
            openedAt,
            updatedAt,
            closedAt: String(record.closedAt || record.closed_at || '').trim(),
            openedDisplay: collapseWhitespace(record.openedDisplay || record.opened_display || formatDateTime(openedAt)) || '-',
            updatedDisplay: collapseWhitespace(record.updatedDisplay || record.updated_display || formatDateTime(updatedAt)) || '-',
            closedDisplay: collapseWhitespace(record.closedDisplay || record.closed_display || formatDateTime(record.closedAt || record.closed_at || '')) || '-',
            statusLabel,
            statusCode: collapseWhitespace(record.statusCode || record.status_code || 'SEM_STATUS') || 'SEM_STATUS',
            statusColor: collapseWhitespace(record.statusColor || record.status_color || '#cbd5e1') || '#cbd5e1',
            resolutionFinal: String(record.resolutionFinal || record.resolution_final || '').trim() || 'Sem finalizacao registrada.',
            sourceView: collapseWhitespace(record.sourceView || record.source_view || currentView) || currentView,
        };

        normalizedRecord.thread = normalizeThreadEntries(
            record.thread || record.timeline || record.timelineEntries || record.timeline_entries,
            normalizedRecord
        );

        return normalizedRecord;
    };

    const buildRecordFromRow = (row) => normalizeRecord({
        idDisplay: row.dataset.omegaId,
        previewTitle: row.dataset.omegaTitle,
        previewCopy: row.dataset.omegaPreview,
        description: row.dataset.omegaDescription,
        userLabel: row.dataset.omegaUser,
        userCode: row.dataset.omegaUserCode,
        analystLabel: row.dataset.omegaAnalyst,
        analystCode: row.dataset.omegaAnalystCode,
        departmentLabel: row.dataset.omegaDepartment,
        typeLabel: row.dataset.omegaType,
        priorityLabel: row.dataset.omegaPriority,
        productLabel: row.dataset.omegaProduct,
        queueCode: row.dataset.omegaQueueCode,
        queueLabel: row.dataset.omegaQueue,
        openedAt: row.dataset.omegaOpened,
        openedDisplay: row.dataset.omegaOpenedDisplay,
        updatedAt: row.dataset.omegaUpdated,
        updatedDisplay: row.dataset.omegaUpdatedDisplay,
        closedAt: row.dataset.omegaClosed,
        closedDisplay: row.dataset.omegaClosedDisplay,
        resolutionFinal: row.dataset.omegaResolution,
        statusLabel: row.dataset.omegaStatus,
        statusCode: row.dataset.omegaStatusCode,
        statusColor: row.dataset.omegaStatusColor,
        thread: row.dataset.omegaThread,
        sourceView: row.dataset.omegaSourceView || currentView,
    });

    const formatThreadMessage = (value) => escapeHtml(String(value || '').trim()).replace(/\n/g, '<br>');

    const buildThreadMarkup = (record) => {
        if (!Array.isArray(record.thread) || record.thread.length === 0) {
            return '<div class="omega-thread__empty">Sem interacoes registradas para este chamado ate o momento.</div>';
        }

        return record.thread.map((entry) => {
            const role = entry.role === 'analyst' ? 'analyst' : 'user';
            const author = collapseWhitespace(entry.author || (role === 'analyst' ? record.analystLabel : record.userLabel))
                || (role === 'analyst' ? record.analystLabel : record.userLabel);
            const timestamp = collapseWhitespace(entry.timestamp || '');
            const cardMarkup = `
                <div class="omega-thread__card">
                    <div class="omega-thread__meta">
                        <strong>${escapeHtml(author)}</strong>
                        <span>${escapeHtml(role === 'analyst' ? 'Analista' : 'Usuario')}</span>
                    </div>
                    <p class="omega-thread__message">${formatThreadMessage(entry.message)}</p>
                </div>
            `;

            return `
                <article class="omega-thread__item is-${role}">
                    <div class="omega-thread__lane omega-thread__lane--left">
                        ${role === 'user' ? cardMarkup : ''}
                    </div>

                    <div class="omega-thread__axis">
                        <span class="omega-thread__stamp">${escapeHtml(timestamp !== '' ? formatDateTime(timestamp) : 'Sem horario informado')}</span>
                        <span class="omega-thread__marker"></span>
                    </div>

                    <div class="omega-thread__lane omega-thread__lane--right">
                        ${role === 'analyst' ? cardMarkup : ''}
                    </div>
                </article>
            `;
        }).join('');
    };

    const syncDetailProgress = (statusCode) => {
        if (detailProgressSteps.length === 0) {
            return;
        }

        const normalizedStatusCode = collapseWhitespace(statusCode).toUpperCase();
        const activeIndex = detailProgressSteps.findIndex((step) => {
            const stepValue = collapseWhitespace(step.getAttribute('data-omega-progress-step') || '').toUpperCase();
            return stepValue === normalizedStatusCode;
        });

        detailProgressSteps.forEach((step, index) => {
            step.classList.remove('is-completed', 'is-current', 'is-upcoming');

            if (activeIndex === -1) {
                step.classList.add('is-upcoming');
                return;
            }

            if (index < activeIndex) {
                step.classList.add('is-completed');
                return;
            }

            if (index === activeIndex) {
                step.classList.add('is-current');
                return;
            }

            step.classList.add('is-upcoming');
        });
    };

    const setThreadRole = (role) => {
        activeThreadRole = role === 'analyst' ? 'analyst' : 'user';

        if (detailThreadRoleInput instanceof HTMLInputElement) {
            detailThreadRoleInput.value = activeThreadRole;
        }

        detailThreadRoleButtons.forEach((button) => {
            const isActive = (button.getAttribute('data-omega-thread-role') || 'user') === activeThreadRole;
            button.classList.toggle('is-active', isActive);
            button.setAttribute('aria-pressed', isActive ? 'true' : 'false');
        });
    };

    const isTerminalRecord = (record) => {
        if (!record || typeof record !== 'object') {
            return false;
        }

        const normalizedStatusCode = collapseWhitespace(record.statusCode || record.status_code || '').toUpperCase();
        return terminalStatusCodes.has(normalizedStatusCode);
    };

    const isRequesterInteractionLocked = (record = activeDetailRecord) => !canAccessDashboard && isTerminalRecord(record);

    const syncDetailInteractionState = (record = activeDetailRecord, inFlight = commentRequestInFlight) => {
        const lockedForRequester = isRequesterInteractionLocked(record);

        if (detailEditButton instanceof HTMLButtonElement || detailEditButton instanceof HTMLInputElement) {
            detailEditButton.disabled = lockedForRequester;
            detailEditButton.setAttribute('aria-disabled', lockedForRequester ? 'true' : 'false');
        }

        if (detailThreadForm instanceof HTMLElement) {
            detailThreadForm.classList.toggle('is-locked', lockedForRequester);
            detailThreadForm.setAttribute('data-omega-thread-locked', lockedForRequester ? 'true' : 'false');
        }

        if (detailThreadHint instanceof HTMLElement) {
            detailThreadHint.textContent = lockedForRequester
                ? 'Chamado finalizado. O solicitante precisa abrir um novo chamado para continuar.'
                : defaultThreadHint;
        }

        if (detailThreadInput instanceof HTMLTextAreaElement) {
            detailThreadInput.disabled = lockedForRequester;
            detailThreadInput.readOnly = inFlight || lockedForRequester;
            detailThreadInput.placeholder = lockedForRequester
                ? 'Chamado finalizado. Abra um novo chamado para continuar.'
                : defaultThreadPlaceholder;
            detailThreadInput.setAttribute('aria-busy', inFlight ? 'true' : 'false');
        }

        detailThreadRoleButtons.forEach((button) => {
            button.disabled = inFlight || lockedForRequester;
        });

        if (detailThreadSubmitButton instanceof HTMLButtonElement || detailThreadSubmitButton instanceof HTMLInputElement) {
            detailThreadSubmitButton.disabled = inFlight || lockedForRequester;
            detailThreadSubmitButton.setAttribute('aria-busy', inFlight ? 'true' : 'false');
        }
    };

    const setCommentSubmissionState = (inFlight) => {
        commentRequestInFlight = inFlight;
        syncDetailInteractionState(activeDetailRecord, inFlight);
    };

    const setCommentFeedback = (message = '', tone = 'neutral') => {
        if (!(detailThreadFeedback instanceof HTMLElement)) {
            return;
        }

        const normalizedMessage = String(message || '').trim();

        if (normalizedMessage === '') {
            detailThreadFeedback.hidden = true;
            detailThreadFeedback.textContent = '';
            detailThreadFeedback.removeAttribute('data-tone');
            return;
        }

        detailThreadFeedback.hidden = false;
        detailThreadFeedback.textContent = normalizedMessage;
        detailThreadFeedback.setAttribute('data-tone', tone);
    };

    const setEditorSubmissionState = (inFlight) => {
        editorRequestInFlight = inFlight;

        Object.values(editorFields).forEach((field) => {
            if (field instanceof HTMLInputElement || field instanceof HTMLSelectElement || field instanceof HTMLTextAreaElement) {
                field.disabled = inFlight;
                field.setAttribute('aria-busy', inFlight ? 'true' : 'false');
            }
        });

        editorCloseButtons.forEach((button) => {
            button.disabled = inFlight;
        });

        if (editorSubmitButton instanceof HTMLButtonElement || editorSubmitButton instanceof HTMLInputElement) {
            editorSubmitButton.disabled = inFlight;
            editorSubmitButton.setAttribute('aria-busy', inFlight ? 'true' : 'false');
        }
    };

    const setEditorFeedback = (message = '', tone = 'neutral') => {
        if (!(editorFeedback instanceof HTMLElement)) {
            return;
        }

        const normalizedMessage = String(message || '').trim();

        if (normalizedMessage === '') {
            editorFeedback.hidden = true;
            editorFeedback.textContent = '';
            editorFeedback.removeAttribute('data-tone');
            return;
        }

        editorFeedback.hidden = false;
        editorFeedback.textContent = normalizedMessage;
        editorFeedback.setAttribute('data-tone', tone);
    };

    const submitCommentToServer = async (record, message, role) => {
        if (!detailThreadForm) {
            throw new Error('Formulario de comentario indisponivel.');
        }

        const authorRole = role === 'analyst' ? 'analyst' : 'user';
        const formData = new FormData(detailThreadForm);
        formData.set('omega_comment_call_id', formatIdDisplay(record.idDisplay));
        formData.set('omega_comment_role', authorRole);
        formData.set('omega_comment_author_functional', authorRole === 'analyst' ? currentFunctional : (record.userCode || currentFunctional));
        formData.set('omega_comment_text', message);

        const response = await fetch(detailThreadForm.getAttribute('action') || window.location.pathname, {
            method: 'POST',
            body: formData,
            credentials: 'same-origin',
            headers: {
                Accept: 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
            },
        });

        const responseText = await response.text();
        let payload = null;

        if (responseText.trim() !== '') {
            try {
                payload = JSON.parse(responseText);
            } catch (error) {
                throw new Error('Nao foi possivel interpretar a resposta do comentario.');
            }
        }

        if (!response.ok || !payload || payload.ok !== true) {
            throw new Error(payload && typeof payload.message === 'string' && payload.message.trim() !== ''
                ? payload.message.trim()
                : 'Nao foi possivel salvar o comentario.');
        }

        const persistedComment = payload.comment && typeof payload.comment === 'object' ? payload.comment : {};
        const persistedRole = collapseWhitespace(persistedComment.role || authorRole).toLowerCase() === 'analyst' ? 'analyst' : 'user';

        return {
            role: persistedRole,
            author: persistedRole === 'analyst' ? currentUserName : record.userLabel,
            timestamp: String(persistedComment.timestamp || toOmegaDateTime()).trim(),
            message: String(persistedComment.message || message).trim() || message,
        };
    };

    const renderRowElement = (rawRecord) => {
        const record = normalizeRecord(rawRecord);
        const row = document.createElement('tr');
        const threadPayload = JSON.stringify(record.thread || []);
        row.className = 'omega-table__row';
        row.tabIndex = 0;
        row.setAttribute('data-omega-detail-row', '');
        row.setAttribute('data-omega-source-view', record.sourceView);
        row.setAttribute('data-omega-id', record.idDisplay);
        row.setAttribute('data-omega-title', record.previewTitle);
        row.setAttribute('data-omega-preview', record.previewCopy);
        row.setAttribute('data-omega-description', record.description);
        row.setAttribute('data-omega-user', record.userLabel);
        row.setAttribute('data-omega-user-code', record.userCode);
        row.setAttribute('data-omega-analyst', record.analystLabel);
        row.setAttribute('data-omega-analyst-code', record.analystCode);
        row.setAttribute('data-omega-department', record.departmentLabel);
        row.setAttribute('data-omega-type', record.typeLabel);
        row.setAttribute('data-omega-priority', record.priorityLabel);
        row.setAttribute('data-omega-queue-code', record.queueCode);
        row.setAttribute('data-omega-queue', record.queueLabel);
        row.setAttribute('data-omega-opened', record.openedAt);
        row.setAttribute('data-omega-opened-display', record.openedDisplay);
        row.setAttribute('data-omega-updated', record.updatedAt);
        row.setAttribute('data-omega-updated-display', record.updatedDisplay);
        row.setAttribute('data-omega-closed', record.closedAt || '');
        row.setAttribute('data-omega-closed-display', record.closedDisplay || '-');
        row.setAttribute('data-omega-resolution', record.resolutionFinal || 'Sem finalizacao registrada.');
        row.setAttribute('data-omega-status', record.statusLabel);
        row.setAttribute('data-omega-status-code', record.statusCode);
        row.setAttribute('data-omega-status-color', record.statusColor);
        row.setAttribute('data-omega-thread', threadPayload);
        row.setAttribute('aria-label', `Abrir detalhes do chamado ${record.idDisplay}`);
        row.innerHTML = `
            <td class="omega-table__check-col">
                <input type="checkbox" value="${escapeHtml(record.idDisplay)}" data-omega-row-select>
            </td>
            <td class="omega-table__id-cell">${escapeHtml(record.idDisplay)}</td>
            <td class="omega-table__preview-cell" title="${escapeHtml(record.previewTitle)}">
                <strong>${escapeHtml(record.previewTitle)}</strong>
                <span>${escapeHtml(record.previewCopy)}</span>
            </td>
            <td class="omega-table__meta-cell" title="${escapeHtml(record.departmentLabel)}">${escapeHtml(record.departmentLabel)}</td>
            <td class="omega-table__meta-cell" title="${escapeHtml(record.typeLabel)}">${escapeHtml(record.typeLabel)}</td>
            <td class="omega-table__person-cell" title="${escapeHtml(record.userLabel)}">
                <strong>${escapeHtml(record.userLabel)}</strong>
                <span>${escapeHtml(record.userCode)}</span>
            </td>
            ${canViewPriority ? `
                <td class="omega-table__pill-cell">
                    <span class="omega-priority ${escapeHtml(resolvePriorityTone(record.priorityLabel))}">
                        <span class="omega-pill__icon" aria-hidden="true"></span>
                        ${escapeHtml(record.priorityLabel)}
                    </span>
                </td>
            ` : ''}
            <td class="omega-table__person-cell" title="${escapeHtml(record.analystLabel || '-')}">
                <strong>${escapeHtml(record.analystLabel || '-')}</strong>
                <span>${escapeHtml(record.analystCode)}</span>
            </td>
            <td class="omega-table__meta-cell" title="${escapeHtml(record.queueLabel)}">${escapeHtml(record.queueLabel)}</td>
            <td class="omega-table__date-cell">${escapeHtml(formatDate(record.openedAt))}</td>
            <td class="omega-table__date-cell">${escapeHtml(formatDate(record.updatedAt))}</td>
            <td class="omega-table__pill-cell">
                <span class="omega-status-pill" style="--omega-status-color: ${escapeHtml(record.statusColor)};">
                    <span class="omega-pill__icon" aria-hidden="true"></span>
                    ${escapeHtml(record.statusLabel)}
                </span>
            </td>
        `;

        return row;
    };

    const updateRenderedRow = (record) => {
        const existingRow = getRowElements().find((row) => formatIdDisplay(row.dataset.omegaId) === formatIdDisplay(record.idDisplay)) || null;

        if (!existingRow) {
            return null;
        }

        const replacementRow = renderRowElement(record);
        const existingCheckbox = existingRow.querySelector('[data-omega-row-select]');
        const nextCheckbox = replacementRow.querySelector('[data-omega-row-select]');

        if (existingCheckbox instanceof HTMLInputElement && nextCheckbox instanceof HTMLInputElement) {
            nextCheckbox.checked = existingCheckbox.checked;
        }

        existingRow.replaceWith(replacementRow);
        syncSelectionState();

        return replacementRow;
    };

    const ensureTableBody = () => {
        const existingTableBody = omegaLayout.querySelector('[data-omega-table-body]');

        if (existingTableBody) {
            return existingTableBody;
        }

        if (!listShell) {
            return null;
        }

        if (emptyState) {
            emptyState.remove();
        }

        const wrapper = document.createElement('div');
        wrapper.className = 'table-wrapper omega-table-wrapper';
        wrapper.innerHTML = `
            <table class="omega-table">
                <thead>
                    <tr>
                        <th class="omega-table__check-col">
                            <input id="omega-select-all" type="checkbox" data-omega-select-all>
                        </th>
                        <th>ID</th>
                        <th>Previa</th>
                        <th>Departamento</th>
                        <th>Assunto</th>
                        <th>Usuario</th>
                        ${canViewPriority ? '<th class="omega-table__heading--pill">Prioridade</th>' : ''}
                        <th>Analista</th>
                        <th>Fila</th>
                        <th class="omega-table__heading--date">Abertura</th>
                        <th class="omega-table__heading--date">Atualizacao</th>
                        <th class="omega-table__heading--pill">Status</th>
                    </tr>
                </thead>
                <tbody data-omega-table-body></tbody>
            </table>
        `;

        const paginationFooter = listShell.querySelector('.omega-pagination');

        if (paginationFooter) {
            paginationFooter.before(wrapper);
        } else {
            listShell.appendChild(wrapper);
        }

        return wrapper.querySelector('[data-omega-table-body]');
    };

    const setFieldValue = (field, value) => {
        if (!(field instanceof HTMLElement)) {
            return;
        }

        if (field instanceof HTMLSelectElement) {
            const candidateValue = String(value ?? '').trim();
            const matchingOption = Array.from(field.options).find((option) => option.value === candidateValue);
            field.value = matchingOption ? candidateValue : field.options[0]?.value || '';
            return;
        }

        if ('value' in field) {
            field.value = String(value ?? '');
        }
    };

    const resetEditorForm = () => {
        if (!editorForm) {
            return;
        }

        Object.entries(editorDefaults).forEach(([fieldName, value]) => {
            setFieldValue(editorFields[fieldName], value);
        });

        const hiddenIdField = editorPanel ? editorPanel.querySelector('[data-omega-editor-id]') : null;

        if (hiddenIdField && 'value' in hiddenIdField) {
            hiddenIdField.value = '';
        }

        syncEditorDepartmentState(editorDefaults.type, editorDefaults.queue, editorDefaults.analyst_functional);

        setEditorFeedback('');
    };

    const submitEditorToServer = async () => {
        if (!editorForm) {
            throw new Error('Formulario do chamado indisponivel.');
        }

        const formData = new FormData(editorForm);
        const titleValue = collapseWhitespace(formData.get('title') || '');
        const descriptionValue = String(formData.get('description') || '').trim();

        if (titleValue === '' || descriptionValue === '') {
            throw new Error('Preencha titulo e descricao antes de salvar.');
        }

        formData.set('title', titleValue);
        formData.set('description', descriptionValue);
        formData.set('current_view', currentView);

        const response = await fetch(editorForm.getAttribute('action') || window.location.pathname, {
            method: 'POST',
            body: formData,
            credentials: 'same-origin',
            headers: {
                Accept: 'application/json',
                'X-Requested-With': 'XMLHttpRequest',
            },
        });

        const responseText = await response.text();
        let payload = null;

        if (responseText.trim() !== '') {
            try {
                payload = JSON.parse(responseText);
            } catch (error) {
                throw new Error('Nao foi possivel interpretar a resposta do chamado.');
            }
        }

        if (!response.ok || !payload || payload.ok !== true || !payload.record || typeof payload.record !== 'object') {
            throw new Error(payload && typeof payload.message === 'string' && payload.message.trim() !== ''
                ? payload.message.trim()
                : 'Nao foi possivel salvar o chamado.');
        }

        return normalizeRecord(payload.record);
    };

    const fillDetailPanel = (record) => {
        if (!detailPanel) {
            return;
        }

        const setText = (selector, value) => {
            const element = detailPanel.querySelector(selector);

            if (element) {
                element.textContent = value;
            }
        };

        setText('[data-omega-detail-id]', record.idDisplay);
        setText('[data-omega-detail-id-card]', record.idDisplay);
        setText('[data-omega-detail-title]', record.previewTitle);
        setText('[data-omega-detail-subcopy]', `${record.queueLabel} - ${record.userLabel}`);
        setText('[data-omega-detail-user]', record.userLabel);
        setText('[data-omega-detail-user-copy]', record.userCode || 'Sem funcional');
        setText('[data-omega-detail-analyst]', record.analystLabel || 'Sem responsavel');
        setText('[data-omega-detail-analyst-copy]', record.analystCode || record.queueLabel);
        setText('[data-omega-detail-queue]', record.queueLabel);
        setText('[data-omega-detail-opened]', record.openedDisplay);
        setText('[data-omega-detail-updated]', record.updatedDisplay);
        setText('[data-omega-detail-closed]', record.closedAt ? record.closedDisplay : '—');
        setText('[data-omega-detail-updated-copy]', `Ultima atualizacao em ${record.updatedDisplay}`);
        setText('[data-omega-detail-status]', record.statusLabel);
        setText('[data-omega-detail-type]', record.typeLabel);
        setText('[data-omega-detail-priority]', record.priorityLabel);
        setText('[data-omega-detail-department]', record.departmentLabel);
        setText('[data-omega-detail-description]', record.description);
        setText('[data-omega-detail-resolution]', record.resolutionFinal);

        if (detailThreadCallIdInput instanceof HTMLInputElement) {
            detailThreadCallIdInput.value = record.idDisplay;
        }

        if (detailThreadAuthorFunctionalInput instanceof HTMLInputElement) {
            detailThreadAuthorFunctionalInput.value = record.userCode || currentFunctional;
        }

        const statusPill = detailPanel.querySelector('[data-omega-detail-status-pill]');
        if (statusPill instanceof HTMLElement) {
            statusPill.style.setProperty('--omega-status-color', record.statusColor || '#cbd5e1');
        }

        const priorityPill = detailPanel.querySelector('[data-omega-detail-priority-pill]');
        if (priorityPill instanceof HTMLElement) {
            priorityPill.classList.remove('is-high', 'is-medium', 'is-low');
            priorityPill.classList.add(resolvePriorityTone(record.priorityLabel));
        }

        syncDetailProgress(record.statusCode);

        if (detailThreadHost) {
            detailThreadHost.innerHTML = buildThreadMarkup(record);
        }

        syncDetailInteractionState(record, commentRequestInFlight);
    };

    const syncFiltersToggleState = (forceOpen = false) => {
        if (!filtersToggle) {
            return;
        }

        filtersToggle.classList.toggle('is-active', forceOpen || initialFiltersButtonActive);
        filtersToggle.setAttribute('aria-expanded', forceOpen ? 'true' : 'false');
    };

    const openFilters = () => {
        if (!filtersModal) {
            return;
        }

        if (filterSearchInput && toolbarSearchInput instanceof HTMLInputElement) {
            filterSearchInput.value = toolbarSearchInput.value;
        }

        setPanelOpen(filtersModal, true);
        syncFiltersToggleState(true);
        syncScrollLock();

        const autofocusTarget = filtersModal.querySelector('input, button, select, textarea');
        if (autofocusTarget instanceof HTMLElement) {
            window.requestAnimationFrame(() => autofocusTarget.focus());
        }
    };

    const closeFilters = () => {
        setPanelOpen(filtersModal, false);
        syncFiltersToggleState(false);
        syncScrollLock();
    };

    const openDetail = (record) => {
        if (!detailPanel) {
            return;
        }

        activeDetailRecord = normalizeRecord(record);
        fillDetailPanel(activeDetailRecord);
        setThreadRole('user');
        setCommentFeedback('');

        if (detailThreadInput instanceof HTMLTextAreaElement) {
            detailThreadInput.value = '';
        }

        setCommentSubmissionState(false);

        setPanelOpen(detailPanel, true);
        syncScrollLock();
    };

    const closeDetail = () => {
        setPanelOpen(detailPanel, false);
        activeDetailRecord = null;
        syncScrollLock();
    };

    const openEditor = (mode, record = null) => {
        if (!editorPanel || !editorForm) {
            return;
        }

        editorSourceRecord = record ? normalizeRecord(record) : null;
        editorPanel.dataset.mode = mode;
        const eyebrow = editorPanel.querySelector('[data-omega-editor-eyebrow]');
        const title = editorPanel.querySelector('[data-omega-editor-title]');
        const submitLabel = editorPanel.querySelector('[data-omega-editor-submit-label]');
        const hiddenIdField = editorPanel.querySelector('[data-omega-editor-id]');

        if (mode === 'edit' && editorSourceRecord) {
            setFieldValue(editorFields.title, editorSourceRecord.previewTitle);
            setFieldValue(editorFields.user, editorSourceRecord.userLabel);
            setFieldValue(editorFields.user_code, editorSourceRecord.userCode);
            const preferredQueue = collapseWhitespace(editorSourceRecord.queueCode || '');
            const resolvedDepartment = getDepartmentForQueue(preferredQueue)
                || collapseWhitespace(editorSourceRecord.departmentLabel || editorDefaults.department)
                || 'POBJ';

            setFieldValue(editorFields.department, resolvedDepartment);
            syncEditorDepartmentState(editorSourceRecord.typeLabel, preferredQueue, editorSourceRecord.analystCode);
            setFieldValue(editorFields.queue, preferredQueue);
            setFieldValue(editorFields.analyst_functional, editorSourceRecord.analystCode);
            setFieldValue(editorFields.priority, editorSourceRecord.priorityLabel);
            setFieldValue(editorFields.status_code, editorSourceRecord.statusCode);
            setFieldValue(editorFields.description, editorSourceRecord.description);

            if (hiddenIdField && 'value' in hiddenIdField) {
                hiddenIdField.value = editorSourceRecord.idDisplay;
            }

            if (eyebrow) {
                eyebrow.textContent = 'Edicao do chamado';
            }

            if (title) {
                title.textContent = `Editar ${editorSourceRecord.idDisplay}`;
            }

            if (submitLabel) {
                submitLabel.textContent = 'Salvar alteracoes';
            }
        } else {
            resetEditorForm();

            if (hiddenIdField && 'value' in hiddenIdField) {
                hiddenIdField.value = '';
            }

            if (eyebrow) {
                eyebrow.textContent = 'Novo chamado';
            }

            if (title) {
                title.textContent = 'Registrar chamado';
            }

            if (submitLabel) {
                submitLabel.textContent = 'Salvar';
            }
        }

        setEditorFeedback('');

        closeFilters();
        closeDetail();
        setPanelOpen(editorPanel, true);
        syncScrollLock();

        const autofocusTarget = editorPanel.querySelector('#omega-editor-title-input');
        if (autofocusTarget instanceof HTMLElement) {
            window.requestAnimationFrame(() => autofocusTarget.focus());
        }
    };

    const closeEditor = () => {
        setPanelOpen(editorPanel, false);
        setEditorFeedback('');
        syncScrollLock();
    };

    let collapsedState = false;

    try {
        collapsedState = window.localStorage.getItem(storageKey) === '1';
    } catch (error) {
        collapsedState = false;
    }

    setSidebarCollapsed(collapsedState);

    if (sidebarToggle) {
        sidebarToggle.addEventListener('click', () => {
            setSidebarCollapsed(!omegaLayout.classList.contains('is-sidebar-collapsed'));
        });
    }

    if (toolbarSearchInput instanceof HTMLInputElement && filterSearchInput instanceof HTMLInputElement) {
        toolbarSearchInput.addEventListener('input', () => {
            filterSearchInput.value = toolbarSearchInput.value;
        });
    }

    if (filterDepartmentField instanceof HTMLSelectElement && filterTypeField instanceof HTMLSelectElement) {
        syncFilterDepartmentState();
        filterDepartmentField.addEventListener('change', () => {
            syncFilterDepartmentState();
        });
    }

    if (filtersToggle && filtersModal) {
        filtersToggle.addEventListener('click', () => {
            if (filtersModal.hidden) {
                openFilters();
            } else {
                closeFilters();
            }
        });
    }

    filtersCloseButtons.forEach((button) => {
        button.addEventListener('click', () => {
            closeFilters();
        });
    });

    if (statusPicker && filterStatusInput instanceof HTMLInputElement) {
        try {
            const parsedStatuses = JSON.parse(statusPicker.getAttribute('data-selected-statuses') || '[]');
            selectedStatuses = Array.isArray(parsedStatuses) ? parsedStatuses.map((status) => collapseWhitespace(status)) : [];
        } catch (error) {
            selectedStatuses = [];
        }

        const syncStatusChips = () => {
            filterStatusInput.value = selectedStatuses.join(',');
            statusChips.forEach((chip) => {
                const chipValue = collapseWhitespace(chip.getAttribute('data-omega-status-chip') || '');
                const isActive = selectedStatuses.includes(chipValue);
                chip.classList.toggle('is-active', isActive);
                chip.setAttribute('aria-pressed', isActive ? 'true' : 'false');
            });
        };

        syncStatusChips();

        statusChips.forEach((chip) => {
            chip.addEventListener('click', () => {
                const chipValue = collapseWhitespace(chip.getAttribute('data-omega-status-chip') || '');

                if (chipValue === '') {
                    return;
                }

                if (selectedStatuses.includes(chipValue)) {
                    selectedStatuses = selectedStatuses.filter((status) => status !== chipValue);
                } else {
                    selectedStatuses = [...selectedStatuses, chipValue];
                }

                syncStatusChips();
            });
        });
    }

    detailCloseButtons.forEach((button) => {
        button.addEventListener('click', () => {
            closeDetail();
        });
    });

    if (detailEditButton) {
        detailEditButton.addEventListener('click', () => {
            if (activeDetailRecord) {
                openEditor('edit', activeDetailRecord);
            }
        });
    }

    detailThreadRoleButtons.forEach((button) => {
        button.addEventListener('click', () => {
            setThreadRole(button.getAttribute('data-omega-thread-role') || 'user');
        });
    });

    if (detailThreadForm && detailThreadInput instanceof HTMLTextAreaElement) {
        detailThreadForm.addEventListener('submit', async (event) => {
            event.preventDefault();

            if (!activeDetailRecord || commentRequestInFlight) {
                return;
            }

            if (isRequesterInteractionLocked(activeDetailRecord)) {
                setCommentFeedback('Este chamado ja foi finalizado. Abra um novo chamado para continuar.', 'error');
                return;
            }

            const submittedRecord = normalizeRecord(activeDetailRecord);
            const submittedRole = activeThreadRole === 'analyst' ? 'analyst' : 'user';
            const message = detailThreadInput.value.trim();

            if (message === '') {
                detailThreadInput.focus();
                return;
            }

            const fallbackTimestamp = toOmegaDateTime();

            try {
                setCommentSubmissionState(true);
                setCommentFeedback('Salvando comentario no historico oficial.', 'neutral');

                const nextEntry = await submitCommentToServer(submittedRecord, message, submittedRole);

                const latestRecordState = activeDetailRecord
                    && formatIdDisplay(activeDetailRecord.idDisplay) === formatIdDisplay(submittedRecord.idDisplay)
                    ? normalizeRecord(activeDetailRecord)
                    : submittedRecord;
                const nextRecord = normalizeRecord({
                    ...latestRecordState,
                    analystLabel: nextEntry.role === 'analyst' ? currentUserName : latestRecordState.analystLabel,
                    analystCode: nextEntry.role === 'analyst' ? currentFunctional : latestRecordState.analystCode,
                    updatedAt: nextEntry.timestamp || fallbackTimestamp,
                    thread: [
                        ...(Array.isArray(latestRecordState.thread) ? latestRecordState.thread : []),
                        nextEntry,
                    ],
                });

                updateRenderedRow(nextRecord);

                if (activeDetailRecord && formatIdDisplay(activeDetailRecord.idDisplay) === formatIdDisplay(nextRecord.idDisplay)) {
                    activeDetailRecord = nextRecord;
                    fillDetailPanel(nextRecord);
                }

                setCommentFeedback('Comentario salvo no historico oficial.', 'success');
                detailThreadInput.value = '';
                detailThreadInput.focus();
            } catch (error) {
                const feedbackMessage = error instanceof Error && error.message.trim() !== ''
                    ? error.message
                    : 'Nao foi possivel salvar o comentario.';
                setCommentFeedback(feedbackMessage, 'error');
            } finally {
                setCommentSubmissionState(false);
            }
        });
    }

    setThreadRole(activeThreadRole);

    if (registerToggle && editorPanel) {
        registerToggle.addEventListener('click', () => {
            openEditor('create');
        });
    }

    editorCloseButtons.forEach((button) => {
        button.addEventListener('click', () => {
            closeEditor();
        });
    });

    if (editorForm) {
        if (editorFields.department instanceof HTMLSelectElement) {
            editorFields.department.addEventListener('change', () => {
                syncEditorDepartmentState();
            });
        }

        if (editorFields.queue instanceof HTMLSelectElement) {
            editorFields.queue.addEventListener('change', () => {
                syncEditorQueueState();
            });
        }

        editorForm.addEventListener('submit', async (event) => {
            event.preventDefault();

            if (editorRequestInFlight) {
                return;
            }

            try {
                setEditorSubmissionState(true);
                setEditorFeedback('Salvando chamado no banco de dados.', 'neutral');

                const nextRecord = await submitEditorToServer();

                if (!listShell) {
                    window.location.reload();
                    return;
                }

                const tableBody = ensureTableBody();

                if (!tableBody) {
                    throw new Error('Nao foi possivel localizar a lista de chamados.');
                }

                const existingRow = getRowElements().find((row) => formatIdDisplay(row.dataset.omegaId) === nextRecord.idDisplay) || null;
                const renderedRow = renderRowElement(nextRecord);

                if (existingRow) {
                    existingRow.replaceWith(renderedRow);
                } else {
                    tableBody.prepend(renderedRow);
                    countsState.total += 1;
                }

                updateListMetrics();
                syncSelectionState();
                closeEditor();
                openDetail(nextRecord);
            } catch (error) {
                const feedbackMessage = error instanceof Error && error.message.trim() !== ''
                    ? error.message
                    : 'Nao foi possivel salvar o chamado.';
                setEditorFeedback(feedbackMessage, 'error');
            } finally {
                setEditorSubmissionState(false);
            }
        });
    }

    omegaLayout.addEventListener('change', (event) => {
        const { target } = event;

        if (!(target instanceof HTMLElement)) {
            return;
        }

        if (target.matches('[data-omega-select-all]') && target instanceof HTMLInputElement) {
            getRowCheckboxes().forEach((checkbox) => {
                checkbox.checked = target.checked;
            });

            syncSelectionState();
            return;
        }

        if (target.matches('[data-omega-row-select]')) {
            syncSelectionState();
        }
    });

    omegaLayout.addEventListener('click', (event) => {
        const { target } = event;

        if (!(target instanceof Element)) {
            return;
        }

        const row = target.closest('[data-omega-detail-row]');

        if (!row || target.closest('input, button, a, label, select, textarea')) {
            return;
        }

        openDetail(buildRecordFromRow(row));
    });

    omegaLayout.addEventListener('keydown', (event) => {
        const { target } = event;

        if (!(target instanceof Element)) {
            return;
        }

        const row = target.closest('[data-omega-detail-row]');

        if (!row || target.closest('input, button, a, label, select, textarea')) {
            return;
        }

        if (event.key === 'Enter' || event.key === ' ') {
            event.preventDefault();
            openDetail(buildRecordFromRow(row));
        }
    });

    document.addEventListener('keydown', (event) => {
        if (event.key !== 'Escape') {
            return;
        }

        if (isPanelOpen(editorPanel)) {
            closeEditor();
            return;
        }

        if (isPanelOpen(detailPanel)) {
            closeDetail();
            return;
        }

        if (isPanelOpen(filtersModal)) {
            closeFilters();
        }
    });

    updateListMetrics();
    syncSelectionState();
    syncFiltersToggleState(false);
    syncScrollLock();
}