<?php

declare(strict_types=1);

function e(?string $value): string
{
    return htmlspecialchars(normalize_display_text((string) $value), ENT_QUOTES, 'UTF-8');
}

function normalize_display_text(?string $value): string
{
    $value = trim((string) $value);

    if ($value === '') {
        return '';
    }

    $value = strtr($value, [
        'Ã¡' => 'á',
        'Ã¢' => 'â',
        'Ã£' => 'ã',
        'Ã¤' => 'ä',
        'Ã§' => 'ç',
        'Ã©' => 'é',
        'Ãª' => 'ê',
        'Ã­' => 'í',
        'Ã³' => 'ó',
        'Ã´' => 'ô',
        'Ãµ' => 'õ',
        'Ã¶' => 'ö',
        'Ãº' => 'ú',
        'Ã¼' => 'ü',
        'Ã' => 'Á',
        'Ã‚' => 'Â',
        'Ãƒ' => 'Ã',
        'Ã„' => 'Ä',
        'Ã‡' => 'Ç',
        'Ã‰' => 'É',
        'ÃŠ' => 'Ê',
        'Ã' => 'Í',
        'Ã“' => 'Ó',
        'Ã”' => 'Ô',
        'Ã•' => 'Õ',
        'Ã–' => 'Ö',
        'Ãš' => 'Ú',
        'Ãœ' => 'Ü',
        'â€¢' => ' - ',
        '•' => ' - ',
        '·' => ' - ',
        'Â·' => ' - ',
        'â€“' => '-',
        '–' => '-',
        'â€”' => '-',
        '—' => '-',
        'â€˜' => "'",
        'â€™' => "'",
        '‘' => "'",
        '’' => "'",
        'â€œ' => '"',
        'â€' => '"',
        '“' => '"',
        '”' => '"',
        'â€¦' => '...',
        '…' => '...',
        'Âº' => 'º',
        'Âª' => 'ª',
        'Â' => '',
    ]);

    if (preg_match('/[ÃÂâ]/u', $value) === 1) {
        $bestValue = $value;
        $bestScore = substr_count($bestValue, 'Ã') + substr_count($bestValue, 'Â') + substr_count($bestValue, 'â');

        foreach (['Windows-1252', 'ISO-8859-1'] as $sourceEncoding) {
            $candidate = @iconv($sourceEncoding, 'UTF-8//IGNORE', $value);

            if (!is_string($candidate) || trim($candidate) === '') {
                continue;
            }

            $candidateScore = substr_count($candidate, 'Ã') + substr_count($candidate, 'Â') + substr_count($candidate, 'â');

            if ($candidateScore < $bestScore) {
                $bestValue = $candidate;
                $bestScore = $candidateScore;
            }
        }

        $value = $bestValue;
    }

    return preg_replace('/\s{2,}/', ' ', $value) ?? $value;
}

function app_url(array $query = []): string
{
    $queryString = http_build_query($query);

    return $queryString === '' ? 'index.php' : 'index.php?' . $queryString;
}

function sanitize_redirect_value(?string $value): string
{
    $value = trim((string) $value);

    return preg_replace('/[\r\n]+/', '', $value) ?? '';
}

function build_internal_url(string $script, array $query = []): string
{
    $allowedScripts = ['index.php', 'omega.php', 'chat.php'];
    $script = trim($script);

    if (!in_array($script, $allowedScripts, true)) {
        $script = 'index.php';
    }

    $sanitizedQuery = [];

    foreach ($query as $key => $value) {
        if (!is_string($key) || is_array($value)) {
            continue;
        }

        $cleanKey = preg_replace('/[^A-Za-z0-9_\-]/', '', $key) ?? '';
        $cleanValue = sanitize_redirect_value((string) $value);

        if ($cleanKey === '' || $cleanValue === '') {
            continue;
        }

        $sanitizedQuery[$cleanKey] = $cleanValue;
    }

    $queryString = http_build_query($sanitizedQuery);

    return $queryString === '' ? $script : $script . '?' . $queryString;
}

function redirect_internal(string $script, array $query = []): void
{
    header('Location: ' . build_internal_url($script, $query));
    exit;
}

function project_path(string $path = ''): string
{
    $rootPath = dirname(__DIR__, 2);

    if ($path === '') {
        return $rootPath;
    }

    $normalizedPath = str_replace(['/', '\\'], DIRECTORY_SEPARATOR, ltrim($path, " \/\\"));

    return $rootPath . DIRECTORY_SEPARATOR . $normalizedPath;
}

function storage_path(string $path = ''): string
{
    return project_path($path === '' ? 'storage' : 'storage' . DIRECTORY_SEPARATOR . $path);
}

function ensure_directory(string $path): void
{
    if (is_dir($path)) {
        return;
    }

    if (!mkdir($path, 0777, true) && !is_dir($path)) {
        throw new RuntimeException('Nao foi possivel preparar a pasta: ' . $path);
    }
}

function json_response(array $payload, int $status = 200): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=UTF-8');

    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(?string $token): bool
{
    return is_string($token)
        && isset($_SESSION['csrf_token'])
        && hash_equals($_SESSION['csrf_token'], $token);
}

function format_decimal(float $value, int $decimals = 2, string $suffix = ''): string
{
    return number_format($value, $decimals, ',', '.') . $suffix;
}

function format_currency(float $value): string
{
    return 'R$ ' . number_format($value, 2, ',', '.');
}

function format_int_readable(float $value): string
{
    return number_format((int) round($value), 0, ',', '.');
}

function format_points_readable(float $value): string
{
    $rounded = round($value, 2);
    $decimals = abs($rounded - round($rounded)) < 0.005 || abs($rounded) >= 1000 ? 0 : 2;

    return number_format($rounded, $decimals, ',', '.');
}

function format_compact_number(float $value, int $baseDecimals = 2): string
{
    $absolute = abs($value);
    $scales = [
        ['divisor' => 1000000000000.0, 'suffix' => ' tri'],
        ['divisor' => 1000000000.0, 'suffix' => ' bi'],
        ['divisor' => 1000000.0, 'suffix' => ' mi'],
        ['divisor' => 1000.0, 'suffix' => ' mil'],
    ];

    foreach ($scales as $scale) {
        $divisor = (float) ($scale['divisor'] ?? 0.0);
        $suffix = (string) ($scale['suffix'] ?? '');

        if ($divisor <= 0) {
            continue;
        }

        if ($absolute < $divisor) {
            continue;
        }

        $scaled = $value / $divisor;
        $scaledAbsolute = abs($scaled);
        $decimals = $scaledAbsolute >= 100 ? 0 : 1;

        if (abs($scaled - round($scaled)) < 0.05) {
            $decimals = 0;
        }

        return number_format($scaled, $decimals, ',', '.') . $suffix;
    }

    $rounded = round($value, $baseDecimals);
    $decimals = $baseDecimals;

    if ($baseDecimals > 0 && abs($rounded - round($rounded)) < 0.005) {
        $decimals = 0;
    }

    return number_format($rounded, $decimals, ',', '.');
}

function format_number_readable(float $value): string
{
    return format_compact_number($value, 2);
}

function format_quantity_readable(float $value): string
{
    return format_compact_number($value, 0);
}

function format_currency_readable(float $value): string
{
    return 'R$ ' . format_compact_number($value, 2);
}

function clamp_date_to_today(?string $value): string
{
    $value = trim((string) $value);

    if ($value === '') {
        return '';
    }

    $today = (new DateTimeImmutable('today'))->format('Y-m-d');

    return strcmp($value, $today) > 0 ? $today : $value;
}

function format_date_br(?string $value): string
{
    $value = trim((string) $value);

    if ($value === '') {
        return '';
    }

    try {
        return (new DateTimeImmutable($value))->format('d/m/Y');
    } catch (Throwable $exception) {
        return $value;
    }
}

function format_month_year_br(?string $value): string
{
    $value = trim((string) $value);

    if ($value === '') {
        return '';
    }

    try {
        $date = preg_match('/^\d{4}-\d{2}$/', $value) === 1
            ? new DateTimeImmutable($value . '-01')
            : new DateTimeImmutable($value);
    } catch (Throwable $exception) {
        return $value;
    }

    $monthLabels = [
        1 => 'Janeiro',
        2 => 'Fevereiro',
        3 => 'Março',
        4 => 'Abril',
        5 => 'Maio',
        6 => 'Junho',
        7 => 'Julho',
        8 => 'Agosto',
        9 => 'Setembro',
        10 => 'Outubro',
        11 => 'Novembro',
        12 => 'Dezembro',
    ];

    $monthNumber = (int) $date->format('n');

    return normalize_display_text($monthLabels[$monthNumber] ?? $date->format('m')) . '/' . $date->format('Y');
}

function resolve_closed_month_value_from_dates(?string $startDate, ?string $endDate): string
{
    $startDate = trim((string) $startDate);
    $endDate = trim((string) $endDate);

    if ($startDate === '' || $endDate === '') {
        return '';
    }

    try {
        $start = new DateTimeImmutable($startDate);
        $end = new DateTimeImmutable($endDate);
    } catch (Throwable $exception) {
        return '';
    }

    if ($start->format('Y-m') !== $end->format('Y-m')) {
        return '';
    }

    if ($start->format('Y-m-d') !== $start->modify('first day of this month')->format('Y-m-d')) {
        return '';
    }

    if ($end->format('Y-m-d') !== $end->modify('last day of this month')->format('Y-m-d')) {
        return '';
    }

    return $start->format('Y-m');
}

function build_closed_month_period_options(array $periods, ?string $referenceDate = null): array
{
    try {
        $reference = new DateTimeImmutable(trim((string) $referenceDate) !== '' ? (string) $referenceDate : 'today');
    } catch (Throwable $exception) {
        $reference = new DateTimeImmutable('today');
    }

    $lastClosedMonthEnd = $reference->modify('first day of this month')->sub(new DateInterval('P1D'));
    $currentMonthStart = $reference->modify('first day of this month');
    $optionsByValue = [];

    foreach ($periods as $period) {
        $periodId = trim((string) ($period['id_periodo'] ?? ''));
        $periodStartRaw = trim((string) ($period['dt_inicio_periodo'] ?? ''));
        $periodEndRaw = trim((string) ($period['dt_fim_periodo'] ?? ''));

        if ($periodId === '' || $periodStartRaw === '' || $periodEndRaw === '') {
            continue;
        }

        try {
            $periodStart = new DateTimeImmutable($periodStartRaw);
            $periodEnd = new DateTimeImmutable($periodEndRaw);
        } catch (Throwable $exception) {
            continue;
        }

        $cursor = $periodStart->modify('first day of this month');
        $limit = $periodEnd->modify('first day of this month');

        while ($cursor <= $limit) {
            $monthStart = $cursor->modify('first day of this month');
            $monthEnd = $cursor->modify('last day of this month');

            $isPastClosedMonth = $monthEnd <= $lastClosedMonthEnd;
            $isCurrentOpenMonth = $monthStart->format('Y-m') === $currentMonthStart->format('Y-m')
                && $reference >= $monthStart
                && $reference <= $periodEnd;

            if ($monthStart >= $periodStart && ($isPastClosedMonth || $isCurrentOpenMonth)) {
                $monthValue = $monthStart->format('Y-m');
                $effectiveEnd = $isCurrentOpenMonth
                    ? ($reference < $monthEnd ? $reference : $monthEnd)
                    : $monthEnd;

                if (!isset($optionsByValue[$monthValue])) {
                    $optionsByValue[$monthValue] = [
                        'value' => $monthValue,
                        'label' => format_month_year_br($monthValue),
                        'start' => $monthStart->format('Y-m-d'),
                        'end' => $effectiveEnd->format('Y-m-d'),
                        'periodo' => $periodId,
                    ];
                }
            }

            $cursor = $cursor->modify('+1 month');
        }
    }

    if ($optionsByValue === []) {
        return [];
    }

    krsort($optionsByValue);

    return array_values($optionsByValue);
}

function resolve_period_id_by_date_range(array $periods, ?string $startDate, ?string $endDate, ?string $fallbackPeriodId = null): ?string
{
    $today = (new DateTimeImmutable('today'))->format('Y-m-d');
    $startDate = clamp_date_to_today($startDate);
    $endDate = clamp_date_to_today($endDate);

    if ($startDate === '' || $endDate === '') {
        return $fallbackPeriodId;
    }

    try {
        $requestedStart = new DateTimeImmutable($startDate);
        $requestedEnd = new DateTimeImmutable($endDate);
    } catch (Throwable $exception) {
        return $fallbackPeriodId;
    }

    $bestPeriodId = $fallbackPeriodId;
    $bestScore = null;

    foreach ($periods as $period) {
        $periodId = (string) ($period['id_periodo'] ?? '');
        $periodStartRaw = trim((string) ($period['dt_inicio_periodo'] ?? ''));
        $periodEndRaw = trim((string) ($period['dt_fim_periodo'] ?? ''));

        if ($periodId === '' || $periodStartRaw === '' || $periodEndRaw === '') {
            continue;
        }

        if (strcmp($periodStartRaw, $today) > 0) {
            continue;
        }

        if ($periodStartRaw === $startDate && $periodEndRaw === $endDate) {
            return $periodId;
        }

        try {
            $periodStart = new DateTimeImmutable($periodStartRaw);
            $periodEnd = new DateTimeImmutable($periodEndRaw);
        } catch (Throwable $exception) {
            continue;
        }

        $overlapStart = max($requestedStart->getTimestamp(), $periodStart->getTimestamp());
        $overlapEnd = min($requestedEnd->getTimestamp(), $periodEnd->getTimestamp());
        $overlapDays = max(0, ($overlapEnd - $overlapStart) / 86400);
        $distancePenalty = abs($requestedStart->getTimestamp() - $periodStart->getTimestamp()) / 86400;
        $distancePenalty += abs($requestedEnd->getTimestamp() - $periodEnd->getTimestamp()) / 86400;
        $score = $overlapDays > 0 ? $overlapDays - ($distancePenalty * 0.01) : -$distancePenalty;

        if ($bestScore === null || $score > $bestScore) {
            $bestScore = $score;
            $bestPeriodId = $periodId;
        }
    }

    return $bestPeriodId;
}

function resolve_accumulated_view_date_range(string $view, ?string $referenceEndDate = null): array
{
    $view = strtoupper(trim($view));
    $endDateRaw = clamp_date_to_today($referenceEndDate);

    try {
        $endDate = new DateTimeImmutable($endDateRaw !== '' ? $endDateRaw : 'today');
    } catch (Throwable $exception) {
        $endDate = new DateTimeImmutable('today');
    }

    switch ($view) {
        case 'SEMESTRAL':
            $startDate = $endDate
                ->modify('first day of this month')
                ->sub(new DateInterval('P5M'));
            break;

        case 'ACUMULADO':
        case 'ANUAL':
            $startDate = $endDate->setDate((int) $endDate->format('Y'), 1, 1);
            break;

        case 'MENSAL_ACUMULADO':
        case 'MENSAL':
        default:
            $startDate = $endDate->modify('first day of this month');
            break;
    }

    return [
        'start' => $startDate->format('Y-m-d'),
        'end' => $endDate->format('Y-m-d'),
    ];
}

function resolve_business_day_snapshot(?string $startDate, ?string $endDate, ?string $referenceDate = null): array
{
    $startDate = trim((string) $startDate);
    $endDate = trim((string) $endDate);

    if ($startDate === '' || $endDate === '') {
        return [
            'total' => 0,
            'elapsed' => 0,
            'remaining' => 0,
            'start' => '',
            'end' => '',
            'today' => (new DateTimeImmutable('today'))->format('Y-m-d'),
        ];
    }

    try {
        $start = new DateTimeImmutable($startDate);
        $end = new DateTimeImmutable($endDate);
        $today = new DateTimeImmutable(clamp_date_to_today($referenceDate));
    } catch (Throwable $exception) {
        return [
            'total' => 0,
            'elapsed' => 0,
            'remaining' => 0,
            'start' => $startDate,
            'end' => $endDate,
            'today' => (new DateTimeImmutable('today'))->format('Y-m-d'),
        ];
    }

    if ($start > $end) {
        [$start, $end] = [$end, $start];
    }

    $effectiveToday = $today > $end ? $end : $today;
    $total = count_business_days_inclusive($start, $end);
    $elapsed = $effectiveToday >= $start ? count_business_days_inclusive($start, $effectiveToday) : 0;

    return [
        'total' => $total,
        'elapsed' => $elapsed,
        'remaining' => max(0, $total - $elapsed),
        'start' => $start->format('Y-m-d'),
        'end' => $end->format('Y-m-d'),
        'today' => $effectiveToday->format('Y-m-d'),
    ];
}

function count_business_days_inclusive(DateTimeImmutable $start, DateTimeImmutable $end): int
{
    if ($start > $end) {
        return 0;
    }

    $days = 0;
    $current = $start;

    while ($current <= $end) {
        $weekday = (int) $current->format('N');

        if ($weekday < 6) {
            $days++;
        }

        $current = $current->add(new DateInterval('P1D'));
    }

    return $days;
}

function format_metric(float $value, string $typeId): string
{
    $typeId = strtoupper($typeId);

    if ($typeId === 'PERCENTUAL') {
        return format_decimal($value, 2, '%');
    }

    if ($typeId === 'QUANTIDADE') {
        return format_decimal($value, 0);
    }

    return format_currency($value);
}

function format_metric_readable(float $value, string $typeId): string
{
    $typeId = strtoupper($typeId);

    if ($typeId === 'PERCENTUAL') {
        return format_decimal($value, 2, '%');
    }

    if ($typeId === 'QUANTIDADE') {
        return format_quantity_readable($value);
    }

    return format_currency_readable($value);
}

function selected_attr(string $value, ?string $currentValue): string
{
    return $value === $currentValue ? ' selected' : '';
}

function user_initials(?string $name): string
{
    $name = trim((string) $name);

    if ($name === '') {
        return 'NP';
    }

    $parts = preg_split('/\s+/', $name) ?: [];
    $parts = array_values(array_filter($parts, static function (string $part): bool {
        return $part !== '';
    }));

    if ($parts === []) {
        return 'NP';
    }

    $firstPart = $parts[0];
    $lastPart = $parts[count($parts) - 1];
    $firstInitial = function_exists('mb_substr') ? mb_substr($firstPart, 0, 1) : substr($firstPart, 0, 1);
    $lastInitial = function_exists('mb_substr') ? mb_substr($lastPart, 0, 1) : substr($lastPart, 0, 1);

    if (count($parts) === 1) {
        $secondInitial = function_exists('mb_substr') ? mb_substr($firstPart, 1, 1) : substr($firstPart, 1, 1);

        return strtoupper($firstInitial . ($secondInitial !== false ? $secondInitial : ''));
    }

    return strtoupper($firstInitial . $lastInitial);
}

function first_name(?string $name): string
{
    $name = trim((string) $name);

    if ($name === '') {
        return 'Usuario';
    }

    $parts = preg_split('/\s+/', $name) ?: [];

    return $parts[0] !== '' ? $parts[0] : 'Usuario';
}

function prime_label(?string $value): string
{
    return normalize_display_text($value);
}

function sanitize_request_token(?string $value, string $fallback = ''): string
{
    $value = trim((string) $value);

    if ($value === '') {
        return $fallback;
    }

    $value = preg_replace('/[^A-Za-z0-9_\-]/', '', $value) ?? '';

    return $value !== '' ? $value : $fallback;
}

function sanitize_request_date(?string $value, string $fallback = ''): string
{
    $value = trim((string) $value);

    if ($value === '') {
        return $fallback;
    }

    $value = preg_replace('/[^0-9\-]/', '', $value) ?? '';

    return $value !== '' ? $value : $fallback;
}

function sanitize_request_choice(?string $value, array $allowed, string $fallback = ''): string
{
    $value = trim((string) $value);

    if ($value === '' || !in_array($value, $allowed, true)) {
        return $fallback;
    }

    return $value;
}
