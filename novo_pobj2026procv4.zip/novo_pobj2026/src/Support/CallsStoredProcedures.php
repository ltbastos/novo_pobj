<?php

declare(strict_types=1);

namespace App\Support;

use InvalidArgumentException;
use PDO;
use PDOStatement;
use Throwable;

trait CallsStoredProcedures
{
    /** @var array<string, array<int, string>> */
    private static $procedureParameterOrderCache = [];

    abstract protected function getProcedureConnection(): PDO;

    protected function fetchProcedureAll(string $procedureName, array $params = []): array
    {
        $statement = $this->prepareProcedureCall($procedureName, $params);
        $rows = $statement->fetchAll();
        $this->closeProcedureStatement($statement);

        return is_array($rows) ? $rows : [];
    }

    protected function fetchProcedureRow(string $procedureName, array $params = []): ?array
    {
        $statement = $this->prepareProcedureCall($procedureName, $params);
        $row = $statement->fetch();
        $this->closeProcedureStatement($statement);

        return is_array($row) ? $row : null;
    }

    protected function fetchProcedureValue(string $procedureName, array $params = [])
    {
        $row = $this->fetchProcedureRow($procedureName, $params);

        if (!is_array($row) || $row === []) {
            return null;
        }

        return reset($row);
    }

    protected function encodeProcedureList(array $values): string
    {
        $normalized = [];

        foreach ($values as $value) {
            $cleanValue = trim((string) $value);

            if ($cleanValue === '') {
                continue;
            }

            $cleanValue = str_replace([',', "\r", "\n"], '', $cleanValue);

            if ($cleanValue === '') {
                continue;
            }

            $normalized[] = $cleanValue;
        }

        $normalized = array_values(array_unique($normalized));

        return implode(',', $normalized);
    }

    private function prepareProcedureCall(string $procedureName, array $params): PDOStatement
    {
        if (preg_match('/^[A-Za-z0-9_]+$/', $procedureName) !== 1) {
            throw new InvalidArgumentException('Nome de procedure invalido.');
        }

        $sanitizedParams = [];

        foreach ($params as $name => $value) {
            if (!is_string($name)) {
                continue;
            }

            $cleanName = preg_replace('/[^A-Za-z0-9_]/', '', $name) ?? '';

            if ($cleanName === '') {
                continue;
            }

            $sanitizedParams[$cleanName] = $value;
        }

        $placeholderParts = [];

        foreach ($this->resolveProcedureParameterOrder($procedureName, $sanitizedParams) as $parameterName) {
            $placeholderParts[] = ':' . $parameterName;
        }

        $sql = $placeholderParts === []
            ? sprintf('CALL %s()', $procedureName)
            : sprintf('CALL %s(%s)', $procedureName, implode(', ', $placeholderParts));

        $statement = $this->getProcedureConnection()->prepare($sql);

        foreach ($sanitizedParams as $key => $value) {
            if (is_int($value)) {
                $statement->bindValue(':' . $key, $value, PDO::PARAM_INT);
                continue;
            }

            if (is_bool($value)) {
                $statement->bindValue(':' . $key, $value, PDO::PARAM_BOOL);
                continue;
            }

            if ($value === null) {
                $statement->bindValue(':' . $key, null, PDO::PARAM_NULL);
                continue;
            }

            $statement->bindValue(':' . $key, (string) $value, PDO::PARAM_STR);
        }

        $statement->execute();

        return $statement;
    }

    private function closeProcedureStatement(PDOStatement $statement): void
    {
        try {
            while ($statement->nextRowset()) {
            }
        } catch (Throwable $exception) {
        }

        $statement->closeCursor();
    }

    private function resolveProcedureParameterOrder(string $procedureName, array $sanitizedParams): array
    {
        $parameterNames = array_keys($sanitizedParams);

        if (count($parameterNames) <= 1) {
            return $parameterNames;
        }

        if (!array_key_exists($procedureName, self::$procedureParameterOrderCache)) {
            $statement = $this->getProcedureConnection()->prepare(
                'SELECT PARAMETER_NAME
                 FROM information_schema.PARAMETERS
                 WHERE SPECIFIC_SCHEMA = DATABASE()
                   AND SPECIFIC_NAME = :procedure_name
                   AND PARAMETER_MODE = "IN"
                 ORDER BY ORDINAL_POSITION'
            );
            $statement->execute(['procedure_name' => $procedureName]);
            $orderedNames = [];

            foreach ($statement->fetchAll() as $row) {
                $parameterName = preg_replace('/^@+/', '', trim((string) ($row['PARAMETER_NAME'] ?? ''))) ?? '';

                if ($parameterName === '') {
                    continue;
                }

                $orderedNames[] = $parameterName;
            }

            $statement->closeCursor();
            self::$procedureParameterOrderCache[$procedureName] = $orderedNames;
        }

        $orderedPlaceholders = [];

        foreach (self::$procedureParameterOrderCache[$procedureName] as $parameterName) {
            if (!array_key_exists($parameterName, $sanitizedParams)) {
                continue;
            }

            $orderedPlaceholders[] = $parameterName;
        }

        if (count($orderedPlaceholders) !== count($sanitizedParams)) {
            return $parameterNames;
        }

        return $orderedPlaceholders;
    }
}