<?php

declare(strict_types=1);

namespace App\Services;

use App\Support\CallsStoredProcedures;
use PDO;
use Throwable;

final class OmegaDashboardService
{
    use CallsStoredProcedures;

    private const CALLS_TABLE_NAME = 'fomegachamado';
    private const COMMENT_TABLE_NAME = 'fomegachamadocomentario';
    private const MOVEMENT_TABLE_NAME = 'fomegachamadomovimentacao';
    private const STATUS_TABLE_NAME = 'domegastatuschamado';
    private const TIMES_TABLE_NAME = 'domegatimes';
    private const CATEGORY_TABLE_NAME = 'domegacategorias';
    private const ANALYST_TEAM_TABLE_NAME = 'fomegaanalistatime';
    private const FOCAL_TEAM_TABLE_NAME = 'fomegafocaltime';
    private const HIERARCHY_TABLE_NAME = 'dHierarquia';
    private const UI_ORIGIN = 'novo_pobj_ui';

    private const VIEW_DEFINITIONS = [
        'my-calls' => 'Meus chamados',
        'my-work' => 'Meus atendimentos',
        'team-queue' => 'Fila da equipe',
    ];

    private const DEPARTMENT_TYPE_DEFAULTS = [
        'POBJ' => ['Contestar Realizado', 'Outros'],
        'Metas' => ['Contestar Meta', 'Redistribuir Meta'],
    ];

    /** @var PDO */
    private $connection;

    /** @var array<string, bool> */
    private $tableAvailability = [];

    /** @var array<string, array<string, bool>> */
    private $columnAvailability = [];

    public function __construct(PDO $connection)
    {
        $this->connection = $connection;
    }

    protected function getProcedureConnection(): PDO
    {
        return $this->connection;
    }

    private function resolveContextAccess(array $context): array
    {
        $functional = trim((string) (($context['profile'] ?? [])['funcional'] ?? ''));
        $analystTeamIds = $this->resolveMappedTeamIds($functional, 'analyst');
        $managerTeamIds = $this->resolveMappedTeamIds($functional, 'manager');
        $accessibleTeamIds = array_values(array_unique(array_merge($analystTeamIds, $managerTeamIds)));
        sort($accessibleTeamIds);

        return [
            'functional' => $functional,
            'analyst_team_ids' => $analystTeamIds,
            'manager_team_ids' => $managerTeamIds,
            'accessible_team_ids' => $accessibleTeamIds,
            'is_analyst' => $analystTeamIds !== [],
            'is_manager' => $managerTeamIds !== [],
            'can_manage_team' => $managerTeamIds !== [],
            'can_access_dashboard' => $accessibleTeamIds !== [],
            'can_view_priority' => $accessibleTeamIds !== [],
        ];
    }

    public function getDashboardData(array $context, array $requestedFilters = []): array
    {
        $this->ensureCallSchema();

        $access = $this->resolveContextAccess($context);
        $functional = $access['functional'];
        $analystTeamIds = $access['analyst_team_ids'];
        $managerTeamIds = $access['manager_team_ids'];
        $accessibleTeamIds = $access['accessible_team_ids'];
        $isAnalyst = $access['is_analyst'];
        $isManager = $access['is_manager'];
        $canManageTeam = $access['can_manage_team'];
        $canAccessDashboard = $access['can_access_dashboard'];
        $canViewPriority = $access['can_view_priority'];
        $availableViews = ['my-calls' => self::VIEW_DEFINITIONS['my-calls']];

        if ($isAnalyst) {
            $availableViews['my-work'] = self::VIEW_DEFINITIONS['my-work'];
        }

        if ($accessibleTeamIds !== []) {
            $availableViews['team-queue'] = self::VIEW_DEFINITIONS['team-queue'];
        }

        $requestedView = trim((string) ($requestedFilters['view'] ?? 'my-calls'));
        $view = isset($availableViews[$requestedView]) ? $requestedView : 'my-calls';
        $filters = [
            'search' => trim((string) ($requestedFilters['search'] ?? '')),
            'call_id' => trim((string) ($requestedFilters['call_id'] ?? '')),
            'requester' => trim((string) ($requestedFilters['requester'] ?? '')),
            'department' => trim((string) ($requestedFilters['department'] ?? '')),
            'type' => trim((string) ($requestedFilters['type'] ?? '')),
            'priority' => trim((string) ($requestedFilters['priority'] ?? '')),
            'status' => trim((string) ($requestedFilters['status'] ?? '')),
            'opened_from' => trim((string) ($requestedFilters['opened_from'] ?? '')),
            'opened_to' => trim((string) ($requestedFilters['opened_to'] ?? '')),
            'page' => max(1, (int) ($requestedFilters['page'] ?? 1)),
        ];

        if (!$canViewPriority) {
            $filters['priority'] = '';
        }

        $perPage = 8;

        $statusOptions = $this->listStatusOptions();
        $statusCodes = $this->normalizeStatusFilter($filters['status']);
        $counts = $this->fetchViewCounts($functional, $analystTeamIds, $accessibleTeamIds);
        $sourceRows = $this->fetchSourceRows($functional, $analystTeamIds, $accessibleTeamIds, $view);

        $sourceRows = $this->sortRowsByRecency($this->attachCommentThreads($this->attachMovementThreads($sourceRows)));

        $filteredRows = $this->filterRows($sourceRows, $filters, $statusCodes);
        $table = $this->paginateRows($filteredRows, (int) ($filters['page'] ?? 1), $perPage);

        return [
            'views' => array_map(static function (string $id, string $label) use ($counts): array {
                return [
                    'id' => $id,
                    'label' => $label,
                    'count' => (int) ($counts[$id] ?? 0),
                ];
            }, array_keys($availableViews), array_values($availableViews)),
            'active_view' => $view,
            'permissions' => [
                'is_analyst' => $isAnalyst,
                'is_manager' => $isManager,
                'can_manage_team' => $canManageTeam,
                'can_access_dashboard' => $canAccessDashboard,
                'can_view_priority' => $canViewPriority,
            ],
            'filters' => [
                'search' => $filters['search'],
                'call_id' => $filters['call_id'],
                'requester' => $filters['requester'],
                'department' => $filters['department'],
                'type' => $filters['type'],
                'priority' => $filters['priority'],
                'status' => implode(',', $statusCodes),
                'opened_from' => $filters['opened_from'],
                'opened_to' => $filters['opened_to'],
                'page' => $table['current_page'],
            ],
            'status_options' => $statusOptions,
            'facet_options' => $this->buildFacetOptions($sourceRows),
            'editor_options' => $this->buildEditorOptions($accessibleTeamIds),
            'analytics' => $this->buildAnalytics($filteredRows),
            'table' => $table,
        ];
    }

    public function getTeamManagementData(array $context, string $requestedTeamCode = ''): array
    {
        $functional = trim((string) (($context['profile'] ?? [])['funcional'] ?? ''));
        $managerTeamIds = $this->resolveMappedTeamIds($functional, 'manager');

        if ($managerTeamIds === []) {
            return [
                'teams' => [],
                'selected_team' => [],
                'managers' => [],
                'analysts' => [],
                'candidate_analysts' => [],
            ];
        }

        $teams = $this->fetchTeamsByIds($managerTeamIds);

        if ($teams === []) {
            return [
                'teams' => [],
                'selected_team' => [],
                'managers' => [],
                'analysts' => [],
                'candidate_analysts' => [],
            ];
        }

        $selectedTeam = $teams[0];
        $requestedTeamCode = strtoupper(trim($requestedTeamCode));

        foreach ($teams as $team) {
            if (strtoupper((string) ($team['code'] ?? '')) !== $requestedTeamCode) {
                continue;
            }

            $selectedTeam = $team;
            break;
        }

        $selectedTeamId = (int) ($selectedTeam['id'] ?? 0);

        return [
            'teams' => $teams,
            'selected_team' => $selectedTeam,
            'managers' => $this->fetchTeamManagers($selectedTeamId),
            'analysts' => $this->fetchTeamAnalysts($selectedTeamId),
            'candidate_analysts' => $this->fetchAssignableAnalystCandidates($selectedTeamId),
        ];
    }

    public function setTeamAnalystMembership(array $context, string $teamCode, string $analystFunctional, bool $active): bool
    {
        $managerFunctional = trim((string) (($context['profile'] ?? [])['funcional'] ?? ''));
        $analystFunctional = substr(trim($analystFunctional), 0, 7);
        $teamCode = strtoupper(trim($teamCode));

        if ($managerFunctional === '' || $analystFunctional === '' || $teamCode === '' || !$this->hasTable(self::ANALYST_TEAM_TABLE_NAME)) {
            return false;
        }

        $managerTeamIds = $this->resolveMappedTeamIds($managerFunctional, 'manager');
        $team = $this->findTeamByCode($teamCode);
        $teamId = (int) ($team['id'] ?? 0);

        if ($teamId <= 0 || !in_array($teamId, $managerTeamIds, true) || !$this->isAssignableAnalystFunctional($analystFunctional)) {
            return false;
        }

        $row = $this->fetchProcedureRow('sp_omega_upsert_analyst_team_mapping', [
            'p_team_id' => $teamId,
            'p_functional' => $analystFunctional,
            'p_active_flag' => $active ? 1 : 0,
            'p_origin' => self::UI_ORIGIN,
        ]);

        return (int) (($row['ok_flag'] ?? 0)) === 1;
    }

    public function addComment(array $context, int $callId, string $authorRole, string $comment): array
    {
        $access = $this->resolveContextAccess($context);
        $callId = max(0, $callId);
        $functionalAuthor = substr(trim((string) ($access['functional'] ?? '')), 0, 7);
        $comment = $this->sanitizeStoredMultilineText($comment, 4000);

        if ($callId <= 0 || $comment === '') {
            return [
                'ok' => false,
                'message' => 'Informe o comentário antes de enviar.',
            ];
        }

        if ($functionalAuthor === '') {
            return [
                'ok' => false,
                'message' => 'Selecione um perfil válido antes de comentar.',
            ];
        }

        $existingCall = $this->fetchRawCallById($callId);

        if ($existingCall === []) {
            return [
                'ok' => false,
                'message' => 'O chamado selecionado não foi encontrado.',
            ];
        }

        $requesterFunctional = substr(trim((string) ($existingCall['solicitante_funcional'] ?? '')), 0, 7);
        $statusCode = strtoupper(trim((string) ($existingCall['codigo_status'] ?? 'SEM_STATUS')));
        $isOperational = (bool) ($access['can_access_dashboard'] ?? false);
        $requestedAnalystRole = strtoupper(trim($authorRole)) === 'ANALYST' && $isOperational;
        $normalizedAuthorRole = $requestedAnalystRole ? 'ANALISTA' : 'SOLICITANTE';

        if (!$isOperational && $requesterFunctional !== '' && $requesterFunctional !== $functionalAuthor) {
            return [
                'ok' => false,
                'message' => 'Você não pode interagir com este chamado.',
            ];
        }

        if ($normalizedAuthorRole === 'SOLICITANTE' && $this->isTerminalStatus($statusCode)) {
            return [
                'ok' => false,
                'message' => 'Este chamado já foi finalizado. Abra um novo chamado para continuar.',
            ];
        }

        $this->ensureCommentTable();

        if (!$this->hasTable(self::COMMENT_TABLE_NAME)) {
            return [
                'ok' => false,
                'message' => 'A estrutura de comentários do Omega não está disponível.',
            ];
        }

        $timestamp = date('Y-m-d H:i:s');
        $commentAuthorFunctional = $normalizedAuthorRole === 'ANALISTA'
            ? $functionalAuthor
            : ($requesterFunctional !== '' ? $requesterFunctional : $functionalAuthor);

        $commentId = (int) ($this->fetchProcedureValue('sp_omega_add_comment', [
            'p_call_id' => $callId,
            'p_functional_author' => $commentAuthorFunctional,
            'p_author_role' => $normalizedAuthorRole,
            'p_comment_text' => $comment,
            'p_commented_at' => $timestamp,
            'p_origin' => self::UI_ORIGIN,
        ]) ?? 0);

        if ($commentId <= 0) {
            return [
                'ok' => false,
                'message' => 'Nao foi possivel registrar o comentario no banco de dados.',
            ];
        }

        return [
            'ok' => true,
            'comment' => [
                'role' => $normalizedAuthorRole === 'ANALISTA' ? 'analyst' : 'user',
                'timestamp' => $timestamp,
                'message' => $comment,
                'functional_author' => $commentAuthorFunctional,
            ],
        ];
    }

    public function saveCall(array $context, array $payload): array
    {
        $this->ensureCallSchema();

        if (!$this->hasTable(self::CALLS_TABLE_NAME)) {
            return [
                'ok' => false,
                'message' => 'A estrutura principal do Omega não está disponível.',
            ];
        }

        $access = $this->resolveContextAccess($context);
        $profile = (array) ($context['profile'] ?? []);
        $junctions = array_values((array) ($context['junctions'] ?? []));
        $currentFunctional = substr(trim((string) ($access['functional'] ?? ($profile['funcional'] ?? ''))), 0, 7);
        $currentName = trim((string) ($profile['nome'] ?? 'Usuário'));
        $currentLevel = substr(trim((string) ($profile['nivel'] ?? 'GC')), 0, 2);
        $currentView = trim((string) ($payload['current_view'] ?? 'my-calls'));
        $callId = max(0, (int) ($payload['call_id'] ?? 0));
        $title = $this->sanitizeStoredPlainText((string) ($payload['title'] ?? ''), 200);
        $description = $this->sanitizeStoredMultilineText((string) ($payload['description'] ?? ''), 1000);
        $departmentLabel = $this->normalizeDepartmentLabel((string) ($payload['department'] ?? 'POBJ'));
        $requestedTypeLabel = $this->sanitizeStoredPlainText((string) ($payload['type'] ?? ''), 120);
        $requestedQueue = trim((string) ($payload['queue'] ?? ''));
        $requestedPriorityLabel = $this->sanitizeStoredPlainText((string) ($payload['priority'] ?? ''), 30);
        $requestedAnalystFunctional = trim((string) ($payload['analyst_functional'] ?? ''));
        $statusCode = strtoupper(trim((string) ($payload['status_code'] ?? 'ABERTO')));
        $isOperational = (bool) ($access['can_access_dashboard'] ?? false);

        if ($currentFunctional === '' || $title === '' || $description === '') {
            return [
                'ok' => false,
                'message' => 'Preencha título e descrição antes de salvar.',
            ];
        }

        $existingCall = $callId > 0 ? $this->fetchRawCallById($callId) : [];

        if ($existingCall !== [] && !$isOperational) {
            $existingRequesterFunctional = substr(trim((string) ($existingCall['solicitante_funcional'] ?? '')), 0, 7);

            if ($existingRequesterFunctional !== '' && $existingRequesterFunctional !== $currentFunctional) {
                return [
                    'ok' => false,
                    'message' => 'Você não pode editar este chamado.',
                ];
            }

            if ($this->isTerminalStatus((string) ($existingCall['codigo_status'] ?? 'SEM_STATUS'))) {
                return [
                    'ok' => false,
                    'message' => 'Este chamado já foi finalizado. Abra um novo chamado para continuar.',
                ];
            }
        }

        if ($existingCall !== [] && !$isOperational) {
            $departmentLabel = $this->normalizeDepartmentLabel((string) ($existingCall['solicitante_segmento'] ?? 'POBJ'));
            $requestedTypeLabel = $this->sanitizeStoredPlainText((string) ($existingCall['nome_categoria'] ?? $requestedTypeLabel), 120);
            $requestedQueue = trim((string) ($existingCall['codigo_time'] ?? $existingCall['nome_time'] ?? $requestedQueue));
            $statusCode = strtoupper(trim((string) ($existingCall['codigo_status'] ?? $statusCode)));
            $requestedPriorityLabel = $this->sanitizeStoredPlainText((string) ($existingCall['priority_label'] ?? ''), 30);
            $requestedAnalystFunctional = trim((string) ($existingCall['funcional_analista_atual'] ?? ''));
        }

        if (!$isOperational && $existingCall === []) {
            $statusCode = 'ABERTO';
            $requestedPriorityLabel = '';
            $requestedAnalystFunctional = '';
            $requestedQueue = $departmentLabel;
        }

        $statusRecord = $this->resolveStatusRecord($statusCode);

        if ($statusRecord === []) {
            return [
                'ok' => false,
                'message' => 'Selecione um status válido para o chamado.',
            ];
        }

        $selectedTeam = $this->resolveRequestedTeam($requestedQueue, $departmentLabel);

        if ($selectedTeam !== []) {
            $departmentLabel = $this->normalizeDepartmentLabel((string) ($selectedTeam['label'] ?? $departmentLabel));
        }

        $typeLabel = $this->normalizeDepartmentType($departmentLabel, $requestedTypeLabel);
        $junctionMap = $existingCall !== []
            ? [
                'ag' => substr(trim((string) ($existingCall['solicitante_juncao_ag'] ?? '')), 0, 4),
                'gr' => substr(trim((string) ($existingCall['solicitante_juncao_gr'] ?? '')), 0, 4),
                'dr' => substr(trim((string) ($existingCall['solicitante_juncao_dr'] ?? '')), 0, 4),
            ]
            : $this->resolveJunctionMap($junctions);
        $requesterFunctional = $existingCall !== []
            ? substr(trim((string) ($existingCall['solicitante_funcional'] ?? $currentFunctional)), 0, 7)
            : $currentFunctional;
        $requesterName = $existingCall !== []
            ? $this->sanitizeStoredPlainText((string) ($existingCall['solicitante_nome'] ?? $currentName), 160)
            : $currentName;
        $requesterLevel = $existingCall !== []
            ? substr(trim((string) ($existingCall['solicitante_nivel'] ?? $currentLevel)), 0, 2)
            : $currentLevel;
        $teamName = trim((string) ($selectedTeam['label'] ?? $selectedTeam['name'] ?? ''));

        if ($teamName === '') {
            $teamName = trim((string) ($existingCall['nome_time'] ?? $departmentLabel));
        }

        $teamId = (int) ($selectedTeam['id'] ?? 0);

        if ($teamId <= 0) {
            $teamId = $this->ensureTeam($teamName !== '' ? $teamName : $departmentLabel);
        }

        if ($teamId <= 0) {
            return [
                'ok' => false,
                'message' => 'Não foi possível localizar a fila selecionada.',
            ];
        }

        $categoryName = $typeLabel !== ''
            ? $typeLabel
            : $this->sanitizeStoredPlainText((string) ($existingCall['nome_categoria'] ?? 'Atendimento'), 120);
        $categoryId = $this->ensureCategory($teamId, $categoryName);
        $priorityLabel = $this->normalizePriorityLabel(
            $requestedPriorityLabel !== ''
                ? $requestedPriorityLabel
                : ($existingCall['priority_label'] ?? $this->inferPriorityLabel($statusCode))
        );
        $analystResolution = $this->resolveAnalystFunctionalForSave(
            $existingCall,
            $access,
            $requesterFunctional,
            $currentView,
            $statusCode,
            $requestedAnalystFunctional,
            $teamId
        );

        if (!(bool) ($analystResolution['ok'] ?? false)) {
            return [
                'ok' => false,
                'message' => (string) ($analystResolution['message'] ?? 'Não foi possível validar o analista selecionado.'),
            ];
        }

        $analystFunctional = substr(trim((string) ($analystResolution['functional'] ?? '')), 0, 7);
        $timestamp = date('Y-m-d H:i:s');
        $closedAt = $this->isTerminalStatus($statusCode)
            ? ($existingCall !== [] && trim((string) ($existingCall['dt_fechamento'] ?? '')) !== ''
                ? trim((string) ($existingCall['dt_fechamento'] ?? ''))
                : $timestamp)
            : null;
        $resolutionFinal = $this->isTerminalStatus($statusCode)
            ? substr($description, 0, 1000)
            : null;

        $this->ensureMovementTable();

        $this->connection->beginTransaction();

        try {
            if ($existingCall !== []) {
                $affectedRows = (int) ($this->fetchProcedureValue('sp_omega_update_call', [
                    'p_call_id' => $callId,
                    'p_requester_name' => $requesterName,
                    'p_requester_level' => $requesterLevel !== '' ? $requesterLevel : 'GC',
                    'p_junction_ag' => $junctionMap['ag'] !== '' ? $junctionMap['ag'] : null,
                    'p_junction_gr' => $junctionMap['gr'] !== '' ? $junctionMap['gr'] : null,
                    'p_junction_dr' => $junctionMap['dr'] !== '' ? $junctionMap['dr'] : null,
                    'p_segment_label' => $departmentLabel !== '' ? $departmentLabel : 'POBJ',
                    'p_team_id' => $teamId,
                    'p_category_id' => $categoryId,
                    'p_status_id' => (int) ($statusRecord['id'] ?? 0),
                    'p_analyst_functional' => $analystFunctional !== '' ? $analystFunctional : null,
                    'p_priority_label' => $priorityLabel,
                    'p_title' => $title,
                    'p_description' => $description,
                    'p_updated_at' => $timestamp,
                    'p_closed_at' => $closedAt,
                    'p_resolution_final' => $resolutionFinal,
                    'p_origin' => self::UI_ORIGIN,
                ]) ?? 0);

                if ($affectedRows <= 0) {
                    throw new \RuntimeException('omega_call_update_failed');
                }

                $this->insertMovement([
                    'call_id' => $callId,
                    'movement_type' => $this->isTerminalStatus($statusCode) ? 'FECHAMENTO' : 'ATUALIZACAO',
                    'responsible_functional' => $currentFunctional,
                    'status_origin_id' => isset($existingCall['id_omega_status_atual']) ? (int) $existingCall['id_omega_status_atual'] : null,
                    'status_destination_id' => (int) ($statusRecord['id'] ?? 0),
                    'time_origin_id' => isset($existingCall['id_omega_time_atual']) ? (int) $existingCall['id_omega_time_atual'] : null,
                    'time_destination_id' => $teamId,
                    'category_origin_id' => isset($existingCall['id_omega_categoria_atual']) ? (int) $existingCall['id_omega_categoria_atual'] : null,
                    'category_destination_id' => $categoryId,
                    'analyst_origin' => substr(trim((string) ($existingCall['funcional_analista_atual'] ?? '')), 0, 7) ?: null,
                    'analyst_destination' => $analystFunctional !== '' ? $analystFunctional : null,
                    'observation' => $this->isTerminalStatus($statusCode)
                        ? 'Finalização registrada via painel Omega.'
                        : 'Atualização registrada via painel Omega.',
                    'moved_at' => $timestamp,
                ]);
            } else {
                $callId = (int) ($this->fetchProcedureValue('sp_omega_insert_call', [
                    'p_requester_functional' => $requesterFunctional,
                    'p_requester_name' => $requesterName,
                    'p_requester_level' => $requesterLevel !== '' ? $requesterLevel : 'GC',
                    'p_junction_ag' => $junctionMap['ag'] !== '' ? $junctionMap['ag'] : null,
                    'p_junction_gr' => $junctionMap['gr'] !== '' ? $junctionMap['gr'] : null,
                    'p_junction_dr' => $junctionMap['dr'] !== '' ? $junctionMap['dr'] : null,
                    'p_segment_label' => $departmentLabel !== '' ? $departmentLabel : 'POBJ',
                    'p_team_id' => $teamId,
                    'p_category_id' => $categoryId,
                    'p_status_id' => (int) ($statusRecord['id'] ?? 0),
                    'p_analyst_functional' => $analystFunctional !== '' ? $analystFunctional : null,
                    'p_priority_label' => $priorityLabel,
                    'p_title' => $title,
                    'p_description' => $description,
                    'p_opened_at' => $timestamp,
                    'p_updated_at' => $timestamp,
                    'p_closed_at' => $closedAt,
                    'p_resolution_final' => $resolutionFinal,
                    'p_origin' => self::UI_ORIGIN,
                ]) ?? 0);

                if ($callId <= 0) {
                    throw new \RuntimeException('omega_call_insert_failed');
                }

                $this->insertMovement([
                    'call_id' => $callId,
                    'movement_type' => 'ABERTURA',
                    'responsible_functional' => $currentFunctional,
                    'status_origin_id' => null,
                    'status_destination_id' => (int) ($statusRecord['id'] ?? 0),
                    'time_origin_id' => null,
                    'time_destination_id' => $teamId,
                    'category_origin_id' => null,
                    'category_destination_id' => $categoryId,
                    'analyst_origin' => null,
                    'analyst_destination' => $analystFunctional !== '' ? $analystFunctional : null,
                    'observation' => 'Chamado registrado via painel Omega.',
                    'moved_at' => $timestamp,
                ]);
            }

            if ($analystFunctional !== '') {
                $this->ensureFunctionalMappedToTeam($analystFunctional, $teamId, 'analyst');
            }

            $this->connection->commit();
        } catch (Throwable $exception) {
            if ($this->connection->inTransaction()) {
                $this->connection->rollBack();
            }

            return [
                'ok' => false,
                'message' => 'Não foi possível salvar o chamado no banco de dados.',
            ];
        }

        return [
            'ok' => true,
            'record' => $this->findCallById($callId),
        ];
    }

    public function findCallById(int $callId): array
    {
        $this->ensureCallSchema();

        $rawRow = $this->fetchRawCallById(max(0, $callId));

        if ($rawRow === []) {
            return [];
        }

        $rows = [$this->normalizeRow($rawRow)];
        $rows = $this->attachMovementThreads($rows);
        $rows = $this->attachCommentThreads($rows);

        return $rows[0] ?? [];
    }

    private function fetchSourceRows(string $functional, array $analystTeamIds, array $accessibleTeamIds, string $view): array
    {
        if ($functional === '' || !$this->hasTable(self::CALLS_TABLE_NAME)) {
            return [];
        }

        switch ($view) {
            case 'my-work':
                if ($analystTeamIds === []) {
                    return [];
                }
                $teamIds = $analystTeamIds;
                break;

            case 'team-queue':
                if ($accessibleTeamIds === []) {
                    return [];
                }
                $teamIds = $accessibleTeamIds;
                break;

            case 'my-calls':
            default:
                $teamIds = [];
                break;
        }

        $rows = [];

        foreach ($this->fetchProcedureAll('sp_omega_list_source_rows', [
            'p_view' => $view,
            'p_functional' => $functional,
            'p_team_ids_csv' => $this->encodeProcedureList(array_map('strval', $teamIds)),
        ]) as $row) {
            $rows[] = $this->normalizeRow($row);
        }

        return $rows;
    }

    private function fetchViewCounts(string $functional, array $analystTeamIds, array $accessibleTeamIds): array
    {
        $counts = [
            'my-calls' => 0,
            'my-work' => 0,
            'team-queue' => 0,
        ];

        if ($functional === '' || !$this->hasTable(self::CALLS_TABLE_NAME)) {
            return $counts;
        }

        $counts['my-calls'] = (int) ($this->fetchProcedureValue('sp_omega_count_calls_by_view', [
            'p_view' => 'my-calls',
            'p_functional' => $functional,
            'p_team_ids_csv' => '',
        ]) ?? 0);

        if ($analystTeamIds !== []) {
            $counts['my-work'] = (int) ($this->fetchProcedureValue('sp_omega_count_calls_by_view', [
                'p_view' => 'my-work',
                'p_functional' => $functional,
                'p_team_ids_csv' => $this->encodeProcedureList(array_map('strval', $analystTeamIds)),
            ]) ?? 0);
        }

        if ($accessibleTeamIds !== []) {
            $counts['team-queue'] = (int) ($this->fetchProcedureValue('sp_omega_count_calls_by_view', [
                'p_view' => 'team-queue',
                'p_functional' => '',
                'p_team_ids_csv' => $this->encodeProcedureList(array_map('strval', $accessibleTeamIds)),
            ]) ?? 0);
        }

        return $counts;
    }

    private function fetchSingleCount(string $sql, array $params): int
    {
        return 0;
    }

    private function buildCallsFromSql(): string
    {
        return '';
    }

    private function listStatusOptions(): array
    {
        if (!$this->hasTable(self::STATUS_TABLE_NAME)) {
            return $this->defaultStatusOptions();
        }

        $rows = $this->fetchProcedureAll('sp_omega_list_status_options');

        if ($rows === []) {
            return $this->defaultStatusOptions();
        }

        $options = [];

        foreach ($rows as $row) {
            $value = trim((string) ($row['codigo_status'] ?? ''));
            $label = trim((string) ($row['nome_status'] ?? ''));

            if ($value === '' || $label === '') {
                continue;
            }

            $options[] = [
                'value' => $value,
                'label' => $label,
                'color' => trim((string) ($row['cor_hex'] ?? '#cbd5e1')),
            ];
        }

        return $options !== [] ? $options : $this->defaultStatusOptions();
    }

    private function defaultStatusOptions(): array
    {
        return [
            ['value' => 'ABERTO', 'label' => 'Aberto', 'color' => '#6CC7BE'],
            ['value' => 'AGUARDANDO', 'label' => 'Aguardando', 'color' => '#7BB9F0'],
            ['value' => 'EM_ATENDIMENTO', 'label' => 'Em atendimento', 'color' => '#9ED8A1'],
            ['value' => 'REJEITADO', 'label' => 'Rejeitado', 'color' => '#F28B82'],
            ['value' => 'FECHADO', 'label' => 'Fechado', 'color' => '#CBD5E1'],
        ];
    }

    private function resolveTeamIds(string $functional): array
    {
        return array_values(array_unique(array_merge(
            $this->resolveMappedTeamIds($functional, 'analyst'),
            $this->resolveMappedTeamIds($functional, 'manager')
        )));
    }

    private function resolveMappedTeamIds(string $functional, string $role): array
    {
        if ($functional === '') {
            return [];
        }

        $teamIds = array_map('intval', array_column($this->fetchProcedureAll(
            'sp_omega_list_mapped_team_ids',
            [
                'p_functional' => $functional,
                'p_role' => $role,
            ]
        ), 'id_omega_time'));
        $teamIds = array_values(array_unique(array_filter($teamIds, static function (int $value): bool {
            return $value > 0;
        })));
        sort($teamIds);

        return $teamIds;
    }

    private function fetchRawCallById(int $callId): array
    {
        if ($callId <= 0 || !$this->hasTable(self::CALLS_TABLE_NAME)) {
            return [];
        }

        $row = $this->fetchProcedureRow('sp_omega_get_call_by_id', ['p_call_id' => $callId]);

        return is_array($row) ? $row : [];
    }

    private function resolveStatusRecord(string $statusCode): array
    {
        $statusCode = strtoupper(trim($statusCode));

        if ($statusCode === '' || !$this->hasTable(self::STATUS_TABLE_NAME)) {
            return [];
        }

        $row = $this->fetchProcedureRow('sp_omega_get_status_record', ['p_status_code' => $statusCode]);

        if (is_array($row)) {
            return [
                'id' => (int) ($row['id_omega_status'] ?? 0),
                'code' => trim((string) ($row['codigo_status'] ?? '')),
                'label' => trim((string) ($row['nome_status'] ?? '')),
                'color' => trim((string) ($row['cor_hex'] ?? '#cbd5e1')),
            ];
        }

        return [];
    }

    private function resolveJunctionMap(array $junctions): array
    {
        $map = ['ag' => '', 'gr' => '', 'dr' => ''];

        foreach ($junctions as $junction) {
            if (!is_array($junction)) {
                continue;
            }

            $type = strtoupper(trim((string) ($junction['tipo_juncao'] ?? '')));
            $code = substr(trim((string) ($junction['juncao'] ?? '')), 0, 4);

            if ($code === '') {
                continue;
            }

            if ($type === 'AG' && $map['ag'] === '') {
                $map['ag'] = $code;
                continue;
            }

            if ($type === 'GR' && $map['gr'] === '') {
                $map['gr'] = $code;
                continue;
            }

            if ($type === 'DR' && $map['dr'] === '') {
                $map['dr'] = $code;
            }
        }

        return $map;
    }

    private function resolveAnalystFunctionalForSave(
        array $existingCall,
        array $access,
        string $requesterFunctional,
        string $currentView,
        string $statusCode,
        string $requestedAnalystFunctional,
        int $teamId
    ): array {
        $currentFunctional = substr(trim((string) ($access['functional'] ?? '')), 0, 7);
        $accessibleTeamIds = array_map('intval', (array) ($access['accessible_team_ids'] ?? []));
        $existingAnalyst = substr(trim((string) ($existingCall['funcional_analista_atual'] ?? '')), 0, 7);
        $currentView = trim($currentView);
        $requestedAnalystFunctional = substr(trim($requestedAnalystFunctional), 0, 7);

        if ($requestedAnalystFunctional !== '') {
            if (!in_array($teamId, $accessibleTeamIds, true) || !$this->isAnalystMappedToTeam($requestedAnalystFunctional, $teamId)) {
                return [
                    'ok' => false,
                    'message' => 'Selecione apenas analistas ativos do seu departamento.',
                    'functional' => '',
                ];
            }

            return [
                'ok' => true,
                'functional' => $requestedAnalystFunctional,
            ];
        }

        if ($existingAnalyst !== '' && $this->isAnalystMappedToTeam($existingAnalyst, $teamId)) {
            return [
                'ok' => true,
                'functional' => $existingAnalyst,
            ];
        }

        if (($currentView === 'my-work' || $currentView === 'team-queue')
            && !$this->isTerminalStatus($statusCode)
            && $currentFunctional !== ''
            && in_array($teamId, $accessibleTeamIds, true)
            && $this->isAnalystMappedToTeam($currentFunctional, $teamId)) {
            return [
                'ok' => true,
                'functional' => $currentFunctional,
            ];
        }

        if ($currentFunctional !== ''
            && $currentFunctional !== $requesterFunctional
            && !$this->isTerminalStatus($statusCode)
            && in_array($teamId, $accessibleTeamIds, true)
            && $this->isAnalystMappedToTeam($currentFunctional, $teamId)) {
            return [
                'ok' => true,
                'functional' => $currentFunctional,
            ];
        }

        return [
            'ok' => true,
            'functional' => '',
        ];
    }

    private function ensureTeam(string $teamName): int
    {
        if (!$this->hasTable(self::TIMES_TABLE_NAME)) {
            return 0;
        }

        $teamName = substr(trim($teamName), 0, 150);

        if ($teamName === '') {
            $teamName = 'POBJ';
        }

        $team = $this->findTeamByName($teamName);
        $teamId = (int) ($team['id'] ?? 0);

        if ($teamId > 0) {
            return $teamId;
        }

        $baseCode = $this->buildOmegaCode($teamName, 50);
        $teamCode = $baseCode;
        $suffix = 2;

        while ($this->omegaTimeCodeExists($teamCode)) {
            $suffixValue = '_' . $suffix;
            $teamCode = substr($baseCode, 0, max(1, 50 - strlen($suffixValue))) . $suffixValue;
            $suffix++;
        }

        return (int) ($this->fetchProcedureValue('sp_omega_insert_team', [
            'p_team_code' => $teamCode,
            'p_team_name' => $teamName,
            'p_description' => 'Time criado automaticamente pelo painel Omega.',
            'p_origin' => self::UI_ORIGIN,
        ]) ?? 0);
    }

    private function omegaTimeCodeExists(string $teamCode): bool
    {
        return (bool) $this->fetchProcedureValue('sp_omega_team_code_exists', ['p_team_code' => $teamCode]);
    }

    private function ensureCategory(int $teamId, string $categoryName): ?int
    {
        if ($teamId <= 0 || !$this->hasTable(self::CATEGORY_TABLE_NAME)) {
            return null;
        }

        $categoryName = substr(trim($categoryName), 0, 150);

        if ($categoryName === '') {
            return null;
        }

        $categoryId = (int) ($this->fetchProcedureValue('sp_omega_ensure_category', [
            'p_team_id' => $teamId,
            'p_category_name' => $categoryName,
            'p_description' => 'Categoria criada automaticamente pelo painel Omega.',
            'p_origin' => self::UI_ORIGIN,
        ]) ?? 0);

        return $categoryId > 0 ? $categoryId : null;
    }

    private function ensureFunctionalMappedToTeam(string $functional, int $teamId, string $role): void
    {
        $functional = substr(trim($functional), 0, 7);

        if ($functional === '' || $teamId <= 0) {
            return;
        }

        $tableName = $role === 'analyst' ? self::ANALYST_TEAM_TABLE_NAME : self::FOCAL_TEAM_TABLE_NAME;

        if (!$this->hasTable($tableName)) {
            return;
        }

        $this->fetchProcedureValue('sp_omega_ensure_team_functional_mapping', [
            'p_team_id' => $teamId,
            'p_functional' => $functional,
            'p_role' => $role,
            'p_origin' => self::UI_ORIGIN,
        ]);
    }

    private function buildOmegaCode(string $value, int $maxLength): string
    {
        $normalizedValue = strtoupper(trim($value));
        $normalizedValue = strtr($normalizedValue, [
            'Á' => 'A', 'À' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Ä' => 'A',
            'É' => 'E', 'È' => 'E', 'Ê' => 'E', 'Ë' => 'E',
            'Í' => 'I', 'Ì' => 'I', 'Î' => 'I', 'Ï' => 'I',
            'Ó' => 'O', 'Ò' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ö' => 'O',
            'Ú' => 'U', 'Ù' => 'U', 'Û' => 'U', 'Ü' => 'U',
            'Ç' => 'C',
        ]);
        $normalizedValue = preg_replace('/[^A-Z0-9]+/', '_', $normalizedValue) ?? '';
        $normalizedValue = trim($normalizedValue, '_');

        if ($normalizedValue === '') {
            $normalizedValue = 'OMEGA';
        }

        return substr($normalizedValue, 0, max(1, $maxLength));
    }

    private function isTerminalStatus(string $statusCode): bool
    {
        return in_array(strtoupper(trim($statusCode)), ['FECHADO', 'FINALIZADO', 'REJEITADO', 'CANCELADO', 'RESOLVIDO'], true);
    }

    private function insertMovement(array $payload): void
    {
        $this->ensureMovementTable();

        if (!$this->hasTable(self::MOVEMENT_TABLE_NAME)) {
            return;
        }

        $callId = max(0, (int) ($payload['call_id'] ?? 0));
        $responsibleFunctional = substr(trim((string) ($payload['responsible_functional'] ?? '')), 0, 7);

        if ($callId <= 0 || $responsibleFunctional === '') {
            return;
        }

        $this->fetchProcedureValue('sp_omega_insert_movement', [
            'p_call_id' => $callId,
            'p_movement_type' => substr(trim((string) ($payload['movement_type'] ?? 'ATUALIZACAO')), 0, 30),
            'p_responsible_functional' => $responsibleFunctional,
            'p_status_origin_id' => $payload['status_origin_id'] !== null ? (int) $payload['status_origin_id'] : null,
            'p_status_destination_id' => $payload['status_destination_id'] !== null ? (int) $payload['status_destination_id'] : null,
            'p_time_origin_id' => $payload['time_origin_id'] !== null ? (int) $payload['time_origin_id'] : null,
            'p_time_destination_id' => $payload['time_destination_id'] !== null ? (int) $payload['time_destination_id'] : null,
            'p_category_origin_id' => $payload['category_origin_id'] !== null ? (int) $payload['category_origin_id'] : null,
            'p_category_destination_id' => $payload['category_destination_id'] !== null ? (int) $payload['category_destination_id'] : null,
            'p_analyst_origin' => $payload['analyst_origin'] !== null ? substr(trim((string) $payload['analyst_origin']), 0, 7) : null,
            'p_analyst_destination' => $payload['analyst_destination'] !== null ? substr(trim((string) $payload['analyst_destination']), 0, 7) : null,
            'p_observation' => ($payload['observation'] ?? null) !== null ? substr(trim((string) ($payload['observation'] ?? '')), 0, 1000) : null,
            'p_moved_at' => trim((string) ($payload['moved_at'] ?? date('Y-m-d H:i:s'))),
            'p_origin' => self::UI_ORIGIN,
        ]);
    }

    private function buildFacetOptions(array $rows): array
    {
        $departments = [];
        $types = [];
        $priorities = [];
        $departmentTypeMap = [];

        foreach ($rows as $row) {
            $department = trim((string) ($row['department_label'] ?? ''));
            $type = trim((string) ($row['type_label'] ?? ''));
            $priority = trim((string) ($row['priority_label'] ?? ''));

            if ($department !== '' && strcasecmp($department, 'Equipe Matriz') !== 0) {
                $departments[$department] = $department;
            }

            if ($type !== '') {
                $types[$type] = $type;

                if ($department !== '' && strcasecmp($department, 'Equipe Matriz') !== 0) {
                    $departmentTypeMap[$department][$type] = $type;
                }
            }

            if ($priority !== '') {
                $priorities[$priority] = $priority;
            }
        }

        foreach (self::DEPARTMENT_TYPE_DEFAULTS as $departmentDefault => $typeDefaults) {
            $departments[$departmentDefault] = $departmentDefault;

            foreach ($typeDefaults as $typeDefault) {
                $types[$typeDefault] = $typeDefault;
                $departmentTypeMap[$departmentDefault][$typeDefault] = $typeDefault;
            }
        }

        foreach (['Alta', 'Média', 'Baixa'] as $priorityDefault) {
            $priorities[$priorityDefault] = $priorityDefault;
        }

        ksort($departments);
        ksort($types);
        ksort($priorities);

        return [
            'departments' => array_map(static function (string $value): array {
                return ['value' => $value, 'label' => $value];
            }, array_values($departments)),
            'types' => array_map(static function (string $value): array {
                return ['value' => $value, 'label' => $value];
            }, array_values($types)),
            'priorities' => array_map(static function (string $value): array {
                return ['value' => $value, 'label' => $value];
            }, array_values($priorities)),
            'department_type_map' => array_map(static function (array $departmentTypes): array {
                ksort($departmentTypes);

                return array_values(array_map(static function (string $value): array {
                    return ['value' => $value, 'label' => $value];
                }, array_values($departmentTypes)));
            }, $departmentTypeMap),
        ];
    }

    private function buildEditorOptions(array $accessibleTeamIds): array
    {
        $queues = $this->fetchAllActiveTeams();
        $queueDepartmentMap = [];
        $queueAnalystMap = [];
        $accessibleTeams = $this->fetchTeamsByIds($accessibleTeamIds);

        foreach ($queues as $queue) {
            $queueValue = trim((string) ($queue['value'] ?? ''));

            if ($queueValue === '') {
                continue;
            }

            $queueDepartmentMap[$queueValue] = (string) ($queue['department'] ?? 'POBJ');
        }

        foreach ($accessibleTeams as $team) {
            $teamId = (int) ($team['id'] ?? 0);
            $teamCode = trim((string) ($team['code'] ?? ''));

            if ($teamId <= 0 || $teamCode === '') {
                continue;
            }

            $queueAnalystMap[$teamCode] = array_map(static function (array $analyst): array {
                $functional = trim((string) ($analyst['functional'] ?? ''));
                $name = trim((string) ($analyst['name'] ?? 'Analista'));
                $level = trim((string) ($analyst['level'] ?? ''));
                $label = $name;

                if ($functional !== '') {
                    $label .= ' • ' . $functional;
                }

                if ($level !== '') {
                    $label .= ' • ' . $level;
                }

                return [
                    'value' => $functional,
                    'label' => $label,
                    'name' => $name,
                    'functional' => $functional,
                    'level' => $level,
                ];
            }, $this->fetchTeamAnalysts($teamId));
        }

        return [
            'queues' => $queues,
            'queue_department_map' => $queueDepartmentMap,
            'queue_analyst_map' => $queueAnalystMap,
        ];
    }

    private function normalizeDepartmentLabel(string $department): string
    {
        $department = trim($department);

        if ($department === '' || strcasecmp($department, 'Equipe Matriz') === 0 || strcasecmp($department, 'Matriz') === 0) {
            return 'POBJ';
        }

        foreach (array_keys(self::DEPARTMENT_TYPE_DEFAULTS) as $allowedDepartment) {
            if (strcasecmp($department, $allowedDepartment) === 0) {
                return $allowedDepartment;
            }
        }

        return 'POBJ';
    }

    private function normalizeDepartmentType(string $department, string $type): string
    {
        $allowedTypes = self::DEPARTMENT_TYPE_DEFAULTS[$department] ?? self::DEPARTMENT_TYPE_DEFAULTS['POBJ'];
        $type = trim($type);

        foreach ($allowedTypes as $allowedType) {
            if (strcasecmp($type, $allowedType) === 0) {
                return $allowedType;
            }
        }

        return $allowedTypes[0] ?? 'Outros';
    }

    private function filterRows(array $rows, array $filters, array $statusCodes): array
    {
        $filteredRows = [];

        foreach ($rows as $row) {
            if (!$this->matchesFilters($row, $filters, $statusCodes)) {
                continue;
            }

            $filteredRows[] = $row;
        }

        return $filteredRows;
    }

    private function paginateRows(array $rows, int $page, int $perPage): array
    {
        $totalRows = count($rows);
        $totalPages = max(1, (int) ceil($totalRows / max(1, $perPage)));
        $currentPage = min(max(1, $page), $totalPages);
        $offset = ($currentPage - 1) * $perPage;

        return [
            'rows' => array_slice($rows, $offset, $perPage),
            'total_rows' => $totalRows,
            'current_page' => $currentPage,
            'per_page' => $perPage,
            'total_pages' => $totalPages,
        ];
    }

    private function buildAnalytics(array $rows): array
    {
        $openedTotal = 0;
        $closedTotal = 0;
        $requesters = [];
        $departments = [];
        $priorities = [];
        $types = [];
        $monthly = [];

        foreach ($rows as $row) {
            $statusCode = strtoupper(trim((string) ($row['status_code'] ?? 'SEM_STATUS')));
            $requester = trim((string) ($row['user_label'] ?? 'Usuário'));
            $department = trim((string) ($row['department_label'] ?? 'POBJ'));
            $priority = $this->normalizePriorityLabel((string) ($row['priority_label'] ?? 'Média'));
            $type = trim((string) ($row['type_label'] ?? 'Atendimento'));
            $openedAt = trim((string) ($row['opened_at'] ?? ''));
            $updatedAt = trim((string) ($row['updated_at'] ?? ''));

            if ($this->isTerminalStatus($statusCode)) {
                $closedTotal++;
            } else {
                $openedTotal++;
            }

            $requesters[$requester] = ($requesters[$requester] ?? 0) + 1;
            $departments[$department] = ($departments[$department] ?? 0) + 1;
            $priorities[$priority] = ($priorities[$priority] ?? 0) + 1;
            $types[$type] = ($types[$type] ?? 0) + 1;

            $openedMonth = $this->normalizeMonthKey($openedAt);

            if ($openedMonth !== '') {
                if (!isset($monthly[$openedMonth])) {
                    $monthly[$openedMonth] = ['opened' => 0, 'closed' => 0];
                }

                $monthly[$openedMonth]['opened']++;
            }

            if ($this->isTerminalStatus($statusCode)) {
                $closedMonth = $this->normalizeMonthKey($updatedAt !== '' ? $updatedAt : $openedAt);

                if ($closedMonth !== '') {
                    if (!isset($monthly[$closedMonth])) {
                        $monthly[$closedMonth] = ['opened' => 0, 'closed' => 0];
                    }

                    $monthly[$closedMonth]['closed']++;
                }
            }
        }

        ksort($monthly);

        $monthlySeries = array_map(function (string $monthKey, array $values): array {
            return [
                'month_key' => $monthKey,
                'label' => $this->formatMonthLabel($monthKey),
                'opened' => (int) ($values['opened'] ?? 0),
                'closed' => (int) ($values['closed'] ?? 0),
            ];
        }, array_keys($monthly), array_values($monthly));

        return [
            'summary' => [
                'opened_total' => $openedTotal,
                'closed_total' => $closedTotal,
                'total_rows' => count($rows),
            ],
            'top_requesters' => $this->formatTopItems($requesters),
            'top_departments' => $this->formatTopItems($departments),
            'priority_breakdown' => $this->formatBreakdown($priorities),
            'type_breakdown' => $this->formatBreakdown($types),
            'monthly_volume' => $monthlySeries,
        ];
    }

    private function matchesFilters(array $row, array $filters, array $statusCodes): bool
    {
        if ($filters['search'] !== '') {
            $haystack = strtolower(implode(' ', [
                (string) ($row['id_display'] ?? ''),
                (string) ($row['preview_title'] ?? ''),
                (string) ($row['preview_copy'] ?? ''),
                (string) ($row['type_label'] ?? ''),
                (string) ($row['queue_label'] ?? ''),
                (string) ($row['status_label'] ?? ''),
            ]));

            if (strpos($haystack, strtolower($filters['search'])) === false) {
                return false;
            }
        }

        if ($filters['call_id'] !== '' && strpos((string) ($row['id_display'] ?? ''), preg_replace('/\D+/', '', $filters['call_id']) ?? '') === false) {
            return false;
        }

        if ($filters['requester'] !== '' && strpos(strtolower((string) ($row['user_label'] ?? '')), strtolower($filters['requester'])) === false) {
            return false;
        }

        if ($filters['department'] !== '' && strcasecmp((string) ($row['department_label'] ?? ''), $filters['department']) !== 0) {
            return false;
        }

        if ($filters['type'] !== '' && strcasecmp((string) ($row['type_label'] ?? ''), $filters['type']) !== 0) {
            return false;
        }

        if ($filters['priority'] !== '' && strcasecmp((string) ($row['priority_label'] ?? ''), $filters['priority']) !== 0) {
            return false;
        }

        if ($statusCodes !== [] && !in_array((string) ($row['status_code'] ?? ''), $statusCodes, true)) {
            return false;
        }

        if ($filters['opened_from'] !== '' && $this->extractDate((string) ($row['opened_at'] ?? '')) < $filters['opened_from']) {
            return false;
        }

        if ($filters['opened_to'] !== '' && $this->extractDate((string) ($row['opened_at'] ?? '')) > $filters['opened_to']) {
            return false;
        }

        return true;
    }

    private function normalizeStatusFilter(string $statusFilter): array
    {
        $statusCodes = array_values(array_filter(array_map(static function (string $value): string {
            return strtoupper(trim($value));
        }, explode(',', $statusFilter)), static function (string $value): bool {
            return $value !== '';
        }));

        return array_values(array_unique($statusCodes));
    }

    private function extractDate(string $value): string
    {
        $value = trim($value);

        if ($value === '') {
            return '';
        }

        return substr($value, 0, 10);
    }

    private function normalizeRow(array $row): array
    {
        $rawId = (int) ($row['id_omega_chamado'] ?? 0);
        $title = trim((string) ($row['titulo'] ?? 'Chamado sem título'));
        $requesterName = trim((string) ($row['solicitante_nome'] ?? 'Usuário'));
        $requesterFunctional = trim((string) ($row['solicitante_funcional'] ?? ''));
        $analystFunctional = trim((string) ($row['funcional_analista_atual'] ?? ''));
        $analystName = trim((string) ($row['analyst_name'] ?? ''));
        $segment = $this->normalizeDepartmentLabel((string) ($row['solicitante_segmento'] ?? 'POBJ'));
        $queueCode = trim((string) ($row['codigo_time'] ?? ''));
        $queueName = trim((string) ($row['nome_time'] ?? ''));
        $queueName = $queueName !== '' ? $queueName : $segment;
        $categoryName = trim((string) ($row['nome_categoria'] ?? ''));
        $categoryName = $categoryName !== '' ? $categoryName : $this->normalizeDepartmentType($segment, '');
        $statusName = trim((string) ($row['nome_status'] ?? 'Sem status'));
        $statusCode = strtoupper(trim((string) ($row['codigo_status'] ?? 'SEM_STATUS')));
        $statusColor = trim((string) ($row['cor_hex'] ?? '#cbd5e1'));
        $priorityLabel = $this->normalizePriorityLabel((string) ($row['priority_label'] ?? $this->inferPriorityLabel($statusCode)));
        $description = trim((string) ($row['descricao_abertura'] ?? ''));
        $resolutionFinal = trim((string) ($row['resolucao_final'] ?? ''));
        $closedAt = trim((string) ($row['dt_fechamento'] ?? ''));

        return [
            'id' => $rawId,
            'id_display' => str_pad((string) max(0, $rawId), 6, '0', STR_PAD_LEFT),
            'preview_title' => $title,
            'preview_copy' => trim($requesterName . ($requesterFunctional !== '' ? ' • ' . $requesterFunctional : '')),
            'department_label' => $segment !== '' ? $segment : 'POBJ',
            'type_label' => $categoryName,
            'user_label' => $requesterName,
            'user_code' => $requesterFunctional,
            'priority_label' => $priorityLabel,
            'analyst_label' => $analystName !== '' ? $analystName : ($analystFunctional !== '' ? $analystFunctional : 'Sem analista'),
            'analyst_code' => $analystFunctional,
            'queue_code' => $queueCode !== '' ? $queueCode : $this->buildOmegaCode($queueName, 50),
            'queue_label' => $queueName,
            'opened_at' => (string) ($row['dt_abertura'] ?? ''),
            'updated_at' => (string) ($row['dt_ultimo_evento'] ?? ''),
            'closed_at' => $closedAt,
            'status_label' => $statusName,
            'status_code' => $statusCode,
            'status_color' => $statusColor,
            'description' => $description !== '' ? $description : 'Sem observações registradas.',
            'resolution_final' => $resolutionFinal !== '' ? $resolutionFinal : 'Sem finalização registrada.',
            'thread' => $this->normalizeThread($row, $requesterName, $analystName !== '' ? $analystName : ($analystFunctional !== '' ? $analystFunctional : 'Sem analista'), $statusName),
        ];
    }

    private function normalizeThread(array $row, string $requesterName, string $analystName, string $statusName): array
    {
        $rawTimeline = $row['timeline_entries'] ?? null;

        if (is_array($rawTimeline) && $rawTimeline !== []) {
            $timeline = [];

            foreach ($rawTimeline as $entry) {
                if (!is_array($entry)) {
                    continue;
                }

                $role = trim((string) ($entry['role'] ?? 'user'));
                $author = trim((string) ($entry['author'] ?? ($role === 'analyst' ? $analystName : $requesterName)));
                $message = trim((string) ($entry['message'] ?? ''));

                if ($message === '') {
                    continue;
                }

                $timeline[] = [
                    'role' => $role === 'analyst' ? 'analyst' : 'user',
                    'author' => $author !== '' ? $author : ($role === 'analyst' ? $analystName : $requesterName),
                    'timestamp' => trim((string) ($entry['timestamp'] ?? '')),
                    'message' => $message,
                ];
            }

            if ($timeline !== []) {
                return $timeline;
            }
        }

        $description = trim((string) ($row['descricao_abertura'] ?? ''));
        $openedAt = trim((string) ($row['dt_abertura'] ?? ''));
        $updatedAt = trim((string) ($row['dt_ultimo_evento'] ?? ''));
        $thread = [];

        if ($description !== '') {
            $thread[] = [
                'role' => 'user',
                'author' => $requesterName !== '' ? $requesterName : 'Solicitante',
                'timestamp' => $openedAt,
                'message' => $description,
            ];
        }

        if ($analystName !== '' && $updatedAt !== '' && $updatedAt !== $openedAt) {
            $thread[] = [
                'role' => 'analyst',
                'author' => $analystName,
                'timestamp' => $updatedAt,
                'message' => 'Status atualizado para ' . $statusName . ' e acompanhamento registrado na fila operacional.',
            ];
        }

        return $thread;
    }

    private function formatTopItems(array $items): array
    {
        arsort($items);
        $maxValue = $items !== [] ? max($items) : 0;
        $formatted = [];

        foreach (array_slice($items, 0, 10, true) as $label => $value) {
            $formatted[] = [
                'label' => $label,
                'value' => (int) $value,
                'share' => $maxValue > 0 ? (int) round(((int) $value / $maxValue) * 100) : 0,
            ];
        }

        return $formatted;
    }

    private function formatBreakdown(array $items): array
    {
        $total = array_sum($items);
        arsort($items);
        $formatted = [];

        foreach ($items as $label => $value) {
            $formatted[] = [
                'label' => $label,
                'value' => (int) $value,
                'percentage' => $total > 0 ? round(((int) $value / $total) * 100, 1) : 0.0,
            ];
        }

        return $formatted;
    }

    private function normalizeMonthKey(string $value): string
    {
        $value = trim($value);

        if ($value === '') {
            return '';
        }

        return substr($value, 0, 7);
    }

    private function formatMonthLabel(string $monthKey): string
    {
        $monthKey = trim($monthKey);

        if ($monthKey === '' || strlen($monthKey) < 7) {
            return 'Sem data';
        }

        $monthNames = [
            '01' => 'Jan',
            '02' => 'Fev',
            '03' => 'Mar',
            '04' => 'Abr',
            '05' => 'Mai',
            '06' => 'Jun',
            '07' => 'Jul',
            '08' => 'Ago',
            '09' => 'Set',
            '10' => 'Out',
            '11' => 'Nov',
            '12' => 'Dez',
        ];

        $month = substr($monthKey, 5, 2);
        $year = substr($monthKey, 2, 2);

        return ($monthNames[$month] ?? $month) . '/' . $year;
    }

    private function inferPriorityLabel(string $statusCode): string
    {
        switch (strtoupper($statusCode)) {
            case 'EM_ATENDIMENTO':
                return 'Alta';

            case 'FECHADO':
            case 'REJEITADO':
                return 'Baixa';

            case 'ABERTO':
            case 'CANCELADO':
            case 'AGUARDANDO':
            default:
                return 'Média';
        }
    }

    private function normalizePriorityLabel(string $priorityLabel): string
    {
        switch (mb_strtolower(trim($priorityLabel), 'UTF-8')) {
            case 'alta':
                return 'Alta';

            case 'baixa':
                return 'Baixa';

            case 'media':
            case 'média':
            default:
                return 'Média';
        }
    }

    private function fetchTeamsByIds(array $teamIds): array
    {
        if ($teamIds === [] || !$this->hasTable(self::TIMES_TABLE_NAME)) {
            return [];
        }
        $teams = [];

        foreach ($this->fetchProcedureAll('sp_omega_list_teams_by_ids', [
            'p_team_ids_csv' => $this->encodeProcedureList(array_map('strval', $teamIds)),
        ]) as $row) {
            $teamId = (int) ($row['id_omega_time'] ?? 0);
            $teamCode = trim((string) ($row['codigo_time'] ?? ''));
            $teamName = trim((string) ($row['nome_time'] ?? ''));

            if ($teamId <= 0 || $teamCode === '' || $teamName === '') {
                continue;
            }

            $teams[] = [
                'id' => $teamId,
                'code' => $teamCode,
                'name' => $teamName,
                'label' => $teamName,
            ];
        }

        return $teams;
    }

    private function fetchAllActiveTeams(): array
    {
        if (!$this->hasTable(self::TIMES_TABLE_NAME)) {
            return [];
        }

        return array_map(function (array $row): array {
            $code = trim((string) ($row['codigo_time'] ?? ''));
            $label = trim((string) ($row['nome_time'] ?? ''));

            return [
                'id' => (int) ($row['id_omega_time'] ?? 0),
                'value' => $code,
                'code' => $code,
                'label' => $label,
                'name' => $label,
                'department' => $this->normalizeDepartmentLabel($label !== '' ? $label : $code),
            ];
        }, $this->fetchProcedureAll('sp_omega_list_all_active_teams'));
    }

    private function findTeamByCode(string $teamCode): array
    {
        if ($teamCode === '' || !$this->hasTable(self::TIMES_TABLE_NAME)) {
            return [];
        }

        $row = $this->fetchProcedureRow('sp_omega_find_team_by_code', ['p_team_code' => $teamCode]);

        if (!is_array($row)) {
            return [];
        }

        return [
            'id' => (int) ($row['id_omega_time'] ?? 0),
            'code' => trim((string) ($row['codigo_time'] ?? '')),
            'name' => trim((string) ($row['nome_time'] ?? '')),
            'label' => trim((string) ($row['nome_time'] ?? '')),
        ];
    }

    private function findTeamByName(string $teamName): array
    {
        if ($teamName === '' || !$this->hasTable(self::TIMES_TABLE_NAME)) {
            return [];
        }

        $row = $this->fetchProcedureRow('sp_omega_find_team_by_name', ['p_team_name' => $teamName]);

        if (!is_array($row)) {
            return [];
        }

        return [
            'id' => (int) ($row['id_omega_time'] ?? 0),
            'code' => trim((string) ($row['codigo_time'] ?? '')),
            'name' => trim((string) ($row['nome_time'] ?? '')),
            'label' => trim((string) ($row['nome_time'] ?? '')),
        ];
    }

    private function resolveRequestedTeam(string $queueIdentifier, string $fallbackDepartment): array
    {
        $queueIdentifier = trim($queueIdentifier);

        if ($queueIdentifier !== '') {
            $team = $this->findTeamByCode($queueIdentifier);

            if ($team !== []) {
                return $team;
            }

            $team = $this->findTeamByName($queueIdentifier);

            if ($team !== []) {
                return $team;
            }
        }

        $fallbackDepartment = $this->normalizeDepartmentLabel($fallbackDepartment);
        $team = $this->findTeamByCode($this->buildOmegaCode($fallbackDepartment, 50));

        if ($team !== []) {
            return $team;
        }

        return $this->findTeamByName($fallbackDepartment);
    }

    private function fetchTeamManagers(int $teamId): array
    {
        return $this->fetchTeamMembersByRole($teamId, 'manager');
    }

    private function fetchTeamAnalysts(int $teamId): array
    {
        return $this->fetchTeamMembersByRole($teamId, 'analyst');
    }

    private function fetchTeamMembersByRole(int $teamId, string $role): array
    {
        if ($teamId <= 0) {
            return [];
        }

        return array_map(static function (array $row): array {
            return [
                'functional' => trim((string) ($row['functional'] ?? '')),
                'name' => trim((string) ($row['name'] ?? '')),
                'level' => trim((string) ($row['level'] ?? '')),
            ];
        }, $this->fetchProcedureAll(
            'sp_omega_list_team_members',
            [
                'p_team_id' => $teamId,
                'p_role' => $role,
            ]
        ));
    }

    private function fetchAssignableAnalystCandidates(int $teamId): array
    {
        if ($teamId <= 0 || !$this->hasTable(self::HIERARCHY_TABLE_NAME)) {
            return [];
        }

        return array_map(static function (array $row): array {
            return [
                'functional' => trim((string) ($row['funcional'] ?? '')),
                'name' => trim((string) ($row['nome'] ?? '')),
                'level' => trim((string) ($row['nivel'] ?? '')),
            ];
        }, $this->fetchProcedureAll('sp_omega_list_assignable_analyst_candidates', ['p_team_id' => $teamId]));
    }

    private function isAssignableAnalystFunctional(string $functional): bool
    {
        if ($functional === '' || !$this->hasTable(self::HIERARCHY_TABLE_NAME)) {
            return false;
        }

        return (bool) $this->fetchProcedureValue(
            'sp_omega_check_assignable_analyst',
            ['p_functional' => $functional]
        );
    }

    private function isAnalystMappedToTeam(string $functional, int $teamId): bool
    {
        $functional = substr(trim($functional), 0, 7);

        if ($functional === '' || $teamId <= 0 || !$this->hasTable(self::ANALYST_TEAM_TABLE_NAME)) {
            return false;
        }

        return (bool) $this->fetchProcedureValue(
            'sp_omega_check_analyst_team_mapping',
            [
                'p_team_id' => $teamId,
                'p_functional' => $functional,
            ]
        );
    }

    private function attachMovementThreads(array $rows): array
    {
        if ($rows === []) {
            return [];
        }

        $this->ensureMovementTable();

        if (!$this->hasTable(self::MOVEMENT_TABLE_NAME)) {
            return $rows;
        }

        $rowsById = [];
        $callIds = [];

        foreach ($rows as $row) {
            $callId = (int) ($row['id'] ?? 0);

            if ($callId <= 0) {
                continue;
            }

            $callIds[$callId] = $callId;
            $rowsById[$callId] = $row;
        }

        if ($callIds === []) {
            return $rows;
        }

        $movementsByCallId = $this->fetchMovementsByCallIds(array_values($callIds), $rowsById);

        foreach ($rows as $index => $row) {
            $callId = (int) ($row['id'] ?? 0);

            if ($callId <= 0 || !isset($movementsByCallId[$callId])) {
                continue;
            }

            $mergedThread = $this->mergeThreadEntries((array) ($row['thread'] ?? []), $movementsByCallId[$callId]);
            $rows[$index]['thread'] = $mergedThread;
            $lastThreadTimestamp = $this->resolveLastThreadTimestamp($mergedThread);

            if ($lastThreadTimestamp !== '' && strcmp($lastThreadTimestamp, (string) ($rows[$index]['updated_at'] ?? '')) > 0) {
                $rows[$index]['updated_at'] = $lastThreadTimestamp;
            }
        }

        return $rows;
    }

    private function fetchMovementsByCallIds(array $callIds, array $rowsById): array
    {
        if ($callIds === []) {
            return [];
        }
        $movementsByCallId = [];

        foreach ($this->fetchProcedureAll('sp_omega_list_movements_by_call_ids', [
            'p_call_ids_csv' => $this->encodeProcedureList(array_map('strval', $callIds)),
        ]) as $row) {
            $callId = (int) ($row['id_omega_chamado'] ?? 0);

            if ($callId <= 0 || !isset($rowsById[$callId])) {
                continue;
            }

            $message = $this->formatMovementMessage((array) $row);

            if ($message === '') {
                continue;
            }

            $contextRow = (array) $rowsById[$callId];
            $responsibleFunctional = trim((string) ($row['funcional_responsavel'] ?? ''));
            $author = trim((string) ($contextRow['analyst_label'] ?? ''));

            if ($author === '' || ($responsibleFunctional !== '' && trim((string) ($contextRow['analyst_code'] ?? '')) !== $responsibleFunctional)) {
                $author = $responsibleFunctional !== '' ? $responsibleFunctional : 'Operação Omega';
            }

            $movementsByCallId[$callId][] = [
                'role' => 'analyst',
                'author' => $author,
                'timestamp' => trim((string) ($row['dt_movimentacao'] ?? '')),
                'message' => $message,
            ];
        }

        return $movementsByCallId;
    }

    private function formatMovementMessage(array $row): string
    {
        $movementType = strtoupper(trim((string) ($row['tipo_movimentacao'] ?? 'ATUALIZACAO')));
        $statusOrigin = trim((string) ($row['status_origem_nome'] ?? ''));
        $statusDestination = trim((string) ($row['status_destino_nome'] ?? ''));
        $timeOrigin = trim((string) ($row['time_origem_nome'] ?? ''));
        $timeDestination = trim((string) ($row['time_destino_nome'] ?? ''));
        $categoryOrigin = trim((string) ($row['category_origem_nome'] ?? ''));
        $categoryDestination = trim((string) ($row['category_destino_nome'] ?? ''));
        $analystOrigin = trim((string) ($row['funcional_analista_origem'] ?? ''));
        $analystDestination = trim((string) ($row['funcional_analista_destino'] ?? ''));
        $observation = trim((string) ($row['observacao'] ?? ''));
        $parts = [];

        if ($movementType === 'ABERTURA') {
            $openingMessage = 'Chamado aberto no Omega';

            if ($timeDestination !== '') {
                $openingMessage .= ' na fila ' . $timeDestination;
            }

            if ($categoryDestination !== '') {
                $openingMessage .= ' em ' . $categoryDestination;
            }

            $parts[] = $openingMessage . '.';
        }

        if ($statusDestination !== '' && $statusDestination !== $statusOrigin) {
            $parts[] = $statusOrigin !== ''
                ? 'Status alterado de ' . $statusOrigin . ' para ' . $statusDestination . '.'
                : 'Status definido como ' . $statusDestination . '.';
        }

        if ($timeDestination !== '' && $timeDestination !== $timeOrigin) {
            $parts[] = $timeOrigin !== ''
                ? 'Fila alterada de ' . $timeOrigin . ' para ' . $timeDestination . '.'
                : 'Fila definida como ' . $timeDestination . '.';
        }

        if ($categoryDestination !== '' && $categoryDestination !== $categoryOrigin) {
            $parts[] = $categoryOrigin !== ''
                ? 'Categoria alterada de ' . $categoryOrigin . ' para ' . $categoryDestination . '.'
                : 'Categoria definida como ' . $categoryDestination . '.';
        }

        if ($analystDestination !== '' && $analystDestination !== $analystOrigin) {
            $parts[] = $analystOrigin !== ''
                ? 'Responsável alterado de ' . $analystOrigin . ' para ' . $analystDestination . '.'
                : 'Responsável definido como ' . $analystDestination . '.';
        }

        if ($observation !== '') {
            $parts[] = $observation;
        }

        if ($parts === []) {
            switch ($movementType) {
                case 'FECHAMENTO':
                    return 'Fechamento registrado no chamado.';

                case 'ABERTURA':
                    return 'Chamado aberto no Omega.';

                case 'ATUALIZACAO':
                default:
                    return 'Atualização operacional registrada.';
            }
        }

        return implode(' ', $parts);
    }

    private function attachCommentThreads(array $rows): array
    {
        if ($rows === []) {
            return [];
        }

        $this->ensureCommentTable();

        if (!$this->hasTable(self::COMMENT_TABLE_NAME)) {
            return $rows;
        }

        $rowsById = [];
        $callIds = [];

        foreach ($rows as $row) {
            $callId = (int) ($row['id'] ?? 0);

            if ($callId <= 0) {
                continue;
            }

            $callIds[$callId] = $callId;
            $rowsById[$callId] = $row;
        }

        if ($callIds === []) {
            return $rows;
        }

        $commentsByCallId = $this->fetchCommentsByCallIds(array_values($callIds), $rowsById);

        foreach ($rows as $index => $row) {
            $callId = (int) ($row['id'] ?? 0);

            if ($callId <= 0 || !isset($commentsByCallId[$callId])) {
                continue;
            }

            $mergedThread = $this->mergeThreadEntries((array) ($row['thread'] ?? []), $commentsByCallId[$callId]);
            $rows[$index]['thread'] = $mergedThread;
            $lastThreadTimestamp = $this->resolveLastThreadTimestamp($mergedThread);

            if ($lastThreadTimestamp !== '' && strcmp($lastThreadTimestamp, (string) ($rows[$index]['updated_at'] ?? '')) > 0) {
                $rows[$index]['updated_at'] = $lastThreadTimestamp;
            }
        }

        return $rows;
    }

    private function fetchCommentsByCallIds(array $callIds, array $rowsById): array
    {
        if ($callIds === []) {
            return [];
        }
        $commentsByCallId = [];

        foreach ($this->fetchProcedureAll('sp_omega_list_comments_by_call_ids', [
            'p_call_ids_csv' => $this->encodeProcedureList(array_map('strval', $callIds)),
        ]) as $row) {
            $callId = (int) ($row['id_omega_chamado'] ?? 0);

            if ($callId <= 0 || !isset($rowsById[$callId])) {
                continue;
            }

            $comment = trim((string) ($row['comentario'] ?? ''));

            if ($comment === '') {
                continue;
            }

            $authorType = strtoupper(trim((string) ($row['tipo_autor'] ?? '')));
            $functionalAuthor = trim((string) ($row['funcional_autor'] ?? ''));
            $role = $this->resolveCommentRole($authorType, $functionalAuthor, (array) $rowsById[$callId]);
            $contextRow = (array) $rowsById[$callId];
            $author = $role === 'analyst'
                ? trim((string) ($contextRow['analyst_label'] ?? ''))
                : trim((string) ($contextRow['user_label'] ?? ''));

            if ($author === '') {
                $author = $functionalAuthor !== ''
                    ? $functionalAuthor
                    : ($role === 'analyst' ? 'Analista' : 'Solicitante');
            }

            $commentsByCallId[$callId][] = [
                'role' => $role,
                'author' => $author,
                'timestamp' => trim((string) ($row['dt_comentario'] ?? '')),
                'message' => $comment,
            ];
        }

        return $commentsByCallId;
    }

    private function resolveCommentRole(string $authorType, string $functionalAuthor, array $contextRow): string
    {
        if (in_array($authorType, ['ANALISTA', 'ATENDENTE', 'ANALYST'], true)) {
            return 'analyst';
        }

        if (in_array($authorType, ['SOLICITANTE', 'USUARIO', 'USER'], true)) {
            return 'user';
        }

        $analystCode = trim((string) ($contextRow['analyst_code'] ?? ''));

        if ($functionalAuthor !== '' && $analystCode !== '' && $functionalAuthor === $analystCode) {
            return 'analyst';
        }

        return 'user';
    }

    private function mergeThreadEntries(array $baseThread, array $commentThread): array
    {
        $mergedThread = [];

        foreach (array_merge($baseThread, $commentThread) as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            $message = trim((string) ($entry['message'] ?? ''));

            if ($message === '') {
                continue;
            }

            $mergedThread[] = [
                'role' => trim((string) ($entry['role'] ?? 'user')) === 'analyst' ? 'analyst' : 'user',
                'author' => trim((string) ($entry['author'] ?? '')),
                'timestamp' => trim((string) ($entry['timestamp'] ?? '')),
                'message' => $message,
            ];
        }

        usort($mergedThread, static function (array $left, array $right): int {
            $leftTimestamp = trim((string) ($left['timestamp'] ?? ''));
            $rightTimestamp = trim((string) ($right['timestamp'] ?? ''));

            if ($leftTimestamp === $rightTimestamp) {
                return strcmp((string) ($left['message'] ?? ''), (string) ($right['message'] ?? ''));
            }

            if ($leftTimestamp === '') {
                return 1;
            }

            if ($rightTimestamp === '') {
                return -1;
            }

            return strcmp($leftTimestamp, $rightTimestamp);
        });

        return $mergedThread;
    }

    private function resolveLastThreadTimestamp(array $thread): string
    {
        $lastTimestamp = '';

        foreach ($thread as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            $timestamp = trim((string) ($entry['timestamp'] ?? ''));

            if ($timestamp !== '' && ($lastTimestamp === '' || strcmp($timestamp, $lastTimestamp) > 0)) {
                $lastTimestamp = $timestamp;
            }
        }

        return $lastTimestamp;
    }

    private function sortRowsByRecency(array $rows): array
    {
        usort($rows, static function (array $left, array $right): int {
            $leftTimestamp = trim((string) ($left['updated_at'] ?? $left['opened_at'] ?? ''));
            $rightTimestamp = trim((string) ($right['updated_at'] ?? $right['opened_at'] ?? ''));

            if ($leftTimestamp === $rightTimestamp) {
                return (int) ($right['id'] ?? 0) <=> (int) ($left['id'] ?? 0);
            }

            return strcmp($rightTimestamp, $leftTimestamp);
        });

        return $rows;
    }

    private function ensureCommentTable(): void
    {
        if ($this->hasTable(self::COMMENT_TABLE_NAME)) {
            return;
        }

        $this->fetchProcedureValue('sp_omega_ensure_comment_table');
        $this->tableAvailability[self::COMMENT_TABLE_NAME] = true;
    }

    private function ensureMovementTable(): void
    {
        if ($this->hasTable(self::MOVEMENT_TABLE_NAME)) {
            return;
        }

        $this->fetchProcedureValue('sp_omega_ensure_movement_table');
        $this->tableAvailability[self::MOVEMENT_TABLE_NAME] = true;
    }

    private function ensureCallSchema(): void
    {
        if (!$this->hasTable(self::CALLS_TABLE_NAME) || $this->hasColumn(self::CALLS_TABLE_NAME, 'prioridade_label')) {
            return;
        }

        try {
            $this->fetchProcedureValue('sp_omega_ensure_call_priority_column');
        } catch (Throwable $exception) {
            // Ignore duplicate-column or unsupported-schema errors and fall back to inferred priority labels.
        }

        unset($this->columnAvailability[self::CALLS_TABLE_NAME]['prioridade_label']);
    }

    private function sanitizeStoredPlainText(string $value, int $maxLength = 255): string
    {
        $value = normalize_display_text($value);
        $value = strip_tags($value);
        $value = preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $value) ?? $value;
        $value = preg_replace('/\s{2,}/u', ' ', trim($value)) ?? trim($value);

        if ($value === '') {
            return '';
        }

        return mb_substr($value, 0, $maxLength);
    }

    private function sanitizeStoredMultilineText(string $value, int $maxLength = 4000): string
    {
        $value = normalize_display_text($value);
        $value = strip_tags($value);
        $value = str_replace(["\r\n", "\r"], "\n", $value);
        $value = preg_replace('/[^\P{C}\n\t]+/u', '', $value) ?? $value;
        $value = preg_replace("/\n{3,}/", "\n\n", trim($value)) ?? trim($value);

        if ($value === '') {
            return '';
        }

        return mb_substr($value, 0, $maxLength);
    }

    private function hasColumn(string $tableName, string $columnName): bool
    {
        if (isset($this->columnAvailability[$tableName]) && array_key_exists($columnName, $this->columnAvailability[$tableName])) {
            return $this->columnAvailability[$tableName][$columnName];
        }

        $this->columnAvailability[$tableName][$columnName] = (bool) $this->fetchProcedureValue(
            'sp_util_column_exists',
            [
                'p_table_name' => $tableName,
                'p_column_name' => $columnName,
            ]
        );

        return $this->columnAvailability[$tableName][$columnName];
    }

    private function hasTable(string $tableName): bool
    {
        if (array_key_exists($tableName, $this->tableAvailability)) {
            return $this->tableAvailability[$tableName];
        }

        $this->tableAvailability[$tableName] = (bool) $this->fetchProcedureValue(
            'sp_util_table_exists',
            ['p_table_name' => $tableName]
        );

        return $this->tableAvailability[$tableName];
    }
}
