<?php

declare(strict_types=1);

namespace App\Services;

use App\Support\CallsStoredProcedures;
use PDO;

final class PrimeBrandService
{
    use CallsStoredProcedures;

    /** @var PDO */
    private $connection;

    public function __construct(PDO $connection)
    {
        $this->connection = $connection;
    }

    protected function getProcedureConnection(): PDO
    {
        return $this->connection;
    }

    public function resolveVisualTheme(?array $context, array $filters): array
    {
        $isPrime = $this->matchesSelectedFilters($filters);

        if (!$isPrime && is_array($context)) {
            $isPrime = $this->matchesProfileContext($context);
        }

        return [
            'code' => $isPrime ? 'prime' : 'classic',
            'is_prime' => $isPrime,
            'label' => $isPrime ? 'Bradesco Prime' : 'Bradesco Empresas',
            'logo_path' => 'assets/img/logo-bradesco-white.svg',
            'logo_alt' => 'Bradesco',
            'reference_path' => 'assets/img/prime-reference.svg',
            'bubble_label' => $isPrime ? 'IA Prime' : 'IA POBJ',
            'badge_copy' => $isPrime ? 'Modo Prime' : 'Modo POBJ',
        ];
    }

    private function matchesSelectedFilters(array $filters): bool
    {
        $agency = trim((string) ($filters['agencia'] ?? ''));

        if ($agency !== '' && $this->matchesPrimeAgency($agency)) {
            return true;
        }

        $regional = trim((string) ($filters['regional'] ?? ''));

        if ($regional !== '' && $this->matchesPrimeRegional($regional)) {
            return true;
        }

        $directorate = trim((string) ($filters['diretoria'] ?? ''));

        if ($directorate !== '' && $this->matchesPrimeDirectorate($directorate)) {
            return true;
        }

        $managementFunctional = trim((string) ($filters['gerente_gestao'] ?? ''));

        if ($managementFunctional !== '' && $this->matchesPrimeFunctional($managementFunctional)) {
            return true;
        }

        $commercialFunctional = trim((string) ($filters['gerente'] ?? ''));

        return $commercialFunctional !== '' && $this->matchesPrimeFunctional($commercialFunctional);
    }

    private function matchesProfileContext(array $context): bool
    {
        $scope = is_array($context['scope'] ?? null) ? $context['scope'] : [];
        $allowed = array_values(array_filter((array) ($scope['allowed'] ?? []), static function ($value): bool {
            return trim((string) $value) !== '';
        }));
        $scopeCode = strtoupper(trim((string) ($scope['code'] ?? '')));

        if ($allowed !== []) {
            if ($scopeCode === 'AG' && $this->matchesPrimeAgencies($allowed)) {
                return true;
            }

            if ($scopeCode === 'GR' && $this->matchesPrimeRegionals($allowed)) {
                return true;
            }

            if ($scopeCode === 'DR' && $this->matchesPrimeDirectorates($allowed)) {
                return true;
            }
        }

        $profile = is_array($context['profile'] ?? null) ? $context['profile'] : [];
        $functional = trim((string) ($profile['funcional'] ?? ''));

        return $functional !== '' && $this->matchesPrimeFunctional($functional);
    }

    private function matchesPrimeAgency(string $agency): bool
    {
        return $this->matchesByMesuField('juncao_ag', [$agency]);
    }

    private function matchesPrimeRegional(string $regional): bool
    {
        return $this->matchesByMesuField('juncao_gr', [$regional]);
    }

    private function matchesPrimeDirectorate(string $directorate): bool
    {
        return $this->matchesByMesuField('juncao_dr', [$directorate]);
    }

    private function matchesPrimeAgencies(array $agencies): bool
    {
        return $this->matchesByMesuField('juncao_ag', $agencies);
    }

    private function matchesPrimeRegionals(array $regionals): bool
    {
        return $this->matchesByMesuField('juncao_gr', $regionals);
    }

    private function matchesPrimeDirectorates(array $directorates): bool
    {
        return $this->matchesByMesuField('juncao_dr', $directorates);
    }

    private function matchesByMesuField(string $field, array $values): bool
    {
        $values = array_values(array_filter(array_map(static function ($value): string {
            return trim((string) $value);
        }, $values), static function (string $value): bool {
            return $value !== '';
        }));

        if ($values === []) {
            return false;
        }

        $scopeCode = $this->resolveMesuFieldScopeCode($field);

        if ($scopeCode === '') {
            return false;
        }

        return (bool) $this->fetchProcedureValue(
            'sp_prime_matches_mesu_field',
            [
                'p_scope_code' => $scopeCode,
                'p_values_csv' => $this->encodeProcedureList($values),
            ]
        );
    }

    private function matchesPrimeFunctional(string $functional): bool
    {
        $functional = trim($functional);

        if ($functional === '') {
            return false;
        }

        return (bool) $this->fetchProcedureValue('sp_prime_matches_functional', ['p_functional' => $functional]);
    }

    private function resolveMesuFieldScopeCode(string $field): string
    {
        switch ($field) {
            case 'juncao_ag':
                return 'AG';
            case 'juncao_gr':
                return 'GR';
            case 'juncao_dr':
                return 'DR';
            default:
                return '';
        }
    }
}
