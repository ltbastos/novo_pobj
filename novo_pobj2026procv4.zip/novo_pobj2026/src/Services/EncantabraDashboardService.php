<?php

declare(strict_types=1);

namespace App\Services;

use App\Support\CallsStoredProcedures;
use PDO;

final class EncantabraDashboardService
{
    use CallsStoredProcedures;

    private const TABLE_NAME = 'encantabra';

    /** @var PDO */
    private $connection;

    /** @var bool|null */
    private $tableAvailable = null;

    public function __construct(PDO $connection)
    {
        $this->connection = $connection;
    }

    protected function getProcedureConnection(): PDO
    {
        return $this->connection;
    }

    public function prepareFilters(array $requestedFilters = []): array
    {
        $profileOptions = [
            ['value' => 'SG', 'label' => 'Segmento'],
            ['value' => 'AG', 'label' => 'Agencia'],
            ['value' => 'GC', 'label' => 'Gerente / Funcional'],
        ];

        if (!$this->hasLocalTable()) {
            return [
                'options' => [
                    'anomes' => [],
                    'perfil' => $profileOptions,
                    'segmento' => [],
                    'juncao' => [],
                    'funcional' => [],
                    'indicador' => [],
                ],
                'values' => [
                    'anomes' => '',
                    'perfil' => 'SG',
                    'segmento' => '',
                    'juncao' => '',
                    'funcional' => '',
                    'indicador' => '',
                ],
            ];
        }

        $monthOptions = $this->fetchMonthOptions();
        $segmentOptions = $this->fetchDistinctOptions('SEGMENTO_PAINEL');
        $requestedJuncao = trim((string) ($requestedFilters['juncao'] ?? ''));
        $requestedFunctional = trim((string) ($requestedFilters['funcional'] ?? ''));
        $requestedProfile = strtoupper(trim((string) ($requestedFilters['perfil'] ?? '')));
        $inferredProfile = 'SG';

        if ($requestedFunctional !== '') {
            $inferredProfile = 'GC';
        } elseif ($requestedJuncao !== '') {
            $inferredProfile = 'AG';
        }

        $selectedMonth = $this->sanitizeOption(
            trim((string) ($requestedFilters['anomes'] ?? '')),
            $monthOptions,
            (string) ($monthOptions[0]['value'] ?? '')
        );
        $selectedProfile = $this->sanitizeOption($requestedProfile, $profileOptions, $inferredProfile);
        $selectedSegment = $this->sanitizeOption(
            trim((string) ($requestedFilters['segmento'] ?? '')),
            $segmentOptions,
            ''
        );

        $juncaoOptions = $this->fetchPairOptions(
            'COD_JUNC',
            'NOME_JUNC',
            [
                'anomes' => $selectedMonth,
                'perfil' => 'AG',
                'segmento' => $selectedSegment,
            ]
        );
        $selectedJuncao = $this->sanitizeOption($requestedJuncao, $juncaoOptions, '');

        $functionalOptions = $this->fetchPairOptions(
            'COD_FUNC',
            'NOME_FUNC',
            [
                'anomes' => $selectedMonth,
                'perfil' => 'GC',
                'segmento' => $selectedSegment,
                'juncao' => $selectedJuncao,
            ]
        );
        $selectedFunctional = $this->sanitizeOption($requestedFunctional, $functionalOptions, '');

        if ($selectedFunctional !== '' && $selectedProfile !== 'GC' && $requestedProfile === '') {
            $selectedProfile = 'GC';
        } elseif ($selectedJuncao !== '' && $selectedProfile === 'SG' && $requestedProfile === '') {
            $selectedProfile = 'AG';
        }

        $indicatorOptions = $this->fetchDistinctOptions(
            'INDICADOR',
            [
                'anomes' => $selectedMonth,
                'perfil' => $selectedProfile,
                'segmento' => $selectedSegment,
                'juncao' => $selectedJuncao,
                'funcional' => $selectedFunctional,
            ]
        );
        $indicatorOptions = $this->ensureSelectedOption(
            $indicatorOptions,
            trim((string) ($requestedFilters['indicador'] ?? ''))
        );
        $selectedIndicator = $this->sanitizeOption(
            trim((string) ($requestedFilters['indicador'] ?? '')),
            $indicatorOptions,
            ''
        );

        return [
            'options' => [
                'anomes' => $monthOptions,
                'perfil' => $profileOptions,
                'segmento' => $segmentOptions,
                'juncao' => $juncaoOptions,
                'funcional' => $functionalOptions,
                'indicador' => $indicatorOptions,
            ],
            'values' => [
                'anomes' => $selectedMonth,
                'perfil' => $selectedProfile,
                'segmento' => $selectedSegment,
                'juncao' => $selectedJuncao,
                'funcional' => $selectedFunctional,
                'indicador' => $selectedIndicator,
            ],
        ];
    }

    public function getDashboardData(array $filters, int $analyticPage = 1): array
    {
        if (!$this->hasLocalTable()) {
            return [
                'reference' => [
                    'month_label' => '',
                    'scope_label' => 'Base EncantaBra nao disponivel no banco local.',
                    'profile_label' => 'Visao EncantaBra',
                    'segment_label' => '',
                ],
                'summary' => [
                    'score_avg' => 0.0,
                    'meta_avg' => 0.0,
                    'real_avg' => 0.0,
                    'rows_total' => 0,
                    'entities_total' => 0,
                    'indicators_total' => 0,
                    'best_indicator' => null,
                    'worst_indicator' => null,
                    'band' => ['label' => 'Sem dados', 'range' => 'Sem leitura', 'tone' => 'is-empty'],
                ],
                'status' => ['fan' => 0, 'encantador' => 0, 'expectativa' => 0, 'critico' => 0],
                'chart' => ['labels' => [], 'series' => [], 'max_value' => 150.0],
                'trimester_tables' => ['year' => '', 'tables' => []],
                'table' => ['title' => 'Performance mes a mes por indicador', 'subtitle' => '', 'columns' => [], 'rows' => []],
            ];
        }

        $selectedMonth = trim((string) ($filters['anomes'] ?? ''));
        $chartMonths = $this->buildMonthWindow($selectedMonth, 12);
        $summary = $this->fetchSummaryMetrics($filters);
        $indicatorRows = $this->fetchIndicatorTableRows($filters);
        $band = $this->resolveBandMeta(isset($summary['score_avg']) ? (float) $summary['score_avg'] : null);
        $bestIndicator = $indicatorRows !== [] ? $indicatorRows[0] : null;
        $worstIndicator = $indicatorRows !== [] ? $indicatorRows[count($indicatorRows) - 1] : null;
        $selectedYear = $this->resolveSelectedYear($selectedMonth);
        $analyticTable = $this->fetchAnalyticTableData($filters, $selectedMonth, $selectedYear, $analyticPage, 20);

        return [
            'reference' => [
                'month_label' => $this->formatAnoMesLabel($selectedMonth, false),
                'scope_label' => $this->buildScopeLabel($filters),
                'profile_label' => $this->resolveProfileLabel((string) ($filters['perfil'] ?? 'SG')),
                'segment_label' => trim((string) ($filters['segmento'] ?? '')) !== ''
                    ? trim((string) $filters['segmento'])
                    : 'Todos os segmentos',
            ],
            'summary' => [
                'score_avg' => (float) ($summary['score_avg'] ?? 0.0),
                'meta_avg' => (float) ($summary['meta_avg'] ?? 0.0),
                'real_avg' => (float) ($summary['real_avg'] ?? 0.0),
                'rows_total' => (int) ($summary['rows_total'] ?? 0),
                'entities_total' => (int) ($summary['entities_total'] ?? 0),
                'indicators_total' => (int) ($summary['indicators_total'] ?? count($indicatorRows)),
                'best_indicator' => $bestIndicator,
                'worst_indicator' => $worstIndicator,
                'band' => $band,
            ],
            'status' => $this->fetchStatusSummary($filters),
            'chart' => $this->buildMonthlyChart($filters, $chartMonths),
            'trimester_tables' => [
                'year' => $selectedYear,
                'tables' => $this->buildTrimesterTables($filters, $selectedYear),
            ],
            'table' => $analyticTable,
        ];
    }

    private function fetchAnalyticTableData(array $filters, string $selectedMonth, string $year, int $page, int $perPage): array
    {
        if ($year === '' && $selectedMonth === '') {
            return [
                'title' => 'Performance mes a mes por indicador',
                'subtitle' => 'Todas as colunas ja vem calculadas pela base EncantaBra; exibimos sem novas transformacoes.',
                'columns' => [],
                'rows' => [],
                'total_rows' => 0,
                'current_page' => 1,
                'per_page' => $perPage,
                'total_pages' => 1,
            ];
        }

        $totalRows = (int) ($this->fetchProcedureValue('sp_encantabra_count_analytic_rows', [
            'p_anomes' => $selectedMonth,
            'p_year' => $year,
            'p_perfil' => trim((string) ($filters['perfil'] ?? '')),
            'p_segmento' => trim((string) ($filters['segmento'] ?? '')),
            'p_juncao' => trim((string) ($filters['juncao'] ?? '')),
            'p_funcional' => trim((string) ($filters['funcional'] ?? '')),
            'p_indicador' => trim((string) ($filters['indicador'] ?? '')),
        ]) ?? 0);
        $totalPages = max(1, (int) ceil($totalRows / max(1, $perPage)));
        $currentPage = min(max(1, $page), $totalPages);
        $offset = ($currentPage - 1) * $perPage;
        $rows = $this->fetchProcedureAll('sp_encantabra_list_analytic_rows', [
            'p_anomes' => $selectedMonth,
            'p_year' => $year,
            'p_perfil' => trim((string) ($filters['perfil'] ?? '')),
            'p_segmento' => trim((string) ($filters['segmento'] ?? '')),
            'p_juncao' => trim((string) ($filters['juncao'] ?? '')),
            'p_funcional' => trim((string) ($filters['funcional'] ?? '')),
            'p_indicador' => trim((string) ($filters['indicador'] ?? '')),
            'p_limit_rows' => max(1, $perPage),
            'p_offset_rows' => max(0, $offset),
        ]);
        $columns = isset($rows[0]) && is_array($rows[0]) ? array_keys($rows[0]) : [];
        $resolvedMonthLabel = $selectedMonth !== '' ? $this->formatAnoMesLabel($selectedMonth, false) : '';

        return [
            'title' => $resolvedMonthLabel !== ''
                ? 'Tabela analitica do mes selecionado'
                : 'Performance do ano por indicador',
            'subtitle' => $resolvedMonthLabel !== ''
                ? 'A tabela abaixo foi filtrada exclusivamente pela competencia ' . $resolvedMonthLabel . '.'
                : 'Todas as colunas ja vem calculadas pela base EncantaBra; exibimos sem novas transformacoes.',
            'columns' => $columns,
            'rows' => $rows,
            'total_rows' => $totalRows,
            'current_page' => $currentPage,
            'per_page' => max(1, $perPage),
            'total_pages' => $totalPages,
        ];
    }

    private function fetchMonthOptions(): array
    {
        $options = [];

        foreach ($this->fetchProcedureAll('sp_encantabra_list_month_options') as $row) {
            $value = trim((string) ($row['value'] ?? ''));

            if ($value === '') {
                continue;
            }

            $options[] = [
                'value' => $value,
                'label' => $this->formatAnoMesLabel($value, false),
            ];
        }

        return $options;
    }

    private function fetchDistinctOptions(string $column, array $filters = []): array
    {
        switch ($column) {
            case 'SEGMENTO_PAINEL':
                $rows = $this->fetchProcedureAll('sp_encantabra_list_segment_options');
                break;

            case 'INDICADOR':
                $rows = $this->fetchProcedureAll('sp_encantabra_list_indicator_options', [
                    'p_anomes' => trim((string) ($filters['anomes'] ?? '')),
                    'p_perfil' => trim((string) ($filters['perfil'] ?? '')),
                    'p_segmento' => trim((string) ($filters['segmento'] ?? '')),
                    'p_juncao' => trim((string) ($filters['juncao'] ?? '')),
                    'p_funcional' => trim((string) ($filters['funcional'] ?? '')),
                ]);
                break;

            default:
                $rows = [];
                break;
        }

        $options = [];

        foreach ($rows as $row) {
            $value = trim((string) ($row['value'] ?? ''));

            if ($value === '') {
                continue;
            }

            $options[] = [
                'value' => $value,
                'label' => $value,
            ];
        }

        return $options;
    }

    private function fetchPairOptions(string $codeColumn, string $labelColumn, array $filters = []): array
    {
        if ($codeColumn === 'COD_JUNC' && $labelColumn === 'NOME_JUNC') {
            $rows = $this->fetchProcedureAll('sp_encantabra_list_junction_options', [
                'p_anomes' => trim((string) ($filters['anomes'] ?? '')),
                'p_segmento' => trim((string) ($filters['segmento'] ?? '')),
            ]);
        } elseif ($codeColumn === 'COD_FUNC' && $labelColumn === 'NOME_FUNC') {
            $rows = $this->fetchProcedureAll('sp_encantabra_list_functional_options', [
                'p_anomes' => trim((string) ($filters['anomes'] ?? '')),
                'p_segmento' => trim((string) ($filters['segmento'] ?? '')),
                'p_juncao' => trim((string) ($filters['juncao'] ?? '')),
            ]);
        } else {
            $rows = [];
        }

        $options = [];

        foreach ($rows as $row) {
            $value = trim((string) ($row['value'] ?? ''));
            $label = trim((string) ($row['label'] ?? ''));

            if ($value === '' || $label === '') {
                continue;
            }

            $options[] = [
                'value' => $value,
                'label' => $label,
            ];
        }

        return $options;
    }

    private function sanitizeOption(string $requestedValue, array $options, string $defaultValue = ''): string
    {
        foreach ($options as $option) {
            if ((string) ($option['value'] ?? '') === $requestedValue) {
                return $requestedValue;
            }
        }

        return $defaultValue;
    }

    private function ensureSelectedOption(array $options, string $requestedValue): array
    {
        $requestedValue = trim($requestedValue);

        if ($requestedValue === '') {
            return $options;
        }

        foreach ($options as $option) {
            if ((string) ($option['value'] ?? '') === $requestedValue) {
                return $options;
            }
        }

        $options[] = [
            'value' => $requestedValue,
            'label' => $requestedValue,
        ];

        return $options;
    }

    private function fetchSummaryMetrics(array $filters): array
    {
        $row = $this->fetchProcedureRow('sp_encantabra_get_summary_metrics', [
            'p_anomes' => trim((string) ($filters['anomes'] ?? '')),
            'p_perfil' => trim((string) ($filters['perfil'] ?? '')),
            'p_segmento' => trim((string) ($filters['segmento'] ?? '')),
            'p_juncao' => trim((string) ($filters['juncao'] ?? '')),
            'p_funcional' => trim((string) ($filters['funcional'] ?? '')),
            'p_indicador' => trim((string) ($filters['indicador'] ?? '')),
        ]);

        return is_array($row) ? $row : [];
    }

    private function fetchStatusSummary(array $filters): array
    {
        $row = $this->fetchProcedureRow('sp_encantabra_get_status_summary', [
            'p_anomes' => trim((string) ($filters['anomes'] ?? '')),
            'p_perfil' => trim((string) ($filters['perfil'] ?? '')),
            'p_segmento' => trim((string) ($filters['segmento'] ?? '')),
            'p_juncao' => trim((string) ($filters['juncao'] ?? '')),
            'p_funcional' => trim((string) ($filters['funcional'] ?? '')),
            'p_indicador' => trim((string) ($filters['indicador'] ?? '')),
        ]);

        return [
            'fan' => (int) ($row['fan'] ?? 0),
            'encantador' => (int) ($row['encantador'] ?? 0),
            'expectativa' => (int) ($row['expectativa'] ?? 0),
            'critico' => (int) ($row['critico'] ?? 0),
        ];
    }

    private function buildMonthlyChart(array $filters, array $months): array
    {
        if ($months === []) {
            return ['labels' => [], 'series' => [], 'max_value' => 100.0];
        }

        $monthKeys = array_map(static function (array $month): string {
            return (string) ($month['key'] ?? '');
        }, $months);
        $seriesMap = [];

        foreach ($this->fetchProcedureAll('sp_encantabra_list_monthly_scores', [
            'p_months_csv' => $this->encodeProcedureList($monthKeys),
            'p_perfil' => trim((string) ($filters['perfil'] ?? '')),
            'p_segmento' => trim((string) ($filters['segmento'] ?? '')),
            'p_juncao' => trim((string) ($filters['juncao'] ?? '')),
            'p_funcional' => trim((string) ($filters['funcional'] ?? '')),
            'p_indicador' => trim((string) ($filters['indicador'] ?? '')),
        ]) as $row) {
            $monthKey = trim((string) ($row['ANO_MES'] ?? ''));

            if ($monthKey === '') {
                continue;
            }

            $seriesMap[$monthKey] = (float) ($row['score_avg'] ?? 0.0);
        }

        $labels = [];
        $values = [];
        $benchmark = [];

        foreach ($months as $month) {
            $monthKey = (string) ($month['key'] ?? '');
            $labels[] = (string) ($month['label'] ?? $monthKey);
            $values[] = isset($seriesMap[$monthKey]) ? (float) $seriesMap[$monthKey] : 0.0;
            $benchmark[] = 90.0;
        }

        $maxValue = $this->resolveVisualScaleMax(array_merge($values, $benchmark), 100.0);

        return [
            'labels' => $labels,
            'series' => [
                [
                    'label' => 'Score medio',
                    'color' => '#cc092f',
                    'values' => $values,
                ],
                [
                    'label' => 'Faixa Encantador',
                    'color' => '#1d4ed8',
                    'values' => $benchmark,
                ],
            ],
            'max_value' => $maxValue,
        ];
    }

    private function buildTrimesterTables(array $filters, string $year): array
    {
        if ($year === '') {
            return [];
        }

        $rows = $this->fetchProcedureAll('sp_encantabra_list_trimester_rows', [
            'p_year' => $year,
            'p_perfil' => trim((string) ($filters['perfil'] ?? '')),
            'p_segmento' => trim((string) ($filters['segmento'] ?? '')),
            'p_juncao' => trim((string) ($filters['juncao'] ?? '')),
            'p_funcional' => trim((string) ($filters['funcional'] ?? '')),
            'p_indicador' => trim((string) ($filters['indicador'] ?? '')),
        ]);

        return [
            $this->buildTrimesterTableDefinition('first_trimester', '1o trimestre', [1, 2, 3], $rows),
            $this->buildTrimesterTableDefinition('second_trimester', '2o trimestre', [4, 5, 6], $rows),
            $this->buildTrimesterTableDefinition('third_trimester', '3o trimestre', [7, 8, 9], $rows),
            $this->buildTrimesterTableDefinition('fourth_trimester', '4o trimestre', [10, 11, 12], $rows),
        ];
    }

    private function buildTrimesterTableDefinition(string $id, string $title, array $months, array $rows): array
    {
        $groupedRows = [];

        foreach ($rows as $row) {
            $month = $this->extractMonthNumber($row['ANO_MES'] ?? null);

            if ($month === null || !in_array($month, $months, true)) {
                continue;
            }

            $indicator = trim((string) ($row['INDICADOR'] ?? ''));

            if ($indicator === '') {
                continue;
            }

            $rowKey = trim((string) ($row['COD_INDICADOR'] ?? '')) !== ''
                ? trim((string) ($row['COD_INDICADOR'] ?? ''))
                : $indicator;

            if (!isset($groupedRows[$rowKey])) {
                $groupedRows[$rowKey] = [
                    'key' => $rowKey,
                    'label' => $indicator,
                    'months' => [],
                    'average' => null,
                    'band' => ['label' => 'Sem dados', 'range' => 'Sem leitura', 'tone' => 'is-empty'],
                ];
            }

            $groupedRows[$rowKey]['months'][$month] = [
                'peso' => $this->nullableFloat($row['peso_avg'] ?? null),
                'real' => $this->nullableFloat($row['real_avg'] ?? null),
                'ating' => $this->nullableFloat($row['ating_avg'] ?? null),
                'pont' => $this->nullableFloat($row['pont_avg'] ?? null),
            ];
        }

        foreach ($groupedRows as $rowKey => $groupedRow) {
            $averages = [];

            foreach ($months as $month) {
                $monthScore = $groupedRow['months'][$month]['pont'] ?? null;

                if ($monthScore === null) {
                    continue;
                }

                $averages[] = $monthScore;
            }

            $average = $averages !== [] ? array_sum($averages) / count($averages) : null;
            $groupedRows[$rowKey]['average'] = $average;
            $groupedRows[$rowKey]['band'] = $this->resolveBandMeta($average);
        }

        usort($groupedRows, static function (array $left, array $right): int {
            return strcmp((string) ($left['label'] ?? ''), (string) ($right['label'] ?? ''));
        });

        $monthDefinitions = [];

        foreach ($months as $month) {
            $monthDefinitions[] = [
                'number' => $month,
                'label' => $this->resolveMonthShortLabel($month),
            ];
        }

        return [
            'id' => $id,
            'title' => $title,
            'months' => $monthDefinitions,
            'rows' => array_values($groupedRows),
        ];
    }

    private function resolveVisualScaleMax(array $values, float $minimum = 100.0): float
    {
        $highestValue = $minimum;

        foreach ($values as $value) {
            if (!is_numeric($value)) {
                continue;
            }

            $highestValue = max($highestValue, (float) $value);
        }

        return ceil($highestValue / 10.0) * 10.0;
    }

    private function fetchIndicatorTableRows(array $filters): array
    {
        $rows = [];

        foreach ($this->fetchProcedureAll('sp_encantabra_list_indicator_rows', [
            'p_anomes' => trim((string) ($filters['anomes'] ?? '')),
            'p_perfil' => trim((string) ($filters['perfil'] ?? '')),
            'p_segmento' => trim((string) ($filters['segmento'] ?? '')),
            'p_juncao' => trim((string) ($filters['juncao'] ?? '')),
            'p_funcional' => trim((string) ($filters['funcional'] ?? '')),
            'p_indicador' => trim((string) ($filters['indicador'] ?? '')),
        ]) as $row) {
            $indicator = trim((string) ($row['INDICADOR'] ?? ''));

            if ($indicator === '') {
                continue;
            }

            $score = (float) ($row['score_avg'] ?? 0.0);
            $rows[] = [
                'indicator' => $indicator,
                'meta_avg' => (float) ($row['meta_avg'] ?? 0.0),
                'real_avg' => (float) ($row['real_avg'] ?? 0.0),
                'score_avg' => $score,
                'row_count' => (int) ($row['row_count'] ?? 0),
                'band' => $this->resolveBandMeta($score),
            ];
        }

        return $rows;
    }

    private function resolveBandMeta(?float $score): array
    {
        if ($score === null) {
            return ['label' => 'Sem dados', 'range' => 'Sem leitura', 'tone' => 'is-empty'];
        }

        if ($score >= 110.0) {
            return ['label' => 'Cliente fa', 'range' => '110 a 150', 'tone' => 'is-fan'];
        }

        if ($score >= 90.0) {
            return ['label' => 'Encantador', 'range' => '90 a 109,99', 'tone' => 'is-encantador'];
        }

        if ($score >= 70.0) {
            return ['label' => 'Atende expectativa', 'range' => '70 a 89,99', 'tone' => 'is-expected'];
        }

        return ['label' => 'Critico', 'range' => '0 a 69,99', 'tone' => 'is-far'];
    }

    private function buildScopeLabel(array $filters): string
    {
        $parts = [$this->resolveProfileLabel((string) ($filters['perfil'] ?? 'SG'))];
        $segment = trim((string) ($filters['segmento'] ?? ''));
        $juncao = trim((string) ($filters['juncao'] ?? ''));
        $functional = trim((string) ($filters['funcional'] ?? ''));
        $indicator = trim((string) ($filters['indicador'] ?? ''));

        if ($segment !== '') {
            $parts[] = $segment;
        }

        if ($juncao !== '') {
            $juncaoLabel = $this->lookupLabelByCode('COD_JUNC', 'NOME_JUNC', $juncao);

            if ($juncaoLabel !== '') {
                $parts[] = $juncaoLabel;
            }
        }

        if ($functional !== '') {
            $functionalLabel = $this->lookupLabelByCode('COD_FUNC', 'NOME_FUNC', $functional);

            if ($functionalLabel !== '') {
                $parts[] = $functionalLabel;
            }
        }

        if ($indicator !== '') {
            $parts[] = $indicator;
        }

        return implode(' - ', array_values(array_filter($parts, static function (string $value): bool {
            return trim($value) !== '';
        })));
    }

    private function lookupLabelByCode(string $codeColumn, string $labelColumn, string $codeValue): string
    {
        if (!$this->hasLocalTable()) {
            return '';
        }

        if ($codeColumn === 'COD_JUNC' && $labelColumn === 'NOME_JUNC') {
            $label = $this->fetchProcedureValue('sp_encantabra_lookup_junction_label', ['p_juncao' => $codeValue]);
        } elseif ($codeColumn === 'COD_FUNC' && $labelColumn === 'NOME_FUNC') {
            $label = $this->fetchProcedureValue('sp_encantabra_lookup_functional_label', ['p_funcional' => $codeValue]);
        } else {
            $label = '';
        }

        return trim((string) $label);
    }

    private function buildMonthWindow(string $selectedMonth, int $window): array
    {
        $options = $this->fetchMonthOptions();
        $filtered = array_values(array_filter($options, static function (array $option) use ($selectedMonth): bool {
            return (string) ($option['value'] ?? '') !== '' && strcmp((string) ($option['value'] ?? ''), $selectedMonth) <= 0;
        }));

        if ($filtered === []) {
            return [];
        }

        $slice = array_slice($filtered, max(0, count($filtered) - $window));
        $months = [];

        foreach ($slice as $month) {
            $value = (string) ($month['value'] ?? '');

            if ($value === '') {
                continue;
            }

            $months[] = [
                'key' => $value,
                'label' => $this->formatAnoMesLabel($value, true),
                'full_label' => $this->formatAnoMesLabel($value, false),
            ];
        }

        return $months;
    }

    private function resolveSelectedYear(string $selectedMonth): string
    {
        $digits = preg_replace('/[^0-9]/', '', $selectedMonth) ?? '';

        if (strlen($digits) >= 4) {
            return substr($digits, 0, 4);
        }

        $monthOptions = $this->fetchMonthOptions();
        $fallbackMonth = trim((string) ($monthOptions[0]['value'] ?? ''));
        $fallbackDigits = preg_replace('/[^0-9]/', '', $fallbackMonth) ?? '';

        return strlen($fallbackDigits) >= 4 ? substr($fallbackDigits, 0, 4) : '';
    }

    private function extractMonthNumber($anoMes): ?int
    {
        if ($anoMes === null || $anoMes === '') {
            return null;
        }

        $digits = preg_replace('/[^0-9]/', '', (string) $anoMes) ?? '';

        if (strlen($digits) < 6) {
            return null;
        }

        $month = (int) substr($digits, -2);

        return $month >= 1 && $month <= 12 ? $month : null;
    }

    private function resolveMonthShortLabel(int $month): string
    {
        $months = [
            1 => 'Jan',
            2 => 'Fev',
            3 => 'Mar',
            4 => 'Abr',
            5 => 'Mai',
            6 => 'Jun',
            7 => 'Jul',
            8 => 'Ago',
            9 => 'Set',
            10 => 'Out',
            11 => 'Nov',
            12 => 'Dez',
        ];

        return $months[$month] ?? (string) $month;
    }

    private function nullableFloat($value): ?float
    {
        if ($value === null || $value === '' || !is_numeric($value)) {
            return null;
        }

        return (float) $value;
    }

    private function resolveProfileLabel(string $profile): string
    {
        $map = [
            'SG' => 'Visao de segmento',
            'AG' => 'Visao por agencia',
            'GC' => 'Visao por gerente',
        ];

        return $map[$profile] ?? 'Visao EncantaBra';
    }

    private function formatAnoMesLabel(string $value, bool $shortYear): string
    {
        $value = preg_replace('/[^0-9]/', '', $value) ?? '';

        if (strlen($value) !== 6) {
            return $value;
        }

        $year = substr($value, 0, 4);
        $monthNumber = (int) substr($value, 4, 2);
        $months = [
            1 => 'jan',
            2 => 'fev',
            3 => 'mar',
            4 => 'abr',
            5 => 'mai',
            6 => 'jun',
            7 => 'jul',
            8 => 'ago',
            9 => 'set',
            10 => 'out',
            11 => 'nov',
            12 => 'dez',
        ];
        $monthLabel = $months[$monthNumber] ?? $value;

        if ($shortYear) {
            return $monthLabel . '/' . substr($year, -2);
        }

        return ucfirst($monthLabel) . '/' . $year;
    }

    private function hasLocalTable(): bool
    {
        if ($this->tableAvailable !== null) {
            return $this->tableAvailable;
        }

        $this->tableAvailable = (bool) $this->fetchProcedureValue(
            'sp_util_table_exists',
            ['p_table_name' => self::TABLE_NAME]
        );

        return $this->tableAvailable;
    }
}
