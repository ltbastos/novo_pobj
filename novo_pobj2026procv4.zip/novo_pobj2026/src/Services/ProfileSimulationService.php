<?php

declare(strict_types=1);

namespace App\Services;

use App\Support\CallsStoredProcedures;
use PDO;

final class ProfileSimulationService
{
    use CallsStoredProcedures;

    private const LEVEL_SCOPE_RANK = [
        'AS' => 0,
        'GC' => 0,
        'PA' => 0,
        'GG' => 1,
        'TL' => 1,
        'AG' => 1,
        'GE' => 2,
        'GR' => 2,
        'DR' => 3,
        'SG' => 4,
        'DP' => 5,
    ];

    private const JUNCTION_SCOPE_RANK = [
        'AG' => 1,
        'GR' => 2,
        'DR' => 3,
        'SG' => 4,
        'DP' => 5,
    ];

    /** @var PDO */
    private $connection;

    public function __construct(PDO $connection)
    {
        $this->connection = $connection;
    }

    protected function getProcedureConnection(): PDO
    {
        return $this->connection;
    }

    public function listProfiles(): array
    {
        return $this->fetchProcedureAll('sp_profile_list_profiles');
    }

    public function profileExists(string $functional): bool
    {
        return (bool) $this->fetchProcedureValue('sp_profile_exists', ['p_functional' => $functional]);
    }

    public function getContext(string $functional): ?array
    {
        $profile = $this->fetchProcedureRow('sp_profile_get_profile', ['p_functional' => $functional]);

        if (!$profile) {
            return null;
        }

        $junctions = $this->fetchProcedureAll('sp_profile_get_junctions', ['p_functional' => $functional]);

        $scope = $this->resolveScope($profile['nivel'], $junctions, $profile['funcional']);

        return [
            'profile' => $profile,
            'junctions' => $junctions,
            'scope' => $scope,
        ];
    }

    private function resolveScope(string $level, array $junctions, string $functional): array
    {
        foreach ($junctions as $junction) {
            if ($junction['juncao'] === '4000') {
                return [
                    'code' => 'GLOBAL',
                    'label' => 'Visao total do departamento',
                    'allowed' => [],
                    'functional' => $functional,
                ];
            }
        }

        if (in_array($level, ['GC', 'PA', 'AS'], true)) {
            return [
                'code' => 'SELF',
                'label' => 'Carteira propria do usuario selecionado',
                'allowed' => [],
                'functional' => $functional,
            ];
        }

        $baseRank = self::LEVEL_SCOPE_RANK[$level] ?? 0;
        $junctionRank = 0;

        foreach ($junctions as $junction) {
            $junctionRank = max($junctionRank, self::JUNCTION_SCOPE_RANK[$junction['tipo_juncao']] ?? 0);
        }

        $effectiveRank = max($baseRank, $junctionRank);

        if ($effectiveRank >= 5) {
            return [
                'code' => 'GLOBAL',
                'label' => 'Visao total do departamento',
                'allowed' => [],
                'functional' => $functional,
            ];
        }

        if ($effectiveRank === 4) {
            return [
                'code' => 'SG',
                'label' => 'Visao de segmento',
                'allowed' => $this->resolveSegmentJunctions($junctions),
                'functional' => $functional,
            ];
        }

        if ($effectiveRank === 3) {
            return [
                'code' => 'DR',
                'label' => 'Visao de diretoria',
                'allowed' => $this->resolveDrJunctions($junctions),
                'functional' => $functional,
            ];
        }

        if ($effectiveRank === 2) {
            return [
                'code' => 'GR',
                'label' => 'Visao regional',
                'allowed' => $this->resolveGrJunctions($junctions),
                'functional' => $functional,
            ];
        }

        if ($effectiveRank === 1) {
            return [
                'code' => 'AG',
                'label' => 'Visao de agencia',
                'allowed' => $this->resolveAgJunctions($junctions),
                'functional' => $functional,
            ];
        }

        return [
            'code' => 'SELF',
            'label' => 'Carteira propria do usuario selecionado',
            'allowed' => [],
            'functional' => $functional,
        ];
    }

    private function resolveSegmentJunctions(array $junctions): array
    {
        $segments = [];

        foreach ($junctions as $junction) {
            if ($junction['tipo_juncao'] === 'SG') {
                $segments[] = $junction['juncao'];
            }
        }

        $segments = array_values(array_unique(array_filter($segments)));
        sort($segments);

        return $segments;
    }

    private function resolveAgJunctions(array $junctions): array
    {
        $agencies = [];

        foreach ($junctions as $junction) {
            if ($junction['tipo_juncao'] === 'AG') {
                $agencies[] = $junction['juncao'];
            }
        }

        $agencies = array_values(array_unique($agencies));
        sort($agencies);

        return $agencies;
    }

    private function resolveGrJunctions(array $junctions): array
    {
        $regionals = [];
        $agencyJunctions = [];

        foreach ($junctions as $junction) {
            if ($junction['tipo_juncao'] === 'GR') {
                $regionals[] = $junction['juncao'];
            }

            if ($junction['tipo_juncao'] === 'AG') {
                $agencyJunctions[] = $junction['juncao'];
            }
        }

        if ($agencyJunctions !== []) {
            $rows = $this->fetchProcedureAll(
                'sp_profile_resolve_gr_from_agencies',
                ['p_agencies_csv' => $this->encodeProcedureList($agencyJunctions)]
            );
            $regionals = array_merge($regionals, array_column($rows, 'juncao_gr'));
        }

        $regionals = array_values(array_unique(array_filter($regionals)));
        sort($regionals);

        return $regionals;
    }

    private function resolveDrJunctions(array $junctions): array
    {
        $directorates = [];
        $regionalJunctions = [];
        $agencyJunctions = [];

        foreach ($junctions as $junction) {
            if ($junction['tipo_juncao'] === 'DR') {
                $directorates[] = $junction['juncao'];
            }

            if ($junction['tipo_juncao'] === 'GR') {
                $regionalJunctions[] = $junction['juncao'];
            }

            if ($junction['tipo_juncao'] === 'AG') {
                $agencyJunctions[] = $junction['juncao'];
            }
        }

        if ($regionalJunctions !== []) {
            $rows = $this->fetchProcedureAll(
                'sp_profile_resolve_dr_from_regionals',
                ['p_regionals_csv' => $this->encodeProcedureList($regionalJunctions)]
            );
            $directorates = array_merge($directorates, array_column($rows, 'juncao_dr'));
        }

        if ($agencyJunctions !== []) {
            $rows = $this->fetchProcedureAll(
                'sp_profile_resolve_dr_from_agencies',
                ['p_agencies_csv' => $this->encodeProcedureList($agencyJunctions)]
            );
            $directorates = array_merge($directorates, array_column($rows, 'juncao_dr'));
        }

        $directorates = array_values(array_unique(array_filter($directorates)));
        sort($directorates);

        return $directorates;
    }
}
