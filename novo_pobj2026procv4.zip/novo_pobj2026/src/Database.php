<?php

declare(strict_types=1);

namespace App;

use PDO;
use PDOException;

final class Database
{
    /** @var PDO|null */
    private static $connection = null;

    public static function connection(): PDO
    {
        if (self::$connection instanceof PDO) {
            return self::$connection;
        }

        $config = require __DIR__ . '/../config/database.php';

        $dsn = sprintf(
            'mysql:host=%s;port=%d;dbname=%s;charset=%s',
            $config['host'],
            $config['port'],
            $config['database'],
            $config['charset']
        );
        $charset = (string) ($config['charset'] ?? 'utf8mb4');
        $collation = stripos($charset, 'utf8mb4') === 0
            ? 'utf8mb4_unicode_ci'
            : (stripos($charset, 'utf8') === 0 ? 'utf8_unicode_ci' : '');
        $initCommand = $collation !== ''
            ? sprintf('SET NAMES %s COLLATE %s', $charset, $collation)
            : sprintf('SET NAMES %s', $charset);

        try {
            self::$connection = new PDO(
                $dsn,
                $config['username'],
                $config['password'],
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                    PDO::MYSQL_ATTR_INIT_COMMAND => $initCommand,
                ]
            );
        } catch (PDOException $exception) {
            throw new PDOException('Falha ao conectar com o banco de dados do projeto.', (int) $exception->getCode(), $exception);
        }

        return self::$connection;
    }
}
