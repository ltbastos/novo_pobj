<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

json_response([
    'ok' => true,
    'answer' => 'Em breve.',
    'message' => 'Em breve.',
    'documents' => [],
    'sources' => [],
]);
