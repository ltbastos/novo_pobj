<?php

declare(strict_types=1);

if (($activeTab ?? 'resumo') !== 'visao-executiva') {
    return;
}

$executive = $executiveData ?? [];
$focus = $executive['focus'] ?? [];
$reference = $executive['reference'] ?? [];
$kpis = $executive['kpis'] ?? [];
$chart = $executive['chart'] ?? ['labels' => [], 'series' => [], 'max_value' => 100.0];
$ranking = $executive['ranking'] ?? ['top' => [], 'bottom' => []];
$insights = $executive['insights'] ?? ['positive' => [], 'negative' => []];
$status = $executive['status'] ?? ['hit' => [], 'quase' => [], 'longe' => [], 'summary' => ['hit' => 0, 'quase' => 0, 'longe' => 0]];
$statusTitle = (string) ($status['title'] ?? ($focus['status_title'] ?? 'Status por Regional'));
$heatmap = $executive['heatmap'] ?? [
    'default_mode' => 'secoes',
    'secoes' => ['title' => '', 'row_axis_label' => 'GR', 'row_axis_sublabel' => 'Familias', 'rows' => [], 'columns' => [], 'data' => []],
    'meta' => ['title' => '', 'row_axis_label' => 'Hierarquia', 'row_axis_sublabel' => 'Mes', 'rows' => [], 'months' => [], 'data' => []],
];

$sectionsHeatmap = $heatmap['secoes'] ?? ['title' => '', 'row_axis_label' => 'GR', 'row_axis_sublabel' => 'Familias', 'rows' => [], 'columns' => [], 'data' => []];
$metaHeatmap = $heatmap['meta'] ?? ['title' => '', 'row_axis_label' => 'Hierarquia', 'row_axis_sublabel' => 'Mes', 'rows' => [], 'months' => [], 'data' => []];
$heatmapDefaultMode = (($heatmap['default_mode'] ?? 'secoes') === 'meta') ? 'meta' : 'secoes';

$formatPoints = static function (float $value): string {
    return format_points_readable($value) . ' pts';
};

$formatAbsoluteValue = static function (?float $value, string $mode = 'value'): string {
    if ($value === null) {
        return '-';
    }

    if ($mode === 'count') {
        return format_int_readable($value);
    }

    return format_number_readable($value);
};

$formatAbsoluteValueDetailed = static function (?float $value, string $mode = 'value'): string {
    if ($value === null) {
        return '-';
    }

    if ($mode === 'count') {
        return format_int_readable($value);
    }

    return format_decimal($value, 2);
};

$formatPercent = static function (float $value): string {
    return format_decimal($value, 1, '%');
};

$resolvePerformanceToneClass = static function (?float $value): string {
    if ($value === null) {
        return 'is-empty';
    }

    if ($value >= 100.0) {
        return 'is-hit';
    }

    if ($value >= 90.0) {
        return 'is-close';
    }

    return 'is-far';
};

$resolveMetaTone = static function (?float $currentMeta, ?float $previousMeta): array {
    if ($currentMeta === null || $previousMeta === null) {
        return ['text' => '-', 'class' => 'is-empty'];
    }

    if ((float) $previousMeta === 0.0) {
        if ((float) $currentMeta === 0.0) {
            return ['text' => '0,0%', 'class' => 'is-up-ok'];
        }

        return ['text' => '-', 'class' => 'is-empty'];
    }

    $delta = (((float) $currentMeta - (float) $previousMeta) / (float) $previousMeta) * 100.0;
    $text = ($delta > 0 ? '+' : '') . format_decimal($delta, 1, '%');

    if ($delta < 0) {
        return ['text' => $text, 'class' => 'is-down'];
    }

    if ($delta <= 5.0) {
        return ['text' => $text, 'class' => 'is-up-ok'];
    }

    if ($delta <= 10.0) {
        return ['text' => $text, 'class' => 'is-up-warn'];
    }

    return ['text' => $text, 'class' => 'is-up-alert'];
};

$chartLabels = array_values(array_filter(array_map(static function ($label): string {
    return trim((string) $label);
}, (array) ($chart['labels'] ?? [])), static function (string $label): bool {
    return $label !== '';
}));
$chartSeries = array_values(array_filter((array) ($chart['series'] ?? []), static function ($series): bool {
    return is_array($series) && trim((string) ($series['label'] ?? '')) !== '';
}));
$chartMaxValue = max(100.0, (float) ($chart['max_value'] ?? 100.0));
$chartWidth = 760.0;
$chartHeight = 208.0;
$paddingLeft = 46.0;
$paddingRight = 14.0;
$paddingTop = 12.0;
$paddingBottom = 30.0;
$plotWidth = max(1.0, $chartWidth - $paddingLeft - $paddingRight);
$plotHeight = max(1.0, $chartHeight - $paddingTop - $paddingBottom);
$chartCount = count($chartLabels);
$xStep = $chartCount > 1 ? $plotWidth / ($chartCount - 1) : 0.0;

$buildChartPoints = static function (array $values) use ($chartCount, $xStep, $paddingLeft, $paddingTop, $plotWidth, $plotHeight, $chartMaxValue): array {
    if ($chartCount === 0) {
        return [];
    }

    $points = [];

    foreach ($values as $index => $value) {
        $safeValue = max(0.0, min($chartMaxValue, (float) $value));
        $x = $chartCount > 1
            ? $paddingLeft + ($xStep * $index)
            : $paddingLeft + ($plotWidth / 2);
        $y = $paddingTop + $plotHeight - (($safeValue / $chartMaxValue) * $plotHeight);
        $points[] = ['x' => $x, 'y' => $y, 'value' => $safeValue];
    }

    return $points;
};

$topList = array_values((array) ($ranking['top'] ?? []));
$bottomList = array_values((array) ($ranking['bottom'] ?? []));
$topFullList = array_values((array) ($ranking['top_all'] ?? $topList));
$bottomFullList = array_values((array) ($ranking['bottom_all'] ?? $bottomList));
$positiveInsights = array_values((array) ($insights['positive'] ?? []));
$negativeInsights = array_values((array) ($insights['negative'] ?? []));
$analysisRowCount = max(count($positiveInsights), count($negativeInsights), 1);
$analysisRows = [];
for ($analysisIndex = 0; $analysisIndex < $analysisRowCount; $analysisIndex++) {
    $analysisRows[] = [
        'positive' => $positiveInsights[$analysisIndex] ?? null,
        'negative' => $negativeInsights[$analysisIndex] ?? null,
        'show_empty_positive' => $analysisIndex === 0 && $positiveInsights === [],
        'show_empty_negative' => $analysisIndex === 0 && $negativeInsights === [],
    ];
}
$statusFullLists = [
    'hit' => array_values((array) ($status['hit_all'] ?? ($status['hit'] ?? []))),
    'quase' => array_values((array) ($status['quase_all'] ?? ($status['quase'] ?? []))),
    'longe' => array_values((array) ($status['longe_all'] ?? ($status['longe'] ?? []))),
];
$sectionRows = (array) ($sectionsHeatmap['rows'] ?? []);
$sectionColumns = (array) ($sectionsHeatmap['columns'] ?? []);
$sectionData = (array) ($sectionsHeatmap['data'] ?? []);
$metaRows = (array) ($metaHeatmap['rows'] ?? []);
$metaMonths = (array) ($metaHeatmap['months'] ?? []);
$metaData = (array) ($metaHeatmap['data'] ?? []);
$monthlyGap = (float) ($kpis['gap'] ?? 0.0);
$monthlyForecast = (float) ($kpis['forecast'] ?? 0.0);
$businessDays = $kpis['business_days'] ?? ['elapsed' => 0, 'total' => 0, 'remaining' => 0];

$kpiCards = [
    [
        'title' => 'Atingimento mensal',
        'icon' => 'target',
        'value' => $formatPercent((float) ($kpis['percent_mens'] ?? 0.0)),
        'detail_primary' => 'Realizado: ' . $formatPoints((float) ($kpis['real_mens'] ?? 0.0)),
        'detail_secondary' => 'Meta: ' . $formatPoints((float) ($kpis['meta_mens'] ?? 0.0)),
        'foot' => (string) ($reference['month_label'] ?? ''),
        'tone' => $resolvePerformanceToneClass((float) ($kpis['percent_mens'] ?? 0.0)),
    ],
    [
        'title' => 'Defasagem',
        'icon' => 'gauge',
        'value' => $formatPoints(abs($monthlyGap)),
        'detail_primary' => $monthlyGap > 0 ? 'Meta - realizado' : 'Realizado acima da meta',
        'detail_secondary' => 'Acumulado: ' . $formatPoints((float) ($kpis['real_acum'] ?? 0.0)) . ' / ' . $formatPoints((float) ($kpis['meta_acum'] ?? 0.0)),
        'foot' => 'Recorte atual',
        'tone' => $monthlyGap > 0 ? 'is-far' : 'is-hit',
    ],
    [
        'title' => 'Forecast',
        'icon' => 'chart-no-axes-column',
        'value' => $formatPercent((float) ($kpis['percent_forecast'] ?? 0.0)),
        'detail_primary' => 'Projetado: ' . $formatPoints($monthlyForecast),
        'detail_secondary' => 'Dias uteis: ' . format_int_readable((float) ($businessDays['elapsed'] ?? 0)) . ' / ' . format_int_readable((float) ($businessDays['total'] ?? 0)),
        'foot' => 'Projecao do mes corrente',
        'tone' => $resolvePerformanceToneClass((float) ($kpis['percent_forecast'] ?? 0.0)),
    ],
];

$statusCards = [
    ['key' => 'hit', 'title' => 'Atingiu', 'tone' => 'is-hit'],
    ['key' => 'quase', 'title' => 'Quase la', 'tone' => 'is-close'],
    ['key' => 'longe', 'title' => 'Longe', 'tone' => 'is-far'],
];

$executiveExpandedSections = [
    [
        'id' => 'ranking-top',
        'title' => (string) ($focus['ranking_title'] ?? 'Desempenho por Regional') . ' - ranking completo',
        'items' => $topFullList,
        'tone' => '',
        'show_deficit' => false,
    ],
    [
        'id' => 'ranking-bottom',
        'title' => (string) ($focus['ranking_title'] ?? 'Desempenho por Regional') . ' - bottom completo',
        'items' => $bottomFullList,
        'tone' => 'is-far',
        'show_deficit' => false,
    ],
    [
        'id' => 'status-hit',
        'title' => $statusTitle . ' - Atingiu',
        'items' => $statusFullLists['hit'],
        'tone' => 'is-hit',
        'show_deficit' => false,
    ],
    [
        'id' => 'status-quase',
        'title' => $statusTitle . ' - Quase la',
        'items' => $statusFullLists['quase'],
        'tone' => 'is-close',
        'show_deficit' => false,
    ],
    [
        'id' => 'status-longe',
        'title' => $statusTitle . ' - Longe',
        'items' => $statusFullLists['longe'],
        'tone' => 'is-far',
        'show_deficit' => true,
    ],
];

$renderExecutiveExpandedItems = static function (array $items, string $tone, bool $showDeficit) use ($formatPercent, $formatPoints, $resolvePerformanceToneClass): void {
    if ($items === []) {
        ?>
        <div class="executive-empty">Sem dados disponiveis.</div>
        <?php
        return;
    }

    foreach ($items as $item) {
        $percent = (float) ($item['p_mens'] ?? 0.0);
        $itemTone = $tone !== '' ? $tone : $resolvePerformanceToneClass($percent);
        ?>
        <article class="executive-list-item <?= e($itemTone) ?>">
            <div class="executive-list-item__head">
                <strong><?= e(prime_label((string) ($item['display_label'] ?? 'Sem referencia'))) ?></strong>
                <?php if ($showDeficit): ?>
                    <span>-<?= e($formatPoints((float) ($item['deficit'] ?? 0.0))) ?></span>
                <?php else: ?>
                    <span><?= e($formatPercent($percent)) ?></span>
                <?php endif; ?>
            </div>
            <div class="executive-list-item__meta"><?= e($formatPoints((float) ($item['real_mens'] ?? 0.0))) ?> / <?= e($formatPoints((float) ($item['meta_mens'] ?? 0.0))) ?></div>
            <div class="executive-list-item__meter is-visible"><span style="--target-width: <?= e(number_format(max(6.0, min(100.0, $percent)), 2, '.', '')) ?>%;"></span></div>
        </article>
        <?php
    }
};

$renderExecutiveInsightItems = static function (?array $item, string $toneClass, bool $showEmptyMessage = false): void {
    if ($item === null) {
        if ($showEmptyMessage) {
            ?>
            <div class="executive-empty executive-empty--compact">Sem leituras disponiveis para este recorte.</div>
            <?php
            return;
        }
        ?>
        <div class="executive-analysis-placeholder" aria-hidden="true"></div>
        <?php
        return;
    }
    ?>
    <article class="executive-insight-card <?= e($toneClass) ?>">
        <div class="executive-insight-card__head">
            <strong><?= e((string) ($item['title'] ?? 'Insight')) ?></strong>
            <?php if (trim((string) ($item['highlight'] ?? '')) !== ''): ?>
                <span><?= e((string) ($item['highlight'] ?? '')) ?></span>
            <?php endif; ?>
        </div>
        <p><?= e((string) ($item['text'] ?? '')) ?></p>
    </article>
    <?php
};
?>
<section class="executive-view" aria-label="Visao executiva" data-executive-view>
    <div class="executive-kpi-grid">
        <?php foreach ($kpiCards as $card): ?>
            <article class="executive-kpi-card <?= e((string) ($card['tone'] ?? 'is-close')) ?>">
                <div class="executive-kpi-card__header">
                    <span class="executive-kpi-card__icon" aria-hidden="true">
                        <i data-lucide="<?= e((string) ($card['icon'] ?? 'sparkles')) ?>"></i>
                    </span>
                    <span class="executive-kpi-card__title"><?= e((string) ($card['title'] ?? '')) ?></span>
                </div>

                <div class="executive-kpi-card__value"><?= e((string) ($card['value'] ?? '0')) ?></div>
                <div class="executive-kpi-card__detail"><?= e((string) ($card['detail_primary'] ?? '')) ?></div>
                <div class="executive-kpi-card__detail executive-kpi-card__detail--muted"><?= e((string) ($card['detail_secondary'] ?? '')) ?></div>
                <div class="executive-kpi-card__foot"><?= e((string) ($card['foot'] ?? '')) ?></div>
            </article>
        <?php endforeach; ?>
    </div>

    <div class="executive-main-grid">
        <section class="executive-panel executive-panel--chart">
            <header class="executive-panel__header">
                <div>
                    <span class="executive-panel__eyebrow">Evolucao mensal</span>
                    <h3 class="executive-panel__title">Evolucao mensal por secao</h3>
                </div>
                <span class="executive-panel__tag"><?= e((string) ($reference['window_label'] ?? 'Ultimos 6 meses')) ?></span>
            </header>

            <?php if ($chartSeries === [] || $chartLabels === []): ?>
                <div class="executive-empty">Nao ha dados suficientes para montar a serie mensal com os filtros atuais.</div>
            <?php else: ?>
                <div class="executive-chart" data-executive-chart>
                    <div class="executive-chart__legend">
                        <?php foreach ($chartSeries as $series): ?>
                            <span class="executive-chart__legend-item">
                                <span class="executive-chart__legend-dot" style="--executive-chart-color: <?= e((string) ($series['color'] ?? '#cc092f')) ?>; background: <?= e((string) ($series['color'] ?? '#cc092f')) ?>;"></span>
                                <span><?= e((string) ($series['label'] ?? '')) ?></span>
                            </span>
                        <?php endforeach; ?>
                    </div>

                    <div class="executive-chart__canvas">
                        <svg class="executive-chart__svg" viewBox="0 0 <?= e(format_decimal($chartWidth, 0)) ?> <?= e(format_decimal($chartHeight, 0)) ?>" role="img" aria-label="Grafico de linhas com evolucao mensal por secao">
                            <?php for ($step = 0; $step <= 4; $step++): ?>
                                <?php
                                $gridValue = $chartMaxValue - (($chartMaxValue / 4) * $step);
                                $gridY = $paddingTop + (($plotHeight / 4) * $step);
                                ?>
                                <line class="executive-chart__grid-line" x1="<?= e((string) $paddingLeft) ?>" y1="<?= e(number_format($gridY, 2, '.', '')) ?>" x2="<?= e(number_format($chartWidth - $paddingRight, 2, '.', '')) ?>" y2="<?= e(number_format($gridY, 2, '.', '')) ?>"></line>
                                <text class="executive-chart__axis-label" x="<?= e(number_format($paddingLeft - 10, 2, '.', '')) ?>" y="<?= e(number_format($gridY + 4, 2, '.', '')) ?>"><?= e(format_decimal($gridValue, 0, '%')) ?></text>
                            <?php endfor; ?>

                            <?php foreach ($chartLabels as $index => $label): ?>
                                <?php
                                $x = $chartCount > 1
                                    ? $paddingLeft + ($xStep * $index)
                                    : $paddingLeft + ($plotWidth / 2);
                                ?>
                                <text class="executive-chart__month-label" x="<?= e(number_format($x, 2, '.', '')) ?>" y="<?= e(number_format($chartHeight - 8, 2, '.', '')) ?>"><?= e($label) ?></text>
                            <?php endforeach; ?>

                            <?php foreach ($chartSeries as $seriesIndex => $series): ?>
                                <?php $seriesPoints = $buildChartPoints((array) ($series['values'] ?? [])); ?>
                                <?php if ($seriesPoints === []): ?>
                                    <?php continue; ?>
                                <?php endif; ?>
                                <polyline class="executive-chart__line" data-executive-line style="--line-delay: <?= e((string) ($seriesIndex * 150)) ?>ms;" points="<?= e(implode(' ', array_map(static function (array $point): string {
                                    return number_format($point['x'], 2, '.', '') . ',' . number_format($point['y'], 2, '.', '');
                                }, $seriesPoints))) ?>" stroke="<?= e((string) ($series['color'] ?? '#cc092f')) ?>"></polyline>
                                <?php foreach ($seriesPoints as $pointIndex => $point): ?>
                                    <?php $pointTooltip = sprintf('%s | %s | Atingimento: %s', (string) ($series['label'] ?? 'Secao'), (string) ($chartLabels[$pointIndex] ?? ''), $formatPercent((float) ($point['value'] ?? 0.0))); ?>
                                    <circle class="executive-chart__point" data-executive-point data-executive-tooltip="<?= e($pointTooltip) ?>" aria-label="<?= e($pointTooltip) ?>" style="--point-delay: <?= e((string) (($seriesIndex * 150) + 180 + ($pointIndex * 55))) ?>ms;" cx="<?= e(number_format((float) $point['x'], 2, '.', '')) ?>" cy="<?= e(number_format((float) $point['y'], 2, '.', '')) ?>" r="5.2" fill="<?= e((string) ($series['color'] ?? '#cc092f')) ?>" tabindex="0"></circle>
                                <?php endforeach; ?>
                            <?php endforeach; ?>
                        </svg>
                    </div>
                </div>
            <?php endif; ?>
        </section>
    </div>

    <section class="executive-panel executive-panel--analysis" aria-label="Analise inteligente">
        <header class="executive-panel__header">
            <div>
                <span class="executive-panel__eyebrow">Analise inteligente</span>
                <h3 class="executive-panel__title">Leituras automatizadas do recorte atual</h3>
            </div>
        </header>

        <div class="executive-analysis-head">
            <div class="executive-analysis-column__head">
                <span class="executive-analysis-column__eyebrow">Positivos</span>
                <h4>O que esta ajudando o resultado</h4>
            </div>
            <div class="executive-analysis-column__head">
                <span class="executive-analysis-column__eyebrow">Negativos</span>
                <h4>O que pede atencao agora</h4>
            </div>
        </div>

        <div class="executive-analysis-grid">
            <?php foreach ($analysisRows as $analysisRow): ?>
                <div class="executive-analysis-row">
                    <div class="executive-analysis-cell">
                        <?php $renderExecutiveInsightItems($analysisRow['positive'], 'is-positive', (bool) ($analysisRow['show_empty_positive'] ?? false)); ?>
                    </div>
                    <div class="executive-analysis-cell">
                        <?php $renderExecutiveInsightItems($analysisRow['negative'], 'is-negative', (bool) ($analysisRow['show_empty_negative'] ?? false)); ?>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <?php if (false): ?>
    <div class="executive-list-grid">
        <section class="executive-panel" aria-label="Top 5">
            <header class="executive-panel__header">
                <div>
                    <span class="executive-panel__eyebrow">Ranking</span>
                    <h3 class="executive-panel__title"><?= e((string) ($focus['ranking_title'] ?? 'Desempenho por Regional')) ?> - Top 5</h3>
                </div>
                <?php if ($topFullList !== []): ?>
                    <button class="executive-panel__action" type="button" data-executive-modal-open="ranking-top" data-executive-modal-title="<?= e((string) ($focus['ranking_title'] ?? 'Desempenho por Regional')) ?> - ranking completo">Ver Mais</button>
                <?php endif; ?>
            </header>

            <div class="executive-list">
                <?php if ($topList === []): ?>
                    <div class="executive-empty">Sem dados disponiveis.</div>
                <?php else: ?>
                    <?php foreach ($topList as $item): ?>
                        <?php $percent = (float) ($item['p_mens'] ?? 0.0); ?>
                        <article class="executive-list-item <?= e($resolvePerformanceToneClass($percent)) ?>">
                            <div class="executive-list-item__head">
                                <strong><?= e(prime_label((string) ($item['display_label'] ?? ''))) ?></strong>
                                <span><?= e($formatPercent($percent)) ?></span>
                            </div>
                            <div class="executive-list-item__meta"><?= e($formatPoints((float) ($item['real_mens'] ?? 0.0))) ?> / <?= e($formatPoints((float) ($item['meta_mens'] ?? 0.0))) ?></div>
                            <div class="executive-list-item__meter" data-executive-meter><span style="--target-width: <?= e(number_format(max(6.0, min(100.0, $percent)), 2, '.', '')) ?>%;"></span></div>
                        </article>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </section>

        <section class="executive-panel" aria-label="Bottom 5">
            <header class="executive-panel__header">
                <div>
                    <span class="executive-panel__eyebrow">Ranking</span>
                    <h3 class="executive-panel__title"><?= e((string) ($focus['ranking_title'] ?? 'Desempenho por Regional')) ?> - Bottom 5</h3>
                </div>
                <?php if ($bottomFullList !== []): ?>
                    <button class="executive-panel__action" type="button" data-executive-modal-open="ranking-bottom" data-executive-modal-title="<?= e((string) ($focus['ranking_title'] ?? 'Desempenho por Regional')) ?> - bottom completo">Ver Mais</button>
                <?php endif; ?>
            </header>

            <div class="executive-list">
                <?php if ($bottomList === []): ?>
                    <div class="executive-empty">Sem dados disponiveis.</div>
                <?php else: ?>
                    <?php foreach ($bottomList as $item): ?>
                        <?php $percent = (float) ($item['p_mens'] ?? 0.0); ?>
                        <article class="executive-list-item is-far">
                            <div class="executive-list-item__head">
                                <strong><?= e(prime_label((string) ($item['display_label'] ?? ''))) ?></strong>
                                <span><?= e($formatPercent($percent)) ?></span>
                            </div>
                            <div class="executive-list-item__meta"><?= e($formatPoints((float) ($item['real_mens'] ?? 0.0))) ?> / <?= e($formatPoints((float) ($item['meta_mens'] ?? 0.0))) ?></div>
                            <div class="executive-list-item__meter" data-executive-meter><span style="--target-width: <?= e(number_format(max(6.0, min(100.0, $percent)), 2, '.', '')) ?>%;"></span></div>
                        </article>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </section>
    </div>

    <?php endif; ?>

    <div class="executive-status-grid">
        <?php foreach ($statusCards as $statusCard): ?>
            <?php $statusItems = (array) ($status[$statusCard['key']] ?? []); ?>
            <section class="executive-panel" aria-label="<?= e($statusCard['title']) ?>">
                <header class="executive-panel__header">
                    <div>
                        <span class="executive-panel__eyebrow"><?= e($statusTitle) ?></span>
                        <h3 class="executive-panel__title"><?= e($statusCard['title']) ?></h3>
                    </div>
                    <?php if (($statusFullLists[$statusCard['key']] ?? []) !== []): ?>
                        <button class="executive-panel__action" type="button" data-executive-modal-open="<?= e('status-' . (string) ($statusCard['key'] ?? '')) ?>" data-executive-modal-title="<?= e($statusTitle . ' - ' . (string) ($statusCard['title'] ?? '')) ?>">Ver Mais</button>
                    <?php endif; ?>
                </header>

                <div class="executive-list executive-list--compact">
                    <?php if ($statusItems === []): ?>
                        <div class="executive-empty">Sem dados disponiveis.</div>
                    <?php else: ?>
                        <?php foreach ($statusItems as $item): ?>
                            <?php $percent = (float) ($item['p_mens'] ?? 0.0); ?>
                            <article class="executive-list-item <?= e($statusCard['tone']) ?>">
                                <div class="executive-list-item__head">
                                    <strong><?= e(prime_label((string) ($item['display_label'] ?? ''))) ?></strong>
                                    <?php if ($statusCard['key'] === 'longe'): ?>
                                        <span>-<?= e($formatPoints((float) ($item['deficit'] ?? 0.0))) ?></span>
                                    <?php else: ?>
                                        <span><?= e($formatPercent($percent)) ?></span>
                                    <?php endif; ?>
                                </div>
                                <div class="executive-list-item__meta"><?= e($formatPoints((float) ($item['real_mens'] ?? 0.0))) ?> / <?= e($formatPoints((float) ($item['meta_mens'] ?? 0.0))) ?></div>
                                <div class="executive-list-item__meter" data-executive-meter><span style="--target-width: <?= e(number_format(max(6.0, min(100.0, $percent)), 2, '.', '')) ?>%;"></span></div>
                            </article>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </section>
        <?php endforeach; ?>
    </div>

    <section class="executive-panel executive-panel--heatmap" data-executive-heatmap data-default-mode="<?= e($heatmapDefaultMode) ?>">
        <header class="executive-panel__header executive-panel__header--heatmap">
            <div>
                <span class="executive-panel__eyebrow">Heatmaps</span>
                <h3 class="executive-panel__title">Leitura de secoes e variacao de meta</h3>
            </div>

            <div class="executive-switch">
                <button class="executive-switch__button<?= $heatmapDefaultMode === 'secoes' ? ' is-active' : '' ?>" type="button" data-executive-heatmap-button="secoes" aria-pressed="<?= $heatmapDefaultMode === 'secoes' ? 'true' : 'false' ?>">Secoes</button>
                <button class="executive-switch__button<?= $heatmapDefaultMode === 'meta' ? ' is-active' : '' ?>" type="button" data-executive-heatmap-button="meta" aria-pressed="<?= $heatmapDefaultMode === 'meta' ? 'true' : 'false' ?>">Meta</button>
            </div>
        </header>

        <div class="executive-heatmap-pane" data-executive-heatmap-pane="secoes"<?= $heatmapDefaultMode === 'secoes' ? '' : ' hidden' ?>>
            <div class="executive-heatmap-pane__title"><?= e((string) ($sectionsHeatmap['title'] ?? 'Heatmap - Secoes')) ?></div>
            <?php if ($sectionRows === [] || $sectionColumns === []): ?>
                <div class="executive-empty">Nao ha dados suficientes para montar o heatmap de secoes neste recorte.</div>
            <?php else: ?>
                <div class="executive-heatmap-table-wrap">
                    <table class="executive-heatmap-table executive-heatmap-table--sections">
                        <thead>
                            <tr>
                                <th scope="col"><?= e((string) ($sectionsHeatmap['row_axis_label'] ?? 'GR')) ?> \ <?= e((string) ($sectionsHeatmap['row_axis_sublabel'] ?? 'Familias')) ?></th>
                                <?php foreach ($sectionColumns as $column): ?>
                                    <th scope="col"><?= e((string) ($column['label'] ?? '')) ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($sectionRows as $row): ?>
                                <?php $rowKey = (string) ($row['key'] ?? ''); ?>
                                <tr>
                                    <th scope="row"><?= e(prime_label((string) ($row['label'] ?? $rowKey))) ?></th>
                                    <?php foreach ($sectionColumns as $column): ?>
                                        <?php
                                        $columnKey = (string) ($column['key'] ?? '');
                                        $cell = $sectionData[$rowKey][$columnKey] ?? null;
                                        $percent = $cell !== null ? (float) ($cell['percent'] ?? 0.0) : null;
                                        $absoluteMode = (string) ($cell['absolute_mode'] ?? 'none');
                                        $realAbsolute = $cell !== null && array_key_exists('real', $cell) && $cell['real'] !== null ? (float) $cell['real'] : null;
                                        $metaAbsolute = $cell !== null && array_key_exists('meta', $cell) && $cell['meta'] !== null ? (float) $cell['meta'] : null;
                                        ?>
                                        <td>
                                            <div class="executive-heatmap-cell <?= e($resolvePerformanceToneClass($percent)) ?>">
                                                <strong><?= e($percent === null ? '-' : $formatPercent($percent)) ?></strong>
                                                <span>
                                                    <?php if ($cell === null || ($realAbsolute === null && $metaAbsolute === null)): ?>
                                                        -
                                                    <?php else: ?>
                                                        <?= e($formatAbsoluteValue($realAbsolute, $absoluteMode)) ?> / <?= e($formatAbsoluteValue($metaAbsolute, $absoluteMode)) ?>
                                                    <?php endif; ?>
                                                </span>
                                            </div>
                                        </td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>

        <div class="executive-heatmap-pane" data-executive-heatmap-pane="meta"<?= $heatmapDefaultMode === 'meta' ? '' : ' hidden' ?>>
            <div class="executive-heatmap-pane__title"><?= e((string) ($metaHeatmap['title'] ?? 'Heatmap - Variacao da meta (mes a mes)')) ?></div>
            <?php if ($metaRows === [] || $metaMonths === []): ?>
                <div class="executive-empty">Nao ha dados suficientes para montar o heatmap de meta neste recorte.</div>
            <?php else: ?>
                <div class="executive-heatmap-table-wrap">
                    <table class="executive-heatmap-table executive-heatmap-table--meta">
                        <thead>
                            <tr>
                                <th scope="col"><?= e((string) ($metaHeatmap['row_axis_label'] ?? 'Hierarquia')) ?> \ <?= e((string) ($metaHeatmap['row_axis_sublabel'] ?? 'Mes')) ?></th>
                                <?php foreach ($metaMonths as $month): ?>
                                    <th scope="col"><?= e((string) ($month['label'] ?? '')) ?></th>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($metaRows as $row): ?>
                                <?php $rowKey = (string) ($row['key'] ?? ''); ?>
                                <tr>
                                    <th scope="row"><?= e(prime_label((string) ($row['label'] ?? $rowKey))) ?></th>
                                    <?php $previousMetaCell = null; ?>
                                    <?php foreach ($metaMonths as $month): ?>
                                        <?php
                                        $monthKey = (string) ($month['key'] ?? '');
                                        $currentCell = isset($metaData[$rowKey][$monthKey]) && is_array($metaData[$rowKey][$monthKey]) ? $metaData[$rowKey][$monthKey] : null;
                                        $currentMeta = $currentCell !== null && array_key_exists('meta', $currentCell) && $currentCell['meta'] !== null ? (float) $currentCell['meta'] : null;
                                        $currentReal = $currentCell !== null && array_key_exists('real', $currentCell) && $currentCell['real'] !== null ? (float) $currentCell['real'] : null;
                                        $currentMode = (string) ($currentCell['absolute_mode'] ?? 'none');
                                        $previousMeta = $previousMetaCell !== null && array_key_exists('meta', $previousMetaCell) && $previousMetaCell['meta'] !== null ? (float) $previousMetaCell['meta'] : null;
                                        $previousMode = (string) ($previousMetaCell['absolute_mode'] ?? 'none');
                                        $variation = $resolveMetaTone($currentMeta, $previousMeta);
                                        $tooltipLabel = sprintf(
                                            '%s | %s | Variacao da meta: %s | Meta atual: %s | Realizado atual: %s | Meta anterior: %s',
                                            prime_label((string) ($row['label'] ?? $rowKey)),
                                            (string) ($month['full_label'] ?? $month['label'] ?? $monthKey),
                                            (string) ($variation['text'] ?? '-'),
                                            $formatAbsoluteValueDetailed($currentMeta, $currentMode),
                                            $formatAbsoluteValueDetailed($currentReal, $currentMode),
                                            $formatAbsoluteValueDetailed($previousMeta, $previousMode)
                                        );
                                        ?>
                                        <td>
                                            <div class="executive-heatmap-cell executive-heatmap-cell--meta <?= e((string) ($variation['class'] ?? 'is-empty')) ?>" tabindex="0" data-executive-tooltip="<?= e($tooltipLabel) ?>" aria-label="<?= e($tooltipLabel) ?>" data-has-tooltip="true">
                                                <strong><?= e((string) ($variation['text'] ?? '-')) ?></strong>
                                                <span class="executive-heatmap-cell__meta-value">Meta <?= e($formatAbsoluteValue($currentMeta, $currentMode)) ?></span>
                                            </div>
                                        </td>
                                        <?php $previousMetaCell = $currentCell; ?>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php foreach ($executiveExpandedSections as $expandedSection): ?>
        <div class="executive-modal-source" hidden data-executive-modal-source="<?= e((string) ($expandedSection['id'] ?? '')) ?>">
            <div class="executive-modal-list">
                <?php $renderExecutiveExpandedItems((array) ($expandedSection['items'] ?? []), (string) ($expandedSection['tone'] ?? ''), (bool) ($expandedSection['show_deficit'] ?? false)); ?>
            </div>
        </div>
    <?php endforeach; ?>

    <div class="executive-dialog" hidden data-executive-dialog aria-hidden="true">
        <button class="executive-dialog__overlay" type="button" aria-label="Fechar modal" data-executive-dialog-close></button>
        <div class="executive-dialog__panel" role="dialog" aria-modal="true" aria-labelledby="executive-dialog-title">
            <header class="executive-dialog__head">
                <div>
                    <span class="executive-panel__eyebrow">Detalhamento</span>
                    <h3 class="executive-dialog__title" id="executive-dialog-title" data-executive-dialog-title>Visao completa</h3>
                </div>
                <button class="executive-dialog__close" type="button" data-executive-dialog-close>Fechar</button>
            </header>
            <div class="executive-dialog__body" data-executive-dialog-body></div>
        </div>
    </div>
</section>

