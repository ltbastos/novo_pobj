<?php

declare(strict_types=1);

if (($activeTab ?? 'resumo') === 'encantabra') {
    return;
}

$tabItems = [
    'resumo' => ['label' => 'Resumo', 'icon' => 'layout-dashboard'],
    'detalhamento' => ['label' => 'Detalhamento', 'icon' => 'list-tree'],
    'rankings' => ['label' => 'Rankings', 'icon' => 'trophy'],
    'visao-executiva' => ['label' => 'Visão executiva', 'icon' => 'chart-column'],
    'simuladores' => ['label' => 'Simuladores', 'icon' => 'calculator'],
    'campanhas' => ['label' => 'Campanhas', 'icon' => 'megaphone'],
];

$baseTabQuery = [
    'page' => 'pobj-dashboard',
    'periodo' => $selectedPeriodId ?? '',
    'periodo_mes' => $selectedPeriodMonth ?? '',
    'advanced_filters' => $advancedFiltersState ?? 'open',
];

if (($indicatorFocusId ?? '') !== '') {
    $baseTabQuery['indicator_focus'] = $indicatorFocusId;
}

foreach (($summaryFilterValues ?? []) as $filterKey => $filterValue) {
    if ($filterValue !== '') {
        $baseTabQuery[$filterKey] = $filterValue;
    }
}

if (($requestedRankingGroup ?? '') !== '') {
    $baseTabQuery['grupo'] = $requestedRankingGroup;
}

$selectedPeriodMetaLabel = trim((string) ($selectedPeriodMonth !== ''
    ? format_month_year_br($selectedPeriodMonth)
    : ($selectedPeriod['descricao_periodo'] ?? 'Período atual')));
?>
<section class="summary-tabs-section" aria-label="Navegação da tela Resumo">
    <div class="summary-tabs-shell">
        <nav class="summary-tabs" aria-label="Abas do módulo POBJ">
            <?php foreach ($tabItems as $tabId => $tabItem): ?>
                <?php $tabQuery = array_merge($baseTabQuery, ['tab' => $tabId]); ?>
                <a class="summary-tabs__item<?= $activeTab === $tabId ? ' is-active' : '' ?>" href="<?= e(app_url($tabQuery)) ?>" data-preserve-filters-state>
                    <span class="summary-tabs__icon" aria-hidden="true"><i data-lucide="<?= e($tabItem['icon']) ?>"></i></span>
                    <span class="summary-tabs__label"><?= e($tabItem['label']) ?></span>
                </a>
            <?php endforeach; ?>
        </nav>

        <div class="summary-tabs__meta">
            <span class="summary-tabs__period-label">
                <span class="summary-tabs__period-copy">Per&iacute;odo: <strong><?= e($selectedPeriodMetaLabel) ?></strong></span>
            </span>
        </div>
    </div>
</section>
