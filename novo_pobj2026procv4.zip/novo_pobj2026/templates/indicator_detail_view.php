<?php

declare(strict_types=1);

if (($indicatorFocusId ?? '') === '') {
    return;
}

$indicatorDetailIndicator = is_array($indicatorDetailData['indicator'] ?? null) ? $indicatorDetailData['indicator'] : [];

if ($indicatorDetailIndicator === []) {
    return;
}

$indicatorDetailSummary = is_array($indicatorDetailData['summary'] ?? null) ? $indicatorDetailData['summary'] : [];
$indicatorDetailTrend = array_values(array_slice((array) ($indicatorDetailData['trend'] ?? []), -3));
$indicatorDetailInsights = is_array($indicatorDetailData['insights'] ?? null)
    ? $indicatorDetailData['insights']
    : ['mode' => 'hierarchy', 'label' => '', 'title' => '', 'top' => [], 'bottom' => []];
$indicatorDetailTransactions = array_values((array) ($indicatorDetailData['transactions'] ?? []));
$indicatorDetailAnalyticAvailable = (bool) ($indicatorDetailData['analytic_available'] ?? ($indicatorDetailTransactions !== []));
$indicatorDetailAnalyticMessage = trim((string) ($indicatorDetailData['analytic_message'] ?? ''));
$indicatorDetailPagination = is_array($indicatorDetailData['analytic_pagination'] ?? null)
    ? $indicatorDetailData['analytic_pagination']
    : ['page' => 1, 'per_page' => 20, 'total_rows' => 0, 'total_pages' => 1, 'from' => 0, 'to' => 0];
$indicatorMetricType = strtoupper((string) ($indicatorDetailIndicator['id_tipo_indicador'] ?? 'VALOR'));
$indicatorDetailTopDrivers = array_values((array) ($indicatorDetailInsights['top'] ?? []));
$indicatorDetailBottomDrivers = array_values((array) ($indicatorDetailInsights['bottom'] ?? []));
$indicatorDetailTransactionsTotal = (int) ($indicatorDetailSummary['transactions_total'] ?? count($indicatorDetailTransactions));
$indicatorDetailTransactionsShown = count($indicatorDetailTransactions);
$indicatorDetailCurrentPage = max(1, (int) ($indicatorDetailPagination['page'] ?? 1));
$indicatorDetailTotalPages = max(1, (int) ($indicatorDetailPagination['total_pages'] ?? 1));
$indicatorDetailPageFrom = (int) ($indicatorDetailPagination['from'] ?? 0);
$indicatorDetailPageTo = (int) ($indicatorDetailPagination['to'] ?? 0);
$indicatorDetailIndicatorName = prime_label((string) ($indicatorDetailIndicator['nome_indicador'] ?? 'Produto nao informado'));
$indicatorDetailHasDiscardedRows = false;

$indicatorDetailCellValue = static function ($value, string $fallback = '-'): string {
    $value = trim((string) $value);

    return $value !== '' ? $value : $fallback;
};

$indicatorDetailResolveProductName = static function (array $transactionRow) use ($indicatorDetailIndicatorName, $indicatorDetailCellValue): string {
    $productName = prime_label((string) ($transactionRow['nome_produto'] ?? ''));

    if ($productName === '' || preg_match('/^[a-z0-9_]+$/i', $productName) === 1) {
        return $indicatorDetailCellValue($indicatorDetailIndicatorName, 'Produto nao informado');
    }

    return $indicatorDetailCellValue($productName, 'Produto nao informado');
};

foreach ($indicatorDetailTransactions as $indicatorDetailTransactionRow) {
    if ((bool) ($indicatorDetailTransactionRow['desconsiderar_producao'] ?? false)) {
        $indicatorDetailHasDiscardedRows = true;
        break;
    }
}

$findOptionLabel = static function (array $options, string $value): string {
    foreach ($options as $option) {
        if ((string) ($option['value'] ?? '') === $value) {
            return (string) ($option['label'] ?? $value);
        }
    }

    return $value;
};

$indicatorDetailCloseQuery = [
    'page' => 'pobj-dashboard',
    'periodo' => $selectedPeriodId ?? '',
    'periodo_mes' => $selectedPeriodMonth ?? '',
    'tab' => $activeTab ?? 'resumo',
    'advanced_filters' => $advancedFiltersState ?? 'open',
];

foreach (($summaryFilterValues ?? []) as $filterKey => $filterValue) {
    if (!is_string($filterValue) || $filterValue === '') {
        continue;
    }

    $indicatorDetailCloseQuery[$filterKey] = $filterValue;
}

if (($activeTab ?? 'resumo') === 'rankings' && ($requestedRankingGroup ?? '') !== '') {
    $indicatorDetailCloseQuery['grupo'] = $requestedRankingGroup;
}

$indicatorDetailCloseUrl = app_url($indicatorDetailCloseQuery);
$indicatorDetailPageBaseQuery = array_merge($indicatorDetailCloseQuery, [
    'indicator_focus' => (string) ($indicatorDetailIndicator['id_indicador'] ?? $indicatorFocusId ?? ''),
]);
$indicatorDetailPageWindowStart = max(1, $indicatorDetailCurrentPage - 2);
$indicatorDetailPageWindowEnd = min($indicatorDetailTotalPages, $indicatorDetailPageWindowStart + 4);
$indicatorDetailPageWindowStart = max(1, $indicatorDetailPageWindowEnd - 4);
$indicatorDetailPercent = (float) ($indicatorDetailSummary['percentual'] ?? 0.0);
$indicatorDetailHeroTone = $indicatorDetailPercent >= 100.0
    ? 'is-ok'
    : ($indicatorDetailPercent >= 80.0 ? 'is-warn' : 'is-risk');
$indicatorDetailScopeLabel = prime_label((string) ($indicatorDetailInsights['label'] ?? 'Recorte atual'));
$indicatorDetailDriversTitle = trim((string) ($indicatorDetailInsights['title'] ?? 'Quem puxa o indicador neste recorte'));
$indicatorDetailDriversCopy = sprintf(
    'Recorte atual de %s, ja filtrado pela hierarquia e pelo periodo selecionados.',
    $indicatorDetailScopeLabel !== '' ? $indicatorDetailScopeLabel : 'unidades'
);

$indicatorChartWidth = 360;
$indicatorChartHeight = 196;
$indicatorChartPaddingLeft = 22;
$indicatorChartPaddingRight = 16;
$indicatorChartPaddingTop = 18;
$indicatorChartPaddingBottom = 34;
$indicatorChartInnerWidth = $indicatorChartWidth - $indicatorChartPaddingLeft - $indicatorChartPaddingRight;
$indicatorChartInnerHeight = $indicatorChartHeight - $indicatorChartPaddingTop - $indicatorChartPaddingBottom;
$indicatorChartMax = 100.0;

foreach ($indicatorDetailTrend as $trendRow) {
    $indicatorChartMax = max(
        $indicatorChartMax,
        (float) (ceil((float) ($trendRow['percentual'] ?? 0.0) / 10) * 10)
    );
}

$indicatorChartMax = min(140.0, max(100.0, $indicatorChartMax));
$indicatorChartPoints = [];

foreach ($indicatorDetailTrend as $trendIndex => $trendRow) {
    $trendCount = count($indicatorDetailTrend);
    $trendPercent = max(0.0, min($indicatorChartMax, (float) ($trendRow['percentual'] ?? 0.0)));
    $trendX = $trendCount <= 1
        ? $indicatorChartPaddingLeft + ($indicatorChartInnerWidth / 2)
        : $indicatorChartPaddingLeft + (($indicatorChartInnerWidth / max(1, $trendCount - 1)) * $trendIndex);
    $trendY = $indicatorChartPaddingTop + ($indicatorChartInnerHeight - (($trendPercent / max(1.0, $indicatorChartMax)) * $indicatorChartInnerHeight));

    $indicatorChartPoints[] = [
        'x' => $trendX,
        'y' => $trendY,
        'month_label' => (string) ($trendRow['month_label'] ?? ''),
        'percentual' => (float) ($trendRow['percentual'] ?? 0.0),
        'realizado' => (float) ($trendRow['realizado'] ?? 0.0),
        'meta' => (float) ($trendRow['meta'] ?? 0.0),
    ];
}

$indicatorChartPolyline = '';
$indicatorChartAreaPath = '';

if ($indicatorChartPoints !== []) {
    $indicatorChartPolyline = implode(' ', array_map(static function (array $point): string {
        return number_format((float) ($point['x'] ?? 0.0), 2, '.', '') . ',' . number_format((float) ($point['y'] ?? 0.0), 2, '.', '');
    }, $indicatorChartPoints));

    $firstPoint = $indicatorChartPoints[0];
    $lastPoint = $indicatorChartPoints[count($indicatorChartPoints) - 1];
    $indicatorChartAreaPath = 'M ' . number_format((float) ($firstPoint['x'] ?? 0.0), 2, '.', '') . ' ' . ($indicatorChartHeight - $indicatorChartPaddingBottom)
        . ' L ' . implode(' L ', array_map(static function (array $point): string {
            return number_format((float) ($point['x'] ?? 0.0), 2, '.', '') . ' ' . number_format((float) ($point['y'] ?? 0.0), 2, '.', '');
        }, $indicatorChartPoints))
        . ' L ' . number_format((float) ($lastPoint['x'] ?? 0.0), 2, '.', '') . ' ' . ($indicatorChartHeight - $indicatorChartPaddingBottom)
        . ' Z';
}

$indicatorChartGridValues = array_values(array_unique(array_filter([
    0,
    50,
    100,
    (int) $indicatorChartMax,
], static function ($value): bool {
    return is_int($value) || is_float($value);
})));
sort($indicatorChartGridValues);

$indicatorDetailKpis = [
    [
        'label' => 'Meta x realizado',
        'value' => format_metric_readable((float) ($indicatorDetailSummary['realizado'] ?? 0.0), $indicatorMetricType),
        'meta' => 'Meta ' . format_metric_readable((float) ($indicatorDetailSummary['meta'] ?? 0.0), $indicatorMetricType),
    ],
    [
        'label' => 'Pontos',
        'value' => format_points_readable((float) ($indicatorDetailSummary['pontos'] ?? 0.0)) . ' pts',
        'meta' => 'Meta ' . format_points_readable((float) ($indicatorDetailSummary['pontos_meta'] ?? 0.0)) . ' pts',
    ],
    [
        'label' => 'Carteira ativada',
        'value' => format_int_readable((float) ($indicatorDetailSummary['contracts_total'] ?? 0)) . ' contratos',
        'meta' => format_int_readable((float) ($indicatorDetailSummary['clients_total'] ?? 0)) . ' clientes',
    ],
    [
        'label' => 'Volume e variavel',
        'value' => format_metric_readable((float) ($indicatorDetailSummary['transaction_volume'] ?? 0.0), $indicatorMetricType),
        'meta' => 'Variavel ' . format_currency_readable((float) ($indicatorDetailSummary['variavel'] ?? 0.0)),
    ],
];

$renderDriverLine = static function (array $driverRow, string $metricType): string {
    $contracts = (int) ($driverRow['contracts_total'] ?? 0);
    $clients = (int) ($driverRow['clients_total'] ?? 0);

    if ($contracts > 0 || $clients > 0) {
        return format_int_readable((float) $contracts) . ' contratos - ' . format_int_readable((float) $clients) . ' clientes';
    }

    return format_metric_readable((float) ($driverRow['realizado'] ?? 0.0), $metricType)
        . ' / '
        . format_metric_readable((float) ($driverRow['meta'] ?? 0.0), $metricType);
};
?>
<section class="indicator-detail-modal" data-indicator-detail-modal data-close-url="<?= e($indicatorDetailCloseUrl) ?>" aria-labelledby="indicator-detail-modal-title">
    <a class="indicator-detail-modal__backdrop" href="<?= e($indicatorDetailCloseUrl) ?>" data-no-loading aria-label="Fechar detalhe do indicador"></a>
    <div class="indicator-detail-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="indicator-detail-modal-title">
        <header class="indicator-detail-modal__header">
            <div>
                <span class="indicator-detail-modal__eyebrow">Detalhe do card</span>
                <h2 class="indicator-detail-modal__title" id="indicator-detail-modal-title"><?= e(prime_label((string) ($indicatorDetailIndicator['nome_indicador'] ?? 'Indicador'))) ?></h2>
                <p class="indicator-detail-modal__copy">
                    <?= e(prime_label((string) ($indicatorDetailIndicator['nome_familia'] ?? 'Familia'))) ?>
                    -
                    <?= e($indicatorMetricType === 'PERCENTUAL' ? 'Percentual' : ($indicatorMetricType === 'QUANTIDADE' ? 'Quantidade' : 'Valor')) ?>.
                    Meta, ritmo e base do recorte atual.
                </p>
            </div>
            <a class="indicator-detail-modal__close" href="<?= e($indicatorDetailCloseUrl) ?>" data-no-loading aria-label="Fechar detalhe do indicador">
                <i data-lucide="x"></i>
                <span>Fechar</span>
            </a>
        </header>

        <section class="indicator-detail <?= e($indicatorDetailHeroTone) ?>" aria-label="Detalhamento do indicador">
            <div class="indicator-detail__kpis">
                <?php foreach ($indicatorDetailKpis as $indicatorKpi): ?>
                    <article class="indicator-detail__kpi indicator-detail__kpi--compact">
                        <span class="indicator-detail__kpi-label"><?= e((string) ($indicatorKpi['label'] ?? 'KPI')) ?></span>
                        <strong class="indicator-detail__kpi-value"><?= e((string) ($indicatorKpi['value'] ?? '0')) ?></strong>
                        <small><?= e((string) ($indicatorKpi['meta'] ?? '')) ?></small>
                    </article>
                <?php endforeach; ?>
            </div>

            <div class="indicator-detail__grid indicator-detail__grid--headline">
                <article class="indicator-detail__panel indicator-detail__panel--chart">
                    <div class="indicator-detail__panel-head">
                        <div>
                            <span class="indicator-detail__panel-eyebrow">Performance</span>
                            <h3 class="indicator-detail__panel-title">Indicador nos ultimos 3 meses</h3>
                            <p class="indicator-detail__panel-copy">Curva mensal do indicador clicado, ja respeitando o recorte hierarquico atual.</p>
                        </div>
                    </div>

                    <?php if ($indicatorDetailTrend === []): ?>
                        <p class="indicator-detail__empty">Sem historico recente para o indicador neste recorte.</p>
                    <?php else: ?>
                        <div class="indicator-detail__chart-shell">
                            <svg class="indicator-detail__chart-svg" viewBox="0 0 <?= e((string) $indicatorChartWidth) ?> <?= e((string) $indicatorChartHeight) ?>" role="img" aria-label="Performance do indicador nos ultimos 3 meses">
                                <defs>
                                    <linearGradient id="indicator-detail-chart-fill" x1="0" x2="0" y1="0" y2="1">
                                        <stop offset="0%" stop-color="rgba(var(--brand-rgb), 0.26)"></stop>
                                        <stop offset="100%" stop-color="rgba(var(--brand-rgb), 0.03)"></stop>
                                    </linearGradient>
                                </defs>
                                <?php foreach ($indicatorChartGridValues as $gridValue): ?>
                                    <?php
                                    $gridY = $indicatorChartPaddingTop + ($indicatorChartInnerHeight - (((float) $gridValue / max(1.0, $indicatorChartMax)) * $indicatorChartInnerHeight));
                                    ?>
                                    <line class="indicator-detail__chart-grid" x1="<?= e((string) $indicatorChartPaddingLeft) ?>" y1="<?= e(number_format($gridY, 2, '.', '')) ?>" x2="<?= e((string) ($indicatorChartWidth - $indicatorChartPaddingRight)) ?>" y2="<?= e(number_format($gridY, 2, '.', '')) ?>"></line>
                                    <text class="indicator-detail__chart-axis" x="<?= e((string) max(0, $indicatorChartPaddingLeft - 8)) ?>" y="<?= e(number_format($gridY - 4, 2, '.', '')) ?>" text-anchor="end"><?= e((string) $gridValue) ?>%</text>
                                <?php endforeach; ?>

                                <?php if ($indicatorChartAreaPath !== ''): ?>
                                    <path class="indicator-detail__chart-area" d="<?= e($indicatorChartAreaPath) ?>"></path>
                                <?php endif; ?>

                                <?php if ($indicatorChartPolyline !== ''): ?>
                                    <polyline class="indicator-detail__chart-line" points="<?= e($indicatorChartPolyline) ?>"></polyline>
                                <?php endif; ?>

                                <?php foreach ($indicatorChartPoints as $chartPoint): ?>
                                    <circle class="indicator-detail__chart-point" cx="<?= e(number_format((float) ($chartPoint['x'] ?? 0.0), 2, '.', '')) ?>" cy="<?= e(number_format((float) ($chartPoint['y'] ?? 0.0), 2, '.', '')) ?>" r="5"></circle>
                                    <text class="indicator-detail__chart-label" x="<?= e(number_format((float) ($chartPoint['x'] ?? 0.0), 2, '.', '')) ?>" y="<?= e((string) ($indicatorChartHeight - 8)) ?>" text-anchor="middle"><?= e((string) ($chartPoint['month_label'] ?? '')) ?></text>
                                <?php endforeach; ?>
                            </svg>

                            <div class="indicator-detail__chart-metrics">
                                <?php foreach ($indicatorChartPoints as $chartPoint): ?>
                                    <article class="indicator-detail__chart-card">
                                        <span><?= e((string) ($chartPoint['month_label'] ?? '')) ?></span>
                                        <strong><?= e(number_format((float) ($chartPoint['percentual'] ?? 0.0), 1, ',', '.')) ?>%</strong>
                                        <small><?= e(format_metric_readable((float) ($chartPoint['realizado'] ?? 0.0), $indicatorMetricType)) ?> / <?= e(format_metric_readable((float) ($chartPoint['meta'] ?? 0.0), $indicatorMetricType)) ?></small>
                                    </article>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </article>

                <article class="indicator-detail__panel indicator-detail__panel--drivers">
                    <div class="indicator-detail__panel-head">
                        <div>
                            <span class="indicator-detail__panel-eyebrow">Quem puxa</span>
                            <h3 class="indicator-detail__panel-title">3 melhores e 3 piores do recorte</h3>
                            <p class="indicator-detail__panel-copy"><?= e($indicatorDetailDriversTitle !== '' ? $indicatorDetailDriversTitle : $indicatorDetailDriversCopy) ?></p>
                        </div>
                    </div>

                    <div class="indicator-detail__driver-columns">
                        <div class="indicator-detail__driver-block">
                            <h4 class="indicator-detail__mini-title">Quem puxa para cima</h4>

                            <?php if ($indicatorDetailTopDrivers === []): ?>
                                <p class="indicator-detail__empty">Sem destaques positivos suficientes neste recorte.</p>
                            <?php else: ?>
                                <div class="indicator-detail__driver-list">
                                    <?php foreach ($indicatorDetailTopDrivers as $driverRow): ?>
                                        <?php $driverGap = (float) ($driverRow['gap'] ?? 0.0); ?>
                                        <?php $driverGapLabel = $driverGap >= 0 ? 'Acima ' : 'Falta '; ?>
                                        <article class="indicator-detail__driver-item">
                                            <div class="indicator-detail__driver-copy">
                                                <strong><?= e(prime_label((string) ($driverRow['display_label'] ?? 'Sem referencia'))) ?></strong>
                                                <span><?= e($renderDriverLine($driverRow, $indicatorMetricType)) ?></span>
                                            </div>
                                            <div class="indicator-detail__driver-metrics">
                                                <strong><?= e(number_format((float) ($driverRow['percentual'] ?? 0.0), 1, ',', '.')) ?>%</strong>
                                                <small><?= e($driverGapLabel . format_metric_readable(abs($driverGap), $indicatorMetricType)) ?></small>
                                            </div>
                                        </article>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="indicator-detail__driver-block">
                            <h4 class="indicator-detail__mini-title">Quem puxa para baixo</h4>

                            <?php if ($indicatorDetailBottomDrivers === []): ?>
                                <p class="indicator-detail__empty">Sem pressoes negativas relevantes neste recorte.</p>
                            <?php else: ?>
                                <div class="indicator-detail__driver-list">
                                    <?php foreach ($indicatorDetailBottomDrivers as $driverRow): ?>
                                        <?php $driverGap = (float) ($driverRow['gap'] ?? 0.0); ?>
                                        <?php $driverGapLabel = $driverGap >= 0 ? 'Acima ' : 'Falta '; ?>
                                        <article class="indicator-detail__driver-item is-risk">
                                            <div class="indicator-detail__driver-copy">
                                                <strong><?= e(prime_label((string) ($driverRow['display_label'] ?? 'Sem referencia'))) ?></strong>
                                                <span><?= e($renderDriverLine($driverRow, $indicatorMetricType)) ?></span>
                                            </div>
                                            <div class="indicator-detail__driver-metrics">
                                                <strong><?= e(number_format((float) ($driverRow['percentual'] ?? 0.0), 1, ',', '.')) ?>%</strong>
                                                <small><?= e($driverGapLabel . format_metric_readable(abs($driverGap), $indicatorMetricType)) ?></small>
                                            </div>
                                        </article>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </article>
            </div>

            <article class="indicator-detail__panel indicator-detail__panel--transactions">
                <div class="indicator-detail__panel-head">
                    <div>
                        <span class="indicator-detail__panel-eyebrow">Analitico</span>
                        <h3 class="indicator-detail__panel-title">Venda a venda do indicador no periodo selecionado</h3>
                        <p class="indicator-detail__panel-copy">
                            <?php if (!$indicatorDetailAnalyticAvailable && $indicatorDetailAnalyticMessage !== ''): ?>
                                <?= e($indicatorDetailAnalyticMessage) ?>
                            <?php else: ?>
                                <?= e(sprintf('Foram encontrados %d eventos do indicador dentro do recorte atual.', $indicatorDetailTransactionsTotal)) ?>
                                <?php if ($indicatorDetailTransactionsTotal > 0): ?>
                                    <?= e(sprintf(' Exibindo de %d a %d.', $indicatorDetailPageFrom, $indicatorDetailPageTo)) ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        </p>
                    </div>
                </div>

                <?php if ($indicatorDetailAnalyticAvailable): ?>
                    <div class="indicator-detail__analytics-meta">
                        <span>Periodo respeitado: <?= e($findOptionLabel((array) ($closedMonthOptions ?? []), (string) ($selectedPeriodMonth ?? ''))) ?></span>
                        <span>Pagina <?= e((string) $indicatorDetailCurrentPage) ?> de <?= e((string) $indicatorDetailTotalPages) ?></span>
                        <span>20 linhas por pagina</span>
                        <?php if ($indicatorDetailHasDiscardedRows): ?>
                            <span class="indicator-detail__analytics-warning">Linhas em vermelho nao entram no realizado do indicador.</span>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php if ($indicatorDetailTransactions === []): ?>
                    <p class="indicator-detail__empty"><?= e($indicatorDetailAnalyticAvailable ? 'Nao ha transacoes detalhadas para o indicador no periodo selecionado.' : ($indicatorDetailAnalyticMessage !== '' ? $indicatorDetailAnalyticMessage : 'Selecione um gerente para ver as vendas do indicador.')) ?></p>
                <?php else: ?>
                    <div class="indicator-detail__table-wrapper">
                        <table class="indicator-detail__table">
                            <thead>
                                <tr>
                                    <th scope="col">Data</th>
                                    <th scope="col">Produto</th>
                                    <th scope="col">Agencia</th>
                                    <th scope="col">Agencia2</th>
                                    <th scope="col">Conta</th>
                                    <th scope="col">Carteira</th>
                                    <th scope="col">Contrato</th>
                                    <th scope="col">Valor financiado</th>
                                    <th scope="col">Realizado</th>
                                    <th scope="col">Realizado2</th>
                                    <th scope="col">Cpf/Cnpj</th>
                                    <th scope="col">Id segmento</th>
                                    <th scope="col">Produto macro</th>
                                    <th scope="col">Vlr orig garantia</th>
                                    <th scope="col">Nr proposta</th>
                                    <th scope="col">Indicador producao</th>
                                    <th scope="col">Juncao final realizado</th>
                                    <th scope="col">Funcional gerente conta</th>
                                    <th scope="col">Gerente negocios</th>
                                    <th scope="col">Juncao BC</th>
                                    <th scope="col">Gerente gestao</th>
                                    <th scope="col">Funcional assistente</th>
                                    <th scope="col">Juncao DR</th>
                                    <th scope="col">Juncao GR</th>
                                    <th scope="col">Juncao final classic</th>
                                    <th scope="col">Juncao GR PA</th>
                                    <th scope="col">Juncao DR PA</th>
                                    <th scope="col">Funcional GA</th>
                                    <th scope="col">Assessor GR</th>
                                    <th scope="col">Assessor DR</th>
                                    <th scope="col">Juncao assistente PA</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($indicatorDetailTransactions as $transactionRow): ?>
                                    <?php
                                    $transactionProductName = $indicatorDetailResolveProductName($transactionRow);
                                    $transactionAgency = $indicatorDetailCellValue($transactionRow['agencia'] ?? '-');
                                    $transactionAgency2 = $indicatorDetailCellValue($transactionRow['agencia_2'] ?? '-');
                                    $transactionConta = $indicatorDetailCellValue($transactionRow['conta'] ?? '-');
                                    $transactionCarteira = $indicatorDetailCellValue($transactionRow['carteira'] ?? '-');
                                    $transactionContrato = $indicatorDetailCellValue($transactionRow['numero_contrato'] ?? '-');
                                    $transactionDocumento = $indicatorDetailCellValue($transactionRow['documento'] ?? '-');
                                    $transactionDate = $indicatorDetailCellValue(format_date_br($transactionRow['data_transacao'] ?? null) ?: 'N/A', 'N/A');
                                    $transactionSegmento = $indicatorDetailCellValue($transactionRow['id_segmento'] ?? '-');
                                    $transactionProdutoMacro = $indicatorDetailCellValue($transactionRow['produto_macro'] ?? '-');
                                    $transactionNrProposta = $indicatorDetailCellValue($transactionRow['nr_proposta'] ?? '-');
                                    $transactionIndicadorProducao = $indicatorDetailCellValue($transactionRow['indicador_producao'] ?? '-');
                                    $transactionJuncaoFinalRealizado = $indicatorDetailCellValue($transactionRow['juncao_final_realizado'] ?? '-');
                                    $transactionFuncionalGerenteConta = $indicatorDetailCellValue($transactionRow['funcional_gerente_conta'] ?? '-');
                                    $transactionGerenteNegocios = $indicatorDetailCellValue(prime_label((string) ($transactionRow['gerente_negocios'] ?? $transactionRow['nome_gerente'] ?? '-')));
                                    $transactionJuncaoBc = $indicatorDetailCellValue($transactionRow['juncao_bc'] ?? '-');
                                    $transactionGerenteGestao = $indicatorDetailCellValue(prime_label((string) ($transactionRow['gerente_gestao'] ?? $transactionRow['nome_gerente_gestao'] ?? '-')));
                                    $transactionFuncionalAssistente = $indicatorDetailCellValue($transactionRow['funcional_assistente'] ?? '-');
                                    $transactionJuncaoDr = $indicatorDetailCellValue($transactionRow['juncao_dr'] ?? '-');
                                    $transactionJuncaoGr = $indicatorDetailCellValue($transactionRow['juncao_gr'] ?? '-');
                                    $transactionJuncaoFinalClassic = $indicatorDetailCellValue($transactionRow['juncao_final_classic'] ?? '-');
                                    $transactionJuncaoGrPa = $indicatorDetailCellValue($transactionRow['juncao_gr_pa'] ?? '-');
                                    $transactionJuncaoDrPa = $indicatorDetailCellValue($transactionRow['juncao_dr_pa'] ?? '-');
                                    $transactionFuncionalGa = $indicatorDetailCellValue($transactionRow['funcional_ga'] ?? '-');
                                    $transactionAssessorGr = $indicatorDetailCellValue(prime_label((string) ($transactionRow['assessor_gr'] ?? '-')));
                                    $transactionAssessorDr = $indicatorDetailCellValue(prime_label((string) ($transactionRow['assessor_dr'] ?? '-')));
                                    $transactionJuncaoAssistentePa = $indicatorDetailCellValue($transactionRow['juncao_assistente_pa'] ?? '-');
                                    ?>
                                    <tr class="<?= !empty($transactionRow['desconsiderar_producao']) ? 'is-discarded' : '' ?>">
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--sm" title="<?= e($transactionDate) ?>"><?= e($transactionDate) ?></span></td>
                                        <td>
                                            <span class="indicator-detail__cell-text indicator-detail__cell-text--xl" title="<?= e($transactionProductName) ?>"><?= e($transactionProductName) ?></span>
                                        </td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--sm" title="<?= e($transactionAgency) ?>"><?= e($transactionAgency) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--sm" title="<?= e($transactionAgency2) ?>"><?= e($transactionAgency2) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--sm" title="<?= e($transactionConta) ?>"><?= e($transactionConta) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--sm" title="<?= e($transactionCarteira) ?>"><?= e($transactionCarteira) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--sm" title="<?= e($transactionContrato) ?>"><?= e($transactionContrato) ?></span></td>
                                        <td><?= e(format_metric((float) ($transactionRow['valor_financiado'] ?? 0.0), 'VALOR')) ?></td>
                                        <td><?= e(format_metric((float) ($transactionRow['valor_realizado'] ?? 0.0), $indicatorMetricType === 'PERCENTUAL' ? 'QUANTIDADE' : $indicatorMetricType)) ?></td>
                                        <td><?= e(format_metric((float) ($transactionRow['valor_realizado_2'] ?? 0.0), $indicatorMetricType === 'PERCENTUAL' ? 'QUANTIDADE' : $indicatorMetricType)) ?></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--md" title="<?= e($transactionDocumento) ?>"><?= e($transactionDocumento) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--sm" title="<?= e($transactionSegmento) ?>"><?= e($transactionSegmento) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--lg" title="<?= e($transactionProdutoMacro) ?>"><?= e($transactionProdutoMacro) ?></span></td>
                                        <td><?= e(format_metric((float) ($transactionRow['valor_origem_garantia'] ?? 0.0), 'VALOR')) ?></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--md" title="<?= e($transactionNrProposta) ?>"><?= e($transactionNrProposta) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--md" title="<?= e($transactionIndicadorProducao) ?>"><?= e($transactionIndicadorProducao) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--md" title="<?= e($transactionJuncaoFinalRealizado) ?>"><?= e($transactionJuncaoFinalRealizado) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--md" title="<?= e($transactionFuncionalGerenteConta) ?>"><?= e($transactionFuncionalGerenteConta) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--lg" title="<?= e($transactionGerenteNegocios) ?>"><?= e($transactionGerenteNegocios) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--sm" title="<?= e($transactionJuncaoBc) ?>"><?= e($transactionJuncaoBc) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--lg" title="<?= e($transactionGerenteGestao) ?>"><?= e($transactionGerenteGestao) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--md" title="<?= e($transactionFuncionalAssistente) ?>"><?= e($transactionFuncionalAssistente) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--sm" title="<?= e($transactionJuncaoDr) ?>"><?= e($transactionJuncaoDr) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--sm" title="<?= e($transactionJuncaoGr) ?>"><?= e($transactionJuncaoGr) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--sm" title="<?= e($transactionJuncaoFinalClassic) ?>"><?= e($transactionJuncaoFinalClassic) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--sm" title="<?= e($transactionJuncaoGrPa) ?>"><?= e($transactionJuncaoGrPa) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--sm" title="<?= e($transactionJuncaoDrPa) ?>"><?= e($transactionJuncaoDrPa) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--md" title="<?= e($transactionFuncionalGa) ?>"><?= e($transactionFuncionalGa) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--lg" title="<?= e($transactionAssessorGr) ?>"><?= e($transactionAssessorGr) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--lg" title="<?= e($transactionAssessorDr) ?>"><?= e($transactionAssessorDr) ?></span></td>
                                        <td><span class="indicator-detail__cell-text indicator-detail__cell-text--md" title="<?= e($transactionJuncaoAssistentePa) ?>"><?= e($transactionJuncaoAssistentePa) ?></span></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                    <?php if ($indicatorDetailTotalPages > 1): ?>
                        <nav class="omega-pagination indicator-detail__pagination" aria-label="Paginacao do analitico do indicador">
                            <span class="omega-pagination__summary">
                                <?= e(sprintf('Mostrando %d-%d de %d linhas', $indicatorDetailPageFrom, $indicatorDetailPageTo, $indicatorDetailTransactionsTotal)) ?>
                            </span>

                            <div class="omega-pagination__nav">
                                <?php
                                $indicatorPrevPageUrl = $indicatorDetailCurrentPage > 1
                                    ? app_url(array_merge($indicatorDetailPageBaseQuery, ['indicator_page' => (string) ($indicatorDetailCurrentPage - 1)]))
                                    : '';
                                $indicatorNextPageUrl = $indicatorDetailCurrentPage < $indicatorDetailTotalPages
                                    ? app_url(array_merge($indicatorDetailPageBaseQuery, ['indicator_page' => (string) ($indicatorDetailCurrentPage + 1)]))
                                    : '';
                                ?>
                                <?php if ($indicatorPrevPageUrl !== ''): ?>
                                    <a class="omega-pagination__button" href="<?= e($indicatorPrevPageUrl) ?>">Anterior</a>
                                <?php else: ?>
                                    <span class="omega-pagination__button is-disabled">Anterior</span>
                                <?php endif; ?>

                                <?php for ($indicatorPageNumber = $indicatorDetailPageWindowStart; $indicatorPageNumber <= $indicatorDetailPageWindowEnd; $indicatorPageNumber++): ?>
                                    <?php if ($indicatorPageNumber === $indicatorDetailCurrentPage): ?>
                                        <span class="omega-pagination__page is-current"><?= e((string) $indicatorPageNumber) ?></span>
                                    <?php else: ?>
                                        <a class="omega-pagination__page" href="<?= e(app_url(array_merge($indicatorDetailPageBaseQuery, ['indicator_page' => (string) $indicatorPageNumber]))) ?>"><?= e((string) $indicatorPageNumber) ?></a>
                                    <?php endif; ?>
                                <?php endfor; ?>

                                <?php if ($indicatorNextPageUrl !== ''): ?>
                                    <a class="omega-pagination__button" href="<?= e($indicatorNextPageUrl) ?>">Proxima</a>
                                <?php else: ?>
                                    <span class="omega-pagination__button is-disabled">Proxima</span>
                                <?php endif; ?>
                            </div>
                        </nav>
                    <?php endif; ?>
                <?php endif; ?>
            </article>
        </section>
    </div>
</section>
