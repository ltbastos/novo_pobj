<?php

declare(strict_types=1);

if (($activeTab ?? 'resumo') !== 'resumo'
    || (($summaryFilterValues['visao_acumulada'] ?? 'MENSAL') === 'ANUAL')
    || (($summaryFilterValues['visao_acumulada'] ?? 'MENSAL') === 'MENSAL_ACUMULADO')
) {
    return;
}
?>
<section class="resumo-mode" data-resumo-mode-root data-default-mode="cards" aria-label="Alternar visao do resumo">
    <div class="resumo-mode__toggle segmented" role="group" aria-label="Alterar visao do resumo">
        <button type="button" class="seg-btn is-active" data-resumo-mode-button data-mode="cards" aria-pressed="true">
            Visao por cards
        </button>
        <button type="button" class="seg-btn" data-resumo-mode-button data-mode="legacy" aria-pressed="false">
            Visao classica
        </button>
    </div>
</section>
