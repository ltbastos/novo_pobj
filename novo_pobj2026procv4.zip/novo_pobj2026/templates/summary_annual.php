<?php

declare(strict_types=1);

if (($activeTab ?? 'resumo') !== 'resumo' || (($summaryFilterValues['visao_acumulada'] ?? 'MENSAL') !== 'ANUAL')) {
    return;
}

$annualRows = $annualPerformanceData['rows'] ?? [];
$annualSummary = $annualPerformanceData['summary'] ?? ['atingiu' => 0, 'quase' => 0, 'distante' => 0];
$annualYear = (int) ($annualPerformanceData['year'] ?? date('Y'));
?>
<section class="annual-view" aria-label="Desempenho anual">
    <header class="annual-view__header">
        <div>
            <span class="annual-view__eyebrow">Visao anual</span>
            <h2 class="annual-view__title">Desempenho mes a mes em <?= e((string) $annualYear) ?></h2>
            <p class="annual-view__copy">Os meses em verde bateram a meta, os em amarelo ficaram proximos e os em vermelho ficaram distantes da meta.</p>
        </div>

        <div class="annual-view__legend" aria-label="Legenda de status">
            <span class="annual-view__legend-item annual-view__legend-item--ok">Atingiu: <?= e((string) ($annualSummary['atingiu'] ?? 0)) ?></span>
            <span class="annual-view__legend-item annual-view__legend-item--warn">Quase: <?= e((string) ($annualSummary['quase'] ?? 0)) ?></span>
            <span class="annual-view__legend-item annual-view__legend-item--danger">Distante: <?= e((string) ($annualSummary['distante'] ?? 0)) ?></span>
        </div>
    </header>

    <div class="annual-view__table-wrapper">
        <table class="annual-view__table">
            <?php if ($annualRows === []): ?>
                <tbody>
                    <tr>
                        <td class="annual-view__empty">Ainda nao ha dados mensais suficientes para a visao anual.</td>
                    </tr>
                </tbody>
            <?php else: ?>
                <thead>
                    <tr>
                        <th scope="col">Leitura</th>
                        <?php foreach ($annualRows as $annualRow): ?>
                            <th scope="col" class="annual-view__month-col"><?= e((string) ($annualRow['month_label'] ?? '')) ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">Atingimento</th>
                        <?php foreach ($annualRows as $annualRow): ?>
                            <?php $percentual = array_key_exists('percentual', $annualRow) ? $annualRow['percentual'] : null; ?>
                            <?php if ($percentual === null): ?>
                                <td class="annual-view__metric-cell">-</td>
                            <?php else: ?>
                                <td class="annual-view__status-cell annual-view__status-cell--<?= e((string) ($annualRow['status'] ?? 'distante')) ?>">
                                    <strong><?= e(number_format((float) $percentual, 1, ',', '.')) ?>%</strong>
                                    <span><?= e((string) ($annualRow['status_label'] ?? 'Nao atingiu')) ?></span>
                                </td>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </tr>
                </tbody>
            <?php endif; ?>
        </table>
    </div>
</section>
