<?php

declare(strict_types=1);

if (($activeTab ?? 'resumo') !== 'resumo' || (($summaryFilterValues['visao_acumulada'] ?? 'MENSAL') !== 'MENSAL_ACUMULADO')) {
    return;
}

$comparison = $dashboardData['comparison'] ?? ['mensal' => ['summary' => [], 'indicators' => []], 'acumulado' => ['summary' => [], 'indicators' => []]];
$mensalData = is_array($comparison['mensal'] ?? null) ? $comparison['mensal'] : ['summary' => [], 'indicators' => []];
$acumuladoData = is_array($comparison['acumulado'] ?? null) ? $comparison['acumulado'] : ['summary' => [], 'indicators' => []];

if (($mensalData['indicators'] ?? []) === [] && ($acumuladoData['indicators'] ?? []) === []) {
    return;
}

$businessSnapshot = $legacyBusinessSnapshot ?? ['total' => 0, 'elapsed' => 0, 'remaining' => 0, 'start' => '', 'end' => '', 'today' => ''];
$periodLabel = format_month_year_br(($selectedPeriodMonth ?? '') !== '' ? (string) $selectedPeriodMonth : (string) ($displayPeriodEnd ?? ''));
$baseDateLabel = format_date_br(($displayPeriodEnd ?? '') !== '' ? (string) $displayPeriodEnd : (string) (($selectedPeriod['dt_fim_periodo'] ?? null) ?? ''));

$calculateComparisonMetrics = static function (array $item, array $snapshot): array {
    $daysTotal = max(0, (int) ($snapshot['total'] ?? 0));
    $daysElapsed = max(0, (int) ($snapshot['elapsed'] ?? 0));
    $daysRemaining = max(0, (int) ($snapshot['remaining'] ?? 0));
    $meta = (float) ($item['meta'] ?? 0.0);
    $realizado = (float) ($item['realizado'] ?? 0.0);
    $gap = max(0.0, $meta - $realizado);
    $forecastPronto = array_key_exists('forecast', $item) ? (float) ($item['forecast'] ?? 0.0) : null;
    $forecast = $forecastPronto !== null
        ? $forecastPronto
        : ($daysElapsed > 0 ? $realizado + (($realizado / $daysElapsed) * $daysRemaining) : $realizado);

    return [
        'referencia_hoje' => array_key_exists('referencia', $item)
            ? (float) ($item['referencia'] ?? 0.0)
            : ($daysTotal > 0 ? ($meta / $daysTotal) * $daysElapsed : 0.0),
        'meta_diaria_necessaria' => array_key_exists('nec_dia', $item)
            ? (float) ($item['nec_dia'] ?? 0.0)
            : ($daysRemaining > 0 ? ($gap / $daysRemaining) : 0.0),
        'projecao' => $forecast,
    ];
};

$groupComparisonIndicators = static function (array $indicatorRows, array $snapshot) use ($calculateComparisonMetrics): array {
    $familyGroups = [];

    foreach ($indicatorRows as $row) {
        $familyLabel = prime_label((string) ($row['nome_familia'] ?? ''));
        $familyKey = $familyLabel !== '' ? $familyLabel : 'Sem familia';
        $row['comparison_metrics'] = $calculateComparisonMetrics($row, $snapshot);

        if (!isset($familyGroups[$familyKey])) {
            $familyGroups[$familyKey] = [
                'label' => $familyKey,
                'items' => [],
                'totals' => [
                    'pontos_atingidos' => 0.0,
                    'pontos_total' => 0.0,
                    'atingimento_total' => 0.0,
                    'atingimento_count' => 0,
                ],
            ];
        }

        $familyGroups[$familyKey]['items'][] = $row;
        $familyGroups[$familyKey]['totals']['pontos_atingidos'] += (float) ($row['pontos'] ?? 0.0);
        $familyGroups[$familyKey]['totals']['pontos_total'] += (float) ($row['pontos_meta'] ?? ($row['peso'] ?? 0.0));
        $familyGroups[$familyKey]['totals']['atingimento_total'] += (float) ($row['percentual_atingimento'] ?? 0.0);
        $familyGroups[$familyKey]['totals']['atingimento_count']++;
    }

    foreach ($familyGroups as &$familyGroup) {
        $count = (int) ($familyGroup['totals']['atingimento_count'] ?? 0);
        $familyGroup['totals']['atingimento_pct'] = $count > 0
            ? (float) ($familyGroup['totals']['atingimento_total'] ?? 0.0) / $count
            : 0.0;
    }
    unset($familyGroup);

    return array_values($familyGroups);
};

$mensalGroups = $groupComparisonIndicators((array) ($mensalData['indicators'] ?? []), $businessSnapshot);
$acumuladoGroups = $groupComparisonIndicators((array) ($acumuladoData['indicators'] ?? []), $businessSnapshot);

$metricVariant = static function (string $metric): string {
    $metric = strtoupper(trim($metric));

    if ($metric === 'PERCENTUAL') {
        return 'perc';
    }

    if ($metric === 'QUANTIDADE') {
        return 'qtd';
    }

    return 'valor';
};

$metricLabel = static function (array $item): string {
    $label = prime_label((string) ($item['ds_metrica'] ?? $item['nome_tipo_indicador'] ?? ''));

    return $label !== '' ? $label : 'Valor';
};

$formatCssPercent = static function (float $percent): string {
    return number_format(max(0, min(100, $percent)), 2, '.', '') . '%';
};

$renderComparisonColumn = static function (string $title, array $dataset, array $familyGroups) use ($metricVariant, $metricLabel, $formatCssPercent, $periodLabel, $baseDateLabel): void {
    $summary = is_array($dataset['summary'] ?? null) ? $dataset['summary'] : [];
    ?>
    <section class="summary-compare__column">
        <header class="summary-compare__hero">
            <div>
                <span class="summary-compare__eyebrow">Indicadores prioritarios do POBJ</span>
                <h3 class="summary-compare__title"><?= e($title) ?> - <?= e($periodLabel) ?></h3>
            </div>
            <div class="summary-compare__base">Base <?= e($baseDateLabel !== '' ? $baseDateLabel : '-') ?></div>
        </header>

        <div class="summary-compare__quick">
            <span class="summary-legacy__chip"><?= e(format_int_readable((float) ($summary['indicadores_total'] ?? 0))) ?> indicadores</span>
            <span class="summary-legacy__chip">Atingidos <strong><?= e(format_int_readable((float) ($summary['indicadores_atingidos'] ?? 0))) ?></strong></span>
            <span class="summary-legacy__chip">Pontos <strong><?= e(format_points_readable((float) ($summary['pontos_realizado'] ?? 0.0))) ?></strong> / <?= e(format_points_readable((float) ($summary['pontos_meta'] ?? 0.0))) ?></span>
        </div>

        <?php if ($familyGroups === []): ?>
            <div class="summary-legacy__section">
                <div class="executive-empty">Sem dados disponiveis para este recorte.</div>
            </div>
        <?php else: ?>
            <div class="summary-compare__sections">
                <?php foreach ($familyGroups as $familyGroup): ?>
                    <?php
                    $averagePercent = (float) ($familyGroup['totals']['atingimento_pct'] ?? 0.0);
                    $pointsTotal = (float) ($familyGroup['totals']['pontos_total'] ?? 0.0);
                    $pointsHit = (float) ($familyGroup['totals']['pontos_atingidos'] ?? 0.0);
                    ?>
                    <section class="summary-legacy__section summary-compare__section">
                        <header class="summary-legacy__head">
                            <div class="summary-legacy__heading">
                                <div class="summary-legacy__title-row">
                                    <span class="summary-legacy__name"><?= e(prime_label((string) ($familyGroup['label'] ?? 'Sem familia'))) ?></span>
                                </div>
                                <div class="summary-legacy__chips">
                                    <span class="summary-legacy__chip"><?= e((string) count((array) ($familyGroup['items'] ?? []))) ?> indicadores</span>
                                    <span class="summary-legacy__chip">Pontos <strong><?= e(format_points_readable($pointsHit)) ?></strong> / <strong><?= e(format_points_readable($pointsTotal)) ?></strong></span>
                                </div>
                            </div>
                            <div class="summary-legacy__stats">
                                <div class="summary-legacy__stat">
                                    <span class="summary-legacy__stat-label">Peso total</span>
                                    <strong class="summary-legacy__stat-value"><?= e(format_points_readable($pointsTotal)) ?></strong>
                                </div>
                                <div class="summary-legacy__stat">
                                    <span class="summary-legacy__stat-label">Atingimento</span>
                                    <strong class="summary-legacy__stat-value"><?= e(number_format($averagePercent, 1, ',', '.')) ?>%</strong>
                                </div>
                            </div>
                        </header>

                        <div class="summary-legacy__table-wrapper">
                            <table class="summary-legacy__table summary-compare__table">
                                <thead>
                                    <tr>
                                        <th scope="col" class="summary-legacy__col--prod">Indicador</th>
                                        <th scope="col" class="summary-legacy__col--peso">Peso</th>
                                        <th scope="col">Metrica</th>
                                        <th scope="col" class="summary-legacy__col--meta">Meta</th>
                                        <th scope="col" class="summary-legacy__col--real">Realizado</th>
                                        <th scope="col" class="summary-legacy__col--pontos">Pontos</th>
                                        <th scope="col" class="summary-legacy__col--ating">Ating.</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ((array) ($familyGroup['items'] ?? []) as $item): ?>
                                        <?php
                                        $metricType = trim((string) ($item['id_tipo_indicador'] ?? 'VALOR'));
                                        $percent = (float) ($item['percentual_atingimento'] ?? 0.0);
                                        $meterClass = $percent >= 100 ? 'is-ok' : ($percent >= 50 ? 'is-warn' : 'is-low');
                                        ?>
                                        <tr class="summary-legacy__row">
                                            <td class="summary-legacy__col--prod">
                                                <div class="summary-legacy__prod-cell">
                                                    <span class="summary-legacy__expand-placeholder" aria-hidden="true"></span>
                                                    <div class="summary-legacy__prod-stack">
                                                        <div class="summary-legacy__prod-name" title="<?= e(prime_label((string) ($item['nome_indicador'] ?? ''))) ?>"><?= e(prime_label((string) ($item['nome_indicador'] ?? ''))) ?></div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="summary-legacy__col--peso"><?= e(format_points_readable((float) ($item['peso'] ?? 0.0))) ?></td>
                                            <td>
                                                <span class="summary-legacy__metric summary-legacy__metric--<?= e($metricVariant($metricType)) ?>">
                                                    <?= e($metricLabel($item)) ?>
                                                </span>
                                            </td>
                                            <td class="summary-legacy__col--meta"><?= e(format_metric_readable((float) ($item['meta'] ?? 0.0), $metricType)) ?></td>
                                            <td class="summary-legacy__col--real"><?= e(format_metric_readable((float) ($item['realizado'] ?? 0.0), $metricType)) ?></td>
                                            <td class="summary-legacy__col--pontos"><?= e(format_points_readable((float) ($item['pontos'] ?? 0.0))) ?> pts</td>
                                            <td class="summary-legacy__col--ating">
                                                <div class="summary-legacy__ating-meter <?= e($meterClass) ?>" style="--fill: <?= e($formatCssPercent($percent)) ?>;" role="progressbar" aria-valuenow="<?= e(number_format(max(0, min(200, $percent)), 1, '.', '')) ?>" aria-valuemin="0" aria-valuemax="200">
                                                    <span class="summary-legacy__ating-fill"></span>
                                                    <span class="summary-legacy__ating-value"><?= e(number_format($percent, 1, ',', '.')) ?>%</span>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </section>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>
    <?php
};
?>
<section class="summary-compare" aria-label="Comparativo mensal e acumulado">
    <?php $renderComparisonColumn('Mensal', $mensalData, $mensalGroups); ?>
    <?php $renderComparisonColumn('Acumulado', $acumuladoData, $acumuladoGroups); ?>
</section>
