<?php

declare(strict_types=1);

if (($activeTab ?? 'resumo') === 'encantabra') {
    return;
}

$visualTheme = is_array($visualTheme ?? null) ? $visualTheme : ['is_prime' => false, 'reference_path' => 'assets/img/prime-reference.svg'];
$visualThemeIsPrime = (bool) ($visualTheme['is_prime'] ?? false);

$filterPlaceholders = [
    'periodo' => 'Selecione...',
    'segmento' => 'Todos',
    'diretoria' => 'Todas',
    'regional' => 'Todas',
    'agencia' => 'Todas',
    'gerente_gestao' => 'Todos',
    'gerente' => 'Todos',
    'familia' => 'Selecione...',
    'indicadores' => 'Selecione...',
    'subindicador' => 'Selecione...',
    'status_indicadores' => 'Todos',
    'visao_acumulada' => 'Mensal',
];

$summaryFilterStates = is_array($summaryFilterStates ?? null) ? $summaryFilterStates : [];
$resolveFilterState = static function (string $field, string $defaultPlaceholder) use ($summaryFilterStates): array {
    $state = is_array($summaryFilterStates[$field] ?? null) ? $summaryFilterStates[$field] : [];

    return [
        'enabled' => array_key_exists('enabled', $state) ? (bool) $state['enabled'] : true,
        'placeholder' => trim((string) ($state['placeholder'] ?? '')) !== ''
            ? (string) $state['placeholder']
            : $defaultPlaceholder,
    ];
};

$renderOptions = static function (array $options, ?string $selectedValue, string $placeholderLabel, string $placeholderValue = ''): void {
    echo '<option value="' . e($placeholderValue) . '">' . e(prime_label($placeholderLabel)) . '</option>';

    foreach ($options as $option) {
        $value = (string) ($option['value'] ?? '');
        $label = (string) ($option['label'] ?? '');

        if ($value === '' || $label === '') {
            continue;
        }

        echo '<option value="' . e($value) . '"' . selected_attr($value, $selectedValue) . '>' . e(prime_label($label)) . '</option>';
    }
};

$advancedFiltersExpanded = ($advancedFiltersState ?? 'open') !== 'closed';
$periodOptions = is_array($closedMonthOptions ?? null) ? $closedMonthOptions : [];
$periodPlaceholder = $periodOptions === [] ? 'Nenhum mes fechado' : $filterPlaceholders['periodo'];
?>
<section class="summary-filters-section" aria-label="Filtros da tela Resumo">
    <?php
    $clearFiltersQuery = [
        'page' => 'pobj-dashboard',
        'periodo' => $selectedPeriodId ?? '',
        'periodo_mes' => $selectedPeriodMonth ?? '',
        'tab' => $activeTab ?? 'resumo',
        'advanced_filters' => $advancedFiltersExpanded ? 'open' : 'closed',
    ];

    if (($indicatorFocusId ?? '') !== '') {
        $clearFiltersQuery['indicator_focus'] = $indicatorFocusId;
    }

    $filtersFormActionQuery = [
        'page' => 'pobj-dashboard',
        'tab' => $activeTab ?? 'resumo',
    ];

    if (($indicatorFocusId ?? '') !== '') {
        $filtersFormActionQuery['indicator_focus'] = $indicatorFocusId;
    }

    if (($activeTab ?? 'resumo') === 'rankings' && ($requestedRankingGroup ?? '') !== '') {
        $filtersFormActionQuery['grupo'] = $requestedRankingGroup;
    }

    $clearFiltersUrl = app_url($clearFiltersQuery);
    ?>
    <div class="filters-card">
        <header class="filters-card__header">
            <div>
                <div class="filters-card__title-row">
                    <h1 class="filters-card__title">POBJ Produ&ccedil;&otilde;es</h1>
                    <?php if ($visualThemeIsPrime): ?>
                        <span class="filters-card__prime-badge">Prime</span>
                    <?php endif; ?>
                </div>
                <?php if (!$visualThemeIsPrime): ?>
                    <p class="filters-card__subtitle">Leitura r&aacute;pida de performance e indicadores do per&iacute;odo.</p>
                <?php endif; ?>
            </div>
        </header>

        <form class="filters-form" method="get" action="<?= e(app_url($filtersFormActionQuery)) ?>">

            <div class="filters-grid filters-grid--top">
                <div class="filter-field">
                    <label class="filter-field__label" for="filter-segmento">Segmento</label>
                    <?php $segmentoState = $resolveFilterState('segmento', $filterPlaceholders['segmento']); ?>
                    <select id="filter-segmento" class="filter-field__control" name="segmento" data-filter-cascade data-enhanced-select="search" data-enhanced-label="Segmento" data-enhanced-placeholder="<?= e($segmentoState['placeholder']) ?>"<?= !$segmentoState['enabled'] ? ' disabled' : '' ?>>
                        <?php $renderOptions($summaryFilterOptions['segmento'] ?? [], $summaryFilterValues['segmento'] ?? '', $segmentoState['placeholder']); ?>
                    </select>
                </div>

                <div class="filter-field">
                    <label class="filter-field__label" for="filter-diretoria">Diretoria</label>
                    <?php $diretoriaState = $resolveFilterState('diretoria', $filterPlaceholders['diretoria']); ?>
                    <select id="filter-diretoria" class="filter-field__control" name="diretoria" data-filter-cascade data-enhanced-select="search" data-enhanced-label="Diretoria" data-enhanced-placeholder="<?= e($diretoriaState['placeholder']) ?>"<?= !$diretoriaState['enabled'] ? ' disabled' : '' ?>>
                        <?php $renderOptions($summaryFilterOptions['diretoria'] ?? [], $summaryFilterValues['diretoria'] ?? '', $diretoriaState['placeholder']); ?>
                    </select>
                </div>

                <div class="filter-field">
                    <label class="filter-field__label" for="filter-regional">Regional</label>
                    <?php $regionalState = $resolveFilterState('regional', $filterPlaceholders['regional']); ?>
                    <select id="filter-regional" class="filter-field__control" name="regional" data-filter-cascade data-enhanced-select="search" data-enhanced-label="Regional" data-enhanced-placeholder="<?= e($regionalState['placeholder']) ?>"<?= !$regionalState['enabled'] ? ' disabled' : '' ?>>
                        <?php $renderOptions($summaryFilterOptions['regional'] ?? [], $summaryFilterValues['regional'] ?? '', $regionalState['placeholder']); ?>
                    </select>
                </div>

                <div class="filters-actions">
                    <button class="filters-button filters-button--primary" type="submit">Filtrar</button>
                    <a class="filters-button filters-button--ghost" href="<?= e($clearFiltersUrl) ?>" data-preserve-filters-state>Limpar filtros</a>
                </div>
            </div>

            <div class="filters-toggle-row">
                <button class="filters-advanced-toggle<?= $advancedFiltersExpanded ? ' is-open' : '' ?>" type="button" aria-expanded="<?= $advancedFiltersExpanded ? 'true' : 'false' ?>" aria-controls="advanced-filters" data-filters-toggle>
                    <?= $advancedFiltersExpanded ? 'Fechar filtros avan&ccedil;ados' : 'Abrir filtros avan&ccedil;ados' ?>
                </button>
            </div>

            <div class="filters-advanced-shell<?= $advancedFiltersExpanded ? '' : ' is-collapsed' ?>" id="advanced-filters" data-filters-shell>
                <div class="filters-advanced" data-filters-advanced>
                    <div class="filters-grid filters-grid--advanced">
                        <div class="filter-field">
                            <label class="filter-field__label" for="filter-agencia">Ag&ecirc;ncia</label>
                            <?php $agenciaState = $resolveFilterState('agencia', $filterPlaceholders['agencia']); ?>
                            <select id="filter-agencia" class="filter-field__control" name="agencia" data-filter-cascade data-enhanced-select="search" data-enhanced-label="Agencia" data-enhanced-placeholder="<?= e($agenciaState['placeholder']) ?>"<?= !$agenciaState['enabled'] ? ' disabled' : '' ?>>
                                <?php $renderOptions($summaryFilterOptions['agencia'] ?? [], $summaryFilterValues['agencia'] ?? '', $agenciaState['placeholder']); ?>
                            </select>
                        </div>

                        <div class="filter-field">
                            <label class="filter-field__label" for="filter-gerente-gestao">Gerente de gest&atilde;o</label>
                            <?php $gerenteGestaoState = $resolveFilterState('gerente_gestao', $filterPlaceholders['gerente_gestao']); ?>
                            <select id="filter-gerente-gestao" class="filter-field__control" name="gerente_gestao" data-filter-cascade data-enhanced-select="search" data-enhanced-label="Gerente de gestao" data-enhanced-placeholder="<?= e($gerenteGestaoState['placeholder']) ?>"<?= !$gerenteGestaoState['enabled'] ? ' disabled' : '' ?>>
                                <?php $renderOptions($summaryFilterOptions['gerente_gestao'] ?? [], $summaryFilterValues['gerente_gestao'] ?? '', $gerenteGestaoState['placeholder']); ?>
                            </select>
                        </div>

                        <div class="filter-field">
                            <label class="filter-field__label" for="filter-gerente">Gerente</label>
                            <?php $gerenteState = $resolveFilterState('gerente', $filterPlaceholders['gerente']); ?>
                            <select id="filter-gerente" class="filter-field__control" name="gerente" data-filter-cascade data-enhanced-select="search" data-enhanced-label="Gerente" data-enhanced-placeholder="<?= e($gerenteState['placeholder']) ?>"<?= !$gerenteState['enabled'] ? ' disabled' : '' ?>>
                                <?php $renderOptions($summaryFilterOptions['gerente'] ?? [], $summaryFilterValues['gerente'] ?? '', $gerenteState['placeholder']); ?>
                            </select>
                        </div>

                        <div class="filter-field">
                            <label class="filter-field__label" for="filter-familia">Fam&iacute;lia</label>
                            <select id="filter-familia" class="filter-field__control" name="familia" data-filter-cascade data-enhanced-select="search" data-enhanced-label="Familia" data-enhanced-placeholder="<?= e($filterPlaceholders['familia']) ?>">
                                <?php $renderOptions($summaryFilterOptions['familia'] ?? [], $summaryFilterValues['familia'] ?? '', $filterPlaceholders['familia']); ?>
                            </select>
                        </div>

                        <div class="filter-field">
                            <label class="filter-field__label" for="filter-indicadores">Indicadores</label>
                            <select id="filter-indicadores" class="filter-field__control" name="indicadores" data-filter-cascade data-enhanced-select="search" data-enhanced-label="Indicadores" data-enhanced-placeholder="<?= e($filterPlaceholders['indicadores']) ?>">
                                <?php $renderOptions($summaryFilterOptions['indicadores'] ?? [], $summaryFilterValues['indicadores'] ?? '', $filterPlaceholders['indicadores']); ?>
                            </select>
                        </div>

                        <div class="filter-field">
                            <label class="filter-field__label" for="filter-subindicador">Subindicador</label>
                            <select id="filter-subindicador" class="filter-field__control" name="subindicador" data-enhanced-select="search" data-enhanced-label="Subindicador" data-enhanced-placeholder="<?= e($filterPlaceholders['subindicador']) ?>">
                                <?php $renderOptions($summaryFilterOptions['subindicador'] ?? [], $summaryFilterValues['subindicador'] ?? '', $filterPlaceholders['subindicador']); ?>
                            </select>
                        </div>

                        <div class="filter-field">
                            <label class="filter-field__label" for="filter-status-indicadores">Status dos indicadores</label>
                            <select id="filter-status-indicadores" class="filter-field__control" name="status_indicadores" data-enhanced-select="basic" data-enhanced-label="Status dos indicadores" data-enhanced-placeholder="<?= e($filterPlaceholders['status_indicadores']) ?>">
                                <?php $renderOptions($summaryFilterOptions['status_indicadores'] ?? [], $summaryFilterValues['status_indicadores'] ?? '', $filterPlaceholders['status_indicadores']); ?>
                            </select>
                        </div>

                        <div class="filter-field">
                            <label class="filter-field__label" for="filter-periodo">Per&iacute;odo</label>
                            <select id="filter-periodo" class="filter-field__control" name="periodo_mes" data-enhanced-select="basic" data-enhanced-label="Periodo" data-enhanced-placeholder="<?= e($periodPlaceholder) ?>" data-autosubmit<?= $periodOptions === [] ? ' disabled' : '' ?>>
                                <?php if ($periodOptions === []): ?>
                                    <option value=""><?= e($periodPlaceholder) ?></option>
                                <?php else: ?>
                                    <?php foreach ($periodOptions as $option): ?>
                                        <option value="<?= e((string) ($option['value'] ?? '')) ?>"<?= selected_attr((string) ($option['value'] ?? ''), $selectedPeriodMonth ?? '') ?>><?= e(prime_label((string) ($option['label'] ?? ''))) ?></option>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </select>
                        </div>

                        <div class="filter-field">
                            <label class="filter-field__label" for="filter-visao-acumulada">Vis&atilde;o</label>
                            <select id="filter-visao-acumulada" class="filter-field__control" name="visao_acumulada" data-enhanced-select="basic" data-enhanced-label="Visao" data-enhanced-placeholder="<?= e($filterPlaceholders['visao_acumulada']) ?>">
                                <?php foreach (($summaryFilterOptions['visao_acumulada'] ?? []) as $option): ?>
                                    <option value="<?= e((string) ($option['value'] ?? '')) ?>"<?= selected_attr((string) ($option['value'] ?? ''), $summaryFilterValues['visao_acumulada'] ?? '') ?>><?= e(prime_label((string) ($option['label'] ?? ''))) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</section>
