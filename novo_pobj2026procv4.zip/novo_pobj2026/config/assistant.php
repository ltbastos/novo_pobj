<?php

declare(strict_types=1);

return [
    // Chave server-side. Nao expor no front.
    'openai_api_key' => (string) getenv('OPENAI_API_KEY'),
    'openai_model' => 'gpt-5-mini',
    'openai_embed_model' => 'text-embedding-3-small',
    'knowledge_base_path' => project_path('base_conhecimento'),
];
