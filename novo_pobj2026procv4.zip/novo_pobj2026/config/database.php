<?php

declare(strict_types=1);

$readDatabaseEnv = static function (string $key, $default = null) {
    $value = getenv($key);

    return $value === false ? $default : $value;
};

return [
    'host' => (string) $readDatabaseEnv('DB_HOST', '127.0.0.1'),
    'port' => (int) $readDatabaseEnv('DB_PORT', 3306),
    'database' => (string) $readDatabaseEnv('DB_NAME', 'novo_pobj'),
    'username' => (string) $readDatabaseEnv('DB_USER', 'root'),
    'password' => $readDatabaseEnv('DB_PASSWORD', null),
    'charset' => (string) $readDatabaseEnv('DB_CHARSET', 'utf8mb4'),
];
