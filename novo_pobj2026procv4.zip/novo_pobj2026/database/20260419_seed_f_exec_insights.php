<?php

declare(strict_types=1);

require dirname(__DIR__) . DIRECTORY_SEPARATOR . 'bootstrap.php';

use App\Database;

$connection = Database::connection();
$createTablePath = __DIR__ . DIRECTORY_SEPARATOR . '20260419_create_f_exec_insights.sql';

if (is_file($createTablePath)) {
    $connection->exec((string) file_get_contents($createTablePath));
}

$tableExists = static function (PDO $pdo, string $tableName): bool {
    $statement = $pdo->prepare(
        'SELECT 1
         FROM information_schema.TABLES
         WHERE TABLE_SCHEMA = DATABASE()
           AND TABLE_NAME = :table_name
         LIMIT 1'
    );
    $statement->execute(['table_name' => $tableName]);

    return (bool) $statement->fetchColumn();
};

$formatPercent = static function (float $value): string {
    return number_format($value, 1, ',', '.') . '%';
};

$formatPointsDiff = static function (float $value): string {
    $prefix = $value >= 0 ? '+' : '-';

    return $prefix . number_format(abs($value), 1, ',', '.') . ' p.p.';
};

$formatCompactNumber = static function (float $value): string {
    $absolute = abs($value);

    if ($absolute >= 1000000) {
        return number_format($value / 1000000, 1, ',', '.') . ' mi';
    }

    if ($absolute >= 1000) {
        return number_format($value / 1000, 0, ',', '.') . ' mil';
    }

    return number_format($value, 0, ',', '.');
};

$formatMonthLabel = static function (string $anomes): string {
    $year = substr($anomes, 0, 4);
    $month = substr($anomes, 4, 2);
    $labels = [
        '01' => 'Janeiro',
        '02' => 'Fevereiro',
        '03' => 'Marco',
        '04' => 'Abril',
        '05' => 'Maio',
        '06' => 'Junho',
        '07' => 'Julho',
        '08' => 'Agosto',
        '09' => 'Setembro',
        '10' => 'Outubro',
        '11' => 'Novembro',
        '12' => 'Dezembro',
    ];

    return ($labels[$month] ?? $month) . '/' . $year;
};

$normalizeLabel = static function (?string $value, string $fallback = ''): string {
    $value = trim((string) $value);

    return $value !== '' ? $value : $fallback;
};

$productLabel = static function (array $row) use ($normalizeLabel): string {
    return $normalizeLabel(
        $row['ds_indicador'] ?? '',
        $normalizeLabel(
            $row['item_ab'] ?? '',
            $normalizeLabel(
                $row['label'] ?? '',
                $normalizeLabel($row['ds_familia'] ?? '', (string) ($row['id_familia'] ?? 'Produto'))
            )
        )
    );
};

$groupRows = static function (array $rows, callable $resolver): array {
    $groups = [];

    foreach ($rows as $row) {
        $identity = $resolver($row);
        $key = trim((string) ($identity['key'] ?? ''));

        if ($key === '') {
            continue;
        }

        if (!isset($groups[$key])) {
            $groups[$key] = [
                'key' => $key,
                'label' => (string) ($identity['label'] ?? $key),
                'meta' => 0.0,
                'realizado' => 0.0,
                'atingimento_sum' => 0.0,
                'atingimento_count' => 0,
            ];
        }

        $groups[$key]['meta'] += (float) ($row['meta'] ?? 0.0);
        $groups[$key]['realizado'] += (float) ($row['realizado'] ?? 0.0);
        $groups[$key]['atingimento_sum'] += (float) ($row['atingimento'] ?? 0.0);
        $groups[$key]['atingimento_count']++;
    }

    foreach ($groups as &$group) {
        $count = max(1, (int) ($group['atingimento_count'] ?? 0));
        $group['atingimento'] = $group['atingimento_sum'] / $count;
    }
    unset($group);

    return array_values($groups);
};

$resolveChildLevel = static function (string $scopeLevel, array $rows): string {
    switch ($scopeLevel) {
        case 'GLOBAL':
            return 'regional';

        case 'SEGMENTO':
            return 'diretoria';

        case 'DIRETORIA':
            return 'regional';

        case 'REGIONAL':
            return 'agencia';

        case 'AGENCIA':
            foreach ($rows as $row) {
                if (trim((string) ($row['gerente_gestao_key'] ?? '')) !== '') {
                    return 'gerente_gestao';
                }
            }

            return 'gerente';

        case 'GERENTE_GESTAO':
            return 'gerente';

        case 'GERENTE':
            return 'produto';

        default:
            return 'regional';
    }
};

$resolveChildIdentity = static function (string $childLevel, array $row) use ($normalizeLabel, $productLabel): array {
    switch ($childLevel) {
        case 'diretoria':
            return [
                'key' => (string) ($row['cod_diretoria'] ?? ''),
                'label' => $normalizeLabel($row['ds_diretoria'] ?? '', (string) ($row['cod_diretoria'] ?? 'Diretoria')),
            ];

        case 'regional':
            return [
                'key' => (string) ($row['cod_regional'] ?? ''),
                'label' => $normalizeLabel($row['ds_regional'] ?? '', (string) ($row['cod_regional'] ?? 'Regional')),
            ];

        case 'agencia':
            return [
                'key' => (string) ($row['cod_agencia'] ?? ''),
                'label' => $normalizeLabel($row['ds_agencia'] ?? '', (string) ($row['cod_agencia'] ?? 'Agencia')),
            ];

        case 'gerente_gestao':
            return [
                'key' => (string) ($row['gerente_gestao_key'] ?? ''),
                'label' => $normalizeLabel($row['gerente_gestao_label'] ?? '', (string) ($row['gerente_gestao_key'] ?? 'Gerente de gestao')),
            ];

        case 'gerente':
            return [
                'key' => (string) ($row['cod_unidade'] ?? ''),
                'label' => $normalizeLabel($row['gerente_label'] ?? '', (string) ($row['cod_unidade'] ?? 'Gerente')),
            ];

        case 'produto':
            $label = $productLabel($row);

            return [
                'key' => $label,
                'label' => $label,
            ];

        default:
            return ['key' => '', 'label' => ''];
    }
};

$resolveIndicatorIdentity = static function (array $row) use ($productLabel): array {
    $label = $productLabel($row);

    return [
        'key' => (string) ($row['id_indicador'] ?? $label),
        'label' => $label,
    ];
};

$buildInsightsForScope = static function (
    string $scopeLevel,
    array $currentRows,
    array $previousRows,
    string $currentAnomes,
    string $previousAnomes
) use (
    $groupRows,
    $resolveChildLevel,
    $resolveChildIdentity,
    $resolveIndicatorIdentity,
    $formatPercent,
    $formatPointsDiff,
    $formatCompactNumber,
    $formatMonthLabel
): array {
    $positive = [];
    $negative = [];
    $currentMonthLabel = $currentAnomes !== '' ? $formatMonthLabel($currentAnomes) : 'mes atual';
    $previousMonthLabel = $previousAnomes !== '' ? $formatMonthLabel($previousAnomes) : 'mes anterior';

    $currentIndicators = $groupRows($currentRows, $resolveIndicatorIdentity);
    $previousIndicators = $groupRows($previousRows, $resolveIndicatorIdentity);
    $previousMap = [];

    foreach ($previousIndicators as $indicatorRow) {
        $previousMap[(string) ($indicatorRow['key'] ?? '')] = $indicatorRow;
    }

    $improvements = [];
    $drops = [];

    foreach ($currentIndicators as $indicatorRow) {
        $indicatorKey = (string) ($indicatorRow['key'] ?? '');

        if ($indicatorKey === '' || !isset($previousMap[$indicatorKey])) {
            continue;
        }

        $previousIndicator = $previousMap[$indicatorKey];
        $delta = (float) ($indicatorRow['atingimento'] ?? 0.0) - (float) ($previousIndicator['atingimento'] ?? 0.0);

        $candidate = [
            'label' => (string) ($indicatorRow['label'] ?? $indicatorKey),
            'delta' => $delta,
            'current' => (float) ($indicatorRow['atingimento'] ?? 0.0),
            'previous' => (float) ($previousIndicator['atingimento'] ?? 0.0),
        ];

        if ($delta > 0) {
            $improvements[] = $candidate;
        } elseif ($delta < 0) {
            $drops[] = $candidate;
        }
    }

    usort($improvements, static function (array $left, array $right): int {
        return ((float) ($right['delta'] ?? 0.0) <=> (float) ($left['delta'] ?? 0.0));
    });
    usort($drops, static function (array $left, array $right): int {
        return ((float) ($left['delta'] ?? 0.0) <=> (float) ($right['delta'] ?? 0.0));
    });

    if ($improvements !== []) {
        $best = $improvements[0];
        $positive[] = [
            'tipo' => 'MELHORA_VS_MES_ANTERIOR',
            'titulo' => 'Voce melhorou ' . $formatPointsDiff((float) ($best['delta'] ?? 0.0)) . ' em ' . (string) ($best['label'] ?? ''),
            'texto' => (string) ($best['label'] ?? '') . ' saiu de ' . $formatPercent((float) ($best['previous'] ?? 0.0)) . ' em ' . $previousMonthLabel . ' para ' . $formatPercent((float) ($best['current'] ?? 0.0)) . ' em ' . $currentMonthLabel . '.',
            'destaque' => $formatPointsDiff((float) ($best['delta'] ?? 0.0)),
            'item_label' => (string) ($best['label'] ?? ''),
        ];
    }

    if ($drops !== []) {
        $worst = $drops[0];
        $negative[] = [
            'tipo' => 'QUEDA_VS_MES_ANTERIOR',
            'titulo' => 'Voce piorou ' . $formatPointsDiff((float) ($worst['delta'] ?? 0.0)) . ' em ' . (string) ($worst['label'] ?? ''),
            'texto' => (string) ($worst['label'] ?? '') . ' caiu de ' . $formatPercent((float) ($worst['previous'] ?? 0.0)) . ' em ' . $previousMonthLabel . ' para ' . $formatPercent((float) ($worst['current'] ?? 0.0)) . ' em ' . $currentMonthLabel . '.',
            'destaque' => $formatPointsDiff((float) ($worst['delta'] ?? 0.0)),
            'item_label' => (string) ($worst['label'] ?? ''),
        ];
    }

    $childLevel = $resolveChildLevel($scopeLevel, $currentRows);
    $childGroups = $groupRows($currentRows, static function (array $row) use ($resolveChildIdentity, $childLevel): array {
        return $resolveChildIdentity($childLevel, $row);
    });

    usort($childGroups, static function (array $left, array $right): int {
        return ((float) ($right['atingimento'] ?? 0.0) <=> (float) ($left['atingimento'] ?? 0.0))
            ?: strcmp((string) ($left['label'] ?? ''), (string) ($right['label'] ?? ''));
    });

    if ($childGroups !== []) {
        $bestChild = $childGroups[0];

        $positive[] = [
            'tipo' => 'MELHOR_DESTAQUE_ATUAL',
            'titulo' => (string) ($bestChild['label'] ?? '') . ' e o melhor destaque do recorte',
            'texto' => 'Hoje este recorte entrega ' . $formatPercent((float) ($bestChild['atingimento'] ?? 0.0)) . ' de atingimento, com realizado de ' . $formatCompactNumber((float) ($bestChild['realizado'] ?? 0.0)) . ' sobre meta de ' . $formatCompactNumber((float) ($bestChild['meta'] ?? 0.0)) . '.',
            'destaque' => $formatPercent((float) ($bestChild['atingimento'] ?? 0.0)),
            'item_label' => (string) ($bestChild['label'] ?? ''),
        ];
    }

    $totalRealizado = 0.0;

    foreach ($childGroups as $childGroup) {
        $totalRealizado += (float) ($childGroup['realizado'] ?? 0.0);
    }

    if ($childGroups !== [] && $totalRealizado > 0.0) {
        $topShare = ((float) ($childGroups[0]['realizado'] ?? 0.0) / $totalRealizado) * 100.0;

        if ($topShare > 0.0) {
            $negative[] = [
                'tipo' => 'CONCENTRACAO_RESULTADO',
                'titulo' => $formatPercent($topShare) . ' do resultado esta concentrado em ' . (string) ($childGroups[0]['label'] ?? ''),
                'texto' => 'O maior peso do recorte esta em ' . (string) ($childGroups[0]['label'] ?? '') . ', com ' . $formatCompactNumber((float) ($childGroups[0]['realizado'] ?? 0.0)) . ' de um total de ' . $formatCompactNumber($totalRealizado) . '.',
                'destaque' => $formatPercent($topShare),
                'item_label' => (string) ($childGroups[0]['label'] ?? ''),
            ];
        }
    }

    if ($childGroups !== [] && count($negative) < 2) {
        $worstChild = $childGroups[count($childGroups) - 1];

        $negative[] = [
            'tipo' => 'PONTO_DE_ATENCAO',
            'titulo' => (string) ($worstChild['label'] ?? '') . ' e o principal ponto de atencao',
            'texto' => 'Neste recorte ele esta com ' . $formatPercent((float) ($worstChild['atingimento'] ?? 0.0)) . ' de atingimento sobre a meta atual.',
            'destaque' => $formatPercent((float) ($worstChild['atingimento'] ?? 0.0)),
            'item_label' => (string) ($worstChild['label'] ?? ''),
        ];
    }

    return [
        'positive' => array_slice($positive, 0, 3),
        'negative' => array_slice($negative, 0, 3),
    ];
};

$fetchSnapshotRows = static function (PDO $pdo, string $tableName) use ($tableExists): array {
    if (!$tableExists($pdo, $tableName)) {
        return [];
    }

    $sql = "SELECT
                CAST(f.`ID_INDICADOR` AS CHAR) AS id_indicador,
                CAST(f.`ID_FAMILIA` AS CHAR) AS id_familia,
                CAST(f.`COD_DIRETORIA` AS CHAR) AS cod_diretoria,
                COALESCE(NULLIF(TRIM(f.`DS_DIRETORIA`), ''), CAST(f.`COD_DIRETORIA` AS CHAR)) AS ds_diretoria,
                CAST(f.`COD_REGIONAL` AS CHAR) AS cod_regional,
                COALESCE(NULLIF(TRIM(f.`DS_REGIONAL`), ''), CAST(f.`COD_REGIONAL` AS CHAR)) AS ds_regional,
                CAST(f.`COD_AGENCIA` AS CHAR) AS cod_agencia,
                COALESCE(NULLIF(TRIM(f.`DS_AGENCIA`), ''), CAST(f.`COD_AGENCIA` AS CHAR)) AS ds_agencia,
                CAST(f.`COD_UNIDADE` AS CHAR) AS cod_unidade,
                COALESCE(NULLIF(TRIM(hg.`nome`), ''), NULLIF(TRIM(f.`DS_UNIDADE`), ''), CAST(f.`COD_UNIDADE` AS CHAR)) AS gerente_label,
                CAST(gg.`funcional_gerente_gestao` AS CHAR) AS gerente_gestao_key,
                COALESCE(NULLIF(TRIM(hgg.`nome`), ''), CAST(gg.`funcional_gerente_gestao` AS CHAR)) AS gerente_gestao_label,
                COALESCE(ds.`segmento`, '') AS segmento_key,
                COALESCE(ds.`nome_segmento`, ds.`segmento`, '') AS segmento_label,
                COALESCE(f.`DS_FAMILIA`, CAST(f.`ID_FAMILIA` AS CHAR)) AS ds_familia,
                COALESCE(f.`DS_INDICADOR`, CAST(f.`ID_INDICADOR` AS CHAR)) AS ds_indicador,
                COALESCE(f.`LABEL`, '') AS label,
                COALESCE(f.`ITEM_AB`, '') AS item_ab,
                COALESCE(f.`VLR_META`, 0) AS meta,
                COALESCE(f.`VLR_PRODUCAO`, 0) AS realizado,
                COALESCE(f.`ATING_FINAL`, f.`ATG_FINAL`, 0) AS atingimento
            FROM `$tableName` f
            LEFT JOIN dHierarquia hg
                ON hg.ativo_sn = 1
               AND CAST(hg.`funcional` AS CHAR) COLLATE utf8mb4_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8mb4_unicode_ci
            LEFT JOIN fGestaoGerente gg
                ON gg.ativo_sn = 1
               AND CAST(gg.`funcional_gerente` AS CHAR) COLLATE utf8mb4_unicode_ci = CAST(f.`COD_UNIDADE` AS CHAR) COLLATE utf8mb4_unicode_ci
            LEFT JOIN dHierarquia hgg
                ON hgg.ativo_sn = 1
               AND CAST(hgg.`funcional` AS CHAR) COLLATE utf8mb4_unicode_ci = CAST(gg.`funcional_gerente_gestao` AS CHAR) COLLATE utf8mb4_unicode_ci
            LEFT JOIN dMesu m
                ON m.ativo_sn = 1
               AND CAST(m.`juncao_ag` AS CHAR) = CAST(f.`COD_AGENCIA` AS CHAR)
            LEFT JOIN dSegmento ds
                ON ds.ativo_sn = 1
               AND ds.`id_segmento` = m.`id_segmento`
            WHERE f.`ativo_sn` = 1";

    return $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) ?: [];
};

$bucketRowsByScope = static function (array $rows): array {
    $buckets = [];

    foreach ($rows as $row) {
        $scopes = [
            ['GLOBAL', 'GLOBAL'],
        ];

        if (trim((string) ($row['segmento_key'] ?? '')) !== '') {
            $scopes[] = ['SEGMENTO', (string) $row['segmento_key']];
        }

        if (trim((string) ($row['cod_diretoria'] ?? '')) !== '') {
            $scopes[] = ['DIRETORIA', (string) $row['cod_diretoria']];
        }

        if (trim((string) ($row['cod_regional'] ?? '')) !== '') {
            $scopes[] = ['REGIONAL', (string) $row['cod_regional']];
        }

        if (trim((string) ($row['cod_agencia'] ?? '')) !== '') {
            $scopes[] = ['AGENCIA', (string) $row['cod_agencia']];
        }

        if (trim((string) ($row['gerente_gestao_key'] ?? '')) !== '') {
            $scopes[] = ['GERENTE_GESTAO', (string) $row['gerente_gestao_key']];
        }

        if (trim((string) ($row['cod_unidade'] ?? '')) !== '') {
            $scopes[] = ['GERENTE', (string) $row['cod_unidade']];
        }

        foreach ($scopes as [$scopeLevel, $scopeKey]) {
            $bucketKey = $scopeLevel . '::' . $scopeKey;
            $buckets[$bucketKey][] = $row;
        }
    }

    return $buckets;
};

$insertStatement = $connection->prepare(
    'INSERT INTO `f_exec_insights`
        (`ANOMES`, `VISAO`, `SCOPE_LEVEL`, `SCOPE_KEY`, `POLARIDADE`, `ORDEM`, `TIPO_INSIGHT`, `TITULO`, `TEXTO`, `DESTAQUE`, `ITEM_LABEL`, `ativo_sn`)
     VALUES
        (:anomes, :visao, :scope_level, :scope_key, :polaridade, :ordem, :tipo_insight, :titulo, :texto, :destaque, :item_label, 1)'
);

$months = ['202601', '202602', '202603', '202604'];
$views = [
    'MENSAL' => 'f_produtividade_mensal_',
    'SEMESTRAL' => 'f_produtividade_semestral_',
    'ACUMULADO' => 'f_acumulado_',
];

$connection->exec("DELETE FROM `f_exec_insights` WHERE `ANOMES` BETWEEN 202601 AND 202604");

foreach ($views as $view => $prefix) {
    foreach ($months as $anomes) {
        $tableName = $prefix . $anomes;

        if (!$tableExists($connection, $tableName)) {
            continue;
        }

        $currentRows = $fetchSnapshotRows($connection, $tableName);

        if ($currentRows === []) {
            continue;
        }

        $previousAnomes = '';
        $previousRows = [];

        try {
            $previousAnomes = (new DateTimeImmutable(substr($anomes, 0, 4) . '-' . substr($anomes, 4, 2) . '-01'))
                ->sub(new DateInterval('P1M'))
                ->format('Ym');
        } catch (Throwable $exception) {
            $previousAnomes = '';
        }

        if ($previousAnomes !== '') {
            $previousTableName = $prefix . $previousAnomes;
            $previousRows = $fetchSnapshotRows($connection, $previousTableName);
        }

        $currentBuckets = $bucketRowsByScope($currentRows);
        $previousBuckets = $bucketRowsByScope($previousRows);

        foreach ($currentBuckets as $bucketKey => $scopeRows) {
            [$scopeLevel, $scopeKey] = array_pad(explode('::', $bucketKey, 2), 2, '');

            if ($scopeLevel === '' || $scopeKey === '') {
                continue;
            }

            $insights = $buildInsightsForScope(
                $scopeLevel,
                $scopeRows,
                $previousBuckets[$bucketKey] ?? [],
                $anomes,
                $previousAnomes
            );

            foreach (['positive' => 'POSITIVO', 'negative' => 'NEGATIVO'] as $sourceKey => $polarity) {
                $rows = array_values((array) ($insights[$sourceKey] ?? []));

                foreach ($rows as $index => $insightRow) {
                    $insertStatement->execute([
                        'anomes' => (int) $anomes,
                        'visao' => $view,
                        'scope_level' => $scopeLevel,
                        'scope_key' => $scopeKey,
                        'polaridade' => $polarity,
                        'ordem' => $index + 1,
                        'tipo_insight' => (string) ($insightRow['tipo'] ?? 'INSIGHT'),
                        'titulo' => (string) ($insightRow['titulo'] ?? ''),
                        'texto' => (string) ($insightRow['texto'] ?? ''),
                        'destaque' => (string) ($insightRow['destaque'] ?? ''),
                        'item_label' => (string) ($insightRow['item_label'] ?? ''),
                    ]);
                }
            }
        }
    }
}

echo "f_exec_insights seeded\n";
