<?php

declare(strict_types=1);

require_once __DIR__ . '/bootstrap.php';

use App\Database;
use App\Services\OmegaDashboardService;
use App\Services\PrimeBrandService;
use App\Services\ProfileSimulationService;

$connection = Database::connection();
$profileService = new ProfileSimulationService($connection);
$omegaService = new OmegaDashboardService($connection);
$brandService = new PrimeBrandService($connection);
$requestMethod = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$requestAction = sanitize_request_token((string) ($_POST['action'] ?? $_GET['action'] ?? ''));
$omegaProfileRedirectKeys = [
    'omega_mode',
    'omega_view',
    'omega_team',
    'omega_search',
    'omega_call_id',
    'omega_requester',
    'omega_department',
    'omega_type',
    'omega_priority',
    'omega_status',
    'omega_opened_from',
    'omega_opened_to',
    'omega_page',
];

if ($requestMethod === 'POST' && $requestAction === 'select_profile') {
    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        http_response_code(419);
        exit('Falha de validacao do formulario de perfil.');
    }

    $selectedFunctional = trim((string) ($_POST['selected_functional'] ?? ''));

    if ($selectedFunctional !== '' && $profileService->profileExists($selectedFunctional)) {
        $_SESSION['selected_profile_functional'] = $selectedFunctional;
    }

    $redirectQuery = [];

    foreach ($omegaProfileRedirectKeys as $queryKey) {
        $queryValue = $_GET[$queryKey] ?? null;

        if (is_array($queryValue)) {
            continue;
        }

        $queryValue = sanitize_redirect_value((string) $queryValue);

        if ($queryValue === '') {
            continue;
        }

        $redirectQuery[$queryKey] = $queryValue;
    }

    redirect_internal('omega.php', $redirectQuery);
}

$profiles = $profileService->listProfiles();
$selectedProfileFunctional = $_SESSION['selected_profile_functional'] ?? ($profiles[0]['funcional'] ?? null);

if ($selectedProfileFunctional !== null) {
    $_SESSION['selected_profile_functional'] = $selectedProfileFunctional;
}

$context = $selectedProfileFunctional !== null ? $profileService->getContext((string) $selectedProfileFunctional) : null;
$visualTheme = $brandService->resolveVisualTheme($context, []);
$themeCode = trim((string) ($visualTheme['code'] ?? 'classic'));
$brandLogoPath = trim((string) ($visualTheme['logo_path'] ?? 'assets/img/logo-bradesco-white.svg'));
$brandLogoAlt = trim((string) ($visualTheme['logo_alt'] ?? 'Bradesco'));

if ($requestMethod === 'POST' && $requestAction === 'omega_manage_team') {
    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        http_response_code(419);
        exit('Falha de validacao da equipe do Omega.');
    }

    $teamCode = strtoupper(trim((string) ($_POST['omega_team_code'] ?? $_GET['omega_team_code'] ?? $_GET['omega_team'] ?? '')));
    $analystFunctional = trim((string) ($_POST['omega_analyst_functional'] ?? ''));
    $operation = trim((string) ($_POST['omega_team_operation'] ?? $_GET['omega_team_operation'] ?? ''));
    $isAddOperation = $operation === 'add';
    $ok = $context !== null && $teamCode !== '' && $analystFunctional !== ''
        ? $omegaService->setTeamAnalystMembership($context, $teamCode, $analystFunctional, $isAddOperation)
        : false;
    $feedbackMessage = $ok
        ? ($isAddOperation ? 'Analista incluído com sucesso na equipe.' : 'Analista removido da equipe com sucesso.')
        : 'Não foi possível atualizar a equipe selecionada.';
    $feedbackTone = $ok ? 'success' : 'error';
    $redirectQuery = [
        'omega_mode' => 'team',
        'omega_team' => $teamCode,
        'omega_team_feedback' => $feedbackMessage,
        'omega_team_feedback_tone' => $feedbackTone,
    ];

    redirect_internal('omega.php', $redirectQuery);
}

if ($requestMethod === 'POST' && $requestAction === 'omega_add_comment') {
    header('Content-Type: application/json; charset=UTF-8');

    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        http_response_code(419);
        echo (string) json_encode([
            'ok' => false,
            'message' => 'Falha de validação do comentário.',
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $callId = max(0, (int) ($_POST['omega_comment_call_id'] ?? 0));
    $commentRole = trim((string) ($_POST['omega_comment_role'] ?? 'user'));
    $commentText = trim((string) ($_POST['omega_comment_text'] ?? ''));
    $authorFunctional = '';

    if ($commentRole === 'analyst') {
        $authorFunctional = trim((string) (($context['profile']['funcional'] ?? $selectedProfileFunctional) ?? ''));
    } else {
        $authorFunctional = trim((string) ($_POST['omega_comment_author_functional'] ?? ''));
    }

    if ($callId <= 0 || $commentText === '') {
        http_response_code(422);
        echo (string) json_encode([
            'ok' => false,
            'message' => 'Informe o comentário antes de enviar.',
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $commentResult = $omegaService->addComment($context ?? [], $callId, $commentRole, $commentText);

    if (!(bool) ($commentResult['ok'] ?? false)) {
        http_response_code(422);
        echo (string) json_encode([
            'ok' => false,
            'message' => (string) ($commentResult['message'] ?? 'Não foi possível salvar o comentário.'),
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    echo (string) json_encode([
        'ok' => true,
        'comment' => (array) ($commentResult['comment'] ?? []),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

if ($requestMethod === 'POST' && $requestAction === 'omega_save_call') {
    header('Content-Type: application/json; charset=UTF-8');

    if (!verify_csrf($_POST['csrf_token'] ?? null)) {
        http_response_code(419);
        echo (string) json_encode([
            'ok' => false,
            'message' => 'Falha de validação do chamado.',
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    if ($context === null) {
        http_response_code(401);
        echo (string) json_encode([
            'ok' => false,
            'message' => 'Selecione um perfil válido antes de salvar o chamado.',
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $omegaSavePayload = [
        'call_id' => max(0, (int) ($_POST['call_id'] ?? 0)),
        'current_view' => trim((string) ($_POST['current_view'] ?? 'my-calls')),
        'title' => trim((string) ($_POST['title'] ?? '')),
        'department' => trim((string) ($_POST['department'] ?? '')),
        'type' => trim((string) ($_POST['type'] ?? '')),
        'queue' => trim((string) ($_POST['queue'] ?? '')),
        'analyst_functional' => trim((string) ($_POST['analyst_functional'] ?? '')),
        'priority' => trim((string) ($_POST['priority'] ?? '')),
        'status_code' => trim((string) ($_POST['status_code'] ?? '')),
        'description' => trim((string) ($_POST['description'] ?? '')),
    ];

    if ($omegaSavePayload['title'] === '' || $omegaSavePayload['description'] === '') {
        http_response_code(422);
        echo (string) json_encode([
            'ok' => false,
            'message' => 'Preencha título e descrição antes de salvar.',
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    $saveResult = $omegaService->saveCall($context, $omegaSavePayload);

    if (!(bool) ($saveResult['ok'] ?? false)) {
        http_response_code(422);
        echo (string) json_encode([
            'ok' => false,
            'message' => (string) ($saveResult['message'] ?? 'Não foi possível salvar o chamado no banco de dados.'),
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    echo (string) json_encode([
        'ok' => true,
        'record' => (array) ($saveResult['record'] ?? []),
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

$omegaRequestedMode = sanitize_request_token((string) ($_GET['omega_mode'] ?? 'list'));
$omegaRequestedTeamCode = sanitize_request_token((string) ($_GET['omega_team'] ?? ''));
$omegaTeamFeedback = trim((string) ($_GET['omega_team_feedback'] ?? ''));
$omegaTeamFeedbackTone = sanitize_request_token((string) ($_GET['omega_team_feedback_tone'] ?? 'neutral'));
$omegaRequestedStatus = $_GET['omega_status'] ?? '';

if (is_array($omegaRequestedStatus)) {
    $omegaRequestedStatus = implode(',', array_map(static function ($value): string {
        return trim((string) $value);
    }, $omegaRequestedStatus));
}

$omegaRequestedFilters = [
    'view' => sanitize_request_token((string) ($_GET['omega_view'] ?? 'my-calls')),
    'search' => trim((string) ($_GET['omega_search'] ?? '')),
    'call_id' => sanitize_request_token((string) ($_GET['omega_call_id'] ?? '')),
    'requester' => trim((string) ($_GET['omega_requester'] ?? '')),
    'department' => trim((string) ($_GET['omega_department'] ?? '')),
    'type' => trim((string) ($_GET['omega_type'] ?? '')),
    'priority' => trim((string) ($_GET['omega_priority'] ?? '')),
    'status' => sanitize_redirect_value((string) $omegaRequestedStatus),
    'opened_from' => sanitize_request_date((string) ($_GET['omega_opened_from'] ?? '')),
    'opened_to' => sanitize_request_date((string) ($_GET['omega_opened_to'] ?? '')),
    'page' => max(1, (int) ($_GET['omega_page'] ?? 1)),
];

$omegaData = $context !== null
    ? $omegaService->getDashboardData($context, $omegaRequestedFilters)
    : [
        'views' => [
            ['id' => 'my-calls', 'label' => 'Meus chamados', 'count' => 0],
        ],
        'permissions' => [
            'is_analyst' => false,
            'is_manager' => false,
            'can_manage_team' => false,
            'can_access_dashboard' => false,
            'can_view_priority' => false,
        ],
        'active_view' => 'my-calls',
        'filters' => [
            'search' => '',
            'call_id' => '',
            'requester' => '',
            'department' => '',
            'type' => '',
            'priority' => '',
            'status' => '',
            'opened_from' => '',
            'opened_to' => '',
            'page' => 1,
        ],
        'status_options' => [],
        'facet_options' => [
            'departments' => [
                ['value' => 'Metas', 'label' => 'Metas'],
                ['value' => 'POBJ', 'label' => 'POBJ'],
            ],
            'types' => [
                ['value' => 'Contestar Meta', 'label' => 'Contestar Meta'],
                ['value' => 'Contestar Realizado', 'label' => 'Contestar Realizado'],
                ['value' => 'Outros', 'label' => 'Outros'],
                ['value' => 'Redistribuir Meta', 'label' => 'Redistribuir Meta'],
            ],
            'priorities' => [],
            'department_type_map' => [
                'POBJ' => [
                    ['value' => 'Contestar Realizado', 'label' => 'Contestar Realizado'],
                    ['value' => 'Outros', 'label' => 'Outros'],
                ],
                'Metas' => [
                    ['value' => 'Contestar Meta', 'label' => 'Contestar Meta'],
                    ['value' => 'Redistribuir Meta', 'label' => 'Redistribuir Meta'],
                ],
            ],
        ],
        'editor_options' => [
            'queues' => [
                ['value' => 'METAS', 'label' => 'Metas', 'department' => 'Metas'],
                ['value' => 'POBJ', 'label' => 'POBJ', 'department' => 'POBJ'],
            ],
            'queue_department_map' => [
                'METAS' => 'Metas',
                'POBJ' => 'POBJ',
            ],
            'queue_analyst_map' => [],
        ],
        'analytics' => [
            'summary' => ['opened_total' => 0, 'closed_total' => 0, 'total_rows' => 0],
            'top_requesters' => [],
            'top_departments' => [],
            'priority_breakdown' => [],
            'type_breakdown' => [],
            'monthly_volume' => [],
        ],
        'table' => ['rows' => [], 'total_rows' => 0, 'current_page' => 1, 'per_page' => 8, 'total_pages' => 1],
    ];

$layoutProfile = $context['profile'] ?? null;
$headerName = $layoutProfile['nome'] ?? 'Usuario';
$headerFirstName = first_name($headerName);
$headerInitials = user_initials($headerName);
$headerFunctional = trim((string) ($layoutProfile['funcional'] ?? $selectedProfileFunctional ?? ''));
$watermarkIdentity = $headerFunctional;

if ($watermarkIdentity === '') {
    $watermarkIdentity = 'Acesso interno monitorado';
}

$omegaViews = array_values((array) ($omegaData['views'] ?? []));
$omegaPermissions = (array) ($omegaData['permissions'] ?? []);
$omegaCanManageTeam = (bool) ($omegaPermissions['can_manage_team'] ?? false);
$omegaCanAccessDashboard = (bool) ($omegaPermissions['can_access_dashboard'] ?? false);
$omegaCanViewPriority = (bool) ($omegaPermissions['can_view_priority'] ?? false);
$omegaAllowedModes = ['list'];

if ($omegaCanAccessDashboard) {
    $omegaAllowedModes[] = 'charts';
}

if ($omegaCanManageTeam) {
    $omegaAllowedModes[] = 'team';
}

$omegaMode = in_array($omegaRequestedMode, $omegaAllowedModes, true) ? $omegaRequestedMode : 'list';
$omegaActiveView = trim((string) ($omegaData['active_view'] ?? 'my-calls'));
$omegaFilters = (array) ($omegaData['filters'] ?? []);
$omegaStatusOptions = array_values((array) ($omegaData['status_options'] ?? []));
$omegaFacetOptions = (array) ($omegaData['facet_options'] ?? ['departments' => [], 'types' => [], 'priorities' => []]);
$omegaAnalytics = (array) ($omegaData['analytics'] ?? []);
$omegaSummaryMetrics = (array) ($omegaAnalytics['summary'] ?? ['opened_total' => 0, 'closed_total' => 0, 'total_rows' => 0]);
$omegaTopRequesters = array_values((array) ($omegaAnalytics['top_requesters'] ?? []));
$omegaTopDepartments = array_values((array) ($omegaAnalytics['top_departments'] ?? []));
$omegaPriorityBreakdown = array_values((array) ($omegaAnalytics['priority_breakdown'] ?? []));
$omegaTypeBreakdown = array_values((array) ($omegaAnalytics['type_breakdown'] ?? []));
$omegaMonthlyVolume = array_values((array) ($omegaAnalytics['monthly_volume'] ?? []));
$omegaDepartmentOptions = array_values((array) ($omegaFacetOptions['departments'] ?? []));
$omegaTypeOptions = array_values((array) ($omegaFacetOptions['types'] ?? []));
$omegaDepartmentTypeMap = (array) ($omegaFacetOptions['department_type_map'] ?? []);
$omegaEditorOptions = (array) ($omegaData['editor_options'] ?? ['queues' => [], 'queue_department_map' => [], 'queue_analyst_map' => []]);
$omegaQueueOptions = array_values((array) ($omegaEditorOptions['queues'] ?? []));
$omegaQueueDepartmentMap = (array) ($omegaEditorOptions['queue_department_map'] ?? []);
$omegaQueueAnalystMap = (array) ($omegaEditorOptions['queue_analyst_map'] ?? []);
$omegaDepartmentTypeMapJson = json_encode($omegaDepartmentTypeMap, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$omegaQueueDepartmentMapJson = json_encode($omegaQueueDepartmentMap, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
$omegaQueueAnalystMapJson = json_encode($omegaQueueAnalystMap, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

if (!is_string($omegaDepartmentTypeMapJson)) {
    $omegaDepartmentTypeMapJson = '{}';
}

if (!is_string($omegaQueueDepartmentMapJson)) {
    $omegaQueueDepartmentMapJson = '{}';
}

if (!is_string($omegaQueueAnalystMapJson)) {
    $omegaQueueAnalystMapJson = '{}';
}

$omegaPriorityOptions = array_values((array) ($omegaFacetOptions['priorities'] ?? []));
$omegaTable = (array) ($omegaData['table'] ?? ['rows' => [], 'total_rows' => 0, 'current_page' => 1, 'per_page' => 8, 'total_pages' => 1]);
$omegaRows = array_values((array) ($omegaTable['rows'] ?? []));
$omegaTotalRows = (int) ($omegaTable['total_rows'] ?? 0);
$omegaCurrentPage = max(1, (int) ($omegaTable['current_page'] ?? 1));
$omegaPerPage = max(1, (int) ($omegaTable['per_page'] ?? 8));
$omegaTotalPages = max(1, (int) ($omegaTable['total_pages'] ?? 1));
$omegaStatusFilterValues = array_values(array_filter(array_map('trim', explode(',', (string) ($omegaFilters['status'] ?? '')))));
$omegaTeamManagement = $omegaCanManageTeam
    ? $omegaService->getTeamManagementData($context ?? [], $omegaRequestedTeamCode)
    : [
        'teams' => [],
        'selected_team' => [],
        'managers' => [],
        'analysts' => [],
        'candidate_analysts' => [],
    ];
$omegaManagedTeams = array_values((array) ($omegaTeamManagement['teams'] ?? []));
$omegaSelectedManagedTeam = (array) ($omegaTeamManagement['selected_team'] ?? []);
$omegaSelectedManagedTeamCode = trim((string) ($omegaSelectedManagedTeam['code'] ?? $omegaRequestedTeamCode));
$omegaManagedTeamManagers = array_values((array) ($omegaTeamManagement['managers'] ?? []));
$omegaManagedTeamAnalysts = array_values((array) ($omegaTeamManagement['analysts'] ?? []));
$omegaManagedTeamCandidates = array_values((array) ($omegaTeamManagement['candidate_analysts'] ?? []));
$omegaHasFilters = false;

foreach (['call_id', 'requester', 'department', 'type', 'priority', 'opened_from', 'opened_to'] as $filterKey) {
    if (trim((string) ($omegaFilters[$filterKey] ?? '')) !== '') {
        $omegaHasFilters = true;
        break;
    }
}

if (!$omegaHasFilters && $omegaStatusFilterValues !== []) {
    $omegaHasFilters = true;
}

$omegaTableStart = $omegaTotalRows > 0 ? (($omegaCurrentPage - 1) * $omegaPerPage) + 1 : 0;
$omegaTableEnd = $omegaRows !== [] ? min($omegaTableStart + count($omegaRows) - 1, $omegaTotalRows) : 0;
$omegaPageTitle = 'Omega';

$buildOmegaDonut = static function (array $items, array $palette): array {
    $total = 0.0;

    foreach ($items as $item) {
        $total += (float) ($item['value'] ?? 0);
    }

    if ($total <= 0.0) {
        return [
            'gradient' => 'conic-gradient(#e8edf5 0deg 360deg)',
            'legend' => [],
        ];
    }

    $start = 0.0;
    $segments = [];
    $legend = [];
    $paletteCount = count($palette);
    $paletteIndex = 0;

    foreach ($items as $item) {
        $value = (float) ($item['value'] ?? 0);

        if ($value <= 0.0) {
            continue;
        }

        $color = $paletteCount > 0 ? $palette[$paletteIndex % $paletteCount] : '#cc092f';
        $angle = ($value / $total) * 360;
        $end = $start + $angle;
        $segments[] = sprintf('%s %.2fdeg %.2fdeg', $color, $start, $end);
        $legend[] = [
            'color' => $color,
            'label' => (string) ($item['label'] ?? 'Sem rótulo'),
            'value' => (int) $value,
            'percentage' => $total > 0 ? round(($value / $total) * 100, 1) : 0.0,
        ];
        $start = $end;
        $paletteIndex++;
    }

    return [
        'gradient' => 'conic-gradient(' . implode(', ', $segments) . ')',
        'legend' => $legend,
    ];
};

$omegaPriorityDonut = $buildOmegaDonut($omegaPriorityBreakdown, ['#cc092f', '#ff8b2d', '#4e9dff', '#8fd2b6', '#a774ff']);
$omegaTypeDonut = $buildOmegaDonut($omegaTypeBreakdown, ['#1d4ed8', '#cc092f', '#f59e0b', '#0f9e79', '#8b5cf6', '#5b6778']);
$omegaMonthlyMax = 0;

foreach ($omegaMonthlyVolume as $monthlyItem) {
    $omegaMonthlyMax = max(
        $omegaMonthlyMax,
        (int) ($monthlyItem['opened'] ?? 0),
        (int) ($monthlyItem['closed'] ?? 0)
    );
}

$omegaMonthlyMax = max(1, $omegaMonthlyMax);
$omegaProfileSwitchQuery = [
    'omega_mode' => $omegaMode,
    'omega_view' => $omegaActiveView,
];

if ($omegaSelectedManagedTeamCode !== '') {
    $omegaProfileSwitchQuery['omega_team'] = $omegaSelectedManagedTeamCode;
}

$omegaBaseQuery = [
    'omega_mode' => $omegaMode,
    'omega_view' => $omegaActiveView,
];

if ($omegaSelectedManagedTeamCode !== '') {
    $omegaBaseQuery['omega_team'] = $omegaSelectedManagedTeamCode;
}

foreach (['omega_search' => 'search', 'omega_call_id' => 'call_id', 'omega_requester' => 'requester', 'omega_department' => 'department', 'omega_type' => 'type', 'omega_priority' => 'priority', 'omega_status' => 'status', 'omega_opened_from' => 'opened_from', 'omega_opened_to' => 'opened_to'] as $queryKey => $filterKey) {
    $value = trim((string) ($omegaFilters[$filterKey] ?? ''));

    if ($value !== '') {
        $omegaBaseQuery[$queryKey] = $value;
    }
}

$buildOmegaUrl = static function (array $extra = []) use ($omegaBaseQuery): string {
    $query = array_merge($omegaBaseQuery, $extra);

    foreach ($query as $key => $value) {
        if (!is_string($value) || trim($value) === '') {
            unset($query[$key]);
        }
    }

    $queryString = http_build_query($query);

    return $queryString === '' ? 'omega.php' : 'omega.php?' . $queryString;
};

$omegaProfileSwitchAction = $buildOmegaUrl(['omega_page' => '1']);
$omegaToolbarSearchAction = $buildOmegaUrl([
    'omega_page' => '1',
    'omega_search' => '',
    'omega_call_id' => '',
    'omega_requester' => '',
    'omega_department' => '',
    'omega_type' => '',
    'omega_priority' => '',
    'omega_status' => '',
    'omega_opened_from' => '',
    'omega_opened_to' => '',
]);
$omegaFilterAction = $buildOmegaUrl([
    'omega_page' => '1',
    'omega_call_id' => '',
    'omega_requester' => '',
    'omega_department' => '',
    'omega_type' => '',
    'omega_priority' => '',
    'omega_status' => '',
    'omega_opened_from' => '',
    'omega_opened_to' => '',
]);

$formatOmegaDate = static function (?string $value): string {
    $value = trim((string) $value);

    if ($value === '') {
        return '—';
    }

    try {
        return (new DateTimeImmutable($value))->format('d/m/Y');
    } catch (Throwable $exception) {
        return $value;
    }
};

$formatOmegaDateTime = static function (?string $value): string {
    $value = trim((string) $value);

    if ($value === '') {
        return '—';
    }

    try {
        return (new DateTimeImmutable($value))->format('d/m/Y, H:i:s');
    } catch (Throwable $exception) {
        return $value;
    }
};

$resolvePriorityTone = static function (string $label): string {
    switch (strtolower(trim($label))) {
        case 'alta':
            return 'is-high';

        case 'baixa':
            return 'is-low';

        case 'média':
        case 'media':
        default:
            return 'is-medium';
    }
};

$omegaViewIcons = [
    'my-calls' => 'inbox',
    'my-work' => 'clipboard-check',
    'team-queue' => 'users',
];
$omegaCurrentViewLabel = 'Meus chamados';

foreach ($omegaViews as $viewItem) {
    if ((string) ($viewItem['id'] ?? '') === $omegaActiveView) {
        $omegaCurrentViewLabel = (string) ($viewItem['label'] ?? $omegaCurrentViewLabel);
        break;
    }
}

$omegaRegisterDefaultTitle = $omegaActiveView === 'my-work' ? 'Ajuste operacional Omega' : 'Novo chamado Omega';
$omegaHeroTitle = $omegaMode === 'charts'
    ? 'Dashboard'
    : ($omegaMode === 'team' ? 'Editar equipe' : $omegaCurrentViewLabel);
$omegaHeroCopy = $omegaMode === 'charts'
    ? 'Leitura executiva do recorte atual com KPIs, rankings e distribuição dos chamados da visão selecionada.'
    : ($omegaMode === 'team'
        ? 'Gestão dos analistas responsáveis por cada departamento sob sua governança.'
        : 'Chamados organizados por visão operacional, com leitura rápida da fila e suporte analítico no mesmo ambiente.');
$omegaSelectedStatusJson = json_encode($omegaStatusFilterValues, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

if (!is_string($omegaSelectedStatusJson)) {
    $omegaSelectedStatusJson = '[]';
}

foreach (['omega_search' => 'search', 'omega_call_id' => 'call_id', 'omega_requester' => 'requester', 'omega_department' => 'department', 'omega_type' => 'type', 'omega_priority' => 'priority', 'omega_status' => 'status', 'omega_opened_from' => 'opened_from', 'omega_opened_to' => 'opened_to'] as $queryKey => $filterKey) {
    $value = trim((string) ($omegaFilters[$filterKey] ?? ''));

    if ($value !== '') {
        $omegaProfileSwitchQuery[$queryKey] = $value;
    }
}

if ($omegaCurrentPage > 1) {
    $omegaProfileSwitchQuery['omega_page'] = (string) $omegaCurrentPage;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($omegaPageTitle) ?></title>
    <link rel="stylesheet" href="assets/css/app.css">
</head>
<body class="omega-body<?= ($visualTheme['is_prime'] ?? false) ? ' theme-prime' : '' ?>" data-visual-theme="<?= e($themeCode) ?>">
    <header class="topbar omega-topbar" role="banner">
        <nav class="topbar__left omega-topbar__left" aria-label="Navegacao principal do Omega">
            <div class="brand brand--static" aria-label="Bradesco">
                <img class="brand__logo" src="<?= e($brandLogoPath) ?>" alt="<?= e($brandLogoAlt) ?>">
            </div>
        </nav>

        <div class="omega-topbar__right">
            <div class="userbox omega-userbox" data-userbox>
                <button class="userbox__trigger omega-userbox__trigger" type="button" aria-haspopup="true" aria-expanded="false" aria-controls="omega-user-menu" aria-label="Menu do usuario: <?= e($headerName) ?>" data-userbox-trigger>
                    <span class="userbox__avatar"><?= e($headerInitials) ?></span>
                    <span class="userbox__identity">
                        <span class="userbox__name"><?= e($headerFirstName) ?></span>
                    </span>
                    <span class="userbox__chevron" aria-hidden="true"></span>
                </button>

                <div class="userbox__menu omega-userbox__menu" id="omega-user-menu" hidden data-userbox-menu>
                    <div class="userbox__menu-header omega-userbox__menu-header">
                        <span class="userbox__menu-title">Usuário logado</span>
                        <strong class="omega-userbox__menu-name"><?= e($headerName) ?></strong>
                        <span class="omega-userbox__menu-meta"><?= e($headerFunctional !== '' ? 'Funcional ' . $headerFunctional : 'Perfil atual') ?></span>
                    </div>

                    <?php if ($profiles !== []): ?>
                        <form class="omega-userbox__profile-form" method="post" action="<?= e($omegaProfileSwitchAction . (strpos($omegaProfileSwitchAction, '?') === false ? '?' : '&') . 'action=select_profile') ?>" aria-label="Selecionar usuario logado no Omega">
                            <?= csrf_field() ?>

                            <label class="omega-userbox__profile-label" for="omega-profile-functional">Trocar usuário</label>
                            <div class="omega-userbox__profile-field">
                                <select id="omega-profile-functional" name="selected_functional" class="omega-userbox__profile-select" data-autosubmit>
                                    <?php foreach ($profiles as $profileItem): ?>
                                        <?php
                                        $profileOptionName = trim((string) ($profileItem['nome'] ?? ''));
                                        $profileOptionLevel = trim((string) ($profileItem['nivel'] ?? ''));
                                        $profileOptionJunction = trim((string) ($profileItem['juncao_principal'] ?? ''));
                                        $profileOptionMeta = $profileOptionLevel;

                                        if ($profileOptionJunction !== '') {
                                            $profileOptionMeta .= ' • ' . $profileOptionJunction;
                                        }

                                        $profileOptionLabel = $profileOptionMeta !== ''
                                            ? $profileOptionName . ' • ' . $profileOptionMeta
                                            : $profileOptionName;
                                        ?>
                                        <option value="<?= e((string) ($profileItem['funcional'] ?? '')) ?>"<?= selected_attr((string) ($profileItem['funcional'] ?? ''), $selectedProfileFunctional ?? null) ?>><?= e(prime_label($profileOptionLabel)) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>

    <div class="omega-layout" data-omega-layout data-omega-current-name="<?= e($headerName) ?>" data-omega-current-first-name="<?= e($headerFirstName) ?>" data-omega-current-functional="<?= e($headerFunctional) ?>" data-omega-current-view="<?= e($omegaActiveView) ?>" data-omega-current-mode="<?= e($omegaMode) ?>" data-omega-can-view-priority="<?= e($omegaCanViewPriority ? '1' : '0') ?>" data-omega-total-rows="<?= e((string) $omegaTotalRows) ?>" data-omega-visible-rows="<?= e((string) count($omegaRows)) ?>" data-omega-page-start="<?= e((string) $omegaTableStart) ?>" data-omega-page-end="<?= e((string) $omegaTableEnd) ?>">
        <div class="app-watermark omega-watermark" aria-hidden="true">
            <?php for ($watermarkRow = 0; $watermarkRow < 8; $watermarkRow++): ?>
                <div class="app-watermark__row" style="top: <?= e((string) (7 + ($watermarkRow * 13))) ?>%;">
                    <?php for ($watermarkItem = 0; $watermarkItem < 5; $watermarkItem++): ?>
                        <span><?= e($watermarkIdentity) ?></span>
                    <?php endfor; ?>
                </div>
            <?php endfor; ?>
        </div>

        <aside class="omega-sidebar" data-omega-sidebar>
            <button class="omega-sidebar__toggle" type="button" aria-label="Recolher menu lateral" data-omega-sidebar-toggle>
                <i data-lucide="panel-left-close"></i>
            </button>

            <div class="omega-sidebar__user-card">
                <span class="omega-sidebar__avatar"><?= e($headerInitials) ?></span>
                <strong class="omega-sidebar__user-name"><?= e($headerName) ?></strong>
                <span class="omega-sidebar__user-meta"><?= e($headerFunctional !== '' ? $headerFunctional : 'Usuário ativo') ?></span>
            </div>

            <nav class="omega-sidebar__nav" aria-label="Navegacao lateral do Omega">
                <?php foreach ($omegaViews as $viewItem): ?>
                    <?php
                    $viewId = (string) ($viewItem['id'] ?? 'my-calls');
                    $viewUrl = $buildOmegaUrl([
                        'omega_mode' => 'list',
                        'omega_view' => $viewId,
                        'omega_page' => '1',
                    ]);
                    ?>
                    <a class="omega-sidebar__item<?= $omegaMode === 'list' && $omegaActiveView === $viewId ? ' is-active' : '' ?>" href="<?= e($viewUrl) ?>">
                        <span class="omega-sidebar__item-main">
                            <span class="omega-sidebar__item-icon" aria-hidden="true"><i data-lucide="<?= e((string) ($omegaViewIcons[$viewId] ?? 'layout-list')) ?>"></i></span>
                            <span class="omega-sidebar__item-copy"><?= e((string) ($viewItem['label'] ?? 'Visão')) ?></span>
                        </span>
                        <span class="omega-sidebar__item-count"><?= e((string) ((int) ($viewItem['count'] ?? 0))) ?></span>
                    </a>
                <?php endforeach; ?>

                <?php if ($omegaCanManageTeam): ?>
                    <a class="omega-sidebar__item<?= $omegaMode === 'team' ? ' is-active' : '' ?>" href="<?= e($buildOmegaUrl(['omega_mode' => 'team', 'omega_team' => $omegaSelectedManagedTeamCode !== '' ? $omegaSelectedManagedTeamCode : ((string) ($omegaManagedTeams[0]['code'] ?? '')), 'omega_page' => '1'])) ?>">
                        <span class="omega-sidebar__item-main">
                            <span class="omega-sidebar__item-icon" aria-hidden="true"><i data-lucide="users-round"></i></span>
                            <span class="omega-sidebar__item-copy">Editar Equipe</span>
                        </span>
                        <span class="omega-sidebar__item-count"><?= e((string) count($omegaManagedTeamAnalysts)) ?></span>
                    </a>
                <?php endif; ?>

                <?php if ($omegaCanAccessDashboard): ?>
                    <a class="omega-sidebar__item<?= $omegaMode === 'charts' ? ' is-active' : '' ?>" href="<?= e($buildOmegaUrl(['omega_mode' => 'charts', 'omega_page' => '1'])) ?>">
                        <span class="omega-sidebar__item-main">
                            <span class="omega-sidebar__item-icon" aria-hidden="true"><i data-lucide="layout-dashboard"></i></span>
                            <span class="omega-sidebar__item-copy">Dashboard</span>
                        </span>
                        <span class="omega-sidebar__item-count"><?= e((string) $omegaTotalRows) ?></span>
                    </a>
                <?php endif; ?>
            </nav>

        </aside>

        <main class="omega-main" aria-label="Area principal do Omega">
            <?php if ($omegaMode === 'team'): ?>
                <section class="omega-toolbar-shell omega-surface">
                    <div class="omega-toolbar-shell__head omega-toolbar-shell__head--team">
                        <div>
                            <h1 class="omega-toolbar-shell__title"><?= e($omegaHeroTitle) ?></h1>
                            <p class="omega-toolbar-shell__copy"><?= e($omegaHeroCopy) ?></p>
                        </div>

                        <?php if ($omegaManagedTeams !== []): ?>
                            <div class="omega-team-switch" aria-label="Selecionar departamento gerenciado">
                                <?php foreach ($omegaManagedTeams as $managedTeam): ?>
                                    <?php $managedTeamCode = (string) ($managedTeam['code'] ?? ''); ?>
                                    <a class="omega-team-switch__item<?= $managedTeamCode === $omegaSelectedManagedTeamCode ? ' is-active' : '' ?>" href="<?= e($buildOmegaUrl(['omega_mode' => 'team', 'omega_team' => $managedTeamCode, 'omega_page' => '1'])) ?>"><?= e((string) ($managedTeam['label'] ?? $managedTeamCode)) ?></a>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </section>

                <section class="omega-team-shell omega-surface">
                    <?php if ($omegaTeamFeedback !== ''): ?>
                        <div class="omega-team-feedback<?= $omegaTeamFeedbackTone === 'success' ? ' is-success' : ($omegaTeamFeedbackTone === 'error' ? ' is-error' : '') ?>"><?= e($omegaTeamFeedback) ?></div>
                    <?php endif; ?>

                    <?php if ($omegaSelectedManagedTeam === []): ?>
                        <div class="omega-empty-state">
                            <div>
                                <h3>Nenhuma equipe disponível para edição</h3>
                                <p>Assim que houver uma vinculação de gestão ativa no Omega, a edição de analistas aparecerá aqui.</p>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="omega-team-grid">
                            <section class="omega-team-card omega-team-card--summary">
                                <div class="omega-team-card__header">
                                    <div>
                                        <p class="omega-team-card__eyebrow">Departamento gerenciado</p>
                                        <h2><?= e((string) ($omegaSelectedManagedTeam['label'] ?? 'Equipe')) ?></h2>
                                    </div>
                                    <span class="omega-team-card__count"><?= e((string) count($omegaManagedTeamAnalysts)) ?> analistas</span>
                                </div>

                                <div class="omega-team-leads">
                                    <h3>Gestores vinculados</h3>
                                    <?php if ($omegaManagedTeamManagers === []): ?>
                                        <p class="omega-team-leads__empty">Nenhum gestor ativo vinculado a esta equipe.</p>
                                    <?php else: ?>
                                        <div class="omega-team-leads__list">
                                            <?php foreach ($omegaManagedTeamManagers as $managerItem): ?>
                                                <article class="omega-team-person">
                                                    <strong><?= e((string) ($managerItem['name'] ?? 'Gestor')) ?></strong>
                                                    <span><?= e((string) ($managerItem['functional'] ?? '')) ?><?= trim((string) ($managerItem['level'] ?? '')) !== '' ? ' • ' . (string) ($managerItem['level'] ?? '') : '' ?></span>
                                                </article>
                                            <?php endforeach; ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </section>

                            <section class="omega-team-card omega-team-card--add">
                                <div class="omega-team-card__header">
                                    <div>
                                        <p class="omega-team-card__eyebrow">Adicionar analista</p>
                                        <h2>Nova vinculação</h2>
                                    </div>
                                </div>

                                <form class="omega-team-form" method="post" action="<?= e(build_internal_url('omega.php', ['action' => 'omega_manage_team', 'omega_mode' => 'team', 'omega_team' => $omegaSelectedManagedTeamCode, 'omega_team_operation' => 'add', 'omega_team_code' => $omegaSelectedManagedTeamCode])) ?>">
                                    <?= csrf_field() ?>

                                    <div class="filter-field">
                                        <label class="filter-field__label" for="omega-team-analyst-functional">Analista disponível</label>
                                        <select id="omega-team-analyst-functional" class="filter-field__control" name="omega_analyst_functional"<?= $omegaManagedTeamCandidates === [] ? ' disabled' : '' ?>>
                                            <?php if ($omegaManagedTeamCandidates === []): ?>
                                                <option value="">Nenhum analista disponível</option>
                                            <?php else: ?>
                                                <?php foreach ($omegaManagedTeamCandidates as $candidateItem): ?>
                                                    <option value="<?= e((string) ($candidateItem['functional'] ?? '')) ?>"><?= e((string) ($candidateItem['name'] ?? 'Analista')) ?><?= trim((string) ($candidateItem['functional'] ?? '')) !== '' ? ' • ' . (string) ($candidateItem['functional'] ?? '') : '' ?><?= trim((string) ($candidateItem['level'] ?? '')) !== '' ? ' • ' . (string) ($candidateItem['level'] ?? '') : '' ?></option>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </select>
                                    </div>

                                    <div class="omega-team-form__actions">
                                        <span>Somente gestores vinculados podem alterar a composição desta equipe.</span>
                                        <button class="filters-button filters-button--primary" type="submit"<?= $omegaManagedTeamCandidates === [] ? ' disabled' : '' ?>>Adicionar analista</button>
                                    </div>
                                </form>
                            </section>

                            <section class="omega-team-card omega-team-card--list">
                                <div class="omega-team-card__header">
                                    <div>
                                        <p class="omega-team-card__eyebrow">Equipe atual</p>
                                        <h2>Analistas do departamento</h2>
                                    </div>
                                </div>

                                <?php if ($omegaManagedTeamAnalysts === []): ?>
                                    <div class="omega-empty-state omega-empty-state--compact">
                                        <div>
                                            <h3>Sem analistas vinculados</h3>
                                            <p>Inclua o primeiro analista para começar a distribuir a fila deste departamento.</p>
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="omega-team-members">
                                        <?php foreach ($omegaManagedTeamAnalysts as $analystItem): ?>
                                            <article class="omega-team-member">
                                                <div class="omega-team-member__identity">
                                                    <strong><?= e((string) ($analystItem['name'] ?? 'Analista')) ?></strong>
                                                    <span><?= e((string) ($analystItem['functional'] ?? '')) ?><?= trim((string) ($analystItem['level'] ?? '')) !== '' ? ' • ' . (string) ($analystItem['level'] ?? '') : '' ?></span>
                                                </div>

                                                <form method="post" action="<?= e(build_internal_url('omega.php', ['action' => 'omega_manage_team', 'omega_mode' => 'team', 'omega_team' => $omegaSelectedManagedTeamCode, 'omega_team_operation' => 'remove', 'omega_team_code' => $omegaSelectedManagedTeamCode])) ?>">
                                                    <?= csrf_field() ?>
                                                    <button class="filters-button filters-button--ghost" type="submit" name="omega_analyst_functional" value="<?= e((string) ($analystItem['functional'] ?? '')) ?>">Remover</button>
                                                </form>
                                            </article>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </section>
                        </div>
                    <?php endif; ?>
                </section>
            <?php else: ?>
                <section class="omega-toolbar-shell omega-surface">
                    <div class="omega-toolbar-shell__head">
                        <div>
                            <h1 class="omega-toolbar-shell__title"><?= e($omegaHeroTitle) ?></h1>
                            <p class="omega-toolbar-shell__copy"><?= e($omegaHeroCopy) ?></p>
                        </div>
                    </div>

                    <form class="omega-toolbar" method="get" action="<?= e($omegaToolbarSearchAction) ?>">
                        <label class="omega-search" for="omega-search-input">
                            <span class="omega-search__icon" aria-hidden="true"><i data-lucide="search"></i></span>
                            <input id="omega-search-input" type="search" name="omega_search" value="<?= e((string) ($omegaFilters['search'] ?? '')) ?>" placeholder="Buscar chamado ou usuário">
                        </label>

                        <div class="omega-toolbar__actions">
                            <button class="omega-toolbar__button<?= $omegaHasFilters ? ' is-active' : '' ?>" type="button" data-omega-filters-toggle>
                                <i data-lucide="sliders-horizontal"></i>
                                <span>Filtros</span>
                            </button>
                            <a class="omega-toolbar__button" href="<?= e($buildOmegaUrl(['omega_page' => '1'])) ?>">
                                <i data-lucide="refresh-cw"></i>
                                <span>Atualizar</span>
                            </a>
                            <button class="omega-toolbar__button omega-toolbar__button--cta" type="button" data-omega-register-toggle>
                                <i data-lucide="plus"></i>
                                <span>Registrar chamado</span>
                            </button>
                        </div>
                    </form>
                </section>

                <?php if ($omegaMode === 'charts'): ?>
                <section class="omega-kpi-grid">
                    <article class="omega-kpi-card omega-surface">
                        <span class="omega-kpi-card__eyebrow">Chamados abertos</span>
                        <strong><?= e((string) ((int) ($omegaSummaryMetrics['opened_total'] ?? 0))) ?></strong>
                        <span>Em aberto, aguardando ou em atendimento no recorte atual.</span>
                    </article>

                    <article class="omega-kpi-card omega-surface">
                        <span class="omega-kpi-card__eyebrow">Chamados fechados</span>
                        <strong><?= e((string) ((int) ($omegaSummaryMetrics['closed_total'] ?? 0))) ?></strong>
                        <span>Encerrados, rejeitados ou concluídos dentro da visão selecionada.</span>
                    </article>
                </section>

                <section class="omega-charts-grid">
                    <article class="omega-chart-card omega-chart-card--ranking omega-surface" style="--omega-card-delay: 80ms;">
                        <div class="omega-chart-card__header">
                            <div>
                                <h2>Solicitantes</h2>
                            </div>
                        </div>

                        <?php if ($omegaTopRequesters === []): ?>
                            <div class="omega-chart-card__empty">Sem registros suficientes para montar o ranking de solicitantes.</div>
                        <?php else: ?>
                            <div class="omega-ranked-list">
                                <?php foreach ($omegaTopRequesters as $item): ?>
                                    <div class="omega-ranked-list__item">
                                        <div class="omega-ranked-list__head">
                                            <strong><?= e((string) ($item['label'] ?? 'Sem nome')) ?></strong>
                                            <span><?= e((string) ((int) ($item['value'] ?? 0))) ?> chamados</span>
                                        </div>
                                        <div class="omega-ranked-list__track">
                                            <span style="width: <?= e((string) ((int) ($item['share'] ?? 0))) ?>%;"></span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </article>

                    <article class="omega-chart-card omega-chart-card--ranking omega-surface" style="--omega-card-delay: 160ms;">
                        <div class="omega-chart-card__header">
                            <div>
                                <h2>Departamentos</h2>
                            </div>
                        </div>

                        <?php if ($omegaTopDepartments === []): ?>
                            <div class="omega-chart-card__empty">Sem registros suficientes para montar o ranking de departamentos.</div>
                        <?php else: ?>
                            <div class="omega-ranked-list omega-ranked-list--department">
                                <?php foreach ($omegaTopDepartments as $item): ?>
                                    <div class="omega-ranked-list__item">
                                        <div class="omega-ranked-list__head">
                                            <strong><?= e((string) ($item['label'] ?? 'Sem nome')) ?></strong>
                                            <span><?= e((string) ((int) ($item['value'] ?? 0))) ?> chamados</span>
                                        </div>
                                        <div class="omega-ranked-list__track">
                                            <span style="width: <?= e((string) ((int) ($item['share'] ?? 0))) ?>%;"></span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </article>

                    <article class="omega-chart-card omega-chart-card--donut omega-surface" style="--omega-card-delay: 240ms;">
                        <div class="omega-chart-card__header">
                            <div>
                                <h2>Prioridade</h2>
                            </div>
                        </div>

                        <div class="omega-donut-card">
                            <div class="omega-donut" style="--omega-donut-gradient: <?= e((string) ($omegaPriorityDonut['gradient'] ?? 'conic-gradient(#e8edf5 0deg 360deg)')) ?>;">
                                <div class="omega-donut__core">
                                    <strong><?= e((string) ((int) ($omegaSummaryMetrics['total_rows'] ?? 0))) ?></strong>
                                    <span>prioridades</span>
                                </div>
                            </div>

                            <div class="omega-donut__legend">
                                <?php foreach ((array) ($omegaPriorityDonut['legend'] ?? []) as $legendItem): ?>
                                    <div class="omega-donut__legend-item">
                                        <span class="omega-donut__legend-dot" style="background: <?= e((string) ($legendItem['color'] ?? '#cbd5e1')) ?>;"></span>
                                        <div>
                                            <strong><?= e((string) ($legendItem['label'] ?? 'Sem rótulo')) ?></strong>
                                            <span><?= e((string) ((int) ($legendItem['value'] ?? 0))) ?> chamados • <?= e((string) ($legendItem['percentage'] ?? 0)) ?>%</span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </article>

                    <article class="omega-chart-card omega-chart-card--donut omega-surface" style="--omega-card-delay: 320ms;">
                        <div class="omega-chart-card__header">
                            <div>
                                <h2>Assunto</h2>
                            </div>
                        </div>

                        <div class="omega-donut-card">
                            <div class="omega-donut" style="--omega-donut-gradient: <?= e((string) ($omegaTypeDonut['gradient'] ?? 'conic-gradient(#e8edf5 0deg 360deg)')) ?>;">
                                <div class="omega-donut__core">
                                    <strong><?= e((string) ((int) ($omegaSummaryMetrics['total_rows'] ?? 0))) ?></strong>
                                    <span>assuntos</span>
                                </div>
                            </div>

                            <div class="omega-donut__legend">
                                <?php foreach ((array) ($omegaTypeDonut['legend'] ?? []) as $legendItem): ?>
                                    <div class="omega-donut__legend-item">
                                        <span class="omega-donut__legend-dot" style="background: <?= e((string) ($legendItem['color'] ?? '#cbd5e1')) ?>;"></span>
                                        <div>
                                            <strong><?= e((string) ($legendItem['label'] ?? 'Sem rótulo')) ?></strong>
                                            <span><?= e((string) ((int) ($legendItem['value'] ?? 0))) ?> chamados • <?= e((string) ($legendItem['percentage'] ?? 0)) ?>%</span>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </article>

                    <article class="omega-chart-card omega-chart-card--monthly omega-surface" style="--omega-card-delay: 400ms;">
                        <div class="omega-chart-card__header">
                            <div>
                                <h2>Chamados por mês</h2>
                            </div>
                        </div>

                        <?php if ($omegaMonthlyVolume === []): ?>
                            <div class="omega-chart-card__empty">Sem volume suficiente para montar a série mensal.</div>
                        <?php else: ?>
                            <div class="omega-monthly-chart">
                                <?php foreach ($omegaMonthlyVolume as $monthlyIndex => $monthlyItem): ?>
                                    <?php
                                    $openedValue = (int) ($monthlyItem['opened'] ?? 0);
                                    $closedValue = (int) ($monthlyItem['closed'] ?? 0);
                                    $openedHeight = $openedValue > 0 ? max(12, (int) round(($openedValue / $omegaMonthlyMax) * 100)) : 0;
                                    $closedHeight = $closedValue > 0 ? max(12, (int) round(($closedValue / $omegaMonthlyMax) * 100)) : 0;
                                    ?>
                                    <div class="omega-monthly-chart__item" style="--omega-bar-delay: <?= e((string) ($monthlyIndex * 85)) ?>ms;">
                                        <div class="omega-monthly-chart__bars">
                                            <span class="omega-monthly-chart__bar is-opened" style="height: <?= e((string) $openedHeight) ?>%;"></span>
                                            <span class="omega-monthly-chart__bar is-closed" style="height: <?= e((string) $closedHeight) ?>%;"></span>
                                        </div>
                                        <strong><?= e((string) ($monthlyItem['label'] ?? 'Sem data')) ?></strong>
                                        <span><?= e((string) $openedValue) ?> abertos • <?= e((string) $closedValue) ?> fechados</span>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </article>
                </section>
            <?php else: ?>
                <section class="omega-list-shell omega-surface">
                    <?php if ($omegaRows === []): ?>
                        <div class="omega-empty-state">
                            <div>
                                <h3>Sem chamados para mostrar agora</h3>
                                <p>Experimente ajustar a busca, os filtros do modal ou trocar a visão lateral. Novos chamados cadastrados aqui já passam a alimentar a base Omega.</p>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="table-wrapper omega-table-wrapper">
                            <table class="omega-table">
                                <thead>
                                    <tr>
                                        <th class="omega-table__check-col">
                                            <input id="omega-select-all" type="checkbox" data-omega-select-all>
                                        </th>
                                        <th>ID</th>
                                        <th>Prévia</th>
                                        <th>Departamento</th>
                                        <th>Assunto</th>
                                        <th>Usuário</th>
                                        <?php if ($omegaCanViewPriority): ?>
                                            <th class="omega-table__heading--pill">Prioridade</th>
                                        <?php endif; ?>
                                        <th>Analista</th>
                                        <th>Fila</th>
                                        <th class="omega-table__heading--date">Abertura</th>
                                        <th class="omega-table__heading--date">Atualização</th>
                                        <th class="omega-table__heading--pill">Status</th>
                                    </tr>
                                </thead>
                                <tbody data-omega-table-body>
                                    <?php foreach ($omegaRows as $omegaRow): ?>
                                        <?php
                                        $omegaThreadJson = json_encode((array) ($omegaRow['thread'] ?? []), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

                                        if (!is_string($omegaThreadJson)) {
                                            $omegaThreadJson = '[]';
                                        }
                                        ?>
                                        <tr
                                            class="omega-table__row"
                                            tabindex="0"
                                            data-omega-detail-row
                                            data-omega-source-view="<?= e($omegaActiveView) ?>"
                                            data-omega-id="<?= e((string) ($omegaRow['id_display'] ?? '000000')) ?>"
                                            data-omega-title="<?= e((string) ($omegaRow['preview_title'] ?? 'Chamado')) ?>"
                                            data-omega-preview="<?= e((string) ($omegaRow['preview_copy'] ?? '')) ?>"
                                            data-omega-description="<?= e((string) ($omegaRow['description'] ?? 'Sem observações registradas.')) ?>"
                                            data-omega-user="<?= e((string) ($omegaRow['user_label'] ?? 'Usuário')) ?>"
                                            data-omega-user-code="<?= e((string) ($omegaRow['user_code'] ?? '')) ?>"
                                            data-omega-analyst="<?= e((string) ($omegaRow['analyst_label'] ?? 'Sem analista')) ?>"
                                            data-omega-analyst-code="<?= e((string) ($omegaRow['analyst_code'] ?? '')) ?>"
                                            data-omega-department="<?= e((string) ($omegaRow['department_label'] ?? 'POBJ')) ?>"
                                            data-omega-type="<?= e((string) ($omegaRow['type_label'] ?? 'Outros')) ?>"
                                            data-omega-priority="<?= e((string) ($omegaRow['priority_label'] ?? 'Média')) ?>"
                                            data-omega-queue-code="<?= e((string) ($omegaRow['queue_code'] ?? 'POBJ')) ?>"
                                            data-omega-queue="<?= e((string) ($omegaRow['queue_label'] ?? 'POBJ')) ?>"
                                            data-omega-opened="<?= e((string) ($omegaRow['opened_at'] ?? '')) ?>"
                                            data-omega-opened-display="<?= e($formatOmegaDateTime((string) ($omegaRow['opened_at'] ?? ''))) ?>"
                                            data-omega-updated="<?= e((string) ($omegaRow['updated_at'] ?? '')) ?>"
                                            data-omega-updated-display="<?= e($formatOmegaDateTime((string) ($omegaRow['updated_at'] ?? ''))) ?>"
                                            data-omega-closed="<?= e((string) ($omegaRow['closed_at'] ?? '')) ?>"
                                            data-omega-closed-display="<?= e($formatOmegaDateTime((string) ($omegaRow['closed_at'] ?? ''))) ?>"
                                            data-omega-resolution="<?= e((string) ($omegaRow['resolution_final'] ?? 'Sem finalização registrada.')) ?>"
                                            data-omega-status="<?= e((string) ($omegaRow['status_label'] ?? 'Sem status')) ?>"
                                            data-omega-status-code="<?= e((string) ($omegaRow['status_code'] ?? 'SEM_STATUS')) ?>"
                                            data-omega-status-color="<?= e((string) ($omegaRow['status_color'] ?? '#cbd5e1')) ?>"
                                            data-omega-thread='<?= e($omegaThreadJson) ?>'
                                            aria-label="Abrir detalhes do chamado <?= e((string) ($omegaRow['id_display'] ?? '000000')) ?>"
                                        >
                                            <td class="omega-table__check-col">
                                                <input type="checkbox" value="<?= e((string) ($omegaRow['id_display'] ?? '')) ?>" data-omega-row-select>
                                            </td>
                                            <td class="omega-table__id-cell"><?= e((string) ($omegaRow['id_display'] ?? '000000')) ?></td>
                                            <td class="omega-table__preview-cell" title="<?= e((string) ($omegaRow['preview_title'] ?? 'Chamado')) ?>">
                                                <strong><?= e((string) ($omegaRow['preview_title'] ?? 'Chamado')) ?></strong>
                                                <span><?= e((string) ($omegaRow['preview_copy'] ?? '')) ?></span>
                                            </td>
                                            <td class="omega-table__meta-cell" title="<?= e((string) ($omegaRow['department_label'] ?? 'POBJ')) ?>"><?= e((string) ($omegaRow['department_label'] ?? 'POBJ')) ?></td>
                                            <td class="omega-table__meta-cell" title="<?= e((string) ($omegaRow['type_label'] ?? 'Outros')) ?>"><?= e((string) ($omegaRow['type_label'] ?? 'Outros')) ?></td>
                                            <td class="omega-table__person-cell" title="<?= e((string) ($omegaRow['user_label'] ?? 'Usuário')) ?>">
                                                <strong><?= e((string) ($omegaRow['user_label'] ?? 'Usuário')) ?></strong>
                                                <span><?= e((string) ($omegaRow['user_code'] ?? '')) ?></span>
                                            </td>
                                            <?php if ($omegaCanViewPriority): ?>
                                                <td class="omega-table__pill-cell">
                                                    <span class="omega-priority <?= e($resolvePriorityTone((string) ($omegaRow['priority_label'] ?? 'Média'))) ?>">
                                                        <span class="omega-pill__icon" aria-hidden="true"></span>
                                                        <?= e((string) ($omegaRow['priority_label'] ?? 'Média')) ?>
                                                    </span>
                                                </td>
                                            <?php endif; ?>
                                            <td class="omega-table__person-cell" title="<?= e((string) ($omegaRow['analyst_label'] ?? '—')) ?>">
                                                <strong><?= e((string) ($omegaRow['analyst_label'] ?? '—')) ?></strong>
                                                <span><?= e((string) ($omegaRow['analyst_code'] ?? '')) ?></span>
                                            </td>
                                            <td class="omega-table__meta-cell" title="<?= e((string) ($omegaRow['queue_label'] ?? 'POBJ')) ?>"><?= e((string) ($omegaRow['queue_label'] ?? 'POBJ')) ?></td>
                                            <td class="omega-table__date-cell"><?= e($formatOmegaDate((string) ($omegaRow['opened_at'] ?? ''))) ?></td>
                                            <td class="omega-table__date-cell"><?= e($formatOmegaDate((string) ($omegaRow['updated_at'] ?? ''))) ?></td>
                                            <td class="omega-table__pill-cell">
                                                <span class="omega-status-pill" style="--omega-status-color: <?= e((string) ($omegaRow['status_color'] ?? '#cbd5e1')) ?>;">
                                                    <span class="omega-pill__icon" aria-hidden="true"></span>
                                                    <?= e((string) ($omegaRow['status_label'] ?? 'Sem status')) ?>
                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>

                    <footer class="omega-pagination">
                        <span class="omega-pagination__summary" data-omega-pagination-summary>
                            <?= e($omegaTotalRows > 0 ? sprintf('%d – %d de %d chamados', $omegaTableStart, $omegaTableEnd, $omegaTotalRows) : '0 chamados') ?>
                        </span>

                        <?php if ($omegaTotalPages > 1): ?>
                            <nav class="omega-pagination__nav" aria-label="Paginação dos chamados do Omega">
                                <?php if ($omegaCurrentPage > 1): ?>
                                    <a class="omega-pagination__button" href="<?= e($buildOmegaUrl(['omega_page' => (string) ($omegaCurrentPage - 1)])) ?>">Anterior</a>
                                <?php else: ?>
                                    <span class="omega-pagination__button is-disabled" aria-disabled="true">Anterior</span>
                                <?php endif; ?>

                                <span class="omega-pagination__page is-current"><?= e((string) $omegaCurrentPage) ?></span>

                                <?php if ($omegaCurrentPage < $omegaTotalPages): ?>
                                    <a class="omega-pagination__button" href="<?= e($buildOmegaUrl(['omega_page' => (string) ($omegaCurrentPage + 1)])) ?>">Próxima</a>
                                <?php else: ?>
                                    <span class="omega-pagination__button is-disabled" aria-disabled="true">Próxima</span>
                                <?php endif; ?>
                            </nav>
                        <?php endif; ?>
                    </footer>
                </section>
            <?php endif; ?>
            <?php endif; ?>
        </main>

        <section class="omega-modal-shell" hidden data-omega-filters-modal>
            <button class="omega-modal-shell__backdrop" type="button" aria-label="Fechar modal de filtros" data-omega-filters-close></button>
            <div class="omega-modal omega-modal--filters" role="dialog" aria-modal="true" aria-labelledby="omega-filters-title">
                <div class="omega-modal__header">
                    <div>
                        <h2 id="omega-filters-title">Filtros</h2>
                    </div>
                    <button class="omega-modal__close" type="button" aria-label="Fechar filtros" data-omega-filters-close>
                        <i data-lucide="x"></i>
                    </button>
                </div>

                <form class="omega-filter-form" method="get" action="<?= e($omegaFilterAction) ?>" data-omega-filter-form data-omega-department-type-map='<?= e($omegaDepartmentTypeMapJson) ?>' data-omega-current-search='<?= e((string) ($omegaFilters['search'] ?? '')) ?>'>
                    <div class="omega-filter-form__grid">
                        <div class="filter-field">
                            <label class="filter-field__label" for="omega-filter-id">ID do chamado</label>
                            <input id="omega-filter-id" class="filter-field__control" type="text" name="omega_call_id" value="<?= e((string) ($omegaFilters['call_id'] ?? '')) ?>" placeholder="Ex.: 100010">
                        </div>

                        <div class="filter-field">
                            <label class="filter-field__label" for="omega-filter-user">Usuário</label>
                            <input id="omega-filter-user" class="filter-field__control" type="text" name="omega_requester" value="<?= e((string) ($omegaFilters['requester'] ?? '')) ?>" placeholder="Digite um nome">
                        </div>

                        <div class="filter-field">
                            <label class="filter-field__label" for="omega-filter-department">Departamento</label>
                            <select id="omega-filter-department" class="filter-field__control" name="omega_department" data-omega-filter-department>
                                <option value="">Selecione...</option>
                                <?php foreach ($omegaDepartmentOptions as $option): ?>
                                    <?php $optionValue = (string) ($option['value'] ?? ''); ?>
                                    <option value="<?= e($optionValue) ?>"<?= selected_attr($optionValue, (string) ($omegaFilters['department'] ?? '')) ?>><?= e((string) ($option['label'] ?? $optionValue)) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <span class="omega-filter-form__hint">Escolha a fila desejada</span>
                        </div>

                        <div class="filter-field">
                            <label class="filter-field__label" for="omega-filter-type">Assunto</label>
                            <select id="omega-filter-type" class="filter-field__control" name="omega_type" data-omega-filter-type>
                                <option value="">Todos os assuntos</option>
                                <?php foreach ($omegaTypeOptions as $option): ?>
                                    <?php $optionValue = (string) ($option['value'] ?? ''); ?>
                                    <option value="<?= e($optionValue) ?>"<?= selected_attr($optionValue, (string) ($omegaFilters['type'] ?? '')) ?>><?= e((string) ($option['label'] ?? $optionValue)) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <span class="omega-filter-form__hint">Escolha o assunto desejado</span>
                        </div>

                        <?php if ($omegaCanViewPriority): ?>
                            <div class="filter-field">
                                <label class="filter-field__label" for="omega-filter-priority">Prioridade</label>
                                <select id="omega-filter-priority" class="filter-field__control" name="omega_priority">
                                    <option value="">Todas</option>
                                    <?php foreach ($omegaPriorityOptions as $option): ?>
                                        <?php $optionValue = (string) ($option['value'] ?? ''); ?>
                                        <option value="<?= e($optionValue) ?>"<?= selected_attr($optionValue, (string) ($omegaFilters['priority'] ?? '')) ?>><?= e((string) ($option['label'] ?? $optionValue)) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        <?php endif; ?>
                    </div>

                    <div class="omega-status-picker" data-omega-status-picker data-selected-statuses='<?= e($omegaSelectedStatusJson) ?>'>
                        <p class="omega-status-picker__label">Status do chamado</p>
                        <div class="omega-status-picker__chips">
                            <?php foreach ($omegaStatusOptions as $statusOption): ?>
                                <?php $statusValue = (string) ($statusOption['value'] ?? ''); ?>
                                <button class="omega-status-chip<?= in_array($statusValue, $omegaStatusFilterValues, true) ? ' is-active' : '' ?>" type="button" data-omega-status-chip="<?= e($statusValue) ?>">
                                    <?= e((string) ($statusOption['label'] ?? $statusValue)) ?>
                                </button>
                            <?php endforeach; ?>
                        </div>
                        <span class="omega-filter-form__hint">Selecione um ou mais status</span>
                    </div>

                    <div class="omega-filter-form__grid omega-filter-form__grid--dates">
                        <div class="filter-field">
                            <label class="filter-field__label" for="omega-filter-opened-from">Abertura desde</label>
                            <input id="omega-filter-opened-from" class="filter-field__control" type="date" name="omega_opened_from" value="<?= e((string) ($omegaFilters['opened_from'] ?? '')) ?>">
                        </div>

                        <div class="filter-field">
                            <label class="filter-field__label" for="omega-filter-opened-to">Até</label>
                            <input id="omega-filter-opened-to" class="filter-field__control" type="date" name="omega_opened_to" value="<?= e((string) ($omegaFilters['opened_to'] ?? '')) ?>">
                        </div>
                    </div>

                    <div class="omega-filter-form__actions">
                        <?php if ($omegaCanViewPriority): ?>
                            <a class="omega-filter-form__clear" href="<?= e($buildOmegaUrl(['omega_call_id' => '', 'omega_requester' => '', 'omega_department' => '', 'omega_type' => '', 'omega_priority' => '', 'omega_status' => '', 'omega_opened_from' => '', 'omega_opened_to' => '', 'omega_page' => '1'])) ?>">Limpar filtros</a>
                        <?php else: ?>
                            <a class="omega-filter-form__clear" href="<?= e($buildOmegaUrl(['omega_call_id' => '', 'omega_requester' => '', 'omega_department' => '', 'omega_type' => '', 'omega_status' => '', 'omega_opened_from' => '', 'omega_opened_to' => '', 'omega_page' => '1'])) ?>">Limpar filtros</a>
                        <?php endif; ?>
                        <button class="filters-button filters-button--primary" type="submit">Aplicar</button>
                    </div>
                </form>
            </div>
        </section>

        <section class="omega-modal-shell" hidden data-omega-detail-panel>
            <button class="omega-modal-shell__backdrop" type="button" aria-label="Fechar detalhe do chamado" data-omega-detail-close></button>
            <div class="omega-modal omega-modal--detail" role="dialog" aria-modal="true" aria-labelledby="omega-detail-title">
                <div class="omega-modal__header omega-modal__header--detail">
                    <div>
                        <h2 id="omega-detail-title">Detalhe do chamado #<span data-omega-detail-id>000000</span></h2>
                        <p class="omega-modal__subcopy">Leitura consolidada do chamado, com histórico operacional completo.</p>
                    </div>
                    <div class="omega-modal__actions">
                        <button class="omega-toolbar__button" type="button" data-omega-detail-edit>
                            <i data-lucide="square-pen"></i>
                            <span>Editar</span>
                        </button>
                        <button class="omega-modal__close" type="button" aria-label="Fechar detalhe" data-omega-detail-close>
                            <i data-lucide="x"></i>
                        </button>
                    </div>
                </div>

                <div class="omega-detail-progress" data-omega-detail-progress>
                    <?php foreach ($omegaStatusOptions as $statusOption): ?>
                        <?php $statusValue = (string) ($statusOption['value'] ?? ''); ?>
                        <div class="omega-detail-progress__step" data-omega-progress-step="<?= e($statusValue) ?>">
                            <span><?= e((string) ($statusOption['label'] ?? $statusValue)) ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>

                <div class="omega-detail-sections">
                    <section class="omega-detail-section-block omega-detail-section-block--summary">
                        <div class="omega-detail-section-block__header">
                            <div>
                                <p class="omega-detail-overview__eyebrow">Resumo do chamado</p>
                                <h3 class="omega-detail-overview__title" data-omega-detail-title>Solicitação operacional</h3>
                                <p class="omega-detail-section-block__copy" data-omega-detail-subcopy>Fila • Usuário</p>
                            </div>
                        </div>

                        <div class="omega-detail-grid omega-detail-grid--summary">
                            <article class="omega-detail-card">
                                <span class="omega-detail-card__label">ID</span>
                                <strong data-omega-detail-id-card>000000</strong>
                                <span>Protocolo do chamado</span>
                            </article>

                            <article class="omega-detail-card">
                                <span class="omega-detail-card__label">Solicitante</span>
                                <strong data-omega-detail-user>Usuário</strong>
                                <span data-omega-detail-user-copy>0000000</span>
                            </article>

                            <article class="omega-detail-card">
                                <span class="omega-detail-card__label">Analista</span>
                                <strong data-omega-detail-analyst>Analista</strong>
                                <span data-omega-detail-analyst-copy>Equipe</span>
                            </article>

                            <article class="omega-detail-card">
                                <span class="omega-detail-card__label">Departamento</span>
                                <strong data-omega-detail-department>POBJ</strong>
                                <span data-omega-detail-queue>Fila atual</span>
                            </article>

                            <article class="omega-detail-card">
                                <span class="omega-detail-card__label">Assunto</span>
                                <strong data-omega-detail-type>Outros</strong>
                                <span>Classificação atual do chamado</span>
                            </article>

                            <?php if ($omegaCanViewPriority): ?>
                                <article class="omega-detail-card omega-detail-card--priority">
                                    <span class="omega-detail-card__label">Prioridade</span>
                                    <span class="omega-priority is-medium" data-omega-detail-priority-pill>
                                        <span class="omega-pill__icon" aria-hidden="true"></span>
                                        <span data-omega-detail-priority>Média</span>
                                    </span>
                                    <span>Visível apenas para perfis operacionais</span>
                                </article>
                            <?php endif; ?>

                            <article class="omega-detail-card">
                                <span class="omega-detail-card__label">Abertura</span>
                                <strong data-omega-detail-opened>—</strong>
                                <span>Registro inicial do chamado</span>
                            </article>

                            <article class="omega-detail-card">
                                <span class="omega-detail-card__label">Última atualização</span>
                                <strong data-omega-detail-updated>—</strong>
                                <span data-omega-detail-updated-copy>Última atualização em —</span>
                            </article>

                            <article class="omega-detail-card">
                                <span class="omega-detail-card__label">Fechamento</span>
                                <strong data-omega-detail-closed>—</strong>
                                <span>Data de encerramento do chamado</span>
                            </article>
                        </div>

                        <div class="omega-detail-grid omega-detail-grid--notes">
                            <section class="omega-detail-card omega-detail-card--wide">
                                <span class="omega-detail-card__label">Abertura</span>
                                <div class="omega-detail-description" data-omega-detail-description>Sem observações registradas.</div>
                            </section>

                            <section class="omega-detail-card omega-detail-card--wide">
                                <span class="omega-detail-card__label">Finalização</span>
                                <div class="omega-detail-description" data-omega-detail-resolution>Sem finalização registrada.</div>
                            </section>
                        </div>
                    </section>

                    <section class="omega-thread-panel omega-thread-panel--wide">
                        <div class="omega-thread-panel__header">
                            <div>
                                <h3>Comentários e linha do tempo</h3>
                                <span>Histórico completo do chamado ocupando toda a largura da área útil.</span>
                            </div>
                        </div>

                        <form class="omega-thread-form" method="post" action="<?= e(build_internal_url('omega.php', ['action' => 'omega_add_comment'])) ?>" data-omega-thread-form>
                            <?= csrf_field() ?>
                            <div class="omega-thread-form__roles">
                                <button class="omega-thread-form__role is-active" type="button" data-omega-thread-role="user">Usuário</button>
                                <?php if ($omegaCanAccessDashboard): ?>
                                    <button class="omega-thread-form__role" type="button" data-omega-thread-role="analyst">Analista</button>
                                <?php endif; ?>
                            </div>
                            <label class="omega-thread-form__field">
                                <span>Adicionar comentário</span>
                                <textarea class="omega-thread-form__textarea" rows="4" name="omega_comment_text" placeholder="Escreva o comentário que deve entrar na linha do tempo..." data-omega-thread-input></textarea>
                            </label>
                            <div class="omega-thread-form__footer">
                                <span data-omega-thread-hint>O comentário passa a fazer parte do histórico oficial do chamado.</span>
                                <button class="filters-button filters-button--primary" type="submit">Adicionar</button>
                            </div>
                            <span class="omega-thread-form__status" data-omega-thread-feedback hidden aria-live="polite"></span>
                        </form>

                        <div class="omega-thread" data-omega-detail-thread></div>
                    </section>
                </div>
            </div>
        </section>

        <aside class="omega-drawer" hidden data-omega-editor-panel>
            <div class="omega-drawer__surface">
                <div class="omega-drawer__header">
                    <div>
                        <p class="omega-drawer__eyebrow" data-omega-editor-eyebrow>Novo chamado</p>
                        <h2 data-omega-editor-title>Registrar chamado</h2>
                    </div>
                    <button class="omega-drawer__close" type="button" aria-label="Fechar editor do chamado" data-omega-editor-close>
                        <i data-lucide="x"></i>
                    </button>
                </div>

                <form class="omega-drawer__body" method="post" action="<?= e(build_internal_url('omega.php', ['action' => 'omega_save_call'])) ?>" data-omega-editor-form data-omega-department-type-map='<?= e($omegaDepartmentTypeMapJson) ?>' data-omega-queue-department-map='<?= e($omegaQueueDepartmentMapJson) ?>' data-omega-queue-analyst-map='<?= e($omegaQueueAnalystMapJson) ?>'>
                    <?= csrf_field() ?>

                    <div class="filter-field">
                        <label class="filter-field__label" for="omega-editor-title-input">Título</label>
                        <input id="omega-editor-title-input" class="filter-field__control" type="text" name="title" value="<?= e($omegaRegisterDefaultTitle) ?>" required data-omega-editor-field="title">
                    </div>

                    <div class="omega-editor-grid">
                        <div class="filter-field">
                            <label class="filter-field__label" for="omega-editor-user-input">Solicitante</label>
                            <input id="omega-editor-user-input" class="filter-field__control" type="text" name="user" value="<?= e($headerName) ?>" readonly data-omega-editor-field="user">
                        </div>

                        <div class="filter-field">
                            <label class="filter-field__label" for="omega-editor-user-code-input">Funcional</label>
                            <input id="omega-editor-user-code-input" class="filter-field__control" type="text" name="user_code" value="<?= e($headerFunctional) ?>" readonly data-omega-editor-field="user_code">
                        </div>
                    </div>

                    <div class="omega-editor-grid omega-editor-grid--double">
                        <div class="filter-field">
                            <label class="filter-field__label" for="omega-editor-department">Departamento</label>
                            <select id="omega-editor-department" class="filter-field__control" name="department" data-omega-editor-field="department">
                                <?php foreach ($omegaDepartmentOptions as $option): ?>
                                    <?php $optionValue = (string) ($option['value'] ?? ''); ?>
                                    <option value="<?= e($optionValue) ?>"><?= e((string) ($option['label'] ?? $optionValue)) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="filter-field">
                            <label class="filter-field__label" for="omega-editor-type">Assunto</label>
                            <select id="omega-editor-type" class="filter-field__control" name="type" data-omega-editor-field="type">
                                <?php foreach ($omegaTypeOptions as $option): ?>
                                    <?php $optionValue = (string) ($option['value'] ?? ''); ?>
                                    <option value="<?= e($optionValue) ?>"><?= e((string) ($option['label'] ?? $optionValue)) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <?php if ($omegaCanAccessDashboard): ?>
                        <div class="omega-editor-grid omega-editor-grid--double">
                            <div class="filter-field">
                                <label class="filter-field__label" for="omega-editor-queue">Fila</label>
                                <select id="omega-editor-queue" class="filter-field__control" name="queue" data-omega-editor-field="queue">
                                    <?php foreach ($omegaQueueOptions as $queueOption): ?>
                                        <?php $queueValue = (string) ($queueOption['value'] ?? ''); ?>
                                        <option value="<?= e($queueValue) ?>"><?= e((string) ($queueOption['label'] ?? $queueValue)) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="filter-field">
                                <label class="filter-field__label" for="omega-editor-analyst">Analista responsável</label>
                                <select id="omega-editor-analyst" class="filter-field__control" name="analyst_functional" data-omega-editor-field="analyst_functional">
                                    <option value="">Sem analista</option>
                                </select>
                            </div>
                        </div>

                        <div class="omega-editor-grid omega-editor-grid--double">
                            <div class="filter-field">
                                <label class="filter-field__label" for="omega-editor-priority">Prioridade</label>
                                <select id="omega-editor-priority" class="filter-field__control" name="priority" data-omega-editor-field="priority">
                                    <?php foreach ($omegaPriorityOptions as $option): ?>
                                        <?php $optionValue = (string) ($option['value'] ?? ''); ?>
                                        <option value="<?= e($optionValue) ?>"><?= e((string) ($option['label'] ?? $optionValue)) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>

                            <div class="filter-field">
                                <label class="filter-field__label" for="omega-editor-status">Status</label>
                                <select id="omega-editor-status" class="filter-field__control" name="status_code" data-omega-editor-field="status_code">
                                    <?php foreach ($omegaStatusOptions as $statusOption): ?>
                                        <?php $statusValue = (string) ($statusOption['value'] ?? ''); ?>
                                        <option value="<?= e($statusValue) ?>" data-status-label="<?= e((string) ($statusOption['label'] ?? $statusValue)) ?>" data-status-color="<?= e((string) ($statusOption['color'] ?? '#cbd5e1')) ?>"><?= e((string) ($statusOption['label'] ?? $statusValue)) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    <?php else: ?>
                        <input class="sr-only" type="text" name="queue" value="POBJ" readonly tabindex="-1" aria-hidden="true" data-omega-editor-field="queue">
                        <input class="sr-only" type="text" name="analyst_functional" value="" readonly tabindex="-1" aria-hidden="true" data-omega-editor-field="analyst_functional">
                        <input class="sr-only" type="text" name="priority" value="Média" readonly tabindex="-1" aria-hidden="true" data-omega-editor-field="priority">
                        <input class="sr-only" type="text" name="status_code" value="ABERTO" readonly tabindex="-1" aria-hidden="true" data-omega-editor-field="status_code">
                    <?php endif; ?>

                    <div class="filter-field">
                        <label class="filter-field__label" for="omega-editor-description">Descrição</label>
                        <textarea id="omega-editor-description" class="omega-drawer__textarea omega-drawer__textarea--editor" name="description" data-omega-editor-field="description"></textarea>
                    </div>

                    <div class="omega-drawer__footer">
                        <span class="omega-thread-form__status" data-omega-editor-feedback hidden aria-live="polite"></span>
                        <button class="filters-button filters-button--ghost" type="button" data-omega-editor-close>Cancelar</button>
                        <button class="filters-button filters-button--primary" type="submit" data-omega-editor-submit-label>Salvar</button>
                    </div>
                </form>
            </div>
        </aside>
    </div>

    <script src="assets/vendor/lucide.min.js"></script>
    <script src="assets/js/app.js"></script>
</body>
</html>
