<?php

declare(strict_types=1);

namespace App\Services;

use App\Support\CallsStoredProcedures;
use PDO;

final class PobjDashboardService
{
    use CallsStoredProcedures;

    private const INDICATOR_ANALYTIC_PER_PAGE = 20;

    /** @var PDO */
    private $connection;

    /** @var bool|null */
    private $managementRelationAvailable;

    /** @var array<string, bool> */
    private $productivitySnapshotTableAvailability;

    public function __construct(PDO $connection)
    {
        $this->connection = $connection;
        $this->managementRelationAvailable = null;
        $this->productivitySnapshotTableAvailability = [];
    }

    protected function getProcedureConnection(): PDO
    {
        return $this->connection;
    }

    private function buildSemestralProcedureScopeParams(array $context): array
    {
        $scope = (array) ($context['scope'] ?? []);

        return [
            'p_scope_code' => strtoupper(trim((string) ($scope['code'] ?? 'GLOBAL'))),
            'p_scope_functional' => trim((string) ($scope['functional'] ?? '')),
            'p_scope_allowed_csv' => $this->encodeProcedureList((array) ($scope['allowed'] ?? [])),
        ];
    }

    private function buildSemestralProcedureHierarchyFilterParams(array $filters): array
    {
        return [
            'p_segmento' => trim((string) ($filters['segmento'] ?? '')),
            'p_diretoria' => trim((string) ($filters['diretoria'] ?? '')),
            'p_regional' => trim((string) ($filters['regional'] ?? '')),
            'p_agencia' => trim((string) ($filters['agencia'] ?? '')),
        ];
    }

    private function buildSemestralProcedureManagerFilterParams(array $filters): array
    {
        return [
            'p_gerente_gestao' => trim((string) ($filters['gerente_gestao'] ?? '')),
            'p_gerente' => trim((string) ($filters['gerente'] ?? '')),
        ];
    }

    private function buildSemestralProcedureMetricFilterParams(array $filters): array
    {
        return [
            'p_familia' => trim((string) ($filters['familia'] ?? '')),
            'p_indicador' => trim((string) ($filters['indicadores'] ?? '')),
        ];
    }

    private function buildAnalyticProcedureScopeParams(array $context): array
    {
        $scope = (array) ($context['scope'] ?? []);
        $profile = (array) ($context['profile'] ?? []);

        return [
            'p_scope_code' => strtoupper(trim((string) ($scope['code'] ?? 'GLOBAL'))),
            'p_scope_functional' => trim((string) ($scope['functional'] ?? '')),
            'p_scope_allowed_csv' => $this->encodeProcedureList((array) ($scope['allowed'] ?? [])),
            'p_profile_level' => strtoupper(trim((string) ($profile['nivel'] ?? ''))),
            'p_profile_functional' => trim((string) ($profile['funcional'] ?? '')),
        ];
    }

    private function buildAnalyticProcedureHierarchyFilterParams(array $filters): array
    {
        return [
            'p_segmento' => trim((string) ($filters['segmento'] ?? '')),
            'p_diretoria' => trim((string) ($filters['diretoria'] ?? '')),
            'p_regional' => trim((string) ($filters['regional'] ?? '')),
            'p_agencia' => trim((string) ($filters['agencia'] ?? '')),
            'p_gerente_gestao' => trim((string) ($filters['gerente_gestao'] ?? '')),
            'p_gerente' => trim((string) ($filters['gerente'] ?? '')),
        ];
    }

    private function buildExecutiveFactProcedureFilterParams(array $filters): array
    {
        $managementFunctional = trim((string) ($filters['gerente_gestao'] ?? ''));

        return [
            'p_segmento' => trim((string) ($filters['segmento'] ?? '')),
            'p_diretoria' => trim((string) ($filters['diretoria'] ?? '')),
            'p_regional' => trim((string) ($filters['regional'] ?? '')),
            'p_agencia' => trim((string) ($filters['agencia'] ?? '')),
            'p_gerente_gestao' => $managementFunctional,
            'p_gerente_gestao_functionals_csv' => $managementFunctional !== ''
                ? $this->encodeProcedureList($this->resolveFunctionalsByManagementFunctional($managementFunctional))
                : '',
            'p_gerente_gestao_agencies_csv' => $managementFunctional !== ''
                ? $this->encodeProcedureList($this->resolveAgenciesByFunctional($managementFunctional))
                : '',
            'p_gerente' => trim((string) ($filters['gerente'] ?? '')),
            'p_familia' => trim((string) ($filters['familia'] ?? '')),
            'p_indicador' => trim((string) ($filters['indicadores'] ?? '')),
        ];
    }

    private function buildIndicatorAggregateProcedureFilterParams(array $filters): array
    {
        $managementFunctional = trim((string) ($filters['gerente_gestao'] ?? ''));

        return [
            'p_segmento' => trim((string) ($filters['segmento'] ?? '')),
            'p_diretoria' => trim((string) ($filters['diretoria'] ?? '')),
            'p_regional' => trim((string) ($filters['regional'] ?? '')),
            'p_agencia' => trim((string) ($filters['agencia'] ?? '')),
            'p_gerente_gestao' => $managementFunctional,
            'p_gerente_gestao_functionals_csv' => $managementFunctional !== ''
                ? $this->encodeProcedureList($this->resolveFunctionalsByManagementFunctional($managementFunctional))
                : '',
            'p_gerente_gestao_agencies_csv' => $managementFunctional !== ''
                ? $this->encodeProcedureList($this->resolveAgenciesByFunctional($managementFunctional))
                : '',
            'p_gerente' => trim((string) ($filters['gerente'] ?? '')),
            'p_indicador' => trim((string) ($filters['indicadores'] ?? '')),
            'p_subindicador' => trim((string) ($filters['subindicador'] ?? '')),
        ];
    }

    public function listPeriods(): array
    {
        return $this->fetchProcedureAll('sp_pobj_list_periods');
    }

    public function periodHasVisibleData(array $context, string $periodId): bool
    {
        foreach ($this->resolveSnapshotTablesForPeriod($periodId) as $tableName) {
            if ((bool) $this->fetchProcedureValue(
                'sp_pobj_table_has_visible_scope_data',
                array_merge(
                    [
                        'p_table_name' => $tableName,
                    ],
                    $this->buildSemestralProcedureScopeParams($context)
                )
            )) {
                return true;
            }
        }

        return false;
    }

    public function getDashboardData(array $context, string $periodId, array $filters = [], string $referenceStartDate = '', string $referenceEndDate = ''): array
    {
        $filters = $this->normalizeSummaryFilters($filters);
        $requestedView = strtoupper(trim((string) ($filters['visao_acumulada'] ?? 'MENSAL')));

        if ($requestedView === 'MENSAL_ACUMULADO') {
            return $this->getMonthlyAccumulatedDashboardData($context, $filters, $referenceEndDate, $periodId);
        }

        $snapshotTableName = $this->resolveProductivitySnapshotTableName($filters, $referenceEndDate, $periodId);

        if ($snapshotTableName !== '') {
            return $this->getSemestralDashboardData($context, $filters, $referenceEndDate, $periodId, $snapshotTableName);
        }

        return $this->getEmptyDashboardData();
    }

    private function getMonthlyAccumulatedDashboardData(array $context, array $filters, string $referenceEndDate, string $periodId): array
    {
        $anomes = $this->resolveSemestralAnoMes($referenceEndDate, $periodId);
        $monthlyTable = 'f_produtividade_mensal_' . $anomes;
        $accumulatedTable = 'f_acumulado_' . $anomes;

        $monthlyData = $this->hasProductivitySnapshotTable($monthlyTable)
            ? $this->getSemestralDashboardData($context, $filters, $referenceEndDate, $periodId, $monthlyTable)
            : $this->getEmptyDashboardData();

        $accumulatedData = $this->hasProductivitySnapshotTable($accumulatedTable)
            ? $this->getSemestralDashboardData($context, $filters, $referenceEndDate, $periodId, $accumulatedTable)
            : $this->getEmptyDashboardData();

        $baseData = $monthlyData;

        if (($baseData['indicators'] ?? []) === [] && ($accumulatedData['indicators'] ?? []) !== []) {
            $baseData = $accumulatedData;
        }

        $baseData['comparison'] = [
            'mensal' => $monthlyData,
            'acumulado' => $accumulatedData,
        ];

        return $baseData;
    }

    public function getDetailData(
        array $context,
        string $periodId,
        array $filters = [],
        string $referenceStartDate = '',
        string $referenceEndDate = '',
        string $detailTableView = 'diretoria',
        int $detailPage = 1
    ): array
    {
        $filters = $this->normalizeSummaryFilters($filters);
        $anomes = $this->resolveSemestralAnoMes($referenceEndDate, $periodId);
        $snapshotTableName = $this->resolveProductivitySnapshotTableName($filters, $referenceEndDate, $periodId);
        $indicatorMetrics = $this->getDetailIndicatorMetricRows($context, $filters, $referenceEndDate, $periodId, $anomes);
        $detailTableView = trim($detailTableView);
        $pagination = $this->buildIndicatorAnalyticPagination(0, 1, self::INDICATOR_ANALYTIC_PER_PAGE);
        $indicatorRowCounts = [];

        if ($detailTableView !== 'contrato') {
            if ($snapshotTableName === '') {
                return [
                    'rows' => [],
                    'indicator_metrics' => $indicatorMetrics,
                    'pagination' => $pagination,
                    'row_counts_by_indicator' => $indicatorRowCounts,
                    'empty_state' => [
                        'title' => 'Nenhum dado encontrado',
                        'message' => 'Nenhum dado encontrado para os filtros selecionados.',
                    ],
                ];
            }

            return [
                'rows' => $this->getSnapshotDetailRows($context, $filters, $anomes, $snapshotTableName),
                'indicator_metrics' => $indicatorMetrics,
                'pagination' => $pagination,
                'row_counts_by_indicator' => $indicatorRowCounts,
                'empty_state' => [
                    'title' => 'Nenhum dado encontrado',
                    'message' => 'Nenhum dado encontrado para os filtros selecionados.',
                ],
            ];
        }

        if (!$this->canExposeAnalyticRows($context, $filters)) {
            return [
                'rows' => [],
                'indicator_metrics' => $indicatorMetrics,
                'pagination' => $pagination,
                'row_counts_by_indicator' => $indicatorRowCounts,
                'empty_state' => [
                    'title' => 'Selecione um gerente',
                    'message' => 'O detalhamento linha a linha fica disponivel apenas quando o recorte estiver no nivel Gerente.',
                ],
            ];
        }

        if ($detailTableView === 'contrato') {
            $totalRows = $this->countAnalyticDetailRows($context, $filters, $anomes);
            $pagination = $this->buildIndicatorAnalyticPagination($totalRows, $detailPage, self::INDICATOR_ANALYTIC_PER_PAGE);

            if ($totalRows > 0) {
                $indicatorRowCounts = $this->getAnalyticDetailIndicatorRowCounts($context, $filters, $anomes);
            }
        }

        return [
            'rows' => $this->getAnalyticDetailRows(
                $context,
                $filters,
                $anomes,
                $detailTableView === 'contrato' ? (int) ($pagination['page'] ?? 1) : 1,
                $detailTableView === 'contrato' ? (int) ($pagination['per_page'] ?? self::INDICATOR_ANALYTIC_PER_PAGE) : 0
            ),
            'indicator_metrics' => $indicatorMetrics,
            'pagination' => $pagination,
            'row_counts_by_indicator' => $indicatorRowCounts,
            'empty_state' => [
                'title' => 'Nenhum dado encontrado',
                'message' => 'Nenhum dado encontrado para os filtros selecionados.',
            ],
        ];
    }

    public function getIndicatorDetailData(
        array $context,
        string $periodId,
        array $filters,
        string $indicatorId,
        string $referenceStartDate = '',
        string $referenceEndDate = '',
        int $transactionPage = 1
    ): array
    {
        $indicatorId = trim($indicatorId);

        if ($indicatorId === '') {
            return [
                'indicator' => [],
                'summary' => [],
                'trend' => [],
                'distributions' => ['channels' => [], 'statuses' => []],
                'insights' => ['mode' => 'hierarchy', 'label' => '', 'title' => '', 'top' => [], 'bottom' => []],
                'transactions' => [],
                'analytic_pagination' => $this->buildIndicatorAnalyticPagination(0, 1, self::INDICATOR_ANALYTIC_PER_PAGE),
            ];
        }

        $filters = $this->normalizeSummaryFilters($filters);
        $filters['indicadores'] = $indicatorId;
        $filters['subindicador'] = '';

        $snapshotTableName = $this->resolveProductivitySnapshotTableName($filters, $referenceEndDate, $periodId);

        if ($snapshotTableName !== '') {
            return $this->getSemestralIndicatorDetailData(
                $context,
                $filters,
                $indicatorId,
                $referenceEndDate,
                $periodId,
                $snapshotTableName,
                $transactionPage
            );
        }

        return [
            'indicator' => [],
            'summary' => [],
            'trend' => [],
            'distributions' => ['channels' => [], 'statuses' => []],
            'insights' => ['mode' => 'hierarchy', 'label' => '', 'title' => '', 'top' => [], 'bottom' => []],
            'transactions' => [],
            'analytic_pagination' => $this->buildIndicatorAnalyticPagination(0, 1, self::INDICATOR_ANALYTIC_PER_PAGE),
        ];
    }

    public function getAnnualPerformanceData(array $context, array $filters, string $referenceEndDate): array
    {
        try {
            $referenceDate = new \DateTimeImmutable($referenceEndDate !== '' ? $referenceEndDate : 'today');
        } catch (\Throwable $exception) {
            $referenceDate = new \DateTimeImmutable('today');
        }

        $year = (int) $referenceDate->format('Y');
        $currentMonth = (int) $referenceDate->format('n');
        $rows = [];
        $attainedMonths = 0;
        $warningMonths = 0;
        $missedMonths = 0;

        for ($monthNumber = 1; $monthNumber <= $currentMonth; $monthNumber++) {
            $monthDate = $referenceDate->setDate($year, $monthNumber, 1);
            $anomes = $monthDate->format('Ym');
            $tableName = 'f_produtividade_mensal_' . $anomes;
            $percentual = null;
            $status = 'sem-dados';
            $statusLabel = 'Sem dados';

            if ($this->hasProductivitySnapshotTable($tableName)) {
                $row = $this->fetchProcedureRow(
                    'sp_pobj_get_executive_snapshot_totals',
                    array_merge(
                        [
                            'p_table_name' => $tableName,
                            'p_anomes' => $anomes,
                        ],
                        $this->buildSemestralProcedureScopeParams($context),
                        $this->buildSemestralProcedureHierarchyFilterParams($filters),
                        $this->buildSemestralProcedureManagerFilterParams($filters),
                        $this->buildSemestralProcedureMetricFilterParams($filters)
                    )
                ) ?: [];

                if ((int) ($row['row_count'] ?? 0) > 0) {
                    $percentual = (float) ($row['atingimento_medio'] ?? 0.0);
                }
            }

            if ($percentual !== null && $percentual >= 100.0) {
                $status = 'atingiu';
                $statusLabel = 'Atingiu';
                $attainedMonths++;
            } elseif ($percentual !== null && $percentual >= 85.0) {
                $status = 'quase';
                $statusLabel = 'Quase';
                $warningMonths++;
            } elseif ($percentual !== null) {
                $status = 'distante';
                $statusLabel = 'Nao atingiu';
                $missedMonths++;
            }

            $rows[] = [
                'month_number' => $monthNumber,
                'month_label' => $this->formatMonthLabel($monthDate),
                'percentual' => $percentual,
                'status' => $status,
                'status_label' => $statusLabel,
            ];
        }

        return [
            'year' => $year,
            'rows' => $rows,
            'summary' => [
                'atingiu' => $attainedMonths,
                'quase' => $warningMonths,
                'distante' => $missedMonths,
            ],
        ];
    }
public function getRankingData(array $context, string $periodId, array $filters = [], string $referenceStartDate = '', string $referenceEndDate = ''): array
    {
        $filters = $this->normalizeSummaryFilters($filters);
        return [
            'level' => $this->resolveRankingLevel($context, $filters),
            'level_label' => $this->resolveRankingLevelLabel($this->resolveRankingLevel($context, $filters)),
            'rows' => [],
            'mask_identities' => false,
            'viewer_row' => null,
        ];
    }

    public function listRankingGroupOptions(array $context, string $periodId, array $filters = [], string $referenceStartDate = '', string $referenceEndDate = ''): array
    {
        return [];
    }

    public function getExecutiveViewData(array $context, string $periodId, array $filters = [], string $referenceStartDate = '', string $referenceEndDate = ''): array
    {
        $filters = $this->normalizeSummaryFilters($filters);
        $selectedTableName = $this->resolveExecutiveSnapshotTableName($filters, $referenceEndDate, $periodId);

        if ($selectedTableName === '') {
            return $this->getEmptyExecutiveViewData();
        }

        $anomes = $this->resolveSemestralAnoMes($referenceEndDate, $periodId);
        $monthlyTableName = $this->hasProductivitySnapshotTable('f_produtividade_mensal_' . $anomes)
            ? 'f_produtividade_mensal_' . $anomes
            : $selectedTableName;
        $accumulatedTableName = $this->hasProductivitySnapshotTable('f_acumulado_' . $anomes)
            ? 'f_acumulado_' . $anomes
            : $selectedTableName;
        $focus = $this->resolveExecutiveFocusConfig($context, $filters, $anomes, $selectedTableName);
        $monthlyTotals = $this->getExecutiveSnapshotTotals($context, $filters, $anomes, $monthlyTableName);
        $accumulatedTotals = $this->getExecutiveSnapshotTotals($context, $filters, $anomes, $accumulatedTableName);
        $referenceTotals = $selectedTableName === $monthlyTableName
            ? $monthlyTotals
            : ($selectedTableName === $accumulatedTableName
                ? $accumulatedTotals
                : $this->getExecutiveSnapshotTotals($context, $filters, $anomes, $selectedTableName));
        $windowMonths = $this->getExecutiveWindowMonths($anomes, 6);
        $businessDays = $this->resolveExecutiveBusinessDays($referenceEndDate, $anomes);
        $elapsedBusinessDays = max(0, (int) ($businessDays['elapsed'] ?? 0));
        $remainingBusinessDays = max(0, (int) ($businessDays['remaining'] ?? 0));
        $forecast = $elapsedBusinessDays > 0
            ? (float) ($monthlyTotals['real_mens'] ?? 0.0) + (((float) ($monthlyTotals['real_mens'] ?? 0.0) / $elapsedBusinessDays) * $remainingBusinessDays)
            : (float) ($monthlyTotals['real_mens'] ?? 0.0);
        $forecastPercent = (float) ($monthlyTotals['meta_mens'] ?? 0.0) > 0.0
            ? ($forecast / (float) ($monthlyTotals['meta_mens'] ?? 0.0)) * 100.0
            : (float) ($monthlyTotals['p_mens'] ?? 0.0);
        $groupRows = $this->getExecutiveFocusRows($context, $filters, $anomes, $selectedTableName, (string) ($focus['group_level'] ?? 'regional'));
        $ranking = $this->buildExecutiveRankingData($groupRows);
        $insights = $this->getExecutiveInsightsData($context, $filters, $anomes);
        $status = $this->buildExecutiveStatusData($groupRows, (string) ($focus['status_title'] ?? 'Status por Regional'));
        $chart = $this->getExecutiveChartData($context, $filters, $windowMonths);
        $heatmap = $this->getExecutiveHeatmapData($context, $filters, $anomes, $selectedTableName, $focus, $ranking, $windowMonths);
        $reference = $this->buildExecutiveReferenceData($anomes, $windowMonths);

        return [
            'focus' => [
                'level' => (string) ($focus['group_level'] ?? 'regional'),
                'label' => (string) ($focus['label'] ?? 'Regional'),
                'ranking_title' => (string) ($focus['ranking_title'] ?? 'Desempenho por Regional'),
                'status_title' => (string) ($focus['status_title'] ?? 'Status por Regional'),
            ],
            'reference' => $reference,
            'kpis' => [
                'percent_mens' => (float) ($monthlyTotals['p_mens'] ?? 0.0),
                'real_mens' => (float) ($monthlyTotals['real_mens'] ?? 0.0),
                'meta_mens' => (float) ($monthlyTotals['meta_mens'] ?? 0.0),
                'gap' => (float) ($monthlyTotals['deficit'] ?? 0.0),
                'referencia' => (float) ($referenceTotals['referencia_total'] ?? 0.0),
                'referencia_perc' => (float) ($referenceTotals['referencia_perc_media'] ?? 0.0),
                'real_acum' => (float) ($accumulatedTotals['real_mens'] ?? 0.0),
                'meta_acum' => (float) ($accumulatedTotals['meta_mens'] ?? 0.0),
                'forecast' => $forecast,
                'percent_forecast' => $forecastPercent,
                'business_days' => $businessDays,
            ],
            'chart' => $chart,
            'ranking' => $ranking,
            'insights' => $insights,
            'status' => $status,
            'heatmap' => $heatmap,
        ];
    }

    private function resolveExecutiveSnapshotTableName(array $filters, string $referenceEndDate = '', string $periodId = ''): string
    {
        $view = strtoupper(trim((string) ($filters['visao_acumulada'] ?? 'MENSAL')));

        if ($view === 'MENSAL_ACUMULADO') {
            $view = 'MENSAL';
        }

        $anomes = $this->resolveSemestralAnoMes($referenceEndDate, $periodId);

        if ($view === 'SEMESTRAL') {
            $tableName = 'f_produtividade_semestral_' . $anomes;
            return $this->hasProductivitySnapshotTable($tableName) ? $tableName : '';
        }

        if ($view === 'ACUMULADO') {
            $tableName = 'f_acumulado_' . $anomes;
            return $this->hasProductivitySnapshotTable($tableName) ? $tableName : '';
        }

        if ($view === 'MENSAL') {
            $tableName = 'f_produtividade_mensal_' . $anomes;
            return $this->hasProductivitySnapshotTable($tableName) ? $tableName : '';
        }

        return $this->resolveProductivityFilterTableName($filters, $referenceEndDate, $periodId);
    }

    private function buildExecutiveReferenceData(string $anomes, array $windowMonths): array
    {
        try {
            $anchor = new \DateTimeImmutable(substr($anomes, 0, 4) . '-' . substr($anomes, 4, 2) . '-01');
        } catch (\Throwable $exception) {
            $anchor = new \DateTimeImmutable('today');
        }

        $monthLabel = $this->formatMonthLabel($anchor) . ' ' . $anchor->format('Y');
        $windowCount = count($windowMonths);

        return [
            'period_label' => $monthLabel,
            'range_label' => $monthLabel,
            'month_label' => $monthLabel,
            'window_label' => 'Ultimos ' . max(1, $windowCount) . ' meses',
        ];
    }

    private function resolveExecutiveBusinessDays(string $referenceEndDate, string $anomes): array
    {
        try {
            $monthStart = new \DateTimeImmutable(substr($anomes, 0, 4) . '-' . substr($anomes, 4, 2) . '-01');
            $monthEnd = $monthStart->modify('last day of this month');
        } catch (\Throwable $exception) {
            return ['elapsed' => 0, 'total' => 0, 'remaining' => 0];
        }

        $referenceEndDate = trim($referenceEndDate);
        $effectiveEnd = $referenceEndDate !== '' ? $referenceEndDate : $monthEnd->format('Y-m-d');

        return \resolve_business_day_snapshot(
            $monthStart->format('Y-m-d'),
            $effectiveEnd,
            $effectiveEnd
        );
    }

    private function getExecutiveSnapshotTotals(array $context, array $filters, string $anomes, string $tableName): array
    {
        if ($tableName === '' || !$this->hasProductivitySnapshotTable($tableName)) {
            return ['meta_mens' => 0.0, 'real_mens' => 0.0, 'p_mens' => 0.0, 'deficit' => 0.0, 'referencia_total' => 0.0, 'referencia_perc_media' => 0.0];
        }

        $row = $this->fetchProcedureRow(
            'sp_pobj_get_executive_snapshot_totals',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_anomes' => $anomes,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildSemestralProcedureHierarchyFilterParams($filters),
                $this->buildSemestralProcedureManagerFilterParams($filters),
                $this->buildSemestralProcedureMetricFilterParams($filters)
            )
        );

        return $this->buildExecutiveScoreMetrics($row ?? []);
    }

    private function buildExecutiveScoreMetrics(array $row): array
    {
        $rowCount = (int) ($row['row_count'] ?? 0);
        $pointsMeta = (float) ($row['pontos_meta_total'] ?? 0.0);
        $pointsReal = (float) ($row['pontos_real_total'] ?? 0.0);
        $readyAverage = (float) ($row['atingimento_medio'] ?? 0.0);

        if ($pointsMeta > 0.0 || $pointsReal > 0.0) {
            $meta = $pointsMeta;
            $real = $pointsReal;
            $percent = $readyAverage;
        } else {
            $meta = $rowCount > 0 ? $rowCount * 100.0 : 0.0;
            $real = $rowCount > 0 ? $readyAverage * $rowCount : 0.0;
            $percent = $rowCount > 0 ? $readyAverage : 0.0;
        }

        return [
            'meta_mens' => $meta,
            'real_mens' => $real,
            'p_mens' => $percent,
            'deficit' => max(0.0, $meta - $real),
            'referencia_total' => (float) ($row['referencia_total'] ?? 0.0),
            'referencia_perc_media' => (float) ($row['referencia_perc_media'] ?? 0.0),
        ];
    }

    private function buildExecutiveHeatmapMetrics(array $row): array
    {
        $rowCount = (int) ($row['row_count'] ?? 0);
        $metaValue = (float) ($row['valor_meta_total'] ?? 0.0);
        $realValue = (float) ($row['valor_real_total'] ?? 0.0);
        $realizedCount = (int) ($row['realizado_count'] ?? 0);
        $readyAverage = (float) ($row['atingimento_medio'] ?? 0.0);

        if ($metaValue > 0.0) {
            return [
                'meta_total' => $metaValue,
                'real_total' => $realValue,
                'percent' => ($realValue / $metaValue) * 100.0,
                'absolute_mode' => 'value',
            ];
        }

        if ($rowCount > 0) {
            return [
                'meta_total' => (float) $rowCount,
                'real_total' => (float) $realizedCount,
                'percent' => $rowCount > 0 ? ($realizedCount / $rowCount) * 100.0 : 0.0,
                'absolute_mode' => 'count',
            ];
        }

        return [
            'meta_total' => null,
            'real_total' => null,
            'percent' => $readyAverage,
            'absolute_mode' => 'none',
        ];
    }

    private function resolveExecutiveFocusConfig(array $context, array $filters, string $anomes, string $tableName): array
    {
        $groupLevel = 'regional';

        if (($filters['gerente'] ?? '') !== '') {
            $groupLevel = 'produto';
        } elseif (($filters['gerente_gestao'] ?? '') !== '') {
            $groupLevel = 'gerente';
        } elseif (($filters['agencia'] ?? '') !== '') {
            $groupLevel = $this->hasSnapshotManagementManagers($context, $filters, $anomes, $tableName)
                ? 'gerente_gestao'
                : 'gerente';
        } elseif (($filters['regional'] ?? '') !== '') {
            $groupLevel = 'agencia';
        } else {
            $profileLevel = strtoupper(trim((string) (($context['profile']['nivel'] ?? ''))));
            $scopeCode = strtoupper(trim((string) (($context['scope']['code'] ?? 'GLOBAL'))));

            if (in_array($profileLevel, ['GC', 'PA', 'AS'], true) || $scopeCode === 'SELF') {
                $groupLevel = 'produto';
            } elseif (in_array($profileLevel, ['GG', 'TL'], true)) {
                $groupLevel = 'gerente';
            } elseif ($profileLevel === 'AG' || $scopeCode === 'AG') {
                $groupLevel = $this->hasSnapshotManagementManagers($context, $filters, $anomes, $tableName)
                    ? 'gerente_gestao'
                    : 'gerente';
            } elseif (in_array($profileLevel, ['GR', 'GE'], true) || $scopeCode === 'GR') {
                $groupLevel = 'agencia';
            } else {
                $groupLevel = 'regional';
            }
        }

        $labels = [
            'regional' => 'Regional',
            'agencia' => 'Agencia',
            'gerente_gestao' => 'Gerente de gestao',
            'gerente' => 'Gerente',
            'produto' => 'Produto',
        ];
        $label = $labels[$groupLevel] ?? 'Regional';

        return [
            'group_level' => $groupLevel,
            'label' => $label,
            'ranking_title' => 'Desempenho por ' . $label,
            'status_title' => 'Status por ' . $label,
            'row_axis_label' => $label,
            'row_axis_sublabel' => 'Familias',
        ];
    }

    private function getExecutiveFocusRows(array $context, array $filters, string $anomes, string $tableName, string $groupLevel): array
    {
        if ($tableName === '' || !$this->hasProductivitySnapshotTable($tableName)) {
            return [];
        }

        $rows = [];

        foreach ($this->fetchProcedureAll(
            'sp_pobj_list_executive_focus_rows',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_anomes' => $anomes,
                    'p_group_level' => $groupLevel,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildSemestralProcedureHierarchyFilterParams($filters),
                $this->buildSemestralProcedureManagerFilterParams($filters),
                $this->buildSemestralProcedureMetricFilterParams($filters)
            )
        ) as $row) {
            $groupValue = trim((string) ($row['group_value'] ?? ''));

            if ($groupValue === '') {
                continue;
            }

            $metrics = $this->buildExecutiveScoreMetrics($row);
            $rows[] = [
                'key' => $groupValue,
                'display_label' => trim((string) ($row['display_label'] ?? $groupValue)),
                'meta_mens' => (float) ($metrics['meta_mens'] ?? 0.0),
                'real_mens' => (float) ($metrics['real_mens'] ?? 0.0),
                'p_mens' => (float) ($metrics['p_mens'] ?? 0.0),
                'deficit' => (float) ($metrics['deficit'] ?? 0.0),
                'row_count' => (int) ($row['row_count'] ?? 0),
                'atingimento_medio' => (float) ($row['atingimento_medio'] ?? 0.0),
                'valor_meta_total' => (float) ($row['valor_meta_total'] ?? 0.0),
                'valor_real_total' => (float) ($row['valor_real_total'] ?? 0.0),
                'realizado_count' => (int) ($row['realizado_count'] ?? 0),
            ];
        }

        return $rows;
    }

    private function buildExecutiveRankingData(array $groupRows): array
    {
        $topRows = $groupRows;
        usort($topRows, static function (array $left, array $right): int {
            $percentComparison = (float) ($right['p_mens'] ?? 0.0) <=> (float) ($left['p_mens'] ?? 0.0);

            if ($percentComparison !== 0) {
                return $percentComparison;
            }

            return strcmp((string) ($left['display_label'] ?? ''), (string) ($right['display_label'] ?? ''));
        });

        $bottomRows = $groupRows;
        usort($bottomRows, static function (array $left, array $right): int {
            $percentComparison = (float) ($left['p_mens'] ?? 0.0) <=> (float) ($right['p_mens'] ?? 0.0);

            if ($percentComparison !== 0) {
                return $percentComparison;
            }

            return strcmp((string) ($left['display_label'] ?? ''), (string) ($right['display_label'] ?? ''));
        });

        return [
            'top' => array_slice($topRows, 0, 5),
            'bottom' => array_slice($bottomRows, 0, 5),
            'top_all' => $topRows,
            'bottom_all' => $bottomRows,
        ];
    }

    private function buildExecutiveStatusData(array $groupRows, string $statusTitle): array
    {
        $hit = [];
        $quase = [];
        $longe = [];

        foreach ($groupRows as $row) {
            $percent = (float) ($row['p_mens'] ?? 0.0);

            if ($percent >= 100.0) {
                $hit[] = $row;
                continue;
            }

            if ($percent >= 90.0) {
                $quase[] = $row;
                continue;
            }

            $longe[] = $row;
        }

        usort($hit, static function (array $left, array $right): int {
            return ((float) ($right['p_mens'] ?? 0.0) <=> (float) ($left['p_mens'] ?? 0.0))
                ?: strcmp((string) ($left['display_label'] ?? ''), (string) ($right['display_label'] ?? ''));
        });
        usort($quase, static function (array $left, array $right): int {
            return ((float) ($right['p_mens'] ?? 0.0) <=> (float) ($left['p_mens'] ?? 0.0))
                ?: strcmp((string) ($left['display_label'] ?? ''), (string) ($right['display_label'] ?? ''));
        });
        usort($longe, static function (array $left, array $right): int {
            $deficitComparison = (float) ($right['deficit'] ?? 0.0) <=> (float) ($left['deficit'] ?? 0.0);

            if ($deficitComparison !== 0) {
                return $deficitComparison;
            }

            return strcmp((string) ($left['display_label'] ?? ''), (string) ($right['display_label'] ?? ''));
        });

        return [
            'title' => $statusTitle,
            'hit' => array_slice($hit, 0, 5),
            'quase' => array_slice($quase, 0, 5),
            'longe' => array_slice($longe, 0, 5),
            'hit_all' => $hit,
            'quase_all' => $quase,
            'longe_all' => $longe,
            'summary' => [
                'hit' => count($hit),
                'quase' => count($quase),
                'longe' => count($longe),
            ],
        ];
    }

    private function getExecutiveWindowMonths(string $anchorAnomes, int $limit = 6): array
    {
        try {
            $anchor = new \DateTimeImmutable(substr($anchorAnomes, 0, 4) . '-' . substr($anchorAnomes, 4, 2) . '-01');
        } catch (\Throwable $exception) {
            $anchor = new \DateTimeImmutable('today');
        }

        $months = [];

        for ($offset = max(0, $limit - 1); $offset >= 0; $offset--) {
            $monthDate = $anchor->sub(new \DateInterval('P' . $offset . 'M'));
            $anomes = $monthDate->format('Ym');
            $tableName = 'f_produtividade_mensal_' . $anomes;

            if (!$this->hasProductivitySnapshotTable($tableName)) {
                continue;
            }

            $months[] = [
                'anomes' => $anomes,
                'table' => $tableName,
                'label' => substr($this->formatMonthLabel($monthDate), 0, 3),
                'full_label' => $this->formatMonthLabel($monthDate) . ' ' . $monthDate->format('Y'),
            ];
        }

        return $months;
    }

    private function getExecutiveChartData(array $context, array $filters, array $windowMonths): array
    {
        if ($windowMonths === []) {
            return ['labels' => [], 'series' => [], 'max_value' => 100.0];
        }

        $labels = array_column($windowMonths, 'label');
        $familyMap = [];

        foreach ($windowMonths as $month) {
            $tableName = (string) ($month['table'] ?? '');
            $anomes = (string) ($month['anomes'] ?? '');

            if ($tableName === '' || $anomes === '') {
                continue;
            }

            $monthIndex = array_search($anomes, array_column($windowMonths, 'anomes'), true);

            if ($monthIndex === false) {
                continue;
            }

            foreach ($this->fetchProcedureAll(
                'sp_pobj_list_executive_focus_rows',
                array_merge(
                    [
                        'p_table_name' => $tableName,
                        'p_anomes' => $anomes,
                        'p_group_level' => 'familia',
                    ],
                    $this->buildSemestralProcedureScopeParams($context),
                    $this->buildSemestralProcedureHierarchyFilterParams($filters),
                    $this->buildSemestralProcedureManagerFilterParams($filters),
                    $this->buildSemestralProcedureMetricFilterParams($filters)
                )
            ) as $row) {
                $label = trim((string) ($row['display_label'] ?? ''));

                if ($label === '') {
                    continue;
                }

                if (!isset($familyMap[$label])) {
                    $familyMap[$label] = [
                        'label' => $label,
                        'values' => array_fill(0, count($windowMonths), 0.0),
                        'weight' => 0.0,
                    ];
                }

                $metrics = $this->buildExecutiveScoreMetrics($row);
                $familyMap[$label]['values'][(int) $monthIndex] = (float) ($metrics['p_mens'] ?? 0.0);
                $familyMap[$label]['weight'] += (float) ($metrics['meta_mens'] ?? 0.0);
            }
        }

        uasort($familyMap, static function (array $left, array $right): int {
            return ((float) ($right['weight'] ?? 0.0) <=> (float) ($left['weight'] ?? 0.0))
                ?: strcmp((string) ($left['label'] ?? ''), (string) ($right['label'] ?? ''));
        });

        $palette = ['#cc092f', '#0f766e', '#2563eb', '#dd8a00', '#6d28d9', '#475569'];
        $series = [];
        $maxValue = 100.0;
        $index = 0;

        foreach (array_slice(array_values($familyMap), 0, 4) as $familyRow) {
            $series[] = [
                'label' => (string) ($familyRow['label'] ?? ''),
                'values' => array_values((array) ($familyRow['values'] ?? [])),
                'color' => $palette[$index % count($palette)],
            ];

            foreach ((array) ($familyRow['values'] ?? []) as $value) {
                $maxValue = max($maxValue, (float) $value);
            }

            $index++;
        }

        return [
            'labels' => $labels,
            'series' => $series,
            'max_value' => min(150.0, max(100.0, ceil($maxValue / 10) * 10)),
        ];
    }

    private function getExecutiveHeatmapData(
        array $context,
        array $filters,
        string $anomes,
        string $tableName,
        array $focus,
        array $ranking,
        array $windowMonths
    ): array {
        $focusLevel = (string) ($focus['group_level'] ?? 'regional');
        $topRows = array_slice(array_values((array) ($ranking['top_all'] ?? [])), 0, 8);
        $rowKeys = array_column($topRows, 'key');
        $rowLabels = [];

        foreach ($topRows as $row) {
            $rowLabels[(string) ($row['key'] ?? '')] = (string) ($row['display_label'] ?? '');
        }

        $familyColumns = [];
        $sectionData = [];

        if ($rowKeys !== [] && $tableName !== '' && $this->hasProductivitySnapshotTable($tableName)) {
            $familyWeights = [];

            foreach ($this->fetchProcedureAll(
                'sp_pobj_list_executive_heatmap_sections',
                array_merge(
                    [
                        'p_table_name' => $tableName,
                        'p_anomes' => $anomes,
                        'p_group_level' => $focusLevel,
                        'p_row_keys_csv' => $this->encodeProcedureList(array_map('strval', $rowKeys)),
                    ],
                    $this->buildSemestralProcedureScopeParams($context),
                    $this->buildSemestralProcedureHierarchyFilterParams($filters),
                    $this->buildSemestralProcedureManagerFilterParams($filters),
                    $this->buildSemestralProcedureMetricFilterParams($filters)
                )
            ) as $row) {
                $rowKey = trim((string) ($row['row_key'] ?? ''));
                $familyKey = trim((string) ($row['family_key'] ?? ''));

                if ($rowKey === '' || $familyKey === '') {
                    continue;
                }

                $metrics = $this->buildExecutiveHeatmapMetrics($row);
                $sectionData[$rowKey][$familyKey] = [
                    'percent' => (float) ($metrics['percent'] ?? 0.0),
                    'real' => $metrics['real_total'] ?? null,
                    'meta' => $metrics['meta_total'] ?? null,
                    'absolute_mode' => (string) ($metrics['absolute_mode'] ?? 'none'),
                ];
                $familyWeights[$familyKey] = ($familyWeights[$familyKey] ?? 0.0) + (float) ($metrics['meta_total'] ?? 0.0);
            }

            arsort($familyWeights);

            foreach (array_slice(array_keys($familyWeights), 0, 6) as $familyKey) {
                $familyColumns[] = [
                    'key' => $familyKey,
                    'label' => $familyKey,
                ];
            }
        }

        $metaMonths = [];
        $metaData = [];

        foreach ($windowMonths as $month) {
            $metaMonths[] = [
                'key' => (string) ($month['anomes'] ?? ''),
                'label' => (string) ($month['label'] ?? ''),
                'full_label' => (string) ($month['full_label'] ?? ''),
            ];
        }

        if ($rowKeys !== [] && $windowMonths !== []) {
            foreach ($windowMonths as $month) {
                $monthAnomes = (string) ($month['anomes'] ?? '');
                $monthTable = (string) ($month['table'] ?? '');

                if ($monthAnomes === '' || $monthTable === '' || !$this->hasProductivitySnapshotTable($monthTable)) {
                    continue;
                }

                $monthRows = $this->getExecutiveFocusRows($context, $filters, $monthAnomes, $monthTable, $focusLevel);

                foreach ($monthRows as $monthRow) {
                    $rowKey = trim((string) ($monthRow['key'] ?? ''));

                    if ($rowKey === '' || !in_array($rowKey, $rowKeys, true)) {
                        continue;
                    }

                        $metrics = $this->buildExecutiveHeatmapMetrics($monthRow);
                        $metaData[$rowKey][$monthAnomes] = [
                            'meta' => $metrics['meta_total'] ?? null,
                            'real' => $metrics['real_total'] ?? null,
                            'percent' => $metrics['percent'] ?? null,
                            'absolute_mode' => (string) ($metrics['absolute_mode'] ?? 'none'),
                        ];
                    }
                }
            }

        $sectionRows = [];

        foreach ($topRows as $row) {
            $rowKey = trim((string) ($row['key'] ?? ''));

            if ($rowKey === '') {
                continue;
            }

            $sectionRows[] = [
                'key' => $rowKey,
                'label' => $rowLabels[$rowKey] ?? $rowKey,
            ];
        }

        return [
            'default_mode' => 'secoes',
            'secoes' => [
                'title' => 'Heatmap por ' . (string) ($focus['label'] ?? 'Regional'),
                'row_axis_label' => (string) ($focus['row_axis_label'] ?? 'Regional'),
                'row_axis_sublabel' => 'Familias',
                'rows' => $sectionRows,
                'columns' => $familyColumns,
                'data' => $sectionData,
            ],
            'meta' => [
                'title' => 'Variacao da meta por ' . (string) ($focus['label'] ?? 'Regional'),
                'row_axis_label' => (string) ($focus['row_axis_label'] ?? 'Regional'),
                'row_axis_sublabel' => 'Mes',
                'rows' => $sectionRows,
                'months' => $metaMonths,
                'data' => $metaData,
            ],
        ];
    }

    public function prepareSummaryFilters(array $context, string $periodId, array $requestedFilters, string $referenceEndDate = ''): array
    {
        $values = $this->normalizeSummaryFilters($requestedFilters);

        $snapshotTableName = $this->resolveProductivityFilterTableName($values, $referenceEndDate, $periodId);

        if ($snapshotTableName !== '') {
            return $this->prepareSemestralSummaryFilters($context, $values, $referenceEndDate, $periodId, $snapshotTableName);
        }

        return $this->buildEmptySummaryFilters($values);
    }

    private function hydrateProfileHierarchySelections(array $context, string $periodId, array $filters): array
    {
        $profile = $context['profile'] ?? [];
        $junctions = $context['junctions'] ?? [];
        $level = strtoupper(trim((string) ($profile['nivel'] ?? '')));
        $functional = trim((string) ($profile['funcional'] ?? ''));

        if ($functional === '') {
            return $filters;
        }

        if (in_array($level, ['GC', 'PA', 'AS'], true)) {
            return $this->mergeResolvedFilters(
                $filters,
                array_merge(
                    ['gerente' => $functional],
                    $this->resolveHierarchyPathForField($context, $periodId, 'f.funcional = :selected_value', $functional)
                )
            );
        }

        $primaryAgency = $this->resolvePrimaryJunction($junctions, 'AG');
        $primaryRegional = $this->resolvePrimaryJunction($junctions, 'GR');
        $primaryDirectorate = $this->resolvePrimaryJunction($junctions, 'DR');

        if (in_array($level, ['GG', 'TL'], true) && $primaryAgency !== '') {
            return $this->mergeResolvedFilters(
                $filters,
                array_merge(
                    ['gerente_gestao' => $functional],
                    $this->resolveHierarchyPathForField($context, $periodId, 'hgg.funcional = :selected_value', $functional)
                )
            );
        }

        if ($level === 'AG' && $primaryAgency !== '') {
            return $this->mergeResolvedFilters(
                $filters,
                array_merge(
                    ['agencia' => $primaryAgency],
                    $this->resolveHierarchyPathForField($context, $periodId, 'f.juncao_ag = :selected_value', $primaryAgency)
                )
            );
        }

        if (in_array($level, ['GR', 'GE'], true) && $primaryRegional !== '') {
            return $this->mergeResolvedFilters(
                $filters,
                array_merge(
                    ['regional' => $primaryRegional],
                    $this->resolveHierarchyPathForField($context, $periodId, 'f.juncao_gr = :selected_value', $primaryRegional)
                )
            );
        }

        if ($level === 'DR' && $primaryDirectorate !== '') {
            return $this->mergeResolvedFilters(
                $filters,
                array_merge(
                    ['diretoria' => $primaryDirectorate],
                    $this->resolveHierarchyPathForField($context, $periodId, 'f.juncao_dr = :selected_value', $primaryDirectorate)
                )
            );
        }

        return $filters;
    }

    private function hydrateHierarchySelections(array $context, string $periodId, array $filters): array
    {
        if (($filters['gerente'] ?? '') !== '') {
            return $this->mergeResolvedFilters(
                $filters,
                $this->resolveHierarchyPathForField($context, $periodId, 'f.funcional = :selected_value', $filters['gerente'])
            );
        }

        if (($filters['gerente_gestao'] ?? '') !== '') {
            $resolved = array_merge(
                ['gerente_gestao' => $filters['gerente_gestao']],
                $this->resolveHierarchyPathForField($context, $periodId, 'hgg.funcional = :selected_value', $filters['gerente_gestao'])
            );

            return $this->mergeResolvedFilters($filters, $resolved);
        }

        if (($filters['agencia'] ?? '') !== '') {
            return $this->mergeResolvedFilters(
                $filters,
                $this->resolveHierarchyPathForField($context, $periodId, 'f.juncao_ag = :selected_value', $filters['agencia'])
            );
        }

        if (($filters['regional'] ?? '') !== '') {
            return $this->mergeResolvedFilters(
                $filters,
                $this->resolveHierarchyPathForField($context, $periodId, 'f.juncao_gr = :selected_value', $filters['regional'])
            );
        }

        if (($filters['diretoria'] ?? '') !== '') {
            return $this->mergeResolvedFilters(
                $filters,
                $this->resolveHierarchyPathForField($context, $periodId, 'f.juncao_dr = :selected_value', $filters['diretoria'])
            );
        }

        return $filters;
    }

    private function mergeResolvedFilters(array $filters, array $resolvedValues): array
    {
        foreach ($resolvedValues as $key => $value) {
            if (!array_key_exists($key, $filters) || $filters[$key] !== '' || $value === '') {
                continue;
            }

            $filters[$key] = $value;
        }

        return $filters;
    }

    private function resolveHierarchyPathForField(array $context, string $periodId, string $fieldSql, string $selectedValue): array
    {
        if ($selectedValue === '') {
            return [];
        }

        $selector = $this->resolveHierarchyPathSelector($fieldSql);

        if (
            $selector === ''
            || !$this->hasDatabaseTable('fMeta')
            || !$this->hasDatabaseTable('dHierarquia')
            || !$this->hasDatabaseTable('fMultiJuncao')
        ) {
            return [];
        }

        $scope = (array) ($context['scope'] ?? []);
        $procedureName = $this->hasManagementRelationTable()
            ? 'sp_pobj_resolve_hierarchy_path_with_management'
            : 'sp_pobj_resolve_hierarchy_path_without_management';
        $rows = $this->fetchProcedureAll(
            $procedureName,
            [
                'p_period_id' => $periodId,
                'p_scope_code' => strtoupper(trim((string) ($scope['code'] ?? 'GLOBAL'))),
                'p_scope_functional' => trim((string) ($scope['functional'] ?? '')),
                'p_scope_allowed_csv' => $this->encodeProcedureList((array) ($scope['allowed'] ?? [])),
                'p_selector' => $selector,
                'p_selected_value' => $selectedValue,
            ]
        );

        if ($rows === []) {
            return [];
        }

        return [
            'segmento' => $this->resolveSingleValue($rows, 'segmento'),
            'diretoria' => $this->resolveSingleValue($rows, 'juncao_dr'),
            'regional' => $this->resolveSingleValue($rows, 'juncao_gr'),
            'agencia' => $this->resolveSingleValue($rows, 'juncao_ag'),
            'gerente_gestao' => $this->resolveSingleValue($rows, 'gerente_gestao'),
        ];
    }

    private function resolveHierarchyPathSelector(string $fieldSql): string
    {
        switch (trim($fieldSql)) {
            case 'f.funcional = :selected_value':
                return 'GERENTE';
            case 'hgg.funcional = :selected_value':
                return 'GERENTE_GESTAO';
            case 'f.juncao_ag = :selected_value':
                return 'AGENCIA';
            case 'f.juncao_gr = :selected_value':
                return 'REGIONAL';
            case 'f.juncao_dr = :selected_value':
                return 'DIRETORIA';
            default:
                return '';
        }
    }

    private function resolveSingleValue(array $rows, string $field): string
    {
        $values = [];

        foreach ($rows as $row) {
            $value = trim((string) ($row[$field] ?? ''));

            if ($value === '') {
                continue;
            }

            $values[$value] = true;
        }

        if (count($values) !== 1) {
            return '';
        }

        foreach ($values as $value => $_unused) {
            return (string) $value;
        }

        return '';
    }

    private function resolvePrimaryJunction(array $junctions, string $type): string
    {
        foreach ($junctions as $junction) {
            if (strtoupper((string) ($junction['tipo_juncao'] ?? '')) !== $type) {
                continue;
            }

            if ((int) ($junction['principal_sn'] ?? 0) !== 1) {
                continue;
            }

            return trim((string) ($junction['juncao'] ?? ''));
        }

        foreach ($junctions as $junction) {
            if (strtoupper((string) ($junction['tipo_juncao'] ?? '')) === $type) {
                return trim((string) ($junction['juncao'] ?? ''));
            }
        }

        return '';
    }

    private function getIndicatorRows(array $context, string $periodId, array $filters = [], array $dateRange = []): array
    {
        $filters = $this->normalizeSummaryFilters($filters);
        $rows = $this->fetchProcedureAll(
            'sp_pobj_list_indicator_rows_base',
            array_merge(
                [
                    'p_period_id' => $periodId,
                    'p_start_date' => ($dateRange['start'] ?? '') !== '' ? trim((string) $dateRange['start']) : null,
                    'p_end_date' => ($dateRange['end'] ?? '') !== '' ? trim((string) $dateRange['end']) : null,
                    'p_subindicador' => trim((string) ($filters['subindicador'] ?? '')),
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildExecutiveFactProcedureFilterParams($filters)
            )
        );

        $metaMap = $this->sumByIndicator('fMeta', 'valor_meta', $context, $periodId, $filters, false, $dateRange);
        $percentualMetaMap = $this->averageByIndicator('fMeta', 'valor_meta', $context, $periodId, $filters, $dateRange);
        $realizadoMap = $this->sumByIndicator('fRealizado', 'valor_realizado', $context, $periodId, $filters, true, $dateRange);
        $variavelMap = $this->sumByIndicator('fVariavel', 'variavel_realizada', $context, $periodId, $filters, false, $dateRange);
        $variavelMetaMap = $this->sumByIndicator('fVariavel', 'variavel_meta', $context, $periodId, $filters, false, $dateRange);
        $metaDateMap = $this->maxDateByIndicator('fMeta', 'dt_meta', $context, $periodId, $filters, false, $dateRange);
        $realizadoDateMap = $this->maxDateByIndicator('fRealizado', 'dt_realizado', $context, $periodId, $filters, true, $dateRange);
        $pontosDateMap = $this->maxDateByIndicator('fPontos', 'data_realizado', $context, $periodId, $filters, false, $dateRange);
        $variavelDateMap = $this->maxDateByIndicator('fVariavel', 'data_realizado', $context, $periodId, $filters, false, $dateRange);
        $subindicatorTotalsMap = $this->getSubindicatorTotalsByIndicator($context, $periodId, $filters, $dateRange);

        foreach ($rows as &$row) {
            $indicatorId = (string) $row['id_indicador'];
            $peso = (float) ($row['peso'] ?? 0.0);
            $ultimaAtualizacao = $this->maxDateValue(
                $this->maxDateValue($metaDateMap[$indicatorId] ?? null, $realizadoDateMap[$indicatorId] ?? null),
                $this->maxDateValue($pontosDateMap[$indicatorId] ?? null, $variavelDateMap[$indicatorId] ?? null)
            );
            $metricType = strtoupper((string) ($row['id_tipo_indicador'] ?? 'VALOR'));
            $metaValue = $metricType === 'PERCENTUAL'
                ? (float) ($percentualMetaMap[$indicatorId] ?? ($metaMap[$indicatorId] ?? 0.0))
                : (float) ($metaMap[$indicatorId] ?? 0.0);
            $realizadoValue = (float) ($realizadoMap[$indicatorId] ?? 0.0);

            $row['meta'] = $metaValue;
            $row['realizado'] = $realizadoValue;
            $row['peso'] = $peso;
            $row['variavel'] = $variavelMap[$indicatorId] ?? 0.0;
            $row['variavel_meta'] = $variavelMetaMap[$indicatorId] ?? 0.0;
            $row['subindicadores'] = $subindicatorTotalsMap[$indicatorId] ?? [];

            if ($metricType !== 'PERCENTUAL' && $row['subindicadores'] !== []) {
                $row['realizado'] = array_reduce($row['subindicadores'], static function (float $carry, array $subindicator): float {
                    return $carry + (float) ($subindicator['total'] ?? 0.0);
                }, 0.0);
            }

            if ($metricType === 'PERCENTUAL') {
                $percentualMetrics = $this->resolvePercentualMetrics(
                    $metaValue,
                    $realizadoValue,
                    $row['subindicadores']
                );

                $row['meta'] = $percentualMetrics['meta'];
                $row['realizado'] = $percentualMetrics['realizado'];
                $row['percentual_atingimento'] = $percentualMetrics['atingimento'];
                $row['realizado_absoluto'] = $percentualMetrics['numerador'];
                $row['base_absoluta'] = $percentualMetrics['denominador'];
                $row['realizado_absoluto_label'] = $percentualMetrics['numerador_label'];
                $row['base_absoluta_label'] = $percentualMetrics['denominador_label'];
                $row['usa_base_absoluta'] = $percentualMetrics['por_base'];
            } else {
                $row['percentual_atingimento'] = $row['meta'] > 0 ? ($row['realizado'] / $row['meta']) * 100 : 0.0;
                $row['realizado_absoluto'] = null;
                $row['base_absoluta'] = null;
                $row['realizado_absoluto_label'] = '';
                $row['base_absoluta_label'] = '';
                $row['usa_base_absoluta'] = false;
            }

            $row['pontos_meta'] = $peso;
            $row['pontos'] = $this->calculateIndicatorPoints($row['percentual_atingimento'], $peso);
            $row['atingiu'] = $row['meta'] > 0 && $row['realizado'] >= $row['meta'];
            $row['ultima_atualizacao'] = $ultimaAtualizacao;
        }
        unset($row);

        if (($filters['status_indicadores'] ?? '') !== '') {
            $rows = array_values(array_filter($rows, static function (array $row) use ($filters): bool {
                if ($filters['status_indicadores'] === 'ATINGIDO') {
                    return (bool) ($row['atingiu'] ?? false);
                }

                if ($filters['status_indicadores'] === 'NAO_ATINGIDO') {
                    return !(bool) ($row['atingiu'] ?? false);
                }

                return true;
            }));
        }

        return $rows;
    }

    private function calculateIndicatorPoints(float $percentualAtingimento, float $peso): float
    {
        if ($peso <= 0) {
            return 0.0;
        }

        return ($percentualAtingimento / 100) * $peso;
    }

    private function getSubindicatorTotalsByIndicator(array $context, string $periodId, array $filters = [], array $dateRange = []): array
    {
        $filters = $this->normalizeSummaryFilters($filters);
        $filters['subindicador'] = '';

        $grouped = [];

        foreach ($this->fetchProcedureAll(
            'sp_pobj_list_subindicator_totals_by_indicator',
            array_merge(
                [
                    'p_start_date' => trim((string) ($dateRange['start'] ?? '')),
                    'p_end_date' => trim((string) ($dateRange['end'] ?? '')),
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildExecutiveFactProcedureFilterParams($filters)
            )
        ) as $row) {
            $indicatorId = (string) ($row['id_indicador'] ?? '');

            if ($indicatorId === '') {
                continue;
            }

            $grouped[$indicatorId][] = [
                'id_subindicador' => (int) ($row['id_subindicador'] ?? 0),
                'nome_subindicador' => (string) ($row['nome_subindicador'] ?? ''),
                'ordem_exibicao' => (int) ($row['ordem_exibicao'] ?? 999),
                'total' => (float) ($row['total'] ?? 0.0),
            ];
        }

        return $grouped;
    }

    private function resolvePercentualMetrics(float $meta, float $realizado, array $subindicatorRows): array
    {
        $meta = min(100.0, max(0.0, $meta));
        $resolvedRealizado = min(100.0, max(0.0, $realizado));
        $numerador = null;
        $denominador = null;
        $numeradorLabel = '';
        $denominadorLabel = '';
        $usedAbsoluteBase = false;

        if ($subindicatorRows !== []) {
            $denominatorRow = $this->findSubindicatorRowByKeywords($subindicatorRows, ['carteira', 'base', 'universo', 'elegiv', 'total']);

            if ($denominatorRow === null) {
                $denominatorRow = $this->pickLargestSubindicatorRow($subindicatorRows);
            }

            if ($denominatorRow !== null) {
                $numeratorRow = $this->findSubindicatorRowByKeywords($subindicatorRows, ['contato', 'contat', 'acion', 'abord', 'atingid', 'realizado', 'falad']);

                if ($numeratorRow === null) {
                    $remainingTotal = 0.0;
                    $remainingLabel = 'Realizado';

                    foreach ($subindicatorRows as $subindicatorRow) {
                        if ((int) ($subindicatorRow['id_subindicador'] ?? 0) === (int) ($denominatorRow['id_subindicador'] ?? 0)) {
                            continue;
                        }

                        $remainingTotal += (float) ($subindicatorRow['total'] ?? 0.0);
                    }

                    if ($remainingTotal > 0) {
                        $numeratorRow = [
                            'total' => $remainingTotal,
                            'nome_subindicador' => $remainingLabel,
                        ];
                    }
                }

                $denominatorTotal = (float) ($denominatorRow['total'] ?? 0.0);
                $numeratorTotal = (float) ($numeratorRow['total'] ?? 0.0);

                if ($denominatorTotal > 0 && $numeratorTotal >= 0) {
                    $resolvedRealizado = min(100.0, max(0.0, ($numeratorTotal / $denominatorTotal) * 100));
                    $numerador = $numeratorTotal;
                    $denominador = $denominatorTotal;
                    $numeradorLabel = (string) ($numeratorRow['nome_subindicador'] ?? 'Realizado');
                    $denominadorLabel = (string) ($denominatorRow['nome_subindicador'] ?? 'Base');
                    $usedAbsoluteBase = true;
                }
            }
        }

        $atingimento = $meta > 0 ? min(100.0, max(0.0, ($resolvedRealizado / $meta) * 100)) : 0.0;

        return [
            'meta' => $meta,
            'realizado' => $resolvedRealizado,
            'atingimento' => $atingimento,
            'numerador' => $numerador,
            'denominador' => $denominador,
            'numerador_label' => $numeradorLabel,
            'denominador_label' => $denominadorLabel,
            'por_base' => $usedAbsoluteBase,
        ];
    }

    private function findSubindicatorRowByKeywords(array $subindicatorRows, array $keywords): ?array
    {
        foreach ($subindicatorRows as $subindicatorRow) {
            $name = strtolower((string) ($subindicatorRow['nome_subindicador'] ?? ''));

            foreach ($keywords as $keyword) {
                if ($keyword !== '' && strpos($name, $keyword) !== false) {
                    return $subindicatorRow;
                }
            }
        }

        return null;
    }

    private function pickLargestSubindicatorRow(array $subindicatorRows): ?array
    {
        $selected = null;

        foreach ($subindicatorRows as $subindicatorRow) {
            if ($selected === null || (float) ($subindicatorRow['total'] ?? 0.0) > (float) ($selected['total'] ?? 0.0)) {
                $selected = $subindicatorRow;
            }
        }

        return $selected;
    }

    private function maxDateByIndicator(string $table, string $dateField, array $context, string $periodId, array $filters = [], bool $supportsSubindicator = false, array $dateRange = []): array
    {
        $this->quoteTableIdentifier($table);
        $this->quoteColumnIdentifier($dateField);

        $dates = [];

        foreach ($this->fetchProcedureAll(
            'sp_pobj_list_indicator_aggregate_rows',
            array_merge(
                [
                    'p_table_name' => $table,
                    'p_value_field' => $dateField,
                    'p_date_field' => $dateField,
                    'p_aggregate_type' => 'MAX_DATE',
                    'p_supports_subindicator' => $supportsSubindicator ? 1 : 0,
                    'p_start_date' => ($dateRange['start'] ?? '') !== '' ? trim((string) $dateRange['start']) : null,
                    'p_end_date' => ($dateRange['end'] ?? '') !== '' ? trim((string) $dateRange['end']) : null,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildIndicatorAggregateProcedureFilterParams($filters)
            )
        ) as $row) {
            $dates[(string) $row['id_indicador']] = (string) ($row['last_date'] ?? '');
        }

        return $dates;
    }

    private function maxDateValue(?string $left, ?string $right): string
    {
        $left = trim((string) $left);
        $right = trim((string) $right);

        if ($left === '') {
            return $right;
        }

        if ($right === '') {
            return $left;
        }

        return strcmp($left, $right) >= 0 ? $left : $right;
    }

    private function sumByIndicator(string $table, string $valueField, array $context, string $periodId, array $filters = [], bool $supportsSubindicator = false, array $dateRange = []): array
    {
        $this->quoteTableIdentifier($table);
        $this->quoteColumnIdentifier($valueField);
        $dateField = $this->resolveFactDateField($table);

        if ($dateField === '') {
            throw new \InvalidArgumentException('Tabela sem campo de data mapeado para agregacao por indicador.');
        }

        $this->quoteColumnIdentifier($dateField);

        $totals = [];

        foreach ($this->fetchProcedureAll(
            'sp_pobj_list_indicator_aggregate_rows',
            array_merge(
                [
                    'p_table_name' => $table,
                    'p_value_field' => $valueField,
                    'p_date_field' => $dateField,
                    'p_aggregate_type' => 'SUM',
                    'p_supports_subindicator' => $supportsSubindicator ? 1 : 0,
                    'p_start_date' => ($dateRange['start'] ?? '') !== '' ? trim((string) $dateRange['start']) : null,
                    'p_end_date' => ($dateRange['end'] ?? '') !== '' ? trim((string) $dateRange['end']) : null,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildIndicatorAggregateProcedureFilterParams($filters)
            )
        ) as $row) {
            $totals[(string) $row['id_indicador']] = (float) $row['total'];
        }

        return $totals;
    }

    private function averageByIndicator(string $table, string $valueField, array $context, string $periodId, array $filters = [], array $dateRange = []): array
    {
        $this->quoteTableIdentifier($table);
        $this->quoteColumnIdentifier($valueField);
        $dateField = $this->resolveFactDateField($table);

        if ($dateField === '') {
            throw new \InvalidArgumentException('Tabela sem campo de data mapeado para media por indicador.');
        }

        $this->quoteColumnIdentifier($dateField);

        $averages = [];

        foreach ($this->fetchProcedureAll(
            'sp_pobj_list_indicator_aggregate_rows',
            array_merge(
                [
                    'p_table_name' => $table,
                    'p_value_field' => $valueField,
                    'p_date_field' => $dateField,
                    'p_aggregate_type' => 'AVG',
                    'p_supports_subindicator' => 0,
                    'p_start_date' => ($dateRange['start'] ?? '') !== '' ? trim((string) $dateRange['start']) : null,
                    'p_end_date' => ($dateRange['end'] ?? '') !== '' ? trim((string) $dateRange['end']) : null,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildIndicatorAggregateProcedureFilterParams($filters)
            )
        ) as $row) {
            $averages[(string) $row['id_indicador']] = (float) $row['average_value'];
        }

        return $averages;
    }

    private function normalizeSummaryFilters(array $requestedFilters): array
    {
        $normalized = [];
        $allowedKeys = [
            'segmento',
            'diretoria',
            'regional',
            'agencia',
            'gerente_gestao',
            'gerente',
            'familia',
            'indicadores',
            'subindicador',
            'status_indicadores',
            'grupo',
            'visao_acumulada',
        ];

        foreach ($allowedKeys as $key) {
            $normalized[$key] = trim((string) ($requestedFilters[$key] ?? ''));
        }

        return $normalized;
    }

    private function resolveExecutiveFocusMeta(array $filters): array
    {
        if (($filters['gerente'] ?? '') !== '') {
            return [
                'level' => 'familia',
                'label' => 'FamÃ­lia',
                'ranking_title' => 'Desempenho por FamÃ­lia',
                'status_title' => 'Status por FamÃ­lia',
            ];
        }

        if (($filters['gerente_gestao'] ?? '') !== '') {
            return [
                'level' => 'gerente',
                'label' => 'Gerente',
                'ranking_title' => 'Desempenho por Gerente',
                'status_title' => 'Status por Gerente',
            ];
        }

        if (($filters['agencia'] ?? '') !== '') {
            return [
                'level' => 'gerente_gestao',
                'label' => 'Gerente de gestÃ£o',
                'ranking_title' => 'Desempenho por Gerente de GestÃ£o',
                'status_title' => 'Status por Gerente de GestÃ£o',
            ];
        }

        if (($filters['regional'] ?? '') !== '') {
            return [
                'level' => 'agencia',
                'label' => 'AgÃªncia',
                'ranking_title' => 'Desempenho por AgÃªncia',
                'status_title' => 'Status por AgÃªncia',
            ];
        }

        if (($filters['diretoria'] ?? '') !== '') {
            return [
                'level' => 'regional',
                'label' => 'Regional',
                'ranking_title' => 'Desempenho por Regional',
                'status_title' => 'Status por Regional',
            ];
        }

        if (($filters['segmento'] ?? '') !== '') {
            return [
                'level' => 'diretoria',
                'label' => 'Diretoria',
                'ranking_title' => 'Desempenho por Diretoria',
                'status_title' => 'Status por Diretoria',
            ];
        }

        return [
            'level' => 'regional',
            'label' => 'Regional',
            'ranking_title' => 'Desempenho por Regional',
            'status_title' => 'Status por Regional',
        ];
    }

    private function resolveExecutiveDateContext(array $context, string $periodId, array $filters = [], string $referenceStartDate = '', string $referenceEndDate = ''): array
    {
        $period = $this->getPeriodDefinition($periodId);
        $periodStartRaw = clamp_date_to_today($period['dt_inicio_periodo'] ?? null);
        $periodEndRaw = clamp_date_to_today($period['dt_fim_periodo'] ?? null);
        $rangeStartRaw = clamp_date_to_today($referenceStartDate !== '' ? $referenceStartDate : $periodStartRaw);
        $rangeEndRaw = clamp_date_to_today($referenceEndDate !== '' ? $referenceEndDate : $periodEndRaw);

        if ($rangeStartRaw === '') {
            $rangeStartRaw = $rangeEndRaw !== '' ? $rangeEndRaw : (new \DateTimeImmutable('today'))->format('Y-m-d');
        }

        if ($rangeEndRaw === '') {
            $rangeEndRaw = $rangeStartRaw;
        }

        try {
            $rangeStart = new \DateTimeImmutable($rangeStartRaw);
            $rangeEnd = new \DateTimeImmutable($rangeEndRaw);
        } catch (\Throwable $exception) {
            $rangeStart = new \DateTimeImmutable('today');
            $rangeEnd = new \DateTimeImmutable('today');
        }

        if ($rangeStart > $rangeEnd) {
            [$rangeStart, $rangeEnd] = [$rangeEnd, $rangeStart];
        }

        $monthAnchor = $rangeEnd->modify('first day of this month');
        $forecastEnd = $monthAnchor->modify('last day of this month');
        $historyAnchor = $this->resolveExecutiveHistoryAnchor($context, $periodId, $filters, $rangeEnd->format('Y-m-d'));
        $historyMonthAnchor = $historyAnchor->modify('first day of this month');
        $chartStart = $historyMonthAnchor
            ->sub(new \DateInterval('P5M'))
            ->modify('first day of this month');
        $metaStart = $historyMonthAnchor
            ->sub(new \DateInterval('P5M'))
            ->modify('first day of this month');
        $chartMonths = [];
        $metaMonths = [];
        $cursor = $chartStart;

        while ($cursor <= $historyMonthAnchor) {
            $chartMonths[] = [
                'key' => $cursor->format('Y-m'),
                'label' => $this->formatExecutiveMonthShortLabel($cursor),
            ];
            $cursor = $cursor->add(new \DateInterval('P1M'));
        }

        $cursor = $metaStart;

        while ($cursor <= $historyMonthAnchor) {
            $metaMonths[] = [
                'key' => $cursor->format('Y-m'),
                'label' => $this->formatExecutiveMonthYearLabel($cursor),
            ];
            $cursor = $cursor->add(new \DateInterval('P1M'));
        }

        return [
            'period' => $period,
            'range' => [
                'start' => $rangeStart->format('Y-m-d'),
                'end' => $rangeEnd->format('Y-m-d'),
            ],
            'month_range' => [
                'start' => $monthAnchor->format('Y-m-d'),
                'end' => $rangeEnd->format('Y-m-d'),
            ],
            'forecast_range' => [
                'start' => $monthAnchor->format('Y-m-d'),
                'end' => $forecastEnd->format('Y-m-d'),
            ],
            'chart_range' => [
                'start' => $chartStart->format('Y-m-d'),
                'end' => $historyAnchor->format('Y-m-d'),
                'months' => $chartMonths,
            ],
            'meta_range' => [
                'start' => $metaStart->format('Y-m-d'),
                'end' => $historyAnchor->format('Y-m-d'),
                'months' => $metaMonths,
            ],
            'month_label' => $this->formatMonthLabel($monthAnchor) . ' ' . $monthAnchor->format('Y'),
            'business_days' => resolve_business_day_snapshot(
                $monthAnchor->format('Y-m-d'),
                $forecastEnd->format('Y-m-d'),
                $rangeEnd->format('Y-m-d')
            ),
        ];
    }

    private function resolveExecutiveHistoryAnchor(array $context, string $periodId, array $filters = [], string $fallbackDate = ''): \DateTimeImmutable
    {
        $row = $this->fetchProcedureRow(
            'sp_pobj_get_executive_history_anchor_dates',
            array_merge(
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildExecutiveFactProcedureFilterParams($filters)
            )
        ) ?: [];
        $pointDate = trim((string) ($row['point_date'] ?? ''));
        $metaDate = trim((string) ($row['meta_date'] ?? ''));

        $resolvedDate = $this->maxDateValue($pointDate, $metaDate);

        if ($resolvedDate === '') {
            $resolvedDate = clamp_date_to_today($fallbackDate !== '' ? $fallbackDate : null);
        }

        try {
            return new \DateTimeImmutable($resolvedDate !== '' ? $resolvedDate : 'today');
        } catch (\Throwable $exception) {
            return new \DateTimeImmutable('today');
        }
    }

    private function getPeriodDefinition(string $periodId): array
    {
        $row = $this->fetchProcedureRow('sp_pobj_get_period_definition', ['p_period_id' => $periodId]);

        return $row ?: [
            'id_periodo' => $periodId,
            'descricao_periodo' => $periodId,
            'dt_inicio_periodo' => '',
            'dt_fim_periodo' => '',
        ];
    }

    private function resolveFactDateRange(string $periodId, string $referenceStartDate = '', string $referenceEndDate = ''): array
    {
        $period = $this->getPeriodDefinition($periodId);
        $periodStartRaw = clamp_date_to_today($period['dt_inicio_periodo'] ?? null);
        $periodEndRaw = clamp_date_to_today($period['dt_fim_periodo'] ?? null);
        $rangeStartRaw = clamp_date_to_today($referenceStartDate !== '' ? $referenceStartDate : $periodStartRaw);
        $rangeEndRaw = clamp_date_to_today($referenceEndDate !== '' ? $referenceEndDate : $periodEndRaw);

        if ($rangeStartRaw === '') {
            $rangeStartRaw = $rangeEndRaw !== '' ? $rangeEndRaw : (new \DateTimeImmutable('today'))->format('Y-m-d');
        }

        if ($rangeEndRaw === '') {
            $rangeEndRaw = $rangeStartRaw;
        }

        try {
            $rangeStart = new \DateTimeImmutable($rangeStartRaw);
            $rangeEnd = new \DateTimeImmutable($rangeEndRaw);
        } catch (\Throwable $exception) {
            $rangeStart = new \DateTimeImmutable('today');
            $rangeEnd = new \DateTimeImmutable('today');
        }

        if ($rangeStart > $rangeEnd) {
            [$rangeStart, $rangeEnd] = [$rangeEnd, $rangeStart];
        }

        return [
            'start' => $rangeStart->format('Y-m-d'),
            'end' => $rangeEnd->format('Y-m-d'),
        ];
    }

    private function resolveFactDateField(string $table): string
    {
        $map = [
            'fMeta' => 'dt_meta',
            'fRealizado' => 'dt_realizado',
            'fPontos' => 'data_realizado',
            'fVariavel' => 'data_realizado',
            'fDetalhe' => 'data_transacao',
        ];

        return $map[$table] ?? '';
    }

    private function buildExecutiveKpis(array $context, string $periodId, array $filters, array $dateContext): array
    {
        $monthlyTotals = $this->fetchExecutivePointSummary(
            $context,
            $periodId,
            $filters,
            $dateContext['month_range']['start'],
            $dateContext['month_range']['end']
        );
        $accumulatedTotals = $this->fetchExecutivePointSummary(
            $context,
            $periodId,
            $filters,
            $dateContext['range']['start'],
            $dateContext['range']['end']
        );
        $monthlyMeta = (float) ($monthlyTotals['meta'] ?? 0.0);
        $monthlyReal = (float) ($monthlyTotals['real'] ?? 0.0);
        $forecast = $monthlyReal;
        $businessDays = $dateContext['business_days'];
        $canExtrapolateForecast = $this->hasExecutiveDailyGranularity(
            $context,
            $filters,
            (string) ($dateContext['month_range']['start'] ?? ''),
            (string) ($dateContext['month_range']['end'] ?? '')
        );

        if ($canExtrapolateForecast && (int) ($businessDays['elapsed'] ?? 0) > 0) {
            $forecast = ($monthlyReal / (int) $businessDays['elapsed']) * (int) ($businessDays['total'] ?? 0);
        }

        $percentMens = $monthlyMeta > 0 ? ($monthlyReal / $monthlyMeta) * 100 : 0.0;
        $percentForecast = $monthlyMeta > 0 ? ($forecast / $monthlyMeta) * 100 : 0.0;

        return [
            'real_mens' => $monthlyReal,
            'meta_mens' => $monthlyMeta,
            'real_acum' => (float) ($accumulatedTotals['real'] ?? 0.0),
            'meta_acum' => (float) ($accumulatedTotals['meta'] ?? 0.0),
            'forecast' => $forecast,
            'gap' => $monthlyMeta - $monthlyReal,
            'percent_mens' => max(0.0, min(140.0, $percentMens)),
            'percent_forecast' => max(0.0, min(140.0, $percentForecast)),
            'business_days' => $businessDays,
        ];
    }

    private function hasExecutiveDailyGranularity(array $context, array $filters, string $startDate, string $endDate): bool
    {
        if ($startDate === '' || $endDate === '') {
            return false;
        }

        return (int) ($this->fetchProcedureValue(
            'sp_pobj_count_executive_daily_granularity_days',
            array_merge(
                [
                    'p_start_date' => $startDate,
                    'p_end_date' => $endDate,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildExecutiveFactProcedureFilterParams($filters)
            ),
            'day_count'
        ) ?? 0) > 3;
    }

    private function fetchExecutivePointSummary(array $context, string $periodId, array $filters, string $startDate, string $endDate): array
    {
        if ($startDate === '' || $endDate === '') {
            return ['real' => 0.0, 'meta' => 0.0];
        }

        $row = $this->fetchProcedureRow(
            'sp_pobj_get_executive_point_summary',
            array_merge(
                [
                    'p_start_date' => $startDate,
                    'p_end_date' => $endDate,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildExecutiveFactProcedureFilterParams($filters)
            )
        ) ?: [];

        return [
            'real' => (float) ($row['real_total'] ?? 0.0),
            'meta' => (float) ($row['meta_total'] ?? 0.0),
        ];
    }

    private function buildExecutiveChart(array $context, string $periodId, array $filters, array $dateContext): array
    {
        $monthKeys = [];
        $labels = [];

        foreach ($dateContext['chart_range']['months'] as $month) {
            $monthKey = (string) ($month['key'] ?? '');

            if ($monthKey === '') {
                continue;
            }

            $monthKeys[] = $monthKey;
            $labels[] = (string) ($month['label'] ?? $monthKey);
        }

        $palette = ['#cc092f', '#0f766e', '#2563eb', '#d97706', '#7c3aed', '#15803d'];
        $seriesMeta = [];
        $seriesValues = [];

        foreach ($this->fetchProcedureAll(
            'sp_pobj_list_executive_chart_totals',
            array_merge(
                [
                    'p_start_date' => (string) ($dateContext['chart_range']['start'] ?? ''),
                    'p_end_date' => (string) ($dateContext['chart_range']['end'] ?? ''),
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildExecutiveFactProcedureFilterParams($filters)
            )
        ) as $row) {
            $sectionKey = trim((string) ($row['section_key'] ?? ''));
            $monthKey = trim((string) ($row['month_key'] ?? ''));

            if ($sectionKey === '' || $monthKey === '') {
                continue;
            }

            if (!isset($seriesMeta[$sectionKey])) {
                $seriesMeta[$sectionKey] = [
                    'label' => (string) ($row['section_label'] ?? $sectionKey),
                    'order' => (int) ($row['section_order'] ?? 999),
                ];
            }

            $metaTotal = (float) ($row['meta_total'] ?? 0.0);
            $realTotal = (float) ($row['real_total'] ?? 0.0);
            $seriesValues[$sectionKey][$monthKey] = $metaTotal > 0 ? ($realTotal / $metaTotal) * 100 : 0.0;
        }

        uasort($seriesMeta, static function (array $left, array $right): int {
            $orderComparison = (int) ($left['order'] ?? 999) <=> (int) ($right['order'] ?? 999);

            if ($orderComparison !== 0) {
                return $orderComparison;
            }

            return strcmp((string) ($left['label'] ?? ''), (string) ($right['label'] ?? ''));
        });

        $series = [];
        $maxValue = 100.0;
        $seriesIndex = 0;

        foreach ($seriesMeta as $sectionKey => $meta) {
            $values = [];

            foreach ($monthKeys as $monthKey) {
                $value = (float) ($seriesValues[$sectionKey][$monthKey] ?? 0.0);
                $values[] = $value;
                $maxValue = max($maxValue, $value);
            }

            $series[] = [
                'id' => (string) $sectionKey,
                'label' => (string) ($meta['label'] ?? $sectionKey),
                'color' => $palette[$seriesIndex % count($palette)],
                'values' => $values,
            ];
            $seriesIndex++;
        }

        $activeMonthIndexes = [];

        foreach ($monthKeys as $monthIndex => $_monthKey) {
            foreach ($series as $seriesItem) {
                if ((float) ($seriesItem['values'][$monthIndex] ?? 0.0) > 0.01) {
                    $activeMonthIndexes[] = $monthIndex;
                    break;
                }
            }
        }

        if ($activeMonthIndexes !== []) {
            $firstActiveMonth = min($activeMonthIndexes);
            $lastActiveMonth = max($activeMonthIndexes);
            $sliceLength = ($lastActiveMonth - $firstActiveMonth) + 1;

            $labels = array_slice($labels, $firstActiveMonth, $sliceLength);

            foreach ($series as &$seriesItem) {
                $seriesItem['values'] = array_slice((array) ($seriesItem['values'] ?? []), $firstActiveMonth, $sliceLength);
            }
            unset($seriesItem);
        }

        $maxValue = min(140.0, ceil($maxValue / 5) * 5);

        return [
            'labels' => $labels,
            'series' => $series,
            'max_value' => max(100.0, $maxValue),
        ];
    }

    private function fetchExecutiveGroupedPerformance(array $context, string $periodId, array $filters, string $level, string $startDate, string $endDate): array
    {
        $rows = [];

        foreach ($this->fetchProcedureAll(
            'sp_pobj_list_executive_grouped_performance',
            array_merge(
                [
                    'p_group_level' => $level,
                    'p_start_date' => $startDate,
                    'p_end_date' => $endDate,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildExecutiveFactProcedureFilterParams($filters)
            )
        ) as $row) {
            $groupValue = trim((string) ($row['group_value'] ?? ''));
            $displayLabel = trim((string) ($row['display_label'] ?? ''));

            if ($groupValue === '' || $displayLabel === '') {
                continue;
            }

            $realMens = (float) ($row['real_mens'] ?? 0.0);
            $metaMens = (float) ($row['meta_mens'] ?? 0.0);
            $percentMens = $metaMens > 0 ? ($realMens / $metaMens) * 100 : 0.0;

            $rows[] = [
                'key' => $groupValue,
                'display_label' => $displayLabel,
                'real_mens' => $realMens,
                'meta_mens' => $metaMens,
                'p_mens' => max(0.0, min(140.0, $percentMens)),
                'gap' => $realMens - $metaMens,
                'deficit' => max(0.0, $metaMens - $realMens),
            ];
        }

        return $rows;
    }

    private function buildExecutiveStatusBuckets(array $rows): array
    {
        $hit = array_values(array_filter($rows, static function (array $row): bool {
            return (float) ($row['p_mens'] ?? 0.0) >= 100.0;
        }));
        $quase = array_values(array_filter($rows, static function (array $row): bool {
            $percent = (float) ($row['p_mens'] ?? 0.0);

            return $percent >= 90.0 && $percent < 100.0;
        }));
        $longe = array_values(array_filter($rows, static function (array $row): bool {
            return (float) ($row['p_mens'] ?? 0.0) < 90.0;
        }));

        usort($hit, static function (array $left, array $right): int {
            return ((float) ($right['p_mens'] ?? 0.0) <=> (float) ($left['p_mens'] ?? 0.0))
                ?: strcmp((string) ($left['display_label'] ?? ''), (string) ($right['display_label'] ?? ''));
        });
        usort($quase, static function (array $left, array $right): int {
            return ((float) ($right['p_mens'] ?? 0.0) <=> (float) ($left['p_mens'] ?? 0.0))
                ?: strcmp((string) ($left['display_label'] ?? ''), (string) ($right['display_label'] ?? ''));
        });
        usort($longe, static function (array $left, array $right): int {
            return ((float) ($left['gap'] ?? 0.0) <=> (float) ($right['gap'] ?? 0.0))
                ?: strcmp((string) ($left['display_label'] ?? ''), (string) ($right['display_label'] ?? ''));
        });

        return [
            'hit' => array_slice($hit, 0, 5),
            'quase' => array_slice($quase, 0, 5),
            'longe' => array_slice($longe, 0, 5),
            'summary' => [
                'hit' => count($hit),
                'quase' => count($quase),
                'longe' => count($longe),
            ],
        ];
    }

    private function buildLegacyExecutiveStatusData(array $context, string $periodId, array $filters, array $focus, array $dateContext, array $primaryRows): array
    {
        $currentLevel = (string) ($focus['level'] ?? 'regional');
        $bestBuckets = $this->buildExecutiveStatusBuckets($primaryRows);
        $bestTitle = $this->resolveExecutiveStatusTitleByLevel($currentLevel);
        $bestFilledBuckets = $this->countFilledExecutiveStatusBuckets($bestBuckets);

        if ($bestFilledBuckets < 3) {
            $levelsToTry = $this->resolveExecutiveStatusFallbackLevels($currentLevel);

            foreach ($levelsToTry as $level) {
                if ($level === $currentLevel) {
                    continue;
                }

                $candidateRows = $this->fetchExecutiveGroupedPerformance(
                    $context,
                    $periodId,
                    $filters,
                    $level,
                    $dateContext['month_range']['start'],
                    $dateContext['month_range']['end']
                );

                if ($candidateRows === []) {
                    continue;
                }

                $candidateBuckets = $this->buildExecutiveStatusBuckets($candidateRows);
                $candidateFilledBuckets = $this->countFilledExecutiveStatusBuckets($candidateBuckets);

                if ($candidateFilledBuckets > $bestFilledBuckets) {
                    $bestBuckets = $candidateBuckets;
                    $bestTitle = $this->resolveExecutiveStatusTitleByLevel($level);
                    $bestFilledBuckets = $candidateFilledBuckets;
                }

                if ($bestFilledBuckets >= 3) {
                    break;
                }
            }
        }

        $bestBuckets['title'] = $bestTitle;

        return $bestBuckets;
    }

    private function countFilledExecutiveStatusBuckets(array $buckets): int
    {
        $count = 0;

        foreach (['hit', 'quase', 'longe'] as $key) {
            if (!empty($buckets[$key])) {
                $count++;
            }
        }

        return $count;
    }

    private function resolveExecutiveStatusFallbackLevels(string $level): array
    {
        $levels = [$level];
        $fallbackMap = [
            'diretoria' => 'regional',
            'regional' => 'agencia',
            'agencia' => 'gerente_gestao',
            'gerente_gestao' => 'gerente',
            'gerente' => 'familia',
        ];

        while (isset($fallbackMap[$level])) {
            $level = $fallbackMap[$level];
            $levels[] = $level;
        }

        return $levels;
    }

    private function resolveExecutiveStatusTitleByLevel(string $level): string
    {
        $titles = [
            'familia' => 'Status por FamÃ­lia',
            'gerente' => 'Status por Gerente',
            'gerente_gestao' => 'Status por Gerente de GestÃ£o',
            'agencia' => 'Status por AgÃªncia',
            'regional' => 'Status por Regional',
            'diretoria' => 'Status por Diretoria',
        ];

        return $titles[$level] ?? 'Status por Regional';
    }

    private function buildExecutiveHeatmap(array $context, string $periodId, array $filters, string $focusLevel, array $dateContext): array
    {
        $unitLevel = $this->resolveExecutiveHeatmapUnitLevel($focusLevel);
        $axisMeta = $this->resolveExecutiveHeatmapAxisMeta($unitLevel, $filters);
        $unitRows = $this->fetchExecutiveGroupedPerformance(
            $context,
            $periodId,
            $filters,
            $unitLevel,
            $dateContext['month_range']['start'],
            $dateContext['month_range']['end']
        );

        usort($unitRows, static function (array $left, array $right): int {
            return ((float) ($right['p_mens'] ?? 0.0) <=> (float) ($left['p_mens'] ?? 0.0))
                ?: strcmp((string) ($left['display_label'] ?? ''), (string) ($right['display_label'] ?? ''));
        });

        $sectionsMatrix = $this->fetchExecutiveHeatmapMatrix(
            $context,
            $periodId,
            $filters,
            $unitLevel,
            'familia',
            $dateContext['month_range']['start'],
            $dateContext['month_range']['end']
        );
        $indicatorsMatrix = $this->fetchExecutiveHeatmapMatrix(
            $context,
            $periodId,
            $filters,
            $unitLevel,
            'indicador',
            $dateContext['month_range']['start'],
            $dateContext['month_range']['end']
        );

        $activeColumns = ($filters['familia'] ?? '') !== ''
            ? $indicatorsMatrix['sections']
            : $sectionsMatrix['sections'];
        $activeData = ($filters['familia'] ?? '') !== ''
            ? $indicatorsMatrix['data']
            : $sectionsMatrix['data'];

        $units = [];

        foreach ($unitRows as $row) {
            $unitKey = (string) ($row['key'] ?? '');

            if ($unitKey === '') {
                continue;
            }

            $units[] = [
                'key' => $unitKey,
                'label' => (string) ($row['display_label'] ?? $unitKey),
                'percent' => (float) ($row['p_mens'] ?? 0.0),
            ];
        }

        return [
            'default_mode' => 'secoes',
            'secoes' => [
                'title' => 'Heatmap â€” ' . $axisMeta['short_label'] . ' Ã— SeÃ§Ãµes',
                'row_axis_label' => $axisMeta['short_label'],
                'row_axis_sublabel' => ($filters['familia'] ?? '') !== '' ? 'Indicadores' : 'FamÃ­lias',
                'rows' => $units,
                'columns' => $activeColumns,
                'data' => $activeData,
            ],
            'meta' => $this->buildExecutiveMetaHeatmap(
                $context,
                $periodId,
                $filters,
                $dateContext['meta_range']['start'],
                $dateContext['meta_range']['end'],
                $dateContext['meta_range']['months']
            ),
        ];
    }

    private function resolveExecutiveHeatmapUnitLevel(string $focusLevel): string
    {
        return $focusLevel === 'familia' ? 'gerente' : $focusLevel;
    }

    private function resolveExecutiveHeatmapAxisMeta(string $unitLevel, array $filters): array
    {
        $map = [
            'diretoria' => ['short_label' => 'DR', 'full_label' => 'Diretoria'],
            'regional' => ['short_label' => 'GR', 'full_label' => 'Regional'],
            'agencia' => ['short_label' => 'AG', 'full_label' => 'AgÃªncia'],
            'gerente_gestao' => ['short_label' => 'GG', 'full_label' => 'Gerente de gestÃ£o'],
            'gerente' => ['short_label' => 'GC', 'full_label' => 'Gerente'],
        ];

        $resolved = $map[$unitLevel] ?? ['short_label' => 'GR', 'full_label' => 'Regional'];

        if (($filters['familia'] ?? '') !== '') {
            $resolved['column_label'] = 'Indicadores';
        } else {
            $resolved['column_label'] = 'FamÃ­lias';
        }

        return $resolved;
    }

    private function buildExecutiveMetaHeatmap(array $context, string $periodId, array $filters, string $startDate, string $endDate, array $months): array
    {
        $rows = [
            ['key' => 'diretoria', 'label' => 'Todas Diretorias'],
            ['key' => 'regional', 'label' => 'Todas Regionais'],
            ['key' => 'agencia', 'label' => 'Todas AgÃªncias'],
            ['key' => 'gerente_gestao', 'label' => 'Todos Ger. de GestÃ£o'],
            ['key' => 'gerente', 'label' => 'Todos GCs'],
        ];
        $data = [];

        foreach ($rows as $row) {
            $monthlyTotals = $this->fetchExecutiveMetaMonthlyTotals(
                $context,
                $periodId,
                $filters,
                $row['key'],
                $startDate,
                $endDate,
                $months
            );

            foreach ($months as $month) {
                $monthKey = trim((string) ($month['key'] ?? ''));

                if ($monthKey === '') {
                    continue;
                }

                $data[$row['key']][$monthKey] = (float) ($monthlyTotals[$monthKey] ?? 0.0);
            }
        }

        return [
            'title' => 'Heatmap â€” VariaÃ§Ã£o da meta (mÃªs a mÃªs)',
            'row_axis_label' => 'Hierarquia',
            'row_axis_sublabel' => 'MÃªs',
            'rows' => $rows,
            'months' => $months,
            'data' => $data,
        ];
    }

    private function fetchExecutiveMetaMonthlyTotals(array $context, string $periodId, array $filters, string $level, string $startDate, string $endDate, array $months): array
    {
        $totals = [];

        foreach ($this->fetchProcedureAll(
            'sp_pobj_list_executive_meta_monthly_totals',
            array_merge(
                [
                    'p_level' => $level,
                    'p_start_date' => $startDate,
                    'p_end_date' => $endDate,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildExecutiveFactProcedureFilterParams($filters)
            )
        ) as $row) {
            $monthKey = trim((string) ($row['month_key'] ?? ''));

            if ($monthKey === '') {
                continue;
            }

            $totals[$monthKey] = ($totals[$monthKey] ?? 0.0) + (float) ($row['meta_total'] ?? 0.0);
        }

        foreach ($months as $month) {
            $monthKey = trim((string) ($month['key'] ?? ''));

            if ($monthKey !== '' && !isset($totals[$monthKey])) {
                $totals[$monthKey] = 0.0;
            }
        }

        return $totals;
    }

    private function fetchExecutiveHeatmapMatrix(array $context, string $periodId, array $filters, string $unitLevel, string $sectionMode, string $startDate, string $endDate): array
    {
        $sections = [];
        $units = [];
        $data = [];

        foreach ($this->fetchProcedureAll(
            'sp_pobj_list_executive_heatmap_matrix',
            array_merge(
                [
                    'p_unit_level' => $unitLevel,
                    'p_section_mode' => $sectionMode,
                    'p_start_date' => $startDate,
                    'p_end_date' => $endDate,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildExecutiveFactProcedureFilterParams($filters)
            )
        ) as $row) {
            $unitKey = trim((string) ($row['unit_key'] ?? ''));
            $sectionKey = trim((string) ($row['section_key'] ?? ''));

            if ($unitKey === '' || $sectionKey === '') {
                continue;
            }

            $units[$unitKey] = [
                'key' => $unitKey,
                'label' => trim((string) ($row['unit_label'] ?? $unitKey)),
            ];
            $sections[$sectionKey] = [
                'key' => $sectionKey,
                'label' => trim((string) ($row['section_label'] ?? $sectionKey)),
                'order' => (int) ($row['section_order'] ?? 999),
            ];

            $realTotal = (float) ($row['real_total'] ?? 0.0);
            $metaTotal = (float) ($row['meta_total'] ?? 0.0);
            $data[$unitKey][$sectionKey] = [
                'real' => $realTotal,
                'meta' => $metaTotal,
                'percent' => $metaTotal > 0 ? ($realTotal / $metaTotal) * 100 : 0.0,
            ];
        }

        uasort($sections, static function (array $left, array $right): int {
            $orderComparison = (int) ($left['order'] ?? 999) <=> (int) ($right['order'] ?? 999);

            if ($orderComparison !== 0) {
                return $orderComparison;
            }

            return strcmp((string) ($left['label'] ?? ''), (string) ($right['label'] ?? ''));
        });

        return [
            'units' => array_values($units),
            'sections' => array_values($sections),
            'data' => $data,
        ];
    }

    private function fetchExecutiveUnitTrend(array $context, string $periodId, array $filters, string $unitLevel, string $startDate, string $endDate, array $months): array
    {
        $monthKeys = [];

        foreach ($months as $month) {
            $monthKey = trim((string) ($month['key'] ?? ''));

            if ($monthKey !== '') {
                $monthKeys[] = $monthKey;
            }
        }

        $trend = [];

        foreach ($this->fetchProcedureAll(
            'sp_pobj_list_executive_unit_trend',
            array_merge(
                [
                    'p_unit_level' => $unitLevel,
                    'p_start_date' => $startDate,
                    'p_end_date' => $endDate,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildExecutiveFactProcedureFilterParams($filters)
            )
        ) as $row) {
            $unitKey = trim((string) ($row['unit_key'] ?? ''));
            $monthKey = trim((string) ($row['month_key'] ?? ''));

            if ($unitKey === '' || $monthKey === '') {
                continue;
            }

            $metaTotal = (float) ($row['meta_total'] ?? 0.0);
            $realTotal = (float) ($row['real_total'] ?? 0.0);
            $trend[$unitKey][$monthKey] = $metaTotal > 0 ? ($realTotal / $metaTotal) * 100 : 0.0;
        }

        foreach ($trend as $unitKey => $values) {
            $ordered = [];

            foreach ($monthKeys as $monthKey) {
                $ordered[] = [
                    'key' => $monthKey,
                    'percent' => (float) ($values[$monthKey] ?? 0.0),
                ];
            }

            $trend[$unitKey] = $ordered;
        }

        return $trend;
    }

    private function formatExecutiveMonthShortLabel(\DateTimeImmutable $date): string
    {
        $map = [
            1 => 'Jan',
            2 => 'Fev',
            3 => 'Mar',
            4 => 'Abr',
            5 => 'Mai',
            6 => 'Jun',
            7 => 'Jul',
            8 => 'Ago',
            9 => 'Set',
            10 => 'Out',
            11 => 'Nov',
            12 => 'Dez',
        ];

        return $map[(int) $date->format('n')] ?? $date->format('m');
    }

    private function formatExecutiveMonthYearLabel(\DateTimeImmutable $date): string
    {
        $map = [
            1 => 'jan',
            2 => 'fev',
            3 => 'mar',
            4 => 'abr',
            5 => 'mai',
            6 => 'jun',
            7 => 'jul',
            8 => 'ago',
            9 => 'set',
            10 => 'out',
            11 => 'nov',
            12 => 'dez',
        ];

        return ($map[(int) $date->format('n')] ?? $date->format('m')) . '/' . $date->format('y');
    }

    private function resolveRankingLevel(array $context, array $filters): string
    {
        if (($filters['gerente'] ?? '') !== '') {
            return 'gerente';
        }

        if (($filters['gerente_gestao'] ?? '') !== '') {
            return 'gerente_gestao';
        }

        $profile = (array) ($context['profile'] ?? []);
        $profileLevel = strtoupper(trim((string) ($profile['nivel'] ?? '')));

        if (($filters['agencia'] ?? '') !== '' && $profileLevel === 'AG') {
            return 'gerente_agencia';
        }

        if (($filters['agencia'] ?? '') !== '') {
            return 'agencia';
        }

        if (($filters['regional'] ?? '') !== '') {
            return 'regional';
        }

        if (($filters['diretoria'] ?? '') !== '') {
            return 'diretoria';
        }

        if (($filters['segmento'] ?? '') !== '') {
            return 'segmento';
        }

        if ($profileLevel === 'AG') {
            return 'gerente_agencia';
        }

        return 'gerente_gestao';
    }

    private function resolveRankingLevelLabel(string $level): string
    {
        $map = [
            'segmento' => 'Segmento',
            'diretoria' => 'Diretoria',
            'regional' => 'Regional',
            'agencia' => 'AgÃªncia',
            'gerente_agencia' => 'Gerente de agÃªncia',
            'gerente_gestao' => 'Gerente de gestÃ£o',
            'gerente' => 'Gerente',
        ];

        return $map[$level] ?? 'Gerente de gestÃ£o';
    }

    private function resolveActiveRankingGroupId(array $context, array $filters, string $rankingLevel, array $rankingGroupOptions = []): string
    {
        $requestedGroupId = $this->sanitizeFilterSelection(trim((string) ($filters['grupo'] ?? '')), $rankingGroupOptions);

        if ($requestedGroupId !== '') {
            return $requestedGroupId;
        }

        if (!$this->shouldMaskRankingLevelIdentities($context, $rankingLevel)) {
            return '';
        }

        if (count($rankingGroupOptions) === 1) {
            return trim((string) ($rankingGroupOptions[0]['value'] ?? ''));
        }

        return '';
    }

    private function shouldMaskRankingLevelIdentities(array $context, string $rankingLevel): bool
    {
        $profile = (array) ($context['profile'] ?? []);
        $level = strtoupper(trim((string) ($profile['nivel'] ?? '')));

        if ($level === 'DP') {
            return false;
        }

        return in_array($rankingLevel, ['diretoria', 'regional', 'agencia', 'gerente_agencia', 'gerente_gestao', 'gerente'], true);
    }

    private function shouldUsePeerRankingScope(array $context, string $rankingLevel): bool
    {
        $profile = (array) ($context['profile'] ?? []);
        $level = strtoupper(trim((string) ($profile['nivel'] ?? '')));

        switch ($rankingLevel) {
            case 'gerente':
                return in_array($level, ['AS', 'GC', 'PA'], true);

            case 'gerente_agencia':
                return $level === 'AG';

            case 'gerente_gestao':
                return in_array($level, ['AG', 'GG', 'TL'], true);

            case 'regional':
                return in_array($level, ['GE', 'GR'], true);

            case 'diretoria':
                return $level === 'DR';

            default:
                return false;
        }
    }

    private function resolveFunctionalGroupId(string $functional): string
    {
        $functional = trim($functional);

        if ($functional === '' || !$this->hasDatabaseTable('fGrupoFuncional')) {
            return '';
        }

        return trim((string) $this->fetchProcedureValue(
            'sp_pobj_resolve_functional_group_id',
            ['p_functional' => $functional]
        ));
    }

    private function resolveFunctionalsByGroupAndLevels(string $groupId, array $levels): array
    {
        $levels = array_values(array_unique(array_filter(array_map('trim', $levels))));

        if (
            $groupId === ''
            || $levels === []
            || !$this->hasDatabaseTable('fGrupoFuncional')
            || !$this->hasDatabaseTable('dHierarquia')
        ) {
            return [];
        }

        $rows = $this->fetchProcedureAll(
            'sp_pobj_resolve_functionals_by_group_levels',
            [
                'p_group_id' => $groupId,
                'p_levels_csv' => $this->encodeProcedureList($levels),
            ]
        );

        return array_values(array_filter(array_map('trim', array_column($rows, 'funcional'))));
    }

    private function resolveJunctionsByGroupAndLevels(string $groupId, string $junctionType, array $levels): array
    {
        $levels = array_values(array_unique(array_filter(array_map('trim', $levels))));
        $junctionType = strtoupper(trim($junctionType));

        if (
            $groupId === ''
            || $junctionType === ''
            || $levels === []
            || !$this->hasDatabaseTable('fGrupoFuncional')
            || !$this->hasDatabaseTable('dHierarquia')
            || !$this->hasDatabaseTable('fMultiJuncao')
        ) {
            return [];
        }

        $rows = $this->fetchProcedureAll(
            'sp_pobj_resolve_junctions_by_group_levels',
            [
                'p_group_id' => $groupId,
                'p_junction_type' => $junctionType,
                'p_levels_csv' => $this->encodeProcedureList($levels),
            ]
        );

        return array_values(array_filter(array_map('trim', array_column($rows, 'juncao'))));
    }

    private function applyMaskedDisplayLabels(array $rows, array $context, array $filters, string $level): array
    {
        if ($rows === []) {
            return [];
        }

        $maskIdentities = $this->shouldMaskRankingLevelIdentities($context, $level);
        $viewerGroupValue = $this->resolveViewerRankingGroupValue($context, $filters, $level);
        $decoratedRows = [];

        foreach ($rows as $row) {
            $groupValue = trim((string) ($row['key'] ?? $row['label'] ?? ''));
            $rawDisplayLabel = trim((string) ($row['raw_display_label'] ?? $row['display_label'] ?? $groupValue));
            $isViewerRow = $viewerGroupValue !== '' && $groupValue !== '' && $groupValue === $viewerGroupValue;
            $isMasked = $maskIdentities && !$isViewerRow;

            $row['raw_display_label'] = $rawDisplayLabel;
            $row['display_label'] = $isMasked ? '***' : $rawDisplayLabel;
            $row['is_masked'] = $isMasked;
            $row['is_viewer_row'] = $isViewerRow;
            $decoratedRows[] = $row;
        }

        return $decoratedRows;
    }

    private function resolveViewerRankingGroupValue(array $context, array $filters, string $rankingLevel): string
    {
        $profile = (array) ($context['profile'] ?? []);
        $junctions = array_values((array) ($context['junctions'] ?? []));
        $functional = trim((string) ($profile['funcional'] ?? ''));

        switch ($rankingLevel) {
            case 'gerente':
                return $functional;

            case 'gerente_agencia':
                $selectedAgency = trim((string) ($filters['agencia'] ?? ''));

                if ($selectedAgency !== '') {
                    return $this->resolveAgencyManagerFunctionalByAgency($selectedAgency);
                }

                return $functional;

            case 'gerente_gestao':
                $selectedManager = trim((string) ($filters['gerente_gestao'] ?? ''));

                return $selectedManager !== '' ? $selectedManager : $functional;

            case 'agencia':
                $selectedAgency = trim((string) ($filters['agencia'] ?? ''));

                return $selectedAgency !== '' ? $selectedAgency : $this->resolvePrimaryJunction($junctions, 'AG');

            case 'regional':
                $selectedRegional = trim((string) ($filters['regional'] ?? ''));

                return $selectedRegional !== '' ? $selectedRegional : $this->resolvePrimaryJunction($junctions, 'GR');

            case 'diretoria':
                $selectedDirectorate = trim((string) ($filters['diretoria'] ?? ''));

                return $selectedDirectorate !== '' ? $selectedDirectorate : $this->resolvePrimaryJunction($junctions, 'DR');

            case 'segmento':
                return trim((string) ($filters['segmento'] ?? ''));

            default:
                return '';
        }
    }

    private function resolveExecutiveWindowLabel(array $labels): string
    {
        $visibleLabelCount = count(array_filter(array_map(static function ($label): string {
            return trim((string) $label);
        }, $labels), static function (string $label): bool {
            return $label !== '';
        }));

        if ($visibleLabelCount <= 1) {
            return 'Ãšltimo mÃªs';
        }

        return sprintf('Ãšltimos %d meses', $visibleLabelCount);
    }

    public function sanitizeFilterSelection(string $selectedValue, array $options, string $defaultValue = ''): string
    {
        if ($selectedValue === '') {
            return $defaultValue;
        }

        foreach ($options as $option) {
            if ((string) ($option['value'] ?? '') === $selectedValue) {
                return $selectedValue;
            }
        }

        return $defaultValue;
    }

    private function formatMonthLabel(\DateTimeImmutable $date): string
    {
        $months = [
            1 => 'Janeiro',
            2 => 'Fevereiro',
            3 => 'MarÃ§o',
            4 => 'Abril',
            5 => 'Maio',
            6 => 'Junho',
            7 => 'Julho',
            8 => 'Agosto',
            9 => 'Setembro',
            10 => 'Outubro',
            11 => 'Novembro',
            12 => 'Dezembro',
        ];

        $monthNumber = (int) $date->format('n');

        return $months[$monthNumber] ?? $date->format('m/Y');
    }

    private function resolveAgenciesByFunctional(string $functional): array
    {
        if (!$this->hasDatabaseTable('fMultiJuncao')) {
            return [];
        }

        $rows = $this->fetchProcedureAll(
            'sp_pobj_resolve_agencies_by_functional',
            ['p_functional' => trim($functional)]
        );

        return array_values(array_filter(array_map('trim', array_column($rows, 'juncao'))));
    }

    private function hasManagementRelationTable(): bool
    {
        if ($this->managementRelationAvailable !== null) {
            return (bool) $this->managementRelationAvailable;
        }

        try {
            $this->managementRelationAvailable = $this->hasDatabaseTable('fGestaoGerente');
        } catch (\Throwable $exception) {
            $this->managementRelationAvailable = false;
        }

        return (bool) $this->managementRelationAvailable;
    }

    private function resolveFunctionalsByManagementFunctional(string $functional): array
    {
        $functional = trim($functional);

        if ($functional === '' || !$this->hasManagementRelationTable()) {
            return [];
        }

        $rows = $this->fetchProcedureAll(
            'sp_pobj_resolve_functionals_by_management_functional',
            ['p_functional' => $functional]
        );

        return array_values(array_filter(array_map('trim', array_column($rows, 'funcional'))));
    }

    private function resolveAgencyManagerFunctionalByAgency(string $agency): string
    {
        $agency = trim($agency);

        if (
            $agency === ''
            || !$this->hasDatabaseTable('fMultiJuncao')
            || !$this->hasDatabaseTable('dHierarquia')
        ) {
            return '';
        }

        return trim((string) $this->fetchProcedureValue(
            'sp_pobj_resolve_agency_manager_functional',
            ['p_agency' => $agency]
        ));
    }

    private function buildIndicatorDetailSummary(array $indicatorRow, array $detailRows): array
    {
        $contracts = [];
        $clients = [];
        $transactionVolume = 0.0;
        $lastTransactionDate = '';

        foreach ($detailRows as $row) {
            $contract = trim((string) ($row['numero_contrato'] ?? ''));
            $client = trim((string) ($row['cnpj'] ?? ''));
            $transactionDate = trim((string) ($row['data_transacao'] ?? ''));

            if ($contract !== '') {
                $contracts[$contract] = true;
            }

            if ($client !== '') {
                $clients[$client] = true;
            }

            $transactionVolume += (float) ($row['valor_realizado'] ?? 0.0);

            if ($transactionDate !== '' && ($lastTransactionDate === '' || strcmp($transactionDate, $lastTransactionDate) > 0)) {
                $lastTransactionDate = $transactionDate;
            }
        }

        return [
            'meta' => (float) ($indicatorRow['meta'] ?? 0.0),
            'realizado' => (float) ($indicatorRow['realizado'] ?? 0.0),
            'percentual' => (float) ($indicatorRow['percentual_atingimento'] ?? 0.0),
            'pontos' => (float) ($indicatorRow['pontos'] ?? 0.0),
            'pontos_meta' => (float) ($indicatorRow['pontos_meta'] ?? 0.0),
            'variavel' => (float) ($indicatorRow['variavel'] ?? 0.0),
            'variavel_meta' => (float) ($indicatorRow['variavel_meta'] ?? 0.0),
            'contracts_total' => count($contracts),
            'clients_total' => count($clients),
            'transactions_total' => count($detailRows),
            'transaction_volume' => $transactionVolume,
            'last_transaction_date' => $lastTransactionDate,
        ];
    }

    private function resolveIndicatorTrendRange(array $dateRange): array
    {
        $end = trim((string) ($dateRange['end'] ?? ''));

        try {
            $endDate = new \DateTimeImmutable($end !== '' ? $end : 'today');
        } catch (\Throwable $exception) {
            $endDate = new \DateTimeImmutable('today');
        }

        $startDate = $endDate
            ->modify('first day of this month')
            ->sub(new \DateInterval('P2M'));

        return [
            'start' => $startDate->format('Y-m-d'),
            'end' => $endDate->format('Y-m-d'),
        ];
    }

    private function buildIndicatorDistributions(array $detailRows): array
    {
        $channels = [];
        $statuses = [];

        foreach ($detailRows as $row) {
            $channel = trim((string) ($row['canal_venda'] ?? ''));
            $status = trim((string) ($row['status_transacao'] ?? ''));
            $contract = trim((string) ($row['numero_contrato'] ?? ''));
            $client = trim((string) ($row['cnpj'] ?? ''));
            $channel = $channel !== '' ? $channel : 'Sem canal';
            $status = $status !== '' ? $status : 'Sem status';
            $value = (float) ($row['valor_realizado'] ?? 0.0);

            if (!isset($channels[$channel])) {
                $channels[$channel] = [
                    'label' => $channel,
                    'count' => 0,
                    'value' => 0.0,
                    'contracts' => [],
                    'clients' => [],
                ];
            }

            if (!isset($statuses[$status])) {
                $statuses[$status] = ['label' => $status, 'count' => 0, 'value' => 0.0];
            }

            $channels[$channel]['count']++;
            $channels[$channel]['value'] += $value;

            if ($contract !== '') {
                $channels[$channel]['contracts'][$contract] = true;
            }

            if ($client !== '') {
                $channels[$channel]['clients'][$client] = true;
            }

            $statuses[$status]['count']++;
            $statuses[$status]['value'] += $value;
        }

        foreach ($channels as &$channelRow) {
            $channelRow['contracts_total'] = count((array) ($channelRow['contracts'] ?? []));
            $channelRow['clients_total'] = count((array) ($channelRow['clients'] ?? []));
            unset($channelRow['contracts'], $channelRow['clients']);
        }
        unset($channelRow);

        $sortDistributionByCount = static function (array &$items): void {
            uasort($items, static function (array $left, array $right): int {
                $countComparison = (int) ($right['count'] ?? 0) <=> (int) ($left['count'] ?? 0);

                if ($countComparison !== 0) {
                    return $countComparison;
                }

                $valueComparison = (float) ($right['value'] ?? 0.0) <=> (float) ($left['value'] ?? 0.0);

                if ($valueComparison !== 0) {
                    return $valueComparison;
                }

                return strcmp((string) ($left['label'] ?? ''), (string) ($right['label'] ?? ''));
            });
        };

        uasort($channels, static function (array $left, array $right): int {
            $valueComparison = (float) ($right['value'] ?? 0.0) <=> (float) ($left['value'] ?? 0.0);

            if ($valueComparison !== 0) {
                return $valueComparison;
            }

            $countComparison = (int) ($right['count'] ?? 0) <=> (int) ($left['count'] ?? 0);

            if ($countComparison !== 0) {
                return $countComparison;
            }

            return strcmp((string) ($left['label'] ?? ''), (string) ($right['label'] ?? ''));
        });

        $sortDistributionByCount($statuses);

        return [
            'channels' => array_slice(array_values($channels), 0, 6),
            'statuses' => array_slice(array_values($statuses), 0, 6),
        ];
    }

    private function resolveIndicatorInsightMeta(array $context, array $filters): array
    {
        $profile = (array) ($context['profile'] ?? []);
        $profileLevel = strtoupper(trim((string) ($profile['nivel'] ?? '')));

        if (($filters['gerente'] ?? '') !== '') {
            return [
                'mode' => 'portfolio',
                'label' => 'Produtos',
                'title' => 'Produtos que mais puxam a carteira deste gerente',
            ];
        }

        if (($filters['gerente_gestao'] ?? '') !== '') {
            return [
                'mode' => 'hierarchy',
                'group_level' => 'gerente',
                'label' => 'Gerentes',
                'title' => 'Gerentes que mais ajudam ou pressionam o indicador',
            ];
        }

        if (($filters['agencia'] ?? '') !== '') {
            return [
                'mode' => 'hierarchy',
                'group_level' => 'gerente_gestao',
                'label' => 'Gerentes de gestÃ£o',
                'title' => 'Gerentes de gestÃ£o em destaque para o indicador',
            ];
        }

        if (($filters['regional'] ?? '') !== '') {
            return [
                'mode' => 'hierarchy',
                'group_level' => 'gerente_agencia',
                'label' => 'Gerentes de agÃªncia',
                'title' => 'Gerentes de agÃªncia que mais puxam o indicador na regional',
            ];
        }

        if (($filters['diretoria'] ?? '') !== '') {
            return [
                'mode' => 'hierarchy',
                'group_level' => 'regional',
                'label' => 'Regionais',
                'title' => 'Regionais em destaque para o indicador',
            ];
        }

        if (($filters['segmento'] ?? '') !== '') {
            return [
                'mode' => 'hierarchy',
                'group_level' => 'diretoria',
                'label' => 'Diretorias',
                'title' => 'Diretorias em destaque dentro do segmento',
            ];
        }

        switch ($profileLevel) {
            case 'DR':
                return [
                    'mode' => 'hierarchy',
                    'group_level' => 'regional',
                    'label' => 'Regionais',
                    'title' => 'Regionais em destaque para o indicador',
                ];

            case 'GR':
            case 'GE':
                return [
                    'mode' => 'hierarchy',
                    'group_level' => 'gerente_agencia',
                    'label' => 'Gerentes de agÃªncia',
                    'title' => 'Gerentes de agÃªncia em destaque para o indicador',
                ];

            case 'AG':
                return [
                    'mode' => 'hierarchy',
                    'group_level' => 'gerente_gestao',
                    'label' => 'Gerentes de gestÃ£o',
                    'title' => 'Gerentes de gestÃ£o em destaque para o indicador',
                ];

            case 'GG':
            case 'TL':
                return [
                    'mode' => 'hierarchy',
                    'group_level' => 'gerente',
                    'label' => 'Gerentes',
                    'title' => 'Gerentes em destaque para o indicador',
                ];

            case 'DP':
                return [
                    'mode' => 'hierarchy',
                    'group_level' => 'segmento',
                    'label' => 'Segmentos',
                    'title' => 'Segmentos em destaque para o indicador',
                ];

            default:
                return [
                    'mode' => 'portfolio',
                    'label' => 'Produtos',
                    'title' => 'Produtos que mais puxam a carteira atual',
                ];
        }
    }

    private function buildPortfolioInsightRows(array $context, string $periodId, array $filters, string $indicatorId, array $dateRange): array
    {
        $portfolioFilters = $filters;
        $portfolioFilters['indicadores'] = '';
        $portfolioFilters['subindicador'] = '';
        $rows = [];

        foreach ($this->getIndicatorRows($context, $periodId, $portfolioFilters, $dateRange) as $row) {
            $currentIndicatorId = (string) ($row['id_indicador'] ?? '');

            if ($currentIndicatorId === '' || $currentIndicatorId === $indicatorId) {
                continue;
            }

            $metaPoints = (float) ($row['pontos_meta'] ?? 0.0);
            $realPoints = (float) ($row['pontos'] ?? 0.0);

            $rows[] = [
                'key' => $currentIndicatorId,
                'display_label' => (string) ($row['nome_indicador'] ?? $currentIndicatorId),
                'meta_points' => $metaPoints,
                'real_points' => $realPoints,
                'percentual' => $metaPoints > 0 ? ($realPoints / $metaPoints) * 100 : 0.0,
                'gap' => $realPoints - $metaPoints,
                'contracts_total' => 0,
                'clients_total' => 0,
            ];
        }

        return $rows;
    }

    private function mergeIndicatorDetailCounts(array $insightRows, array $detailRows, string $groupLevel): array
    {
        $countMap = [];

        foreach ($detailRows as $row) {
            $identity = $this->resolveIndicatorDetailIdentity($row, $groupLevel);
            $key = trim((string) ($identity['key'] ?? ''));

            if ($key === '') {
                continue;
            }

            if (!isset($countMap[$key])) {
                $countMap[$key] = [
                    'contracts' => [],
                    'clients' => [],
                ];
            }

            $contract = trim((string) ($row['numero_contrato'] ?? ''));
            $client = trim((string) ($row['cnpj'] ?? ''));

            if ($contract !== '') {
                $countMap[$key]['contracts'][$contract] = true;
            }

            if ($client !== '') {
                $countMap[$key]['clients'][$client] = true;
            }
        }

        foreach ($insightRows as &$insightRow) {
            $rowKey = trim((string) ($insightRow['key'] ?? ''));
            $counts = $countMap[$rowKey] ?? ['contracts' => [], 'clients' => []];
            $insightRow['contracts_total'] = count($counts['contracts']);
            $insightRow['clients_total'] = count($counts['clients']);
        }
        unset($insightRow);

        return $insightRows;
    }

    private function resolveIndicatorDetailIdentity(array $row, string $groupLevel): array
    {
        switch ($groupLevel) {
            case 'segmento':
                return ['key' => (string) ($row['segmento'] ?? ''), 'label' => (string) ($row['segmento'] ?? '')];

            case 'diretoria':
                return ['key' => (string) ($row['juncao_dr'] ?? ''), 'label' => (string) ($row['nome_diretoria'] ?? '')];

            case 'regional':
                return ['key' => (string) ($row['juncao_gr'] ?? ''), 'label' => (string) ($row['nome_regional'] ?? '')];

            case 'gerente_agencia':
                return [
                    'key' => (string) ($row['funcional_gerente_agencia'] ?? ''),
                    'label' => (string) ($row['nome_gerente_agencia'] ?? ''),
                ];

            case 'gerente_gestao':
                return [
                    'key' => (string) ($row['funcional_gerente_gestao'] ?? ''),
                    'label' => (string) ($row['nome_gerente_gestao'] ?? ''),
                ];

            case 'gerente':
                return ['key' => (string) ($row['funcional'] ?? ''), 'label' => (string) ($row['nome_gerente'] ?? '')];

            default:
                return ['key' => '', 'label' => ''];
        }
    }

    private function sliceTopIndicatorInsightRows(array $rows): array
    {
        usort($rows, static function (array $left, array $right): int {
            $percentComparison = (float) ($right['percentual'] ?? 0.0) <=> (float) ($left['percentual'] ?? 0.0);

            if ($percentComparison !== 0) {
                return $percentComparison;
            }

            return strcmp((string) ($left['display_label'] ?? ''), (string) ($right['display_label'] ?? ''));
        });

        return array_slice($rows, 0, 3);
    }

    private function sliceBottomIndicatorInsightRows(array $rows): array
    {
        usort($rows, static function (array $left, array $right): int {
            $percentComparison = (float) ($left['percentual'] ?? 0.0) <=> (float) ($right['percentual'] ?? 0.0);

            if ($percentComparison !== 0) {
                return $percentComparison;
            }

            return strcmp((string) ($left['display_label'] ?? ''), (string) ($right['display_label'] ?? ''));
        });

        return array_slice($rows, 0, 3);
    }

    private function resolveProductivitySnapshotView(array $filters): string
    {
        $view = strtoupper(trim((string) ($filters['visao_acumulada'] ?? 'MENSAL')));

        if ($view === 'MENSAL_ACUMULADO') {
            return 'MENSAL';
        }

        return in_array($view, ['MENSAL', 'SEMESTRAL', 'ACUMULADO'], true) ? $view : '';
    }

    private function resolveProductivitySnapshotTableName(array $filters, string $referenceEndDate = '', string $periodId = ''): string
    {
        $view = $this->resolveProductivitySnapshotView($filters);

        if ($view === '') {
            return '';
        }

        $anomes = $this->resolveSemestralAnoMes($referenceEndDate, $periodId);
        $prefixMap = [
            'MENSAL' => 'f_produtividade_mensal',
            'SEMESTRAL' => 'f_produtividade_semestral',
            'ACUMULADO' => 'f_acumulado',
        ];
        $tableName = sprintf(
            '%s_%s',
            $prefixMap[$view] ?? 'f_produtividade_mensal',
            $anomes
        );

        return $this->hasProductivitySnapshotTable($tableName) ? $tableName : '';
    }

    private function resolveProductivityFilterTableName(array $filters, string $referenceEndDate = '', string $periodId = ''): string
    {
        $tableName = $this->resolveProductivitySnapshotTableName($filters, $referenceEndDate, $periodId);

        if ($tableName !== '') {
            return $tableName;
        }

        $anomes = $this->resolveSemestralAnoMes($referenceEndDate, $periodId);

        foreach ([
            'f_produtividade_mensal_' . $anomes,
            'f_produtividade_semestral_' . $anomes,
            'f_acumulado_' . $anomes,
        ] as $candidateTable) {
            if ($this->hasProductivitySnapshotTable($candidateTable)) {
                return $candidateTable;
            }
        }

        return '';
    }

    private function hasProductivitySnapshotTable(string $tableName): bool
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $tableName)) {
            return false;
        }

        if (array_key_exists($tableName, $this->productivitySnapshotTableAvailability)) {
            return $this->productivitySnapshotTableAvailability[$tableName];
        }

        $this->productivitySnapshotTableAvailability[$tableName] = $this->hasDatabaseTable($tableName);

        return $this->productivitySnapshotTableAvailability[$tableName];
    }

    private function hasDatabaseTable(string $tableName): bool
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $tableName)) {
            return false;
        }

        return (bool) $this->fetchProcedureValue('sp_util_table_exists', ['p_table_name' => $tableName]);
    }

    private function resolveSnapshotTablesForPeriod(string $periodId): array
    {
        $period = $this->getPeriodDefinition($periodId);
        $periodStartRaw = trim((string) ($period['dt_inicio_periodo'] ?? ''));
        $periodEndRaw = trim((string) ($period['dt_fim_periodo'] ?? ''));

        if ($periodStartRaw === '' || $periodEndRaw === '') {
            return [];
        }

        try {
            $cursor = (new \DateTimeImmutable($periodStartRaw))->modify('first day of this month');
            $limit = (new \DateTimeImmutable($periodEndRaw))->modify('first day of this month');
        } catch (\Throwable $exception) {
            return [];
        }

        $tables = [];

        while ($cursor <= $limit) {
            $suffix = $cursor->format('Ym');

            foreach ([
                'f_produtividade_mensal_' . $suffix,
                'f_produtividade_semestral_' . $suffix,
                'f_acumulado_' . $suffix,
            ] as $candidateTable) {
                if ($this->hasProductivitySnapshotTable($candidateTable)) {
                    $tables[] = $candidateTable;
                }
            }

            $cursor = $cursor->modify('+1 month');
        }

        return array_values(array_unique($tables));
    }

    private function quoteTableIdentifier(string $tableName): string
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $tableName)) {
            throw new \InvalidArgumentException('Nome de tabela invalido para consulta.');
        }

        return '`' . str_replace('`', '``', $tableName) . '`';
    }

    private function quoteColumnIdentifier(string $columnName): string
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', $columnName)) {
            throw new \InvalidArgumentException('Nome de coluna invalido para consulta.');
        }

        return '`' . str_replace('`', '``', $columnName) . '`';
    }

    private function resolveSemestralAnoMes(string $referenceEndDate = '', string $periodId = ''): string
    {
        $referenceEndDate = trim($referenceEndDate);

        if ($referenceEndDate === '' && $periodId !== '') {
            $period = $this->getPeriodDefinition($periodId);
            $referenceEndDate = trim((string) ($period['dt_fim_periodo'] ?? ''));
        }

        try {
            $anchor = new \DateTimeImmutable($referenceEndDate !== '' ? $referenceEndDate : 'today');
        } catch (\Throwable $exception) {
            $anchor = new \DateTimeImmutable('today');
        }

        return $anchor->format('Ym');
    }

    private function prepareSemestralSummaryFilters(array $context, array $values, string $referenceEndDate, string $periodId, string $tableName): array
    {
        $anomes = $this->resolveSemestralAnoMes($referenceEndDate, $periodId);
        $values = $this->hydrateSemestralProfileHierarchySelections($context, $values, $anomes, $tableName);
        $scopeCode = strtoupper(trim((string) (($context['scope']['code'] ?? 'GLOBAL'))));

        $options = [];
        $states = [];
        $options['segmento'] = $this->listSemestralSegmentOptions(
            $context,
            $anomes,
            [
                'diretoria' => $values['diretoria'],
                'regional' => $values['regional'],
                'agencia' => $values['agencia'],
                'gerente' => $values['gerente'],
            ],
            $tableName
        );
        $defaultProgram = '';

        foreach ($options['segmento'] as $segmentOption) {
            $candidateValue = trim((string) ($segmentOption['value'] ?? ''));

            if ($candidateValue === '') {
                continue;
            }

            if ($defaultProgram === '') {
                $defaultProgram = $candidateValue;
                continue;
            }

            if (ctype_digit($candidateValue) && ctype_digit($defaultProgram)) {
                if ((int) $candidateValue < (int) $defaultProgram) {
                    $defaultProgram = $candidateValue;
                }

                continue;
            }

            if (strcmp($candidateValue, $defaultProgram) < 0) {
                $defaultProgram = $candidateValue;
            }
        }

        $values['segmento'] = $this->sanitizeFilterSelection($values['segmento'], $options['segmento'], $defaultProgram);
        $states['segmento'] = [
            'enabled' => true,
            'placeholder' => 'Todos os programas',
        ];

        $diretoriaEnabled = true;
        $options['diretoria'] = $diretoriaEnabled
            ? $this->listSemestralHierarchyOptions(
                $context,
                $anomes,
                ['segmento' => $values['segmento']],
                'COD_DIRETORIA',
                'DS_DIRETORIA',
                ['segmento'],
                $tableName
            )
            : [];
        $values['diretoria'] = $this->sanitizeFilterSelection($values['diretoria'], $options['diretoria']);
        $states['diretoria'] = [
            'enabled' => $diretoriaEnabled,
            'placeholder' => 'Todas',
        ];

        $regionalEnabled = ($values['diretoria'] ?? '') !== ''
            || ($values['regional'] ?? '') !== ''
            || in_array($scopeCode, ['DR', 'GR', 'AG', 'SELF', 'SG'], true);
        $options['regional'] = $regionalEnabled
            ? $this->listSemestralHierarchyOptions(
                $context,
                $anomes,
                [
                    'segmento' => $values['segmento'],
                    'diretoria' => $values['diretoria'],
                ],
                'COD_REGIONAL',
                'DS_REGIONAL',
                ['segmento', 'diretoria'],
                $tableName
            )
            : [];
        $values['regional'] = $this->sanitizeFilterSelection($values['regional'], $options['regional']);
        $states['regional'] = [
            'enabled' => $regionalEnabled,
            'placeholder' => $regionalEnabled ? 'Todas' : 'Selecione os filtros anteriores',
        ];

        $agenciaEnabled = ($values['regional'] ?? '') !== ''
            || ($values['agencia'] ?? '') !== ''
            || in_array($scopeCode, ['GR', 'AG', 'SELF', 'SG'], true);
        $options['agencia'] = $agenciaEnabled
            ? $this->listSemestralHierarchyOptions(
                $context,
                $anomes,
                [
                    'segmento' => $values['segmento'],
                    'diretoria' => $values['diretoria'],
                    'regional' => $values['regional'],
                ],
                'COD_AGENCIA',
                'DS_AGENCIA',
                ['segmento', 'diretoria', 'regional'],
                $tableName
            )
            : [];
        $values['agencia'] = $this->sanitizeFilterSelection($values['agencia'], $options['agencia']);
        $states['agencia'] = [
            'enabled' => $agenciaEnabled,
            'placeholder' => $agenciaEnabled ? 'Todas' : 'Selecione os filtros anteriores',
        ];

        $gerenteGestaoEnabled = ($values['agencia'] ?? '') !== '' || ($values['gerente_gestao'] ?? '') !== '' || ($values['gerente'] ?? '') !== '';
        $hasManagementManagers = $gerenteGestaoEnabled && ($values['agencia'] ?? '') !== ''
            ? $this->hasSnapshotManagementManagers(
                $context,
                [
                    'segmento' => $values['segmento'],
                    'diretoria' => $values['diretoria'],
                    'regional' => $values['regional'],
                    'agencia' => $values['agencia'],
                ],
                $anomes,
                $tableName
            )
            : (($values['gerente_gestao'] ?? '') !== '');
        $gerenteGestaoFieldEnabled = $gerenteGestaoEnabled && $hasManagementManagers;
        $options['gerente_gestao'] = $gerenteGestaoFieldEnabled
            ? $this->listSemestralManagementManagerOptions(
                $context,
                $anomes,
                [
                    'segmento' => $values['segmento'],
                    'diretoria' => $values['diretoria'],
                    'regional' => $values['regional'],
                    'agencia' => $values['agencia'],
                ],
                $tableName
            )
            : [];
        if ($gerenteGestaoFieldEnabled) {
            $options['gerente_gestao'] = $this->ensureSelectedHierarchyOption($options['gerente_gestao'], $context, $values['gerente_gestao'] ?? '');
        }
        $values['gerente_gestao'] = $this->sanitizeFilterSelection($values['gerente_gestao'], $options['gerente_gestao']);
        $states['gerente_gestao'] = [
            'enabled' => $gerenteGestaoFieldEnabled,
            'placeholder' => !$gerenteGestaoEnabled
                ? 'Selecione os filtros anteriores'
                : ((($values['agencia'] ?? '') !== '' && !$hasManagementManagers)
                    ? 'Sem gerente de gestao nesta agencia'
                    : ($gerenteGestaoFieldEnabled ? 'Todos' : 'Selecione os filtros anteriores')),
        ];

        $gerenteEnabled = ($values['agencia'] ?? '') !== ''
            || ($values['gerente'] ?? '') !== '';
        $options['gerente'] = $gerenteEnabled
            ? $this->listSemestralCommercialManagerOptions(
                $context,
                $anomes,
                [
                    'segmento' => $values['segmento'],
                    'diretoria' => $values['diretoria'],
                    'regional' => $values['regional'],
                    'agencia' => $values['agencia'],
                    'gerente_gestao' => $values['gerente_gestao'],
                ],
                $tableName
            )
            : [];
        if ($gerenteEnabled) {
            $options['gerente'] = $this->ensureSelectedHierarchyOption($options['gerente'], $context, $values['gerente'] ?? '');
        }
        $values['gerente'] = $this->sanitizeFilterSelection($values['gerente'], $options['gerente']);
        $states['gerente'] = [
            'enabled' => $gerenteEnabled,
            'placeholder' => $gerenteEnabled ? 'Todos' : 'Selecione os filtros anteriores',
        ];

        $options['familia'] = $this->listSemestralFamilyOptions(
            $context,
            $anomes,
            [
                'segmento' => $values['segmento'],
                'diretoria' => $values['diretoria'],
                'regional' => $values['regional'],
                'agencia' => $values['agencia'],
                'gerente_gestao' => $values['gerente_gestao'],
                'gerente' => $values['gerente'],
            ],
            $tableName
        );
        $values['familia'] = $this->sanitizeFilterSelection($values['familia'], $options['familia']);

        $options['indicadores'] = $this->listSemestralIndicatorOptions(
            $context,
            $anomes,
            [
                'segmento' => $values['segmento'],
                'diretoria' => $values['diretoria'],
                'regional' => $values['regional'],
                'agencia' => $values['agencia'],
                'gerente_gestao' => $values['gerente_gestao'],
                'gerente' => $values['gerente'],
                'familia' => $values['familia'],
            ],
            $tableName
        );
        $values['indicadores'] = $this->sanitizeFilterSelection($values['indicadores'], $options['indicadores']);

        $options['subindicador'] = [];
        $values['subindicador'] = '';

        $options['status_indicadores'] = [
            ['value' => 'ATINGIDO', 'label' => 'Atingido'],
            ['value' => 'NAO_ATINGIDO', 'label' => 'Nao atingido'],
        ];
        $values['status_indicadores'] = $this->sanitizeFilterSelection($values['status_indicadores'], $options['status_indicadores']);

        $options['visao_acumulada'] = [
            ['value' => 'MENSAL', 'label' => 'Mensal'],
            ['value' => 'SEMESTRAL', 'label' => 'Semestral'],
            ['value' => 'ACUMULADO', 'label' => 'Acumulado'],
            ['value' => 'ANUAL', 'label' => 'Anual'],
            ['value' => 'MENSAL_ACUMULADO', 'label' => 'Mensal/Acumulado'],
        ];
        $values['visao_acumulada'] = $this->sanitizeFilterSelection($values['visao_acumulada'], $options['visao_acumulada'], 'MENSAL');

        return [
            'options' => $options,
            'values' => $values,
            'states' => $states,
        ];
    }

    private function hydrateSemestralProfileHierarchySelections(array $context, array $filters, string $anomes = '', string $tableName = ''): array
    {
        $profile = $context['profile'] ?? [];
        $junctions = $context['junctions'] ?? [];
        $level = strtoupper(trim((string) ($profile['nivel'] ?? '')));
        $functional = trim((string) ($profile['funcional'] ?? ''));
        $primaryAgency = $this->resolvePrimaryJunction($junctions, 'AG');
        $primaryRegional = $this->resolvePrimaryJunction($junctions, 'GR');
        $primaryDirectorate = $this->resolvePrimaryJunction($junctions, 'DR');

        if (in_array($level, ['GC', 'PA', 'AS'], true) && $functional !== '' && ($filters['gerente'] ?? '') === '') {
            $filters['gerente'] = $functional;
        } elseif (in_array($level, ['GG', 'TL'], true) && $functional !== '' && ($filters['gerente_gestao'] ?? '') === '') {
            $filters['gerente_gestao'] = $functional;
            if (($filters['agencia'] ?? '') === '' && $primaryAgency !== '') {
                $filters['agencia'] = $primaryAgency;
            }
        } elseif ($level === 'AG' && $primaryAgency !== '') {
            if (($filters['agencia'] ?? '') === '') {
                $filters['agencia'] = $primaryAgency;
            }
        } elseif (in_array($level, ['GR', 'GE'], true) && $primaryRegional !== '') {
            if (($filters['regional'] ?? '') === '') {
                $filters['regional'] = $primaryRegional;
            }
        } elseif ($level === 'DR' && $primaryDirectorate !== '') {
            if (($filters['diretoria'] ?? '') === '') {
                $filters['diretoria'] = $primaryDirectorate;
            }
        }

        return $this->hydrateSemestralHierarchySelections($context, $filters, $anomes, $tableName);
    }

    private function hydrateSemestralHierarchySelections(array $context, array $filters, string $anomes, string $tableName): array
    {
        if ($anomes === '' || $tableName === '' || !$this->hasProductivitySnapshotTable($tableName)) {
            return $filters;
        }

        if (($filters['gerente'] ?? '') !== '') {
            return $this->mergeResolvedFilters(
                $filters,
                $this->resolveSemestralHierarchyPath($context, $anomes, $tableName, [
                    'gerente' => (string) ($filters['gerente'] ?? ''),
                ])
            );
        }

        if (($filters['agencia'] ?? '') !== '') {
            return $this->mergeResolvedFilters(
                $filters,
                $this->resolveSemestralHierarchyPath($context, $anomes, $tableName, [
                    'agencia' => (string) ($filters['agencia'] ?? ''),
                ])
            );
        }

        if (($filters['regional'] ?? '') !== '') {
            return $this->mergeResolvedFilters(
                $filters,
                $this->resolveSemestralHierarchyPath($context, $anomes, $tableName, [
                    'regional' => (string) ($filters['regional'] ?? ''),
                ])
            );
        }

        return $filters;
    }

    private function resolveSemestralHierarchyPath(array $context, string $anomes, string $tableName, array $selectedFilters): array
    {
        $row = $this->fetchProcedureRow(
            'sp_pobj_list_snapshot_detail_rows',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_anomes' => $anomes,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                [
                    'p_segmento' => '',
                    'p_diretoria' => '',
                    'p_regional' => trim((string) ($selectedFilters['regional'] ?? '')),
                    'p_agencia' => trim((string) ($selectedFilters['agencia'] ?? '')),
                    'p_gerente_gestao' => trim((string) ($selectedFilters['gerente_gestao'] ?? '')),
                    'p_gerente' => trim((string) ($selectedFilters['gerente'] ?? '')),
                ]
            )
        );

        if (!$row) {
            return [];
        }

        $resolved = [];

        if (($selectedFilters['gerente'] ?? '') !== '') {
            $resolved['gerente_gestao'] = trim((string) ($row['funcional_gerente_gestao'] ?? ''));
            $resolved['agencia'] = trim((string) ($row['juncao_ag'] ?? ''));
            $resolved['regional'] = trim((string) ($row['juncao_gr'] ?? ''));
            $resolved['diretoria'] = trim((string) ($row['juncao_dr'] ?? ''));

            return $resolved;
        }

        if (($selectedFilters['agencia'] ?? '') !== '') {
            $resolved['regional'] = trim((string) ($row['juncao_gr'] ?? ''));
            $resolved['diretoria'] = trim((string) ($row['juncao_dr'] ?? ''));

            return $resolved;
        }

        if (($selectedFilters['regional'] ?? '') !== '') {
            $resolved['diretoria'] = trim((string) ($row['juncao_dr'] ?? ''));
        }

        return $resolved;
    }

    private function listSemestralSegmentOptions(array $context, string $anomes, array $filters, string $tableName): array
    {
        if (!$this->hasProductivitySnapshotTable($tableName)) {
            return [];
        }

        return $this->fetchProcedureAll(
            'sp_pobj_list_semestral_segment_options',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_anomes' => $anomes,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                [
                    'p_diretoria' => trim((string) ($filters['diretoria'] ?? '')),
                    'p_regional' => trim((string) ($filters['regional'] ?? '')),
                    'p_agencia' => trim((string) ($filters['agencia'] ?? '')),
                    'p_gerente' => trim((string) ($filters['gerente'] ?? '')),
                ]
            )
        );
    }

    private function listSemestralUnitOptions(array $context, string $anomes, array $filters, string $tableName): array
    {
        if (!$this->hasProductivitySnapshotTable($tableName)) {
            return [];
        }

        return $this->fetchProcedureAll(
            'sp_pobj_list_semestral_unit_options',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_anomes' => $anomes,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildSemestralProcedureHierarchyFilterParams($filters)
            )
        );
    }

    private function listSemestralHierarchyOptions(
        array $context,
        string $anomes,
        array $filters,
        string $codeField,
        string $labelField,
        array $allowedFilters,
        string $tableName
    ): array {
        if (!$this->hasProductivitySnapshotTable($tableName)) {
            return [];
        }

        $level = '';

        if ($codeField === 'COD_DIRETORIA' && $labelField === 'DS_DIRETORIA') {
            $level = 'DIRETORIA';
        } elseif ($codeField === 'COD_REGIONAL' && $labelField === 'DS_REGIONAL') {
            $level = 'REGIONAL';
        } elseif ($codeField === 'COD_AGENCIA' && $labelField === 'DS_AGENCIA') {
            $level = 'AGENCIA';
        }

        if ($level === '') {
            return [];
        }

        $effectiveFilters = [
            'segmento' => in_array('segmento', $allowedFilters, true) ? (string) ($filters['segmento'] ?? '') : '',
            'diretoria' => in_array('diretoria', $allowedFilters, true) ? (string) ($filters['diretoria'] ?? '') : '',
            'regional' => in_array('regional', $allowedFilters, true) ? (string) ($filters['regional'] ?? '') : '',
        ];

        return $this->fetchProcedureAll(
            'sp_pobj_list_semestral_hierarchy_options',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_anomes' => $anomes,
                    'p_level' => $level,
                    'p_segmento' => $effectiveFilters['segmento'],
                    'p_diretoria' => $effectiveFilters['diretoria'],
                    'p_regional' => $effectiveFilters['regional'],
                ],
                $this->buildSemestralProcedureScopeParams($context)
            )
        );
    }

    private function listSemestralManagementManagerOptions(array $context, string $anomes, array $filters, string $tableName): array
    {
        if (
            !$this->hasProductivitySnapshotTable($tableName)
            || !$this->hasManagementRelationTable()
            || !$this->hasDatabaseTable('dHierarquia')
        ) {
            return [];
        }

        return $this->fetchProcedureAll(
            'sp_pobj_list_semestral_management_manager_options',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_anomes' => $anomes,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildSemestralProcedureHierarchyFilterParams($filters)
            )
        );
    }

    private function listSemestralCommercialManagerOptions(array $context, string $anomes, array $filters, string $tableName): array
    {
        if (!$this->hasProductivitySnapshotTable($tableName) || !$this->hasDatabaseTable('dHierarquia')) {
            return [];
        }

        return $this->fetchProcedureAll(
            'sp_pobj_list_semestral_commercial_manager_options',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_anomes' => $anomes,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildSemestralProcedureHierarchyFilterParams($filters),
                [
                    'p_gerente_gestao' => trim((string) ($filters['gerente_gestao'] ?? '')),
                ]
            )
        );
    }

    private function listSemestralFamilyOptions(array $context, string $anomes, array $filters, string $tableName): array
    {
        if (!$this->hasProductivitySnapshotTable($tableName)) {
            return [];
        }

        return $this->fetchProcedureAll(
            'sp_pobj_list_semestral_family_options',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_anomes' => $anomes,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildSemestralProcedureHierarchyFilterParams($filters),
                $this->buildSemestralProcedureManagerFilterParams($filters)
            )
        );
    }

    private function listSemestralIndicatorOptions(array $context, string $anomes, array $filters, string $tableName): array
    {
        if (!$this->hasProductivitySnapshotTable($tableName)) {
            return [];
        }

        return $this->fetchProcedureAll(
            'sp_pobj_list_semestral_indicator_options',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_anomes' => $anomes,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildSemestralProcedureHierarchyFilterParams($filters),
                $this->buildSemestralProcedureManagerFilterParams($filters),
                [
                    'p_familia' => trim((string) ($filters['familia'] ?? '')),
                ]
            )
        );
    }

    private function getSemestralDashboardData(array $context, array $filters, string $referenceEndDate, string $periodId, string $tableName): array
    {
        $indicatorRows = $this->getSemestralIndicatorRows($context, $filters, $referenceEndDate, $periodId, $tableName);
        $summaryRows = array_values(array_filter($indicatorRows, static function (array $row): bool {
            return (int) ($row['nivel'] ?? 1) <= 1;
        }));
        $indicatorCount = count($summaryRows);
        $achievedCount = 0;
        $pontosMeta = 0.0;
        $pontosRealizado = 0.0;
        $anomes = $this->resolveSemestralAnoMes($referenceEndDate, $periodId);
        $variableTotals = $this->getVariableSummary($context, $filters, $anomes);

        foreach ($summaryRows as $row) {
            if ((bool) ($row['atingiu'] ?? false)) {
                $achievedCount++;
            }

            $pontosMeta += (float) ($row['pontos_meta'] ?? 0.0);
            $pontosRealizado += (float) ($row['pontos'] ?? 0.0);
        }

        return [
            'summary' => [
                'indicadores_atingidos' => $achievedCount,
                'indicadores_total' => $indicatorCount,
                'taxa_atingimento' => $indicatorCount > 0 ? ($achievedCount / $indicatorCount) * 100 : 0.0,
                'pontos_meta' => $pontosMeta,
                'pontos_realizado' => $pontosRealizado,
                'variavel_meta' => (float) ($variableTotals['meta'] ?? 0.0),
                'variavel_realizada' => (float) ($variableTotals['realizado'] ?? 0.0),
                'funcionais_visiveis' => $this->countSemestralVisibleUnits($context, $filters, $referenceEndDate, $periodId, $tableName),
                'contratos_visiveis' => 0,
            ],
            'indicators' => $indicatorRows,
        ];
    }

    private function getSemestralIndicatorRows(array $context, array $filters, string $referenceEndDate, string $periodId, string $tableName): array
    {
        $filters = $this->normalizeSummaryFilters($filters);
        $anomes = $this->resolveSemestralAnoMes($referenceEndDate, $periodId);
        $rows = $this->fetchProcedureAll(
            'sp_pobj_list_semestral_indicator_rows',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_anomes' => $anomes,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildSemestralProcedureHierarchyFilterParams($filters),
                $this->buildSemestralProcedureManagerFilterParams($filters),
                $this->buildSemestralProcedureMetricFilterParams($filters)
            )
        );

        try {
            $monthEnd = (new \DateTimeImmutable(substr($anomes, 0, 4) . '-' . substr($anomes, 4, 2) . '-01'))
                ->modify('last day of this month')
                ->format('Y-m-d');
        } catch (\Throwable $exception) {
            $monthEnd = '';
        }

        $filteredRows = [];

        foreach ($rows as $row) {
            $metricType = trim((string) ($row['id_tipo_indicador'] ?? ''));

            if ($metricType === '') {
                $metricType = $this->inferSemestralMetricType((string) ($row['ds_metrica'] ?? ''));
            }

            $meta = (float) ($row['meta_total'] ?? 0.0);
            $realizado = (float) ($row['realizado_total'] ?? 0.0);
            $readyAtingimento = (float) ($row['atingimento_medio'] ?? 0.0);
            $percentual = $readyAtingimento;

            $row['id_tipo_indicador'] = $metricType;
            $row['nome_tipo_indicador'] = trim((string) ($row['nome_tipo_indicador'] ?? '')) !== ''
                ? (string) $row['nome_tipo_indicador']
                : $metricType;
            $row['id_pai_indicador'] = (string) ($row['id_pai_indicador'] ?? $row['id_indicador'] ?? '');
            $row['nivel'] = (int) ($row['nivel'] ?? 0);
            $row['id_programa'] = (string) ($row['id_programa'] ?? '');
            $row['meta'] = $meta;
            $row['realizado'] = $realizado;
            $row['peso'] = (float) ($row['pontos_meta_total'] ?? 0.0);
            $row['pontos_meta'] = (float) ($row['pontos_meta_total'] ?? 0.0);
            $row['pontos'] = (float) ($row['pontos_total'] ?? 0.0);
            $row['percentual_atingimento'] = $percentual;
            $row['nec_dia'] = (float) ($row['nec_dia_medio'] ?? 0.0);
            $row['referencia'] = (float) ($row['referencia_media'] ?? 0.0);
            $row['variavel'] = 0.0;
            $row['variavel_meta'] = 0.0;
            $row['subindicadores'] = [];
            $row['ultima_atualizacao'] = trim((string) ($row['data_base_max'] ?? '')) !== ''
                ? (string) $row['data_base_max']
                : $monthEnd;
            $row['atingiu'] = $percentual >= 100.0;
            $row['realizado_absoluto'] = null;
            $row['base_absoluta'] = null;
            $row['realizado_absoluto_label'] = '';
            $row['base_absoluta_label'] = '';
            $row['usa_base_absoluta'] = false;

            if (($filters['status_indicadores'] ?? '') === 'ATINGIDO' && !$row['atingiu']) {
                continue;
            }

            if (($filters['status_indicadores'] ?? '') === 'NAO_ATINGIDO' && $row['atingiu']) {
                continue;
            }

            $filteredRows[] = $row;
        }

        return $filteredRows;
    }

    private function getSemestralIndicatorDetailData(
        array $context,
        array $filters,
        string $indicatorId,
        string $referenceEndDate,
        string $periodId,
        string $tableName,
        int $transactionPage = 1
    ): array
    {
        $indicatorRows = $this->getSemestralIndicatorRows($context, $filters, $referenceEndDate, $periodId, $tableName);
        $indicatorRow = [];

        foreach ($indicatorRows as $row) {
            if ((string) ($row['id_indicador'] ?? '') === $indicatorId) {
                $indicatorRow = $row;
                break;
            }
        }

        if ($indicatorRow === []) {
            return [
                'indicator' => [],
                'summary' => [],
                'trend' => [],
                'distributions' => ['channels' => [], 'statuses' => []],
                'insights' => ['mode' => 'hierarchy', 'label' => '', 'title' => '', 'top' => [], 'bottom' => []],
                'transactions' => [],
                'analytic_pagination' => $this->buildIndicatorAnalyticPagination(0, 1, self::INDICATOR_ANALYTIC_PER_PAGE),
            ];
        }

        $anomes = $this->resolveSemestralAnoMes($referenceEndDate, $periodId);
        $transactionPerPage = self::INDICATOR_ANALYTIC_PER_PAGE;
        $variableTotals = $this->getVariableSummary($context, $filters, $anomes);
        $summary = $this->buildIndicatorDetailSummary($indicatorRow, []);
        $summary['variavel'] = (float) ($variableTotals['realizado'] ?? 0.0);
        $summary['variavel_meta'] = (float) ($variableTotals['meta'] ?? 0.0);
        $summary['transaction_volume'] = (float) ($indicatorRow['realizado'] ?? 0.0);
        $trendRows = $this->getSnapshotIndicatorTrendRows($context, $filters, $indicatorId, (string) ($indicatorRow['id_tipo_indicador'] ?? 'VALOR'));
        $insightRows = $this->getSnapshotIndicatorInsightData($context, $filters, $indicatorId, $anomes, $tableName);
        $analyticAvailable = $this->canExposeAnalyticRows($context, $filters);
        $analyticSummary = [
            'contracts_total' => 0,
            'clients_total' => 0,
            'transactions_total' => 0,
            'transaction_volume' => (float) ($indicatorRow['realizado'] ?? 0.0),
            'last_transaction_date' => '',
        ];
        $analyticPagination = $this->buildIndicatorAnalyticPagination(0, 1, $transactionPerPage);
        $transactionRows = [];

        if ($analyticAvailable) {
            $analyticSummary = $this->getSnapshotIndicatorAnalyticSummary($context, $filters, $indicatorId, $anomes);
            $analyticPagination = $this->buildIndicatorAnalyticPagination(
                (int) ($analyticSummary['transactions_total'] ?? 0),
                $transactionPage,
                $transactionPerPage
            );
            $transactionRows = $this->getSnapshotIndicatorTransactionRows(
                $context,
                $filters,
                $indicatorId,
                $anomes,
                (int) ($analyticPagination['page'] ?? 1),
                $transactionPerPage
            );
        }

        $summary['contracts_total'] = (int) ($analyticSummary['contracts_total'] ?? 0);
        $summary['clients_total'] = (int) ($analyticSummary['clients_total'] ?? 0);
        $summary['transactions_total'] = (int) ($analyticSummary['transactions_total'] ?? 0);
        $summary['transaction_volume'] = (float) ($analyticSummary['transaction_volume'] ?? (float) ($indicatorRow['realizado'] ?? 0.0));
        $summary['last_transaction_date'] = (string) ($analyticSummary['last_transaction_date'] ?? '');

        return [
            'indicator' => $indicatorRow,
            'summary' => $summary,
            'trend' => $trendRows,
            'distributions' => ['channels' => [], 'statuses' => []],
            'insights' => $insightRows,
            'analytic_available' => $analyticAvailable,
            'analytic_message' => $analyticAvailable
                ? ''
                : 'Selecione um gerente para ver a venda a venda do indicador neste periodo.',
            'transactions' => $transactionRows,
            'analytic_pagination' => $analyticPagination,
        ];
    }

    private function getSnapshotIndicatorAnalyticSummary(array $context, array $filters, string $indicatorId, string $anomes): array
    {
        $tableName = $this->resolveAnalyticSnapshotTableName($anomes);
        $snapshotTableName = $this->hasProductivitySnapshotTable('f_produtividade_mensal_' . $anomes)
            ? 'f_produtividade_mensal_' . $anomes
            : '';

        if ($tableName === '') {
            return [
                'contracts_total' => 0,
                'clients_total' => 0,
                'transactions_total' => 0,
                'transaction_volume' => 0.0,
                'last_transaction_date' => '',
            ];
        }

        $row = $this->fetchProcedureRow(
            'sp_pobj_get_snapshot_indicator_analytic_summary',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_snapshot_table_name' => $snapshotTableName,
                    'p_anomes' => $anomes,
                    'p_indicator_id' => $indicatorId,
                ],
                $this->buildAnalyticProcedureScopeParams($context),
                $this->buildAnalyticProcedureHierarchyFilterParams($filters)
            )
        ) ?: [];

        return [
            'contracts_total' => (int) ($row['contracts_total'] ?? 0),
            'clients_total' => (int) ($row['clients_total'] ?? 0),
            'transactions_total' => (int) ($row['transactions_total'] ?? 0),
            'transaction_volume' => (float) ($row['transaction_volume'] ?? 0.0),
            'last_transaction_date' => trim((string) ($row['last_transaction_date'] ?? '')),
        ];
    }

    private function getSnapshotIndicatorTransactionRows(
        array $context,
        array $filters,
        string $indicatorId,
        string $anomes,
        int $page,
        int $perPage
    ): array {
        $tableName = $this->resolveAnalyticSnapshotTableName($anomes);
        $snapshotTableName = $this->hasProductivitySnapshotTable('f_produtividade_mensal_' . $anomes)
            ? 'f_produtividade_mensal_' . $anomes
            : '';

        if ($tableName === '') {
            return [];
        }

        $page = max(1, $page);
        $perPage = max(1, $perPage);
        $offset = ($page - 1) * $perPage;

        $rows = [];

        foreach ($this->fetchProcedureAll(
            'sp_pobj_list_snapshot_indicator_transactions',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_snapshot_table_name' => $snapshotTableName,
                    'p_anomes' => $anomes,
                    'p_indicator_id' => $indicatorId,
                    'p_limit_rows' => $perPage,
                    'p_offset_rows' => $offset,
                ],
                $this->buildAnalyticProcedureScopeParams($context),
                $this->buildAnalyticProcedureHierarchyFilterParams($filters)
            )
        ) as $row) {
            $documentInfo = $this->buildAnalyticDocumentInfo(
                (string) ($row['cpf_cnpj'] ?? ''),
                (string) ($row['cpf_cnpj_fil'] ?? ''),
                (string) ($row['cpf_cnpj_dig'] ?? '')
            );
            $managerName = trim((string) ($row['gerente_negocios'] ?? ''));
            $productName = trim((string) ($row['nome_produto'] ?? ''));

            if ($managerName === '') {
                $managerName = trim((string) ($row['funcional_gerente_conta'] ?? ''));
            }

            $rows[] = [
                'data_transacao' => (string) ($row['data_transacao'] ?? ''),
                'agencia' => (string) ($row['agencia'] ?? ''),
                'agencia_2' => (string) ($row['agencia_2'] ?? ''),
                'conta' => (string) ($row['conta'] ?? ''),
                'carteira' => (string) ($row['carteira'] ?? ''),
                'numero_contrato' => (string) ($row['numero_contrato'] ?? ''),
                'valor_financiado' => (float) ($row['valor_financiado'] ?? 0.0),
                'valor_realizado' => (float) ($row['valor_realizado'] ?? 0.0),
                'valor_realizado_2' => (float) ($row['valor_realizado_2'] ?? 0.0),
                'documento' => (string) ($documentInfo['display'] ?? ''),
                'documento_tipo' => (string) ($documentInfo['kind'] ?? ''),
                'nome_produto' => $productName !== '' ? $productName : 'Produto nao informado',
                'id_segmento' => trim((string) ($row['id_segmento'] ?? '')),
                'produto_macro' => trim((string) ($row['produto_macro'] ?? '')),
                'valor_origem_garantia' => (float) ($row['valor_origem_garantia'] ?? 0.0),
                'nr_proposta' => trim((string) ($row['nr_proposta'] ?? '')),
                'indicador_producao' => trim((string) ($row['identificador_producao'] ?? '')),
                'juncao_final_realizado' => trim((string) ($row['juncao_final_realizado'] ?? '')),
                'funcional_gerente_conta' => trim((string) ($row['funcional_gerente_conta'] ?? '')),
                'gerente_negocios' => trim((string) ($row['gerente_negocios'] ?? '')),
                'juncao_bc' => trim((string) ($row['juncao_bc'] ?? '')),
                'gerente_gestao' => trim((string) ($row['gerente_gestao'] ?? '')),
                'funcional_assistente' => trim((string) ($row['funcional_assistente'] ?? '')),
                'juncao_dr' => trim((string) ($row['juncao_dr'] ?? '')),
                'juncao_gr' => trim((string) ($row['juncao_gr'] ?? '')),
                'juncao_final_classic' => trim((string) ($row['juncao_final_classic'] ?? '')),
                'juncao_gr_pa' => trim((string) ($row['juncao_gr_pa'] ?? '')),
                'juncao_dr_pa' => trim((string) ($row['juncao_dr_pa'] ?? '')),
                'funcional_ga' => trim((string) ($row['funcional_ga'] ?? '')),
                'assessor_gr' => trim((string) ($row['assessor_gr'] ?? '')),
                'assessor_dr' => trim((string) ($row['assessor_dr'] ?? '')),
                'juncao_assistente_pa' => trim((string) ($row['juncao_assistente_pa'] ?? '')),
                'nome_gerente' => $managerName,
                'nome_gerente_gestao' => trim((string) ($row['gerente_gestao'] ?? '')),
                'desconsiderar_producao' => (int) ($row['flag_desconsiderar_producao'] ?? 0) === 1,
                'flag_desconsiderar_producao' => (int) ($row['flag_desconsiderar_producao'] ?? 0),
            ];
        }

        return $rows;
    }

    private function getSnapshotIndicatorTrendRows(array $context, array $filters, string $indicatorId, string $metricType): array
    {
        try {
            $anchorMonth = (new \DateTimeImmutable('today'))->modify('first day of this month');
        } catch (\Throwable $exception) {
            $anchorMonth = (new \DateTimeImmutable('now'))->modify('first day of this month');
        }

        $rows = [];

        for ($offset = 2; $offset >= 0; $offset--) {
            $monthDate = $anchorMonth->sub(new \DateInterval('P' . $offset . 'M'));
            $anomes = $monthDate->format('Ym');
            $tableName = 'f_produtividade_mensal_' . $anomes;

            if (!$this->hasProductivitySnapshotTable($tableName)) {
                continue;
            }

            $row = $this->fetchProcedureRow(
                'sp_pobj_get_snapshot_indicator_trend_point',
                array_merge(
                    [
                        'p_table_name' => $tableName,
                        'p_anomes' => $anomes,
                        'p_indicator_id' => $indicatorId,
                        'p_familia' => trim((string) ($filters['familia'] ?? '')),
                    ],
                    $this->buildSemestralProcedureScopeParams($context),
                    $this->buildSemestralProcedureHierarchyFilterParams($filters),
                    $this->buildSemestralProcedureManagerFilterParams($filters)
                )
            ) ?: [];
            $meta = (float) ($row['meta_total'] ?? 0.0);
            $realizado = (float) ($row['realizado_total'] ?? 0.0);
            $readyPercentual = (float) ($row['atingimento_medio'] ?? 0.0);

            $rows[] = [
                'month_key' => $monthDate->format('Y-m'),
                'month_label' => $this->formatMonthLabel($monthDate),
                'meta' => $meta,
                'realizado' => $realizado,
                'percentual' => $readyPercentual,
                'metric_type' => $metricType,
            ];
        }

        return $rows;
    }

    private function getSnapshotIndicatorInsightData(array $context, array $filters, string $indicatorId, string $anomes, string $tableName): array
    {
        $groupConfig = $this->resolveSnapshotIndicatorInsightGroup($context, $filters, $anomes, $tableName);
        $rows = $this->getSnapshotIndicatorInsightRows($context, $filters, $indicatorId, $anomes, $tableName, (string) ($groupConfig['level'] ?? ''));
        $topRows = $this->sliceTopIndicatorInsightRows($rows);
        $topKeys = array_fill_keys(array_map(static function (array $row): string {
            return trim((string) ($row['key'] ?? ''));
        }, $topRows), true);
        $bottomPool = array_values(array_filter($rows, static function (array $row) use ($topKeys): bool {
            $key = trim((string) ($row['key'] ?? ''));

            if ($key === '') {
                return false;
            }

            return !isset($topKeys[$key]);
        }));

        return [
            'mode' => 'hierarchy',
            'label' => (string) ($groupConfig['label'] ?? 'Recorte atual'),
            'title' => (string) ($groupConfig['title'] ?? 'Comparativo do recorte atual'),
            'top' => $topRows,
            'bottom' => $bottomPool === [] ? [] : $this->sliceBottomIndicatorInsightRows($bottomPool),
        ];
    }

    private function resolveSnapshotIndicatorInsightGroup(array $context, array $filters, string $anomes, string $tableName): array
    {
        if (($filters['gerente'] ?? '') !== '') {
            return [
                'level' => 'produto',
                'label' => 'Produtos',
                'title' => 'Produtos do gerente selecionado',
            ];
        }

        if (($filters['gerente_gestao'] ?? '') !== '') {
            return [
                'level' => 'gerente',
                'label' => 'Gerentes',
                'title' => 'Gerentes do gerente de gestao selecionado',
            ];
        }

        if (($filters['agencia'] ?? '') !== '') {
            if ($this->hasSnapshotManagementManagers($context, $filters, $anomes, $tableName)) {
                return [
                    'level' => 'gerente_gestao',
                    'label' => 'Gerentes de gestao',
                    'title' => 'Gerentes de gestao da agencia selecionada',
                ];
            }

            return [
                'level' => 'gerente',
                'label' => 'Gerentes',
                'title' => 'Gerentes da agencia selecionada',
            ];
        }

        if (($filters['regional'] ?? '') !== '') {
            return [
                'level' => 'agencia',
                'label' => 'Agencias',
                'title' => 'Agencias da regional selecionada',
            ];
        }

        if (($filters['diretoria'] ?? '') !== '') {
            return [
                'level' => 'regional',
                'label' => 'Regionais',
                'title' => 'Regionais da diretoria selecionada',
            ];
        }

        if (($filters['segmento'] ?? '') !== '') {
            return [
                'level' => 'diretoria',
                'label' => 'Diretorias',
                'title' => 'Diretorias do segmento selecionado',
            ];
        }

        $profileLevel = strtoupper(trim((string) (($context['profile']['nivel'] ?? ''))));
        $scopeCode = strtoupper(trim((string) (($context['scope']['code'] ?? 'GLOBAL'))));

        if (in_array($profileLevel, ['GC', 'PA', 'AS'], true) || $scopeCode === 'SELF') {
            return [
                'level' => 'produto',
                'label' => 'Produtos',
                'title' => 'Produtos do gerente selecionado',
            ];
        }

        if (in_array($profileLevel, ['GG', 'TL'], true)) {
            return [
                'level' => 'gerente',
                'label' => 'Gerentes',
                'title' => 'Gerentes do gerente de gestao selecionado',
            ];
        }

        if ($profileLevel === 'AG' || $scopeCode === 'AG') {
            if ($this->hasSnapshotManagementManagers($context, $filters, $anomes, $tableName)) {
                return [
                    'level' => 'gerente_gestao',
                    'label' => 'Gerentes de gestao',
                    'title' => 'Gerentes de gestao da agencia selecionada',
                ];
            }

            return [
                'level' => 'gerente',
                'label' => 'Gerentes',
                'title' => 'Gerentes da agencia selecionada',
            ];
        }

        if (in_array($profileLevel, ['GR', 'GE'], true) || $scopeCode === 'GR') {
            return [
                'level' => 'agencia',
                'label' => 'Agencias',
                'title' => 'Agencias da regional selecionada',
            ];
        }

        if ($profileLevel === 'DR' || $scopeCode === 'DR') {
            return [
                'level' => 'regional',
                'label' => 'Regionais',
                'title' => 'Regionais da diretoria selecionada',
            ];
        }

        return [
            'level' => 'diretoria',
            'label' => 'Diretorias',
            'title' => 'Diretorias do recorte atual',
        ];
    }

    private function hasSnapshotManagementManagers(array $context, array $filters, string $anomes, string $tableName): bool
    {
        if (!$this->hasProductivitySnapshotTable($tableName) || !$this->hasManagementRelationTable()) {
            return false;
        }

        return (bool) $this->fetchProcedureValue(
            'sp_pobj_has_snapshot_management_managers',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_anomes' => $anomes,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildSemestralProcedureHierarchyFilterParams($filters)
            )
        );
    }

    private function getSnapshotIndicatorInsightRows(
        array $context,
        array $filters,
        string $indicatorId,
        string $anomes,
        string $tableName,
        string $groupLevel
    ): array {
        if ($groupLevel === '') {
            return [];
        }

        $rows = [];

        foreach ($this->fetchProcedureAll(
            'sp_pobj_list_snapshot_indicator_insight_rows',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_anomes' => $anomes,
                    'p_indicator_id' => $indicatorId,
                    'p_group_level' => $groupLevel,
                    'p_familia' => trim((string) ($filters['familia'] ?? '')),
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildSemestralProcedureHierarchyFilterParams($filters),
                $this->buildSemestralProcedureManagerFilterParams($filters)
            )
        ) as $row) {
            $groupValue = trim((string) ($row['group_value'] ?? ''));

            if ($groupValue === '') {
                continue;
            }

            $meta = (float) ($row['meta_total'] ?? 0.0);
            $realizado = (float) ($row['realizado_total'] ?? 0.0);
            $readyPercentual = (float) ($row['atingimento_medio'] ?? 0.0);

            $rows[] = [
                'key' => $groupValue,
                'display_label' => trim((string) ($row['display_label'] ?? $groupValue)),
                'meta' => $meta,
                'realizado' => $realizado,
                'percentual' => $readyPercentual,
                'gap' => $realizado - $meta,
                'contracts_total' => 0,
                'clients_total' => 0,
            ];
        }

        return $rows;
    }

    private function countSemestralVisibleUnits(array $context, array $filters, string $referenceEndDate, string $periodId, string $tableName): int
    {
        if ($tableName === '' || !$this->hasProductivitySnapshotTable($tableName)) {
            return 0;
        }

        $anomes = $this->resolveSemestralAnoMes($referenceEndDate, $periodId);

        return (int) ($this->fetchProcedureValue(
            'sp_pobj_count_semestral_visible_units',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_anomes' => $anomes,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildSemestralProcedureHierarchyFilterParams($filters),
                $this->buildSemestralProcedureManagerFilterParams($filters)
            )
        ) ?? 0);
    }

    private function getDetailIndicatorMetricRows(array $context, array $filters, string $referenceEndDate, string $periodId, string $anomes): array
    {
        $tableName = $this->resolveProductivitySnapshotTableName($filters, $referenceEndDate, $periodId);

        if ($tableName === '') {
            return [];
        }

        return $this->getSemestralIndicatorRows($context, $filters, $referenceEndDate, $periodId, $tableName);
    }

    private function getSnapshotDetailRows(array $context, array $filters, string $anomes, string $tableName): array
    {
        $rows = [];

        foreach ($this->fetchProcedureAll(
            'sp_pobj_list_snapshot_detail_rows',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_anomes' => $anomes,
                ],
                $this->buildSemestralProcedureScopeParams($context),
                $this->buildSemestralProcedureHierarchyFilterParams($filters),
                $this->buildSemestralProcedureManagerFilterParams($filters)
            )
        ) as $row) {
            $metricType = $this->inferSemestralMetricType((string) ($row['ds_metrica'] ?? ''));

            $rows[] = [
                'id_transacao' => 'snapshot-' . (string) ($row['id_detail'] ?? ''),
                'id_indicador' => (string) ($row['id_indicador'] ?? ''),
                'id_subindicador' => (string) ($row['id_subindicador'] ?? ''),
                'funcional' => (string) ($row['funcional'] ?? ''),
                'nome_gerente' => (string) ($row['nome_gerente'] ?? ''),
                'funcional_gerente_gestao' => (string) ($row['funcional_gerente_gestao'] ?? ''),
                'nome_gerente_gestao' => (string) ($row['nome_gerente_gestao'] ?? ''),
                'juncao_ag' => (string) ($row['juncao_ag'] ?? ''),
                'nome_agencia' => (string) ($row['nome_agencia'] ?? ''),
                'juncao_gr' => (string) ($row['juncao_gr'] ?? ''),
                'nome_regional' => (string) ($row['nome_regional'] ?? ''),
                'juncao_dr' => (string) ($row['juncao_dr'] ?? ''),
                'nome_diretoria' => (string) ($row['nome_diretoria'] ?? ''),
                'data_transacao' => (string) ($row['data_transacao'] ?? ''),
                'valor_realizado' => (float) ($row['valor_realizado'] ?? 0.0),
                'valor_meta_detail' => (float) ($row['valor_meta_detail'] ?? 0.0),
                'atingimento_detail' => (float) ($row['atingimento_detail'] ?? 0.0),
                'referencia_detail' => (float) ($row['referencia_detail'] ?? 0.0),
                'necessidade_diaria_detail' => (float) ($row['necessidade_diaria_detail'] ?? 0.0),
                'forecast_detail' => (float) ($row['forecast_detail'] ?? 0.0),
                'peso_detail' => (float) ($row['peso_detail'] ?? 0.0),
                'pontos_detail' => (float) ($row['pontos_detail'] ?? 0.0),
                'id_tipo_indicador' => $metricType,
                'tipo_detail' => $metricType,
                'nome_familia' => (string) ($row['nome_familia'] ?? ''),
                'nome_indicador' => (string) ($row['nome_indicador'] ?? ''),
                'nome_subindicador' => (string) ($row['nome_subindicador'] ?? 'Sem subindicador'),
                'detail_source' => 'snapshot',
            ];
        }

        return $rows;
    }

    private function resolveAnalyticSnapshotTableName(string $anomes): string
    {
        $tableName = 'f_analitico_' . preg_replace('/[^0-9]/', '', $anomes);

        return $this->hasProductivitySnapshotTable($tableName)
            ? $tableName
            : '';
    }

    private function buildIndicatorAnalyticPagination(int $totalRows, int $requestedPage, int $perPage): array
    {
        $perPage = max(1, $perPage);
        $totalRows = max(0, $totalRows);
        $totalPages = max(1, (int) ceil($totalRows / $perPage));
        $page = max(1, min($requestedPage, $totalPages));
        $from = $totalRows > 0 ? (($page - 1) * $perPage) + 1 : 0;
        $to = $totalRows > 0 ? min($totalRows, $page * $perPage) : 0;

        return [
            'page' => $page,
            'per_page' => $perPage,
            'total_rows' => $totalRows,
            'total_pages' => $totalPages,
            'from' => $from,
            'to' => $to,
        ];
    }

    private function buildAnalyticDocumentInfo(string $base, string $branch, string $digit): array
    {
        $baseDigits = preg_replace('/\D+/', '', trim($base));
        $branchDigits = preg_replace('/\D+/', '', trim($branch));
        $digitDigits = preg_replace('/\D+/', '', trim($digit));

        if ($baseDigits === '') {
            return ['raw' => '', 'display' => '', 'kind' => ''];
        }

        $looksLikeCnpj = $branchDigits !== '' || $digitDigits !== '' || strlen($baseDigits) > 11;

        if ($looksLikeCnpj) {
            $rootDigits = substr($baseDigits, 0, 8);

            if ($rootDigits === '') {
                $rootDigits = $baseDigits;
            }

            $raw = str_pad($rootDigits, 8, '0', STR_PAD_LEFT)
                . str_pad($branchDigits, 4, '0', STR_PAD_LEFT)
                . str_pad($digitDigits, 2, '0', STR_PAD_LEFT);

            return [
                'raw' => $raw,
                'display' => $raw,
                'kind' => 'CNPJ',
            ];
        }

        return [
            'raw' => str_pad(substr($baseDigits, 0, 11), 11, '0', STR_PAD_LEFT),
            'display' => str_repeat('*', 11),
            'kind' => 'CPF',
        ];
    }

    private function canExposeAnalyticRows(array $context, array $filters): bool
    {
        if (trim((string) ($filters['gerente'] ?? '')) !== '') {
            return true;
        }

        $profile = (array) ($context['profile'] ?? []);
        $level = strtoupper(trim((string) ($profile['nivel'] ?? '')));

        return in_array($level, ['GC', 'PA', 'AS'], true);
    }

    private function countAnalyticDetailRows(array $context, array $filters, string $anomes): int
    {
        $tableName = $this->resolveAnalyticSnapshotTableName($anomes);
        $snapshotTableName = $this->hasProductivitySnapshotTable('f_produtividade_mensal_' . $anomes)
            ? 'f_produtividade_mensal_' . $anomes
            : '';

        if ($tableName === '' || $snapshotTableName === '') {
            return 0;
        }

        return (int) ($this->fetchProcedureValue(
            'sp_pobj_count_analytic_detail_rows',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_snapshot_table_name' => $snapshotTableName,
                    'p_anomes' => $anomes,
                ],
                $this->buildAnalyticProcedureScopeParams($context),
                $this->buildAnalyticProcedureHierarchyFilterParams($filters),
                $this->buildSemestralProcedureMetricFilterParams($filters)
            ),
            'total_rows'
        ) ?? 0);
    }

    /**
     * @return array<string, int>
     */
    private function getAnalyticDetailIndicatorRowCounts(array $context, array $filters, string $anomes): array
    {
        $tableName = $this->resolveAnalyticSnapshotTableName($anomes);
        $snapshotTableName = $this->hasProductivitySnapshotTable('f_produtividade_mensal_' . $anomes)
            ? 'f_produtividade_mensal_' . $anomes
            : '';

        if ($tableName === '' || $snapshotTableName === '') {
            return [];
        }

        $counts = [];

        foreach ($this->fetchProcedureAll(
            'sp_pobj_count_analytic_detail_rows_by_indicator',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_snapshot_table_name' => $snapshotTableName,
                    'p_anomes' => $anomes,
                ],
                $this->buildAnalyticProcedureScopeParams($context),
                $this->buildAnalyticProcedureHierarchyFilterParams($filters),
                $this->buildSemestralProcedureMetricFilterParams($filters)
            )
        ) as $row) {
            $indicatorId = trim((string) ($row['id_indicador'] ?? ''));

            if ($indicatorId === '') {
                continue;
            }

            $counts[$indicatorId] = max(1, (int) ($row['total_rows'] ?? 0));
        }

        return $counts;
    }

    private function getAnalyticDetailRows(
        array $context,
        array $filters,
        string $anomes,
        int $page = 1,
        int $perPage = 0
    ): array
    {
        $tableName = $this->resolveAnalyticSnapshotTableName($anomes);
        $snapshotTableName = $this->hasProductivitySnapshotTable('f_produtividade_mensal_' . $anomes)
            ? 'f_produtividade_mensal_' . $anomes
            : '';

        if ($tableName === '' || $snapshotTableName === '') {
            return [];
        }
        $rows = [];
        $limit = $perPage > 0 ? $perPage : max(1, self::INDICATOR_ANALYTIC_PER_PAGE);
        $offset = $perPage > 0 ? max(0, ($page - 1) * $perPage) : 0;

        foreach ($this->fetchProcedureAll(
            'sp_pobj_list_analytic_detail_rows',
            array_merge(
                [
                    'p_table_name' => $tableName,
                    'p_snapshot_table_name' => $snapshotTableName,
                    'p_anomes' => $anomes,
                    'p_limit_rows' => $limit,
                    'p_offset_rows' => $offset,
                ],
                $this->buildAnalyticProcedureScopeParams($context),
                $this->buildAnalyticProcedureHierarchyFilterParams($filters),
                $this->buildSemestralProcedureMetricFilterParams($filters)
            )
        ) as $row) {
            $metricType = $this->inferSemestralMetricType((string) ($row['ds_metrica'] ?? ''));

            $rows[] = [
                'id_transacao' => (string) ($row['id_transacao'] ?? ''),
                'id_indicador' => (string) ($row['id_indicador'] ?? ''),
                'id_subindicador' => '',
                'funcional' => (string) ($row['funcional'] ?? ''),
                'nome_gerente' => (string) ($row['nome_gerente'] ?? ''),
                'funcional_gerente_gestao' => (string) ($row['funcional_gerente_gestao'] ?? ''),
                'nome_gerente_gestao' => (string) ($row['nome_gerente_gestao'] ?? ''),
                'juncao_ag' => (string) ($row['juncao_ag'] ?? ''),
                'nome_agencia' => (string) ($row['nome_agencia'] ?? ''),
                'juncao_gr' => (string) ($row['juncao_gr'] ?? ''),
                'nome_regional' => (string) ($row['nome_regional'] ?? ''),
                'juncao_dr' => (string) ($row['juncao_dr'] ?? ''),
                'nome_diretoria' => (string) ($row['nome_diretoria'] ?? ''),
                'segmento' => (string) ($row['segmento'] ?? ''),
                'numero_contrato' => (string) ($row['numero_contrato'] ?? ''),
                'conta' => (string) ($row['conta'] ?? ''),
                'data_transacao' => (string) ($row['data_transacao'] ?? ''),
                'status_transacao' => (string) ($row['status_transacao'] ?? ''),
                'observacao' => (string) ($row['observacao'] ?? ''),
                'cnpj' => (string) ($this->buildAnalyticDocumentInfo(
                    (string) ($row['cpf_cnpj'] ?? ''),
                    (string) ($row['cpf_cnpj_fil'] ?? ''),
                    (string) ($row['cpf_cnpj_dig'] ?? '')
                )['display'] ?? ''),
                'nome_cliente' => (string) ($row['nome_cliente'] ?? ''),
                'valor_realizado' => (float) ($row['valor_realizado'] ?? 0.0),
                'forecast_detail' => (float) ($row['valor_realizado'] ?? 0.0),
                'referencia_detail' => 0.0,
                'necessidade_diaria_detail' => 0.0,
                'atingimento_detail' => 0.0,
                'pontos_detail' => 0.0,
                'nome_indicador' => (string) ($row['nome_indicador'] ?? ''),
                'id_tipo_indicador' => $metricType,
                'nome_familia' => (string) ($row['nome_familia'] ?? ''),
                'nome_subindicador' => 'Sem subindicador',
                'desconsiderar_producao' => (int) ($row['flag_desconsiderar_producao'] ?? 0) === 1,
                'flag_desconsiderar_producao' => (int) ($row['flag_desconsiderar_producao'] ?? 0),
                'detail_source' => 'analytic',
            ];
        }

        return $rows;
    }

    private function getVariableSummary(array $context, array $filters, string $anomes): array
    {
        if (!$this->hasProductivitySnapshotTable('f_variavel')) {
            return ['meta' => 0.0, 'realizado' => 0.0];
        }

        $row = $this->fetchProcedureRow(
            'sp_pobj_get_variable_summary',
            array_merge(
                ['p_anomes' => $anomes],
                $this->buildAnalyticProcedureScopeParams($context),
                $this->buildAnalyticProcedureHierarchyFilterParams($filters)
            )
        ) ?: [];

        return [
            'meta' => (float) ($row['meta_total'] ?? 0.0),
            'realizado' => (float) ($row['realizado_total'] ?? 0.0),
        ];
    }

    private function inferSemestralMetricType(string $metricLabel): string
    {
        $metricLabel = strtoupper(trim($metricLabel));

        if ($metricLabel === '') {
            return 'VALOR';
        }

        if (strpos($metricLabel, 'PERCENT') !== false || strpos($metricLabel, '%') !== false) {
            return 'PERCENTUAL';
        }

        if (strpos($metricLabel, 'VOLUME') !== false || strpos($metricLabel, 'QUANT') !== false) {
            return 'QUANTIDADE';
        }

        return 'VALOR';
    }

    private function getEmptyDashboardData(): array
    {
        return [
            'summary' => [
                'indicadores_atingidos' => 0,
                'indicadores_total' => 0,
                'taxa_atingimento' => 0.0,
                'pontos_meta' => 0.0,
                'pontos_realizado' => 0.0,
                'variavel_meta' => 0.0,
                'variavel_realizada' => 0.0,
                'funcionais_visiveis' => 0,
                'contratos_visiveis' => 0,
            ],
            'indicators' => [],
            'comparison' => [
                'mensal' => ['summary' => [], 'indicators' => []],
                'acumulado' => ['summary' => [], 'indicators' => []],
            ],
        ];
    }

    private function buildEmptySummaryFilters(array $values): array
    {
        $options = [
            'segmento' => [],
            'diretoria' => [],
            'regional' => [],
            'agencia' => [],
            'gerente_gestao' => [],
            'gerente' => [],
            'familia' => [],
            'indicadores' => [],
            'subindicador' => [],
            'status_indicadores' => [
                ['value' => 'ATINGIDO', 'label' => 'Atingido'],
                ['value' => 'NAO_ATINGIDO', 'label' => 'Nao atingido'],
            ],
            'visao_acumulada' => [
                ['value' => 'MENSAL', 'label' => 'Mensal'],
                ['value' => 'SEMESTRAL', 'label' => 'Semestral'],
                ['value' => 'ACUMULADO', 'label' => 'Acumulado'],
                ['value' => 'ANUAL', 'label' => 'Anual'],
                ['value' => 'MENSAL_ACUMULADO', 'label' => 'Mensal/Acumulado'],
            ],
        ];

        $values['status_indicadores'] = $this->sanitizeFilterSelection($values['status_indicadores'] ?? '', $options['status_indicadores']);
        $values['visao_acumulada'] = $this->sanitizeFilterSelection($values['visao_acumulada'] ?? '', $options['visao_acumulada'], 'MENSAL');

        return [
            'options' => $options,
            'values' => $values,
            'states' => [
                'segmento' => ['enabled' => true, 'placeholder' => 'Todos os programas'],
                'diretoria' => ['enabled' => true, 'placeholder' => 'Todas'],
                'regional' => ['enabled' => false, 'placeholder' => 'Selecione os filtros anteriores'],
                'agencia' => ['enabled' => false, 'placeholder' => 'Selecione os filtros anteriores'],
                'gerente_gestao' => ['enabled' => false, 'placeholder' => 'Nao utilizado neste modelo'],
                'gerente' => ['enabled' => false, 'placeholder' => 'Selecione os filtros anteriores'],
            ],
        ];
    }

    private function ensureSelectedHierarchyOption(array $options, array $context, string $selectedValue): array
    {
        $selectedValue = trim($selectedValue);

        if ($selectedValue === '') {
            return $options;
        }

        foreach ($options as $option) {
            if (trim((string) ($option['value'] ?? '')) === $selectedValue) {
                return $options;
            }
        }

        $profile = (array) ($context['profile'] ?? []);
        $profileFunctional = trim((string) ($profile['funcional'] ?? ''));
        $profileName = trim((string) ($profile['nome'] ?? ''));
        $label = $selectedValue;

        if ($profileFunctional !== '' && $profileFunctional === $selectedValue && $profileName !== '') {
            $label = $selectedValue . ' - ' . $profileName;
        }

        $options[] = [
            'value' => $selectedValue,
            'label' => $label,
        ];

        return $options;
    }

    private function getExecutiveInsightsData(array $context, array $filters, string $anomes): array
    {
        if (!$this->hasProductivitySnapshotTable('f_exec_insights')) {
            return ['positive' => [], 'negative' => []];
        }

        $view = strtoupper(trim((string) ($filters['visao_acumulada'] ?? 'MENSAL')));

        if ($view === 'MENSAL_ACUMULADO') {
            $view = 'MENSAL';
        }

        if (!in_array($view, ['MENSAL', 'SEMESTRAL', 'ACUMULADO'], true)) {
            $view = 'MENSAL';
        }

        $scope = $this->resolveExecutiveInsightScope($context, $filters);
        $result = ['positive' => [], 'negative' => []];

        foreach ($this->fetchProcedureAll('sp_pobj_list_executive_insights', [
            'p_anomes' => $anomes,
            'p_visao' => $view,
            'p_scope_level' => (string) ($scope['level'] ?? 'GLOBAL'),
            'p_scope_key' => (string) ($scope['key'] ?? 'GLOBAL'),
        ]) as $row) {
            $polarity = strtoupper(trim((string) ($row['POLARIDADE'] ?? '')));
            $targetKey = $polarity === 'NEGATIVO' ? 'negative' : 'positive';
            $result[$targetKey][] = [
                'type' => trim((string) ($row['TIPO_INSIGHT'] ?? 'INSIGHT')),
                'title' => trim((string) ($row['TITULO'] ?? '')),
                'text' => trim((string) ($row['TEXTO'] ?? '')),
                'highlight' => trim((string) ($row['DESTAQUE'] ?? '')),
                'item_label' => trim((string) ($row['ITEM_LABEL'] ?? '')),
            ];
        }

        return $result;
    }

    private function resolveExecutiveInsightScope(array $context, array $filters): array
    {
        $filters = $this->hydrateSemestralProfileHierarchySelections($context, $filters);

        if (($filters['gerente'] ?? '') !== '') {
            return ['level' => 'GERENTE', 'key' => (string) $filters['gerente']];
        }

        if (($filters['gerente_gestao'] ?? '') !== '') {
            return ['level' => 'GERENTE_GESTAO', 'key' => (string) $filters['gerente_gestao']];
        }

        if (($filters['agencia'] ?? '') !== '') {
            return ['level' => 'AGENCIA', 'key' => (string) $filters['agencia']];
        }

        if (($filters['regional'] ?? '') !== '') {
            return ['level' => 'REGIONAL', 'key' => (string) $filters['regional']];
        }

        if (($filters['diretoria'] ?? '') !== '') {
            return ['level' => 'DIRETORIA', 'key' => (string) $filters['diretoria']];
        }

        if (($filters['segmento'] ?? '') !== '') {
            return ['level' => 'SEGMENTO', 'key' => (string) $filters['segmento']];
        }

        $profile = (array) ($context['profile'] ?? []);
        $junctions = (array) ($context['junctions'] ?? []);
        $profileLevel = strtoupper(trim((string) ($profile['nivel'] ?? '')));
        $profileFunctional = trim((string) ($profile['funcional'] ?? ''));
        $primaryAgency = $this->resolvePrimaryJunction($junctions, 'AG');
        $primaryRegional = $this->resolvePrimaryJunction($junctions, 'GR');
        $primaryDirectorate = $this->resolvePrimaryJunction($junctions, 'DR');
        $primarySegment = $this->resolvePrimaryJunction($junctions, 'SG');

        if (in_array($profileLevel, ['GC', 'PA', 'AS'], true) && $profileFunctional !== '') {
            return ['level' => 'GERENTE', 'key' => $profileFunctional];
        }

        if (in_array($profileLevel, ['GG', 'TL'], true) && $profileFunctional !== '') {
            return ['level' => 'GERENTE_GESTAO', 'key' => $profileFunctional];
        }

        if ($profileLevel === 'AG' && $primaryAgency !== '') {
            return ['level' => 'AGENCIA', 'key' => $primaryAgency];
        }

        if (in_array($profileLevel, ['GR', 'GE'], true) && $primaryRegional !== '') {
            return ['level' => 'REGIONAL', 'key' => $primaryRegional];
        }

        if ($profileLevel === 'DR' && $primaryDirectorate !== '') {
            return ['level' => 'DIRETORIA', 'key' => $primaryDirectorate];
        }

        if ($profileLevel === 'SG' && $primarySegment !== '') {
            return ['level' => 'SEGMENTO', 'key' => $primarySegment];
        }

        return ['level' => 'GLOBAL', 'key' => 'GLOBAL'];
    }

    private function getEmptyExecutiveViewData(): array
    {
        return [
            'focus' => ['level' => 'regional', 'label' => 'Regional', 'ranking_title' => 'Desempenho por Regional', 'status_title' => 'Status por Regional'],
            'reference' => ['period_label' => '', 'range_label' => '', 'month_label' => '', 'window_label' => 'Ãšltimos 6 meses'],
            'kpis' => [],
            'chart' => ['labels' => [], 'series' => [], 'max_value' => 100.0],
            'ranking' => ['top' => [], 'bottom' => []],
            'insights' => ['positive' => [], 'negative' => []],
            'status' => ['hit' => [], 'quase' => [], 'longe' => [], 'summary' => ['hit' => 0, 'quase' => 0, 'longe' => 0]],
            'heatmap' => [
                'default_mode' => 'secoes',
                'secoes' => ['title' => '', 'row_axis_label' => 'GR', 'row_axis_sublabel' => 'FamÃ­lias', 'rows' => [], 'columns' => [], 'data' => []],
                'meta' => ['title' => '', 'row_axis_label' => 'Hierarquia', 'row_axis_sublabel' => 'MÃªs', 'rows' => [], 'months' => [], 'data' => []],
            ],
        ];
    }

}
