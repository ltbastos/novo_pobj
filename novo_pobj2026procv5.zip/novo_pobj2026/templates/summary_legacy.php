<?php

declare(strict_types=1);

if (($activeTab ?? 'resumo') !== 'resumo'
    || (($summaryFilterValues['visao_acumulada'] ?? 'MENSAL') === 'ANUAL')
    || (($summaryFilterValues['visao_acumulada'] ?? 'MENSAL') === 'MENSAL_ACUMULADO')
) {
    return;
}

$indicatorRows = is_array($dashboardData['indicators'] ?? null)
    ? $dashboardData['indicators']
    : [];

if ($indicatorRows === []) {
    return;
}

$prepareLegacySubrows = static function (array $row): array {
    $subrows = array_values(array_filter((array) ($row['subindicadores'] ?? []), static function (array $subrow): bool {
        $subId = trim((string) ($subrow['id_subindicador'] ?? ''));
        $subName = trim((string) ($subrow['nome_subindicador'] ?? ''));

        return $subId !== ''
            || ($subName !== '' && strcasecmp($subName, 'Sem subindicador') !== 0);
    }));

    if ($subrows === [] && strcasecmp(trim((string) ($row['nome_indicador'] ?? '')), 'Previdencia Privada - Venda Bruta PU') === 0) {
        $subrows[] = [
            'id_subindicador' => 'teste-previdencia-pu',
            'nome_subindicador' => 'Subindicador teste - carteira assistida',
            'total' => 1500000.0,
        ];
    }

    return $subrows;
};

$sortIndicatorRows = static function (array &$rows): void {
    usort($rows, static function (array $left, array $right): int {
        $leftLevel = (int) ($left['nivel'] ?? 0);
        $rightLevel = (int) ($right['nivel'] ?? 0);

        if ($leftLevel !== $rightLevel) {
            return $leftLevel <=> $rightLevel;
        }

        $leftName = strtolower(trim((string) ($left['nome_indicador'] ?? '')));
        $rightName = strtolower(trim((string) ($right['nome_indicador'] ?? '')));

        if ($leftName !== $rightName) {
            return $leftName <=> $rightName;
        }

        return trim((string) ($left['id_indicador'] ?? '')) <=> trim((string) ($right['id_indicador'] ?? ''));
    });
};

$isFamilyRow = static function (array $row): bool {
    $level = (int) ($row['nivel'] ?? 0);
    $dsNivel = strtoupper(trim((string) ($row['ds_nivel'] ?? '')));
    $indicatorName = trim((string) ($row['nome_indicador'] ?? ''));
    $familyName = trim((string) ($row['nome_familia'] ?? ''));
    $parentId = trim((string) ($row['id_pai_indicador'] ?? ''));
    $indicatorId = trim((string) ($row['id_indicador'] ?? ''));

    if ($dsNivel === 'FAMILIA' || $level <= 0) {
        return true;
    }

    return $indicatorName !== ''
        && $familyName !== ''
        && strcasecmp($indicatorName, $familyName) === 0
        && $parentId !== ''
        && $parentId !== $indicatorId;
};

$flattenIndicatorRows = null;
$flattenIndicatorRows = static function (array $item, array $childrenByParent, int $depth = 1) use (&$flattenIndicatorRows): array {
    $rows = [
        [
            'type' => 'indicator',
            'depth' => $depth,
            'item' => $item,
        ],
    ];
    $indicatorId = trim((string) ($item['id_indicador'] ?? ''));
    $children = $childrenByParent[$indicatorId] ?? [];

    if ($children !== []) {
        foreach ($children as $child) {
            foreach ($flattenIndicatorRows($child, $childrenByParent, $depth + 1) as $childRow) {
                $rows[] = $childRow;
            }
        }

        return $rows;
    }

    foreach ((array) ($item['legacy_subrows'] ?? []) as $subrow) {
        $rows[] = [
            'type' => 'subindicador',
            'depth' => $depth + 1,
            'item' => $subrow,
            'metric_type' => (string) ($item['id_tipo_indicador'] ?? 'VALOR'),
            'update_date' => (string) ($item['ultima_atualizacao'] ?? ''),
        ];
    }

    return $rows;
};

$familyGroups = [];

foreach ($indicatorRows as $row) {
    $familyLabel = trim((string) ($row['nome_familia'] ?? ''));
    $familyKey = $familyLabel !== '' ? $familyLabel : 'Sem familia';

    if (!isset($familyGroups[$familyKey])) {
        $familyGroups[$familyKey] = [
            'label' => $familyKey,
            'family_row' => null,
            'items' => [],
            'pontos_atingidos' => 0.0,
            'pontos_total' => 0.0,
        ];
    }

    $row['ds_nivel'] = trim((string) ($row['ds_nivel'] ?? ''));
    $row['legacy_subrows'] = $prepareLegacySubrows($row);

    if ($isFamilyRow($row) && $familyGroups[$familyKey]['family_row'] === null) {
        $row['legacy_display_name'] = 'Total da familia';
        $familyGroups[$familyKey]['family_row'] = $row;
        continue;
    }

    $familyGroups[$familyKey]['pontos_atingidos'] += (float) ($row['pontos'] ?? 0.0);
    $familyGroups[$familyKey]['pontos_total'] += (float) ($row['pontos_meta'] ?? 0.0);
    $familyGroups[$familyKey]['items'][] = $row;
}

foreach ($familyGroups as &$familyGroup) {
    $sortIndicatorRows($familyGroup['items']);
    $rowsById = [];

    foreach ($familyGroup['items'] as $item) {
        $indicatorId = trim((string) ($item['id_indicador'] ?? ''));

        if ($indicatorId === '') {
            continue;
        }

        $rowsById[$indicatorId] = $item;
    }

    $childrenByParent = [];
    $rootItems = [];

    foreach ($rowsById as $indicatorId => $item) {
        $currentIndicatorId = trim((string) ($item['id_indicador'] ?? $indicatorId));
        $parentId = trim((string) ($item['id_pai_indicador'] ?? ''));

        if ($parentId === '' || $parentId === $currentIndicatorId || !isset($rowsById[$parentId])) {
            $rootItems[] = $item;
            continue;
        }

        if (!isset($childrenByParent[$parentId])) {
            $childrenByParent[$parentId] = [];
        }

        $childrenByParent[$parentId][] = $item;
    }

    $sortIndicatorRows($rootItems);

    foreach ($childrenByParent as &$children) {
        $sortIndicatorRows($children);
    }
    unset($children);

    $childRows = [];

    foreach ($rootItems as $rootItem) {
        foreach ($flattenIndicatorRows($rootItem, $childrenByParent, 1) as $childRow) {
            $childRows[] = $childRow;
        }
    }

    $familyGroup['child_rows'] = $childRows;
    $familyGroup['child_indicator_count'] = count($rootItems);
}
unset($familyGroup);

$metricVariant = static function (string $metric): string {
    $metric = strtoupper(trim($metric));

    if ($metric === 'PERCENTUAL') {
        return 'perc';
    }

    if ($metric === 'QUANTIDADE') {
        return 'qtd';
    }

    return 'valor';
};

$metricLabel = static function (string $metric): string {
    $metric = strtoupper(trim($metric));

    if ($metric === 'PERCENTUAL') {
        return 'Percentual';
    }

    if ($metric === 'QUANTIDADE') {
        return 'Quantidade';
    }

    return 'Valor';
};

$formatCssPercent = static function (float $percent): string {
    return number_format(max(0, min(100, $percent)), 2, '.', '') . '%';
};

$formatMetricCell = static function (array $item, string $field, string $metricType): string {
    if (!array_key_exists($field, $item) || $item[$field] === null || $item[$field] === '') {
        return '-';
    }

    return format_metric_readable((float) $item[$field], $metricType);
};

$formatPointsCell = static function (array $item, string $field, string $suffix = ''): string {
    if (!array_key_exists($field, $item) || $item[$field] === null || $item[$field] === '') {
        return '-';
    }

    return format_points_readable((float) $item[$field]) . $suffix;
};

$renderMetricRow = static function (array $item, string $kind, int $depth, bool $hidden, bool $expandable, bool $expanded = false) use ($formatCssPercent, $formatMetricCell, $formatPointsCell, $metricLabel, $metricVariant): void {
    $metricType = trim((string) ($item['id_tipo_indicador'] ?? ''));
    $metricName = trim((string) ($item['nome_tipo_indicador'] ?? ''));
    $displayName = trim((string) ($item['legacy_display_name'] ?? $item['nome_indicador'] ?? ''));
    $paddingLeft = $kind === 'family' ? 0 : 28 + (($depth - 1) * 22);
    $percent = null;

    if (array_key_exists('percentual_atingimento', $item) && $item['percentual_atingimento'] !== null && $item['percentual_atingimento'] !== '') {
        $percent = (float) $item['percentual_atingimento'];
    }

    if ($metricType === '') {
        $metricType = 'VALOR';
    }

    if ($metricName === '') {
        $metricName = $metricLabel($metricType);
    }

    $meterClass = $percent !== null && $percent >= 100
        ? 'is-ok'
        : ($percent !== null && $percent >= 50 ? 'is-warn' : 'is-low');
    $updateDate = format_date_br($item['ultima_atualizacao'] ?? null);
    $rowClass = 'summary-legacy__row';

    if ($kind === 'family') {
        $rowClass .= ' summary-legacy__row--family';
    } elseif ($kind === 'indicator') {
        $rowClass .= ' summary-legacy__row--indicator';
    }
    ?>
    <tr class="<?= e($rowClass) ?>"<?= $hidden ? ' hidden data-legacy-child-row' : '' ?>>
        <td class="summary-legacy__col--prod">
            <div class="summary-legacy__prod-cell">
                <?php if ($expandable): ?>
                    <button class="summary-legacy__expand" type="button" data-legacy-toggle-row aria-expanded="<?= $expanded ? 'true' : 'false' ?>" aria-label="Expandir familia <?= e((string) ($item['nome_familia'] ?? $displayName)) ?>">
                        <span class="summary-legacy__expand-icon" aria-hidden="true"></span>
                    </button>
                <?php else: ?>
                    <span class="summary-legacy__expand-placeholder" aria-hidden="true"></span>
                <?php endif; ?>

                <div class="summary-legacy__prod-stack" style="padding-left: <?= e((string) $paddingLeft) ?>px;">
                    <div class="summary-legacy__prod-name<?= $kind === 'family' ? ' summary-legacy__prod-name--family' : '' ?>" title="<?= e($displayName) ?>"><?= e($displayName) ?></div>
                </div>
            </div>
        </td>
        <td class="summary-legacy__col--peso"><?= e($formatPointsCell($item, 'peso')) ?></td>
        <td>
            <?php if ($metricName === '-'): ?>
                -
            <?php else: ?>
                <span class="summary-legacy__metric summary-legacy__metric--<?= e($metricVariant($metricType)) ?>">
                    <?= e($metricName) ?>
                </span>
            <?php endif; ?>
        </td>
        <td class="summary-legacy__col--meta"><?= e($formatMetricCell($item, 'meta', $metricType)) ?></td>
        <td class="summary-legacy__col--real"><?= e($formatMetricCell($item, 'realizado', $metricType)) ?></td>
        <td class="summary-legacy__col--ref"><?= e($formatMetricCell($item, 'referencia', $metricType)) ?></td>
        <td class="summary-legacy__col--forecast"><?= e($formatMetricCell($item, 'forecast', $metricType)) ?></td>
        <td class="summary-legacy__col--meta-dia"><?= e($formatMetricCell($item, 'nec_dia', $metricType)) ?></td>
        <td class="summary-legacy__col--pontos"><?= e($formatPointsCell($item, 'pontos', ' pts')) ?></td>
        <td class="summary-legacy__col--ating">
            <?php if ($percent === null): ?>
                -
            <?php else: ?>
                <div class="summary-legacy__ating-meter <?= e($meterClass) ?>" style="--fill: <?= e($formatCssPercent($percent)) ?>;" role="progressbar" aria-valuenow="<?= e(number_format(max(0, min(200, $percent)), 1, '.', '')) ?>" aria-valuemin="0" aria-valuemax="200">
                    <span class="summary-legacy__ating-fill"></span>
                    <span class="summary-legacy__ating-value"><?= e(number_format($percent, 1, ',', '.')) ?>%</span>
                </div>
            <?php endif; ?>
        </td>
        <td class="summary-legacy__col--update"><?= e($updateDate !== '' ? $updateDate : '-') ?></td>
    </tr>
    <?php
};

$renderSubindicatorRow = static function (array $subrow, int $depth, string $metricType, string $updateDate, bool $hidden = true) use ($metricLabel, $metricVariant): void {
    $subMetricType = strtoupper(trim($metricType)) === 'PERCENTUAL' ? 'QUANTIDADE' : trim($metricType);
    $paddingLeft = 28 + (($depth - 1) * 22);

    if ($subMetricType === '') {
        $subMetricType = 'VALOR';
    }
    ?>
    <tr class="summary-legacy__row summary-legacy__row--sub"<?= $hidden ? ' hidden' : '' ?> data-legacy-child-row>
        <td class="summary-legacy__col--prod">
            <div class="summary-legacy__prod-cell">
                <span class="summary-legacy__expand-placeholder" aria-hidden="true"></span>
                <div class="summary-legacy__prod-stack" style="padding-left: <?= e((string) $paddingLeft) ?>px;">
                    <div class="summary-legacy__sub-name" title="<?= e((string) ($subrow['nome_subindicador'] ?? 'Subindicador')) ?>"><?= e((string) ($subrow['nome_subindicador'] ?? 'Subindicador')) ?></div>
                </div>
            </div>
        </td>
        <td class="summary-legacy__col--peso">-</td>
        <td>
            <span class="summary-legacy__metric summary-legacy__metric--<?= e($metricVariant($subMetricType)) ?>">
                <?= e($metricLabel($subMetricType)) ?>
            </span>
        </td>
        <td class="summary-legacy__col--meta">-</td>
        <td class="summary-legacy__col--real"><?= e(format_metric_readable((float) ($subrow['total'] ?? 0.0), $subMetricType)) ?></td>
        <td class="summary-legacy__col--ref">-</td>
        <td class="summary-legacy__col--forecast">-</td>
        <td class="summary-legacy__col--meta-dia">-</td>
        <td class="summary-legacy__col--pontos">-</td>
        <td class="summary-legacy__col--ating">-</td>
        <td class="summary-legacy__col--update"><?= e($updateDate !== '' ? format_date_br($updateDate) : '-') ?></td>
    </tr>
    <?php
};
?>
<section class="summary-legacy" data-resumo-pane="legacy" hidden aria-label="Resumo em visao classica">
    <?php foreach ($familyGroups as $familyGroup): ?>
        <?php
        $familyRow = $familyGroup['family_row'] ?? null;
        $hasFamilyRow = is_array($familyRow);
        $childRows = is_array($familyGroup['child_rows'] ?? null) ? $familyGroup['child_rows'] : [];

        if (!$hasFamilyRow && $childRows === []) {
            continue;
        }
        $childIndicatorCount = (int) ($familyGroup['child_indicator_count'] ?? 0);
        $sectionPointsAchieved = (float) ($familyGroup['pontos_atingidos'] ?? 0.0);
        $sectionPointsTotal = (float) ($familyGroup['pontos_total'] ?? 0.0);
        ?>
        <section class="summary-legacy__section" data-legacy-section>
            <header class="summary-legacy__head">
                <div class="summary-legacy__heading">
                    <div class="summary-legacy__title-row">
                        <span class="summary-legacy__name"><?= e($familyGroup['label']) ?></span>
                        <span class="summary-legacy__chip">
                            Pontos: <?= e(format_points_readable($sectionPointsAchieved)) ?> / <?= e(format_points_readable($sectionPointsTotal)) ?>
                        </span>
                    </div>
                </div>
            </header>

            <div class="summary-legacy__table-wrapper">
                <table class="summary-legacy__table">
                    <thead>
                        <tr>
                            <th scope="col" class="summary-legacy__col--prod">Indicador</th>
                            <th scope="col" class="summary-legacy__col--peso">Peso</th>
                            <th scope="col">Metrica</th>
                            <th scope="col" class="summary-legacy__col--meta">Meta</th>
                            <th scope="col" class="summary-legacy__col--real">Realizado</th>
                            <th scope="col" class="summary-legacy__col--ref">Ref. da tabela</th>
                            <th scope="col" class="summary-legacy__col--forecast">Forecast</th>
                            <th scope="col" class="summary-legacy__col--meta-dia">Meta diaria</th>
                            <th scope="col" class="summary-legacy__col--pontos">Pontos</th>
                            <th scope="col" class="summary-legacy__col--ating">Ating.</th>
                            <th scope="col" class="summary-legacy__col--update">Atualizacao</th>
                        </tr>
                    </thead>

                    <tbody class="summary-legacy__group" data-legacy-group>
                        <?php if ($hasFamilyRow): ?>
                            <?php $renderMetricRow($familyRow, 'family', 0, false, $childRows !== [], false); ?>
                        <?php endif; ?>

                        <?php foreach ($childRows as $childRow): ?>
                            <?php if (($childRow['type'] ?? '') === 'indicator'): ?>
                                <?php $renderMetricRow((array) ($childRow['item'] ?? []), 'indicator', max(1, (int) ($childRow['depth'] ?? 1)), $hasFamilyRow, false); ?>
                            <?php elseif (($childRow['type'] ?? '') === 'subindicador'): ?>
                                <?php $renderSubindicatorRow((array) ($childRow['item'] ?? []), max(1, (int) ($childRow['depth'] ?? 1)), (string) ($childRow['metric_type'] ?? 'VALOR'), (string) ($childRow['update_date'] ?? ''), $hasFamilyRow); ?>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
    <?php endforeach; ?>
</section>
