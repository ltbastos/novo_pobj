<?php

declare(strict_types=1);

if (($activeTab ?? 'resumo') === 'encantabra') {
    return;
}

$tabItems = [
    'resumo' => ['label' => 'Resumo', 'icon' => 'layout-dashboard'],
    'detalhamento' => ['label' => 'Detalhamento', 'icon' => 'list-tree'],
    'rankings' => ['label' => 'Rankings', 'icon' => 'trophy'],
    'visao-executiva' => ['label' => 'Visao executiva', 'icon' => 'chart-column'],
    'simuladores' => ['label' => 'Simuladores', 'icon' => 'calculator'],
    'campanhas' => ['label' => 'Campanhas', 'icon' => 'megaphone'],
];

$selectedPeriodMetaLabel = trim((string) ($selectedPeriodMonth !== ''
    ? format_month_year_br($selectedPeriodMonth)
    : ($selectedPeriod['descricao_periodo'] ?? 'Periodo atual')));
?>
<section class="summary-tabs-section" aria-label="Navegacao da tela Resumo">
    <div class="summary-tabs-shell">
        <nav class="summary-tabs" aria-label="Abas do modulo POBJ">
            <?php foreach ($tabItems as $tabId => $tabItem): ?>
                <?php $tabActionFields = json_attr(['tab' => $tabId]); ?>
                <a
                    class="summary-tabs__item<?= $activeTab === $tabId ? ' is-active' : '' ?>"
                    href="<?= e(app_url()) ?>"
                    data-dashboard-action="set_dashboard_tab"
                    data-dashboard-fields="<?= $tabActionFields ?>"
                    data-dashboard-message="Abrindo <?= e((string) ($tabItem['label'] ?? 'aba')) ?>..."
                >
                    <span class="summary-tabs__icon" aria-hidden="true"><i data-lucide="<?= e($tabItem['icon']) ?>"></i></span>
                    <span class="summary-tabs__label"><?= e($tabItem['label']) ?></span>
                </a>
            <?php endforeach; ?>
        </nav>

        <div class="summary-tabs__meta">
            <span class="summary-tabs__period-label">
                <span class="summary-tabs__period-copy">Per&iacute;odo: <strong><?= e($selectedPeriodMetaLabel) ?></strong></span>
            </span>
        </div>
    </div>
</section>
