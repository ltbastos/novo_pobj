<?php

declare(strict_types=1);

$layoutProfile = $context['profile'] ?? null;
$headerName = prime_label($layoutProfile['nome'] ?? 'Usuario de teste');
$headerFirstName = first_name($headerName);
$headerInitials = user_initials($headerName);
$headerFunctional = trim((string) ($layoutProfile['funcional'] ?? $selectedProfileFunctional ?? ''));
$visualTheme = is_array($visualTheme ?? null) ? $visualTheme : ['code' => 'classic', 'is_prime' => false, 'logo_path' => 'assets/img/logo-bradesco-white.svg', 'logo_alt' => 'Bradesco', 'reference_path' => 'assets/img/prime-reference.svg', 'bubble_label' => 'IA POBJ', 'badge_copy' => 'Modo POBJ'];
$assistantUserName = trim((string) ($headerName !== '' ? $headerName : $headerFirstName));
$themeCode = trim((string) ($visualTheme['code'] ?? 'classic'));
$brandLogoPath = trim((string) ($visualTheme['logo_path'] ?? 'assets/img/logo-bradesco-white.svg'));
$brandLogoAlt = trim((string) ($visualTheme['logo_alt'] ?? 'Bradesco'));
$appCssVersion = is_file(project_path('assets/css/app.css')) ? (string) (filemtime(project_path('assets/css/app.css')) ?: time()) : (string) time();
$appJsVersion = is_file(project_path('assets/js/app.js')) ? (string) (filemtime(project_path('assets/js/app.js')) ?: time()) : (string) time();
$lucideVersion = is_file(project_path('assets/vendor/lucide.min.js')) ? (string) (filemtime(project_path('assets/vendor/lucide.min.js')) ?: time()) : (string) time();
$hasIndicatorDetailModal = (($indicatorFocusId ?? '') !== '');
$isStandaloneEncantabraPage = current_app_script('index.php') === 'encantabra.php';
$watermarkIdentity = $headerFunctional;

if ($watermarkIdentity === '') {
    $watermarkIdentity = 'Acesso interno monitorado';
}

$dashboardUrl = $isStandaloneEncantabraPage ? build_internal_url('index.php') : app_url();
$dashboardSummaryActionFields = json_attr(['tab' => 'resumo']);
$encantabraUrl = build_internal_url('encantabra.php');
$profileFormState = [
    'tab' => (string) ($activeTab ?? 'resumo'),
    'advanced_filters' => (string) ($advancedFiltersState ?? 'open'),
];

if (($activeTab ?? '') === 'detalhamento' && ($requestedDetailTableView ?? '') !== '') {
    $profileFormState['detail_table_view'] = (string) $requestedDetailTableView;
}

if (($indicatorFocusId ?? '') !== '') {
    $profileFormState['indicator_focus'] = (string) $indicatorFocusId;
    $profileFormState['indicator_page'] = (string) ((int) ($requestedIndicatorPage ?? 1));
}

if (($activeTab ?? '') === 'rankings' && ($requestedRankingGroup ?? '') !== '') {
    $profileFormState['grupo'] = (string) $requestedRankingGroup;
}

if (($activeTab ?? '') === 'encantabra') {
    $profileFormState['enc_tab'] = (string) ($encantabraActiveSection ?? 'resultado');
}

$omegaUrl = 'omega.php';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($pageTitle ?? 'Novo POBJ') ?></title>
    <link rel="stylesheet" href="assets/css/app.css?v=<?= e($appCssVersion) ?>">
    <noscript><style>.global-loading-overlay{display:none !important;}</style></noscript>
</head>
<body class="is-booting<?= ($visualTheme['is_prime'] ?? false) ? ' theme-prime' : '' ?><?= $hasIndicatorDetailModal ? ' has-modal-open' : '' ?>" data-visual-theme="<?= e($themeCode) ?>">
    <header class="topbar" role="banner">
        <nav id="main-navigation" class="topbar__left" aria-label="Navegacao principal">
            <?php if ($isStandaloneEncantabraPage): ?>
                <a href="<?= e($dashboardUrl) ?>" class="brand">
                    <img class="brand__logo" src="<?= e($brandLogoPath) ?>" alt="<?= e($brandLogoAlt) ?>">
                </a>
            <?php else: ?>
                <a
                    href="<?= e($dashboardUrl) ?>"
                    class="brand"
                    data-dashboard-action="set_dashboard_tab"
                    data-dashboard-fields="<?= $dashboardSummaryActionFields ?>"
                    data-dashboard-message="Abrindo resumo..."
                >
                    <img class="brand__logo" src="<?= e($brandLogoPath) ?>" alt="<?= e($brandLogoAlt) ?>">
                </a>
            <?php endif; ?>
        </nav>

        <nav class="topbar__right" aria-label="Menu do usuario">
            <?php if (($profiles ?? []) !== []): ?>
                <form class="topbar-profile" method="post" action="<?= e(app_url()) ?>" aria-label="Selecionar usuario logado temporario">
                    <?= csrf_field() ?>
                    <input type="hidden" name="action" value="select_profile">
                    <?= hidden_fields($profileFormState) ?>

                    <label class="topbar-profile__label" for="topbar-profile-functional">Usuario logado</label>
                    <div class="topbar-profile__field">
                        <select id="topbar-profile-functional" name="selected_functional" class="topbar-profile__select" data-autosubmit aria-label="Selecionar usuario logado temporario">
                            <?php foreach ($profiles as $profileItem): ?>
                                <?php
                                $profileOptionName = trim((string) ($profileItem['nome'] ?? ''));
                                $profileOptionLevel = trim((string) ($profileItem['nivel'] ?? ''));
                                $profileOptionJunction = trim((string) ($profileItem['juncao_principal'] ?? ''));
                                $profileOptionMeta = $profileOptionLevel;

                                if ($profileOptionJunction !== '') {
                                    $profileOptionMeta .= ' - ' . $profileOptionJunction;
                                }

                                $profileOptionLabel = $profileOptionMeta !== ''
                                    ? $profileOptionName . ' - ' . $profileOptionMeta
                                    : $profileOptionName;
                                ?>
                                <option value="<?= e((string) ($profileItem['funcional'] ?? '')) ?>"<?= selected_attr((string) ($profileItem['funcional'] ?? ''), $selectedProfileFunctional ?? null) ?>><?= e(prime_label($profileOptionLabel)) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </form>
            <?php endif; ?>

            <div class="userbox" data-userbox>
                <button class="userbox__trigger" id="btn-user-menu" type="button" aria-haspopup="true" aria-expanded="false" aria-controls="user-menu" aria-label="Menu do usuario: <?= e($headerName) ?>" data-userbox-trigger>
                    <span class="userbox__avatar"><?= e($headerInitials) ?></span>
                    <span class="userbox__identity">
                        <span class="userbox__name"><?= e($headerFirstName) ?></span>
                    </span>
                    <span class="userbox__chevron" aria-hidden="true"></span>
                </button>

                <div class="userbox__menu" id="user-menu" hidden data-userbox-menu>
                    <div class="userbox__menu-header">
                        <span class="userbox__menu-title">Links uteis</span>
                    </div>

                    <div class="userbox__menu-section">
                        <button class="userbox__menu-item" type="button" data-userbox-dismiss>Portal PJ</button>

                        <div class="userbox__submenu">
                            <button class="userbox__menu-item userbox__menu-item--has-sub" type="button" aria-expanded="false" aria-controls="user-submenu-manuais" data-userbox-submenu-trigger>
                                <span>Manuais</span>
                                <span class="userbox__submenu-chevron" aria-hidden="true"></span>
                            </button>

                            <div class="userbox__submenu-list" id="user-submenu-manuais" hidden data-userbox-submenu>
                                <button class="userbox__menu-item" type="button" data-userbox-dismiss>Manual do POBJ</button>
                                <button class="userbox__menu-item" type="button" data-userbox-dismiss>Manual do Omega</button>
                            </div>
                        </div>

                        <button class="userbox__menu-item" type="button" data-userbox-dismiss>Mapao de Oportunidades</button>
                        <a class="userbox__menu-item" href="<?= e($omegaUrl) ?>" target="_blank" rel="noopener" data-userbox-dismiss>Omega</a>
                        <a class="userbox__menu-item" href="<?= e($encantabraUrl) ?>" target="_blank" rel="noopener" data-userbox-dismiss>
                            EncantaBra
                        </a>
                    </div>
                    <div class="userbox__divider"></div>
                    <button class="userbox__menu-item userbox__menu-item--logout" type="button" data-userbox-dismiss>
                        <span class="userbox__logout-icon" aria-hidden="true"><i data-lucide="log-out"></i></span>
                        <span>Sair</span>
                    </button>
                </div>
            </div>
        </nav>
    </header>

    <div class="app-shell">
        <div class="app-watermark" aria-hidden="true">
            <?php for ($watermarkRow = 0; $watermarkRow < 8; $watermarkRow++): ?>
                <div class="app-watermark__row" style="top: <?= e((string) (6 + ($watermarkRow * 13))) ?>%;">
                    <?php for ($watermarkItem = 0; $watermarkItem < 10; $watermarkItem++): ?>
                        <span><?= e($watermarkIdentity) ?></span>
                    <?php endfor; ?>
                </div>
            <?php endfor; ?>
        </div>

        <main id="main-content" class="main-content" aria-label="Area principal do painel">
            <?php include __DIR__ . '/summary_filters.php'; ?>
            <?php include __DIR__ . '/summary_tabs.php'; ?>
            <?php include __DIR__ . '/summary_mode_toggle.php'; ?>
            <?php include __DIR__ . '/summary_cards.php'; ?>
            <?php include __DIR__ . '/summary_indicator_cards.php'; ?>
            <?php include __DIR__ . '/summary_comparison.php'; ?>
            <?php include __DIR__ . '/summary_legacy.php'; ?>
            <?php include __DIR__ . '/summary_annual.php'; ?>
            <?php include __DIR__ . '/rankings.php'; ?>
            <?php include __DIR__ . '/detail_view.php'; ?>
            <?php include __DIR__ . '/executive_view.php'; ?>
            <?php include __DIR__ . '/encantabra_view.php'; ?>
            <?php include __DIR__ . '/coming_soon.php'; ?>
        </main>
    </div>

    <?php include __DIR__ . '/indicator_detail_view.php'; ?>

    <div class="chatw" data-assistant-root data-assistant-static="true" data-assistant-user-name="<?= e($assistantUserName) ?>">
        <button id="chat-launcher" class="chatw__btn" type="button" aria-controls="chat-panel" aria-expanded="false" aria-label="Abrir chat de duvidas" data-assistant-toggle>
            <span class="chatw__btn-icon" aria-hidden="true"><i data-lucide="message-square"></i></span>
        </button>

        <section id="chat-panel" class="chatw__panel" aria-hidden="true" role="dialog" aria-label="Chat POBJ">
            <header class="chatw__header">
                <div class="chatw__title">Assistente POBJ</div>
                <button id="chat-close" class="chatw__close" type="button" aria-label="Fechar chat" data-assistant-close>
                    <i data-lucide="x"></i>
                </button>
            </header>

            <div class="chatw__msgs chatw__msgs--static" aria-live="polite">
                <article class="msg msg--bot">
                    <div class="msg__bubble">Em breve.</div>
                </article>
            </div>
        </section>
    </div>

    <div class="global-loading-overlay" aria-live="polite" aria-busy="true" data-loading-overlay>
        <div class="global-loading-overlay__panel">
            <div class="global-loading-overlay__mark" aria-hidden="true">
                <span class="global-loading-overlay__ring global-loading-overlay__ring--outer"></span>
                <span class="global-loading-overlay__ring global-loading-overlay__ring--inner"></span>
                <span class="global-loading-overlay__core"></span>
            </div>
            <strong class="global-loading-overlay__title">Atualizando painel</strong>
            <span class="global-loading-overlay__copy" data-loading-text>Carregando dados do POBJ...</span>
        </div>
    </div>

    <form method="post" action="<?= e(app_url()) ?>" hidden data-dashboard-action-form>
        <?= csrf_field() ?>
        <input type="hidden" name="action" value="" data-dashboard-action-input>
        <input type="hidden" name="advanced_filters" value="<?= e((string) ($advancedFiltersState ?? 'open')) ?>" data-filters-state>
        <div data-dashboard-action-fields-holder></div>
    </form>

    <script src="assets/vendor/lucide.min.js?v=<?= e($lucideVersion) ?>"></script>
    <script src="assets/js/app.js?v=<?= e($appJsVersion) ?>"></script>
</body>
</html>
