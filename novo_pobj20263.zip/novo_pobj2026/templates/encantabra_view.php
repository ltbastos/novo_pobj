<?php

declare(strict_types=1);

if (($activeTab ?? 'resumo') !== 'encantabra') {
    return;
}

$encantabra = $encantabraData ?? [];
$encantabraReference = $encantabra['reference'] ?? ['month_label' => '', 'scope_label' => '', 'profile_label' => '', 'segment_label' => ''];
$encantabraSummary = $encantabra['summary'] ?? ['score_avg' => 0.0, 'meta_avg' => 0.0, 'real_avg' => 0.0, 'rows_total' => 0, 'entities_total' => 0, 'indicators_total' => 0, 'best_indicator' => null, 'worst_indicator' => null, 'band' => ['label' => 'Sem dados', 'range' => 'Sem leitura', 'tone' => 'is-empty']];
$encantabraStatus = $encantabra['status'] ?? ['fan' => 0, 'encantador' => 0, 'expectativa' => 0, 'critico' => 0];
$encantabraChart = $encantabra['chart'] ?? ['labels' => [], 'series' => [], 'max_value' => 150.0];
$encantabraTrimesterTables = $encantabra['trimester_tables'] ?? ['year' => '', 'tables' => []];
$encantabraTable = $encantabra['table'] ?? ['title' => '', 'subtitle' => '', 'columns' => [], 'rows' => []];
$encantabraFilters = $encantabraFilterValues ?? ['anomes' => '', 'perfil' => 'SG', 'segmento' => '', 'juncao' => '', 'funcional' => '', 'indicador' => ''];
$encantabraOptions = $encantabraFilterOptions ?? ['anomes' => [], 'perfil' => [], 'segmento' => [], 'juncao' => [], 'funcional' => [], 'indicador' => []];
$encantabraSection = $encantabraActiveSection ?? 'resultado';
$encantabraFiltersExpanded = ($advancedFiltersState ?? 'open') !== 'closed';
$encantabraBaseQuery = [
    'page' => 'pobj-dashboard',
    'tab' => 'encantabra',
    'advanced_filters' => $encantabraFiltersExpanded ? 'open' : 'closed',
];
$encantabraAnalyticQueryBase = array_merge($encantabraBaseQuery, ['enc_tab' => 'resultado']);
$encantabraTableColumns = array_values((array) ($encantabraTable['columns'] ?? []));
$encantabraTableRows = array_values((array) ($encantabraTable['rows'] ?? []));
$encantabraTableTotalRows = (int) ($encantabraTable['total_rows'] ?? 0);
$encantabraTableCurrentPage = max(1, (int) ($encantabraTable['current_page'] ?? 1));
$encantabraTablePerPage = max(1, (int) ($encantabraTable['per_page'] ?? 20));
$encantabraTableTotalPages = max(1, (int) ($encantabraTable['total_pages'] ?? 1));
$encantabraTableStartRow = $encantabraTableTotalRows > 0 ? (($encantabraTableCurrentPage - 1) * $encantabraTablePerPage) + 1 : 0;
$encantabraTableEndRow = $encantabraTableRows !== []
    ? min($encantabraTableStartRow + count($encantabraTableRows) - 1, $encantabraTableTotalRows)
    : 0;
$placeholderLink = 'https://www.bradesco.com.br/';

foreach ($encantabraFilters as $filterKey => $filterValue) {
    if (!is_string($filterValue) || $filterValue === '') {
        continue;
    }

    $encantabraBaseQuery['enc_' . $filterKey] = $filterValue;
}

$renderEncantabraOptions = static function (array $options, string $selectedValue, string $placeholder): void {
    echo '<option value="">' . e($placeholder) . '</option>';

    foreach ($options as $option) {
        $value = (string) ($option['value'] ?? '');
        $label = (string) ($option['label'] ?? $value);

        if ($value === '' || $label === '') {
            continue;
        }

        echo '<option value="' . e($value) . '"' . selected_attr($value, $selectedValue) . '>' . e($label) . '</option>';
    }
};

$formatScore = static function (?float $value): string {
    return $value === null ? '—' : format_decimal($value, 1);
};

$formatWholeMetric = static function (?float $value): string {
    return $value === null ? '—' : number_format((float) round($value), 0, ',', '.');
};

$resolveScoreTone = static function (?float $value): string {
    if ($value === null) {
        return 'is-empty';
    }

    if ($value >= 110.0) {
        return 'is-fan';
    }

    if ($value >= 90.0) {
        return 'is-encantador';
    }

    if ($value >= 70.0) {
        return 'is-expected';
    }

    return 'is-far';
};

$decimalMetricColumns = [
    'META' => true,
    'REALIZADO' => true,
    'ATINGIMENTO' => true,
    'PESO' => true,
    'PONTUACAO' => true,
    'PESO_DISTRIBUICAO' => true,
    'SUM_PESO_DISTRIBUICAO' => true,
    'NOVO_PESO' => true,
    'NOVA_PONTUACAO' => true,
];
$integerLikeColumns = [
    'id' => true,
    'ANO_MES' => true,
    'COD_JUNC' => true,
    'COD_JUNC_PA' => true,
    'COD_FUNC' => true,
    'COD_CARGO' => true,
    'COD_FUNC_GEST' => true,
    'COD_GRUPO_INDICADOR' => true,
    'COD_INDICADOR' => true,
];
$displayRawValue = static function (string $columnKey, $value) use ($decimalMetricColumns, $integerLikeColumns): string {
    if ($value === null || $value === '') {
        return '—';
    }

    if (isset($decimalMetricColumns[$columnKey]) && is_numeric($value)) {
        return format_decimal((float) $value, 1);
    }

    if (isset($integerLikeColumns[$columnKey]) && is_numeric($value)) {
        return number_format((float) $value, 0, ',', '.');
    }

    return trim((string) $value) !== '' ? (string) $value : '—';
};

$formatColumnLabel = static function (string $columnKey): string {
    return str_replace('_', ' ', $columnKey);
};

$buildEncantabraPageUrl = static function (int $pageNumber) use ($encantabraAnalyticQueryBase): string {
    return app_url(array_merge($encantabraAnalyticQueryBase, ['enc_page' => (string) max(1, $pageNumber)]));
};

$chartLabels = array_values((array) ($encantabraChart['labels'] ?? []));
$chartSeries = array_values((array) ($encantabraChart['series'] ?? []));
$scoreSeries = array_values((array) (($chartSeries[0]['values'] ?? [])));
$chartMaxValue = max(100.0, (float) ($encantabraChart['max_value'] ?? 100.0));
$gaugeScaleMax = 150.0;
$chartPoints = [];

foreach ($chartLabels as $index => $label) {
    $rawLabel = strtolower(trim((string) $label));
    $parts = explode('/', $rawLabel);
    $monthLabel = ucfirst($parts[0] ?? $rawLabel);
    $yearLabel = $parts[1] ?? '';

    if (strlen($yearLabel) === 2) {
        $yearLabel = '20' . $yearLabel;
    }

    $value = isset($scoreSeries[$index]) ? (float) $scoreSeries[$index] : 0.0;
    $chartPoints[] = [
        'month' => $monthLabel,
        'year' => $yearLabel,
        'value' => $value,
        'height' => max(8.0, min(100.0, ($value / $chartMaxValue) * 100.0)),
        'tone' => $resolveScoreTone($value),
    ];
}

$gaugeScoreRaw = (float) ($encantabraSummary['score_avg'] ?? 0.0);
$gaugeScore = $gaugeScoreRaw > 0.0 ? max(0.0, min($gaugeScaleMax, $gaugeScoreRaw)) : null;
$benchmarkHeight = min(100.0, ($chartMaxValue > 0.0 ? (90.0 / $chartMaxValue) * 100.0 : 0.0));
$selectedMonthLabel = str_replace('/', ' - ', (string) ($encantabraReference['month_label'] ?? 'Base atual'));
$trimesterYear = trim((string) ($encantabraTrimesterTables['year'] ?? ''));
$trimesterTables = array_values((array) ($encantabraTrimesterTables['tables'] ?? []));

$polarToCartesian = static function (float $cx, float $cy, float $radius, float $angleDeg): array {
    $angleRad = (($angleDeg - 90.0) * 3.141592653589793) / 180.0;

    return [
        'x' => $cx + ($radius * cos($angleRad)),
        'y' => $cy + ($radius * sin($angleRad)),
    ];
};

$valueToAngle = static function (float $value) use ($gaugeScaleMax): float {
    $clampedValue = max(0.0, min($gaugeScaleMax, $value));

    return -90.0 + (($clampedValue / $gaugeScaleMax) * 180.0);
};

$describeArc = static function (float $startValue, float $endValue) use ($polarToCartesian, $valueToAngle, $gaugeScaleMax): string {
    $boundedStart = max(0.0, min($gaugeScaleMax, $startValue));
    $boundedEnd = max(0.0, min($gaugeScaleMax, $endValue));

    if ($boundedEnd <= $boundedStart) {
        return '';
    }

    $start = $polarToCartesian(100.0, 110.0, 90.0, $valueToAngle($boundedStart));
    $end = $polarToCartesian(100.0, 110.0, 90.0, $valueToAngle($boundedEnd));
    $largeArcFlag = ($boundedEnd - $boundedStart) <= ($gaugeScaleMax / 2.0) ? 0 : 1;

    return sprintf('M %.3F %.3F A 90 90 0 %d 1 %.3F %.3F', $start['x'], $start['y'], $largeArcFlag, $end['x'], $end['y']);
};

$gaugeTrackPath = $describeArc(0.0, $gaugeScaleMax);
$gaugeNeedleDegrees = $gaugeScore === null ? -90.0 : $valueToAngle($gaugeScore);
$gaugeSegments = [];
$gaugeSegmentDefinitions = [
    ['start' => 0.0, 'end' => 70.0, 'color' => '#d62828'],
    ['start' => 70.0, 'end' => 90.0, 'color' => '#f2b035'],
    ['start' => 90.0, 'end' => 110.0, 'color' => '#1b86e8'],
    ['start' => 110.0, 'end' => $gaugeScaleMax, 'color' => '#3ba755'],
];

foreach ($gaugeSegmentDefinitions as $segmentIndex => $segmentDefinition) {
    $segmentPath = $describeArc((float) $segmentDefinition['start'], (float) $segmentDefinition['end']);

    if ($segmentPath === '') {
        continue;
    }

    $gaugeSegments[] = [
        'path' => $segmentPath,
        'color' => (string) $segmentDefinition['color'],
        'delay' => (int) ($segmentIndex * 120),
    ];
}

$bandLegend = [
    ['key' => 'fan', 'tone' => 'is-fan', 'range' => '110 a 150', 'label' => 'Cliente fã'],
    ['key' => 'encantador', 'tone' => 'is-encantador', 'range' => '90 a 109,99', 'label' => 'Encantador'],
    ['key' => 'expectativa', 'tone' => 'is-expected', 'range' => '70 a 89,99', 'label' => 'Atende expectativa'],
    ['key' => 'critico', 'tone' => 'is-far', 'range' => '0 a 69,99', 'label' => 'Crítico'],
];

$encantabraInnerTabs = [
    'resultado' => ['label' => 'Resultado', 'icon' => 'bar-chart-3'],
    'regulamento' => ['label' => 'Regulamento', 'icon' => 'file-text'],
    'apoio' => ['label' => 'Apoio e Destaques', 'icon' => 'life-buoy'],
];

$regulationResources = [
    ['title' => 'Varejo', 'icon' => 'file-text'],
    ['title' => 'Digital Varejo', 'icon' => 'file-text'],
    ['title' => 'Prime e Prime Digital', 'icon' => 'file-text'],
    ['title' => 'Empresas', 'icon' => 'file-text'],
    ['title' => 'Período Anterior', 'icon' => 'file-text'],
];

$supportYearHighlights = [
    ['year' => '2023', 'periods' => ['1º Semestre', '2º Semestre']],
    ['year' => '2024', 'periods' => ['1º Semestre', '2º Semestre']],
    ['year' => '2025', 'periods' => ['1º Semestre', '2º Semestre']],
];

$supportFeatureCards = [
    ['icon' => 'megaphone', 'title' => 'Papo que Encanta', 'copy' => 'Trilha de dicas para se tornar cada vez mais encantador', 'badge' => 'Novo'],
    ['icon' => 'messages-square', 'title' => 'Comunicações', 'copy' => 'Aqui você fica sabendo de todos nossos conteúdos divulgados', 'badge' => ''],
];

$supportChannelLinks = [
    ['icon' => 'mail', 'label' => 'E-mail', 'copy' => 'Materiais, campanhas e dúvidas rápidas do programa.'],
    ['icon' => 'messages-square', 'label' => 'Viva Engage', 'copy' => 'Comunicados, conteúdos e trocas do EncantaBra.'],
];

$supportManagementTools = [
    [
        'title' => 'Manifestação',
        'items' => [
            ['label' => 'Painel de Reclamações', 'copy' => 'Acompanhamento de reclamações (entrada) da rotina SACL'],
            ['label' => 'Painel de Clientes (Manifestações)', 'copy' => 'Consultar todas as reclamações, por cliente/segmento'],
        ],
    ],
    [
        'title' => 'Pesquisas',
        'items' => [
            ['label' => 'Pesquisa Estágios de Relacionamento', 'copy' => 'Análise até nível gerente dos indicadores de pesquisa de contato e visita.'],
            ['label' => 'Portal Bridge', 'copy' => 'Pesquisa de satisfação Prime.'],
        ],
    ],
    [
        'title' => 'NPS e Engajamento',
        'items' => [
            ['label' => 'Medallia', 'copy' => 'Ferramenta para gerenciamento da experiência do cliente.'],
            ['label' => 'NPS FAQ', 'copy' => 'Tire suas dúvidas.'],
            ['label' => 'Engajamento NPS', 'copy' => 'Acesso aos dashboards do EncantaBra.'],
        ],
    ],
];

$clearEncantabraUrl = app_url([
    'page' => 'pobj-dashboard',
    'tab' => 'encantabra',
    'enc_tab' => $encantabraSection,
    'advanced_filters' => $encantabraFiltersExpanded ? 'open' : 'closed',
]);
?>
<section class="encantabra-view" aria-label="Painel EncantaBra">
    <section class="filters-card encantabra-filters-card" aria-label="Filtros do EncantaBra">
        <header class="filters-card__header">
            <div>
                <h1 class="filters-card__title">EncantaBra</h1>
                <p class="filters-card__subtitle">Acompanhe dados atualizados de performance.</p>
            </div>
        </header>

        <form class="filters-form" method="get" action="index.php">
            <input type="hidden" name="page" value="pobj-dashboard">
            <input type="hidden" name="tab" value="encantabra">
            <input type="hidden" name="enc_tab" value="<?= e($encantabraSection) ?>">
            <input type="hidden" name="advanced_filters" value="<?= e($encantabraFiltersExpanded ? 'open' : 'closed') ?>" data-filters-state>

            <div class="filters-grid filters-grid--top encantabra-filters-grid">
                <div class="filter-field">
                    <label class="filter-field__label" for="enc-filter-segmento">Segmento</label>
                    <select id="enc-filter-segmento" class="filter-field__control" name="enc_segmento" data-enhanced-select="search" data-enhanced-label="Segmento" data-enhanced-placeholder="Todos">
                        <?php $renderEncantabraOptions($encantabraOptions['segmento'] ?? [], (string) ($encantabraFilters['segmento'] ?? ''), 'Todos'); ?>
                    </select>
                </div>

                <div class="filter-field">
                    <label class="filter-field__label" for="enc-filter-juncao">Junção</label>
                    <select id="enc-filter-juncao" class="filter-field__control" name="enc_juncao" data-enhanced-select="search" data-enhanced-label="Junção" data-enhanced-placeholder="Todas">
                        <?php $renderEncantabraOptions($encantabraOptions['juncao'] ?? [], (string) ($encantabraFilters['juncao'] ?? ''), 'Todas'); ?>
                    </select>
                </div>

                <div class="filter-field">
                    <label class="filter-field__label" for="enc-filter-funcional">Funcionário</label>
                    <select id="enc-filter-funcional" class="filter-field__control" name="enc_funcional" data-enhanced-select="search" data-enhanced-label="Funcionário" data-enhanced-placeholder="Todos">
                        <?php $renderEncantabraOptions($encantabraOptions['funcional'] ?? [], (string) ($encantabraFilters['funcional'] ?? ''), 'Todos'); ?>
                    </select>
                </div>

                <div class="filters-actions encantabra-filters-actions">
                    <button class="filters-button filters-button--primary" type="submit">Filtrar</button>
                    <a class="filters-button filters-button--ghost" href="<?= e($clearEncantabraUrl) ?>">Limpar filtros</a>
                </div>
            </div>

            <div class="filters-toggle-row encantabra-filters-toggle-row">
                <button class="filters-advanced-toggle<?= $encantabraFiltersExpanded ? ' is-open' : '' ?>" type="button" aria-expanded="<?= $encantabraFiltersExpanded ? 'true' : 'false' ?>" aria-controls="encantabra-advanced-filters" data-filters-toggle>
                    <?= $encantabraFiltersExpanded ? 'Fechar filtros avançados' : 'Abrir filtros avançados' ?>
                </button>
            </div>

            <div class="filters-advanced-shell<?= $encantabraFiltersExpanded ? '' : ' is-collapsed' ?>" id="encantabra-advanced-filters" data-filters-shell>
                <div class="filters-advanced" data-filters-advanced>
                    <div class="filters-grid filters-grid--advanced encantabra-filters-grid encantabra-filters-grid--advanced">
                        <div class="filter-field">
                            <label class="filter-field__label" for="enc-filter-perfil">Visão</label>
                            <select id="enc-filter-perfil" class="filter-field__control" name="enc_perfil" data-enhanced-select="basic" data-enhanced-label="Visão" data-enhanced-placeholder="Selecione a visão">
                                <?php $renderEncantabraOptions($encantabraOptions['perfil'] ?? [], (string) ($encantabraFilters['perfil'] ?? 'SG'), 'Selecione a visão'); ?>
                            </select>
                        </div>

                        <div class="filter-field">
                            <label class="filter-field__label" for="enc-filter-indicador">Indicador</label>
                            <select id="enc-filter-indicador" class="filter-field__control" name="enc_indicador" data-enhanced-select="search" data-enhanced-label="Indicador" data-enhanced-placeholder="Todos os indicadores">
                                <?php $renderEncantabraOptions($encantabraOptions['indicador'] ?? [], (string) ($encantabraFilters['indicador'] ?? ''), 'Todos os indicadores'); ?>
                            </select>
                        </div>

                        <div class="filter-field">
                            <label class="filter-field__label" for="enc-filter-anomes">Data</label>
                            <select id="enc-filter-anomes" class="filter-field__control" name="enc_anomes" data-enhanced-select="basic" data-enhanced-label="Data" data-enhanced-placeholder="Selecione a data">
                                <?php $renderEncantabraOptions($encantabraOptions['anomes'] ?? [], (string) ($encantabraFilters['anomes'] ?? ''), 'Selecione a data'); ?>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </section>

    <section class="summary-tabs-section encantabra-tabs-section" aria-label="Navegação interna do EncantaBra">
        <div class="summary-tabs-shell encantabra-tabs-shell">
            <nav class="summary-tabs" aria-label="Abas do EncantaBra">
            <?php foreach ($encantabraInnerTabs as $tabId => $tabItem): ?>
                <?php $tabUrl = app_url(array_merge($encantabraBaseQuery, ['enc_tab' => $tabId])); ?>
                <a class="summary-tabs__item<?= $encantabraSection === $tabId ? ' is-active' : '' ?>" href="<?= e($tabUrl) ?>" data-preserve-filters-state>
                    <span class="summary-tabs__icon" aria-hidden="true"><i data-lucide="<?= e($tabItem['icon']) ?>"></i></span>
                    <span class="summary-tabs__label"><?= e($tabItem['label']) ?></span>
                </a>
            <?php endforeach; ?>
            </nav>

            <div class="summary-tabs__meta">
                <span class="summary-tabs__meta-button summary-tabs__meta-button--static encantabra-tabs-shell__meta-pill">Data selecionada: <?= e($selectedMonthLabel !== '' ? $selectedMonthLabel : 'Base atual') ?></span>
            </div>
        </div>
    </section>

    <?php if ($encantabraSection === 'resultado'): ?>
        <?php if ((int) ($encantabraSummary['rows_total'] ?? 0) === 0): ?>
            <section class="coming-soon encantabra-empty" aria-label="Sem dados do EncantaBra">
                <div class="coming-soon__card">
                    <span class="coming-soon__eyebrow">Sem dados</span>
                    <h2 class="coming-soon__title">Nenhuma leitura encontrada para o recorte selecionado.</h2>
                    <p class="coming-soon__copy">Ajuste os filtros do EncantaBra para reconstruir a leitura do período com base na tabela local.</p>
                </div>
            </section>
        <?php else: ?>
            <div class="encantabra-result-grid">
                <section class="executive-panel encantabra-score-panel">
                    <header class="executive-panel__header">
                        <div>
                            <h3 class="executive-panel__title">Pontuação média do período</h3>
                        </div>
                    </header>

                    <div class="encantabra-score-panel__body">
                        <div class="encantabra-gauge">
                            <div class="encantabra-gauge__shell">
                                <svg class="encantabra-gauge__svg" viewBox="0 0 220 145" role="img" aria-label="Velocímetro da pontuação média do período">
                                    <path d="<?= e($gaugeTrackPath) ?>" class="encantabra-gauge__track"></path>
                                    <?php foreach ($gaugeSegments as $segment): ?>
                                        <path d="<?= e((string) ($segment['path'] ?? '')) ?>" class="encantabra-gauge__segment" style="stroke: <?= e((string) ($segment['color'] ?? '#94a3b8')) ?>; --segment-delay: <?= e((string) ((int) ($segment['delay'] ?? 0))) ?>ms;"></path>
                                    <?php endforeach; ?>
                                    <g class="encantabra-gauge__needle" style="--needle-angle: <?= e(number_format($gaugeNeedleDegrees, 2, '.', '')) ?>deg;">
                                        <line x1="100" y1="110" x2="100" y2="24"></line>
                                        <polygon points="96,24 104,24 100,12"></polygon>
                                        <circle cx="100" cy="110" r="6"></circle>
                                    </g>
                                </svg>
                                <div class="encantabra-gauge__score-box">
                                    <strong><?= e($formatScore($gaugeScoreRaw > 0.0 ? $gaugeScoreRaw : null)) ?></strong>
                                    <span><?= e($selectedMonthLabel !== '' ? $selectedMonthLabel : 'Período atual') ?></span>
                                </div>
                            </div>
                            <div class="encantabra-gauge__scale" aria-hidden="true">
                                <span>0</span>
                                <span>Meta 90</span>
                                <span>150</span>
                            </div>
                        </div>

                        <div class="encantabra-gauge__legend">
                            <h4>Faixas de leitura do programa</h4>
                            <?php foreach ($bandLegend as $item): ?>
                                <div class="encantabra-gauge__legend-row <?= e($item['tone']) ?>">
                                    <span class="encantabra-gauge__legend-dot" aria-hidden="true"></span>
                                    <div class="encantabra-gauge__legend-copy">
                                        <strong><?= e($item['range']) ?></strong>
                                        <span><?= e($item['label']) ?></span>
                                    </div>
                                    <span class="encantabra-gauge__legend-count"><?= e(format_int_readable((float) ($encantabraStatus[$item['key']] ?? 0))) ?></span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </section>

                <section class="executive-panel encantabra-monthly-panel">
                    <header class="executive-panel__header">
                        <div>
                            <h3 class="executive-panel__title">Evolução temporal</h3>
                        </div>
                        <span class="executive-panel__tag">Faixa Encantador: 90+</span>
                    </header>

                    <?php if ($chartPoints === []): ?>
                        <div class="executive-empty">Ainda não há dados suficientes para montar a evolução temporal deste recorte.</div>
                    <?php else: ?>
                        <div class="encantabra-monthly" style="--encantabra-benchmark: <?= e(number_format($benchmarkHeight, 2, '.', '')) ?>%;">
                            <div class="encantabra-monthly__grid">
                                <?php foreach ($chartPoints as $index => $point): ?>
                                    <?php $tooltip = sprintf('%s/%s: %s', (string) ($point['month'] ?? ''), (string) ($point['year'] ?? ''), $formatScore((float) ($point['value'] ?? 0.0))); ?>
                                    <article class="encantabra-monthly__item">
                                        <div class="encantabra-monthly__track">
                                            <span class="encantabra-monthly__benchmark" aria-hidden="true"></span>
                                            <div class="encantabra-monthly__bar <?= e((string) ($point['tone'] ?? 'is-empty')) ?>" style="--bar-height: <?= e(number_format((float) ($point['height'] ?? 0.0), 2, '.', '')) ?>%; --bar-delay: <?= e((string) ((int) $index * 85)) ?>ms;" title="<?= e($tooltip) ?>" aria-label="<?= e($tooltip) ?>">
                                                <span><?= e($formatScore((float) ($point['value'] ?? 0.0))) ?></span>
                                            </div>
                                        </div>
                                        <div class="encantabra-monthly__label"><?= e((string) ($point['month'] ?? '')) ?></div>
                                        <div class="encantabra-monthly__year"><?= e((string) ($point['year'] ?? '')) ?></div>
                                    </article>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </section>
            </div>

            <section class="executive-panel encantabra-table-panel encantabra-analytic-panel">
                <header class="executive-panel__header encantabra-table-panel__header">
                    <div>
                        <h3 class="executive-panel__title"><?= e((string) ($encantabraTable['title'] ?? 'Performance mês a mês por indicador')) ?></h3>
                        <?php if (($encantabraTable['subtitle'] ?? '') !== ''): ?>
                            <p class="encantabra-table-panel__copy"><?= e((string) ($encantabraTable['subtitle'] ?? '')) ?></p>
                        <?php endif; ?>
                    </div>

                    <div class="encantabra-table-panel__actions">
                        <span class="executive-panel__tag">
                            <?= e($encantabraTableTotalRows > 0 ? sprintf('Exibindo %d-%d de %d linhas', $encantabraTableStartRow, $encantabraTableEndRow, $encantabraTableTotalRows) : 'Sem linhas para exibir') ?>
                        </span>

                        <?php if ($encantabraTableTotalPages > 1): ?>
                            <nav class="encantabra-pagination" aria-label="Paginação da tabela analítica do EncantaBra">
                                <?php if ($encantabraTableCurrentPage > 1): ?>
                                    <a class="encantabra-pagination__button" href="<?= e($buildEncantabraPageUrl($encantabraTableCurrentPage - 1)) ?>">Anterior</a>
                                <?php else: ?>
                                    <span class="encantabra-pagination__button is-disabled" aria-disabled="true">Anterior</span>
                                <?php endif; ?>

                                <span class="encantabra-pagination__status">Página <?= e((string) $encantabraTableCurrentPage) ?> de <?= e((string) $encantabraTableTotalPages) ?></span>

                                <?php if ($encantabraTableCurrentPage < $encantabraTableTotalPages): ?>
                                    <a class="encantabra-pagination__button" href="<?= e($buildEncantabraPageUrl($encantabraTableCurrentPage + 1)) ?>">Próxima</a>
                                <?php else: ?>
                                    <span class="encantabra-pagination__button is-disabled" aria-disabled="true">Próxima</span>
                                <?php endif; ?>
                            </nav>
                        <?php endif; ?>
                    </div>
                </header>

                <?php if ($encantabraTableRows === [] || $encantabraTableColumns === []): ?>
                    <div class="executive-empty">Sem linhas suficientes para montar a tabela analítica deste recorte.</div>
                <?php else: ?>
                    <div class="table-wrapper encantabra-table-wrapper">
                        <table class="encantabra-table encantabra-table--raw">
                            <thead>
                                <tr>
                                    <?php foreach ($encantabraTableColumns as $columnKey): ?>
                                        <th><?= e($formatColumnLabel((string) $columnKey)) ?></th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($encantabraTableRows as $tableRow): ?>
                                    <tr>
                                        <?php foreach ($encantabraTableColumns as $columnKey): ?>
                                            <td><?= e($displayRawValue((string) $columnKey, $tableRow[$columnKey] ?? null)) ?></td>
                                        <?php endforeach; ?>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </section>

            <section class="executive-panel encantabra-table-panel encantabra-trimester-panel">
                <header class="executive-panel__header encantabra-table-panel__header">
                    <div>
                        <h3 class="executive-panel__title">Visão trimestral do projeto</h3>
                        <p class="encantabra-table-panel__copy">
                            <?= e($trimesterYear !== '' ? 'As tabelas consolidam o ano de ' . $trimesterYear . ' e respeitam os demais filtros, sem travar na data selecionada.' : 'As tabelas consolidam o ano disponível e respeitam os demais filtros aplicados.') ?>
                        </p>
                    </div>
                    <span class="executive-panel__tag"><?= e($trimesterYear !== '' ? 'Ano base: ' . $trimesterYear : 'Trimestres') ?></span>
                </header>

                <?php if ($trimesterTables === []): ?>
                    <div class="executive-empty">Sem dados suficientes para montar as tabelas trimestrais do EncantaBra.</div>
                <?php else: ?>
                    <div class="encantabra-trimester-stack">
                        <?php foreach ($trimesterTables as $trimesterTable): ?>
                            <?php
                            $trimesterRows = array_values((array) ($trimesterTable['rows'] ?? []));
                            $trimesterMonths = array_values((array) ($trimesterTable['months'] ?? []));
                            $firstMonthLabel = $trimesterMonths !== [] ? (string) ($trimesterMonths[0]['label'] ?? '') : '';
                            $lastMonthLabel = $trimesterMonths !== [] ? (string) ($trimesterMonths[count($trimesterMonths) - 1]['label'] ?? '') : '';
                            ?>
                            <section class="encantabra-trimester-card">
                                <div class="encantabra-trimester-card__header">
                                    <div>
                                        <h4><?= e((string) ($trimesterTable['title'] ?? 'Trimestre')) ?></h4>
                                        <p><?= e(format_int_readable((float) count($trimesterRows))) ?> indicadores consolidados</p>
                                    </div>
                                    <span class="encantabra-trimester-card__badge"><?= e(trim($firstMonthLabel . ' a ' . $lastMonthLabel)) ?></span>
                                </div>

                                <?php if ($trimesterRows === []): ?>
                                    <div class="executive-empty">Sem indicadores suficientes para este trimestre.</div>
                                <?php else: ?>
                                    <div class="table-wrapper">
                                        <table class="encantabra-table encantabra-table--trimester">
                                            <thead>
                                                <tr>
                                                    <th rowspan="2" class="encantabra-table__sticky-col">Indicador</th>
                                                    <?php foreach ($trimesterMonths as $monthIndex => $trimesterMonth): ?>
                                                        <?php $monthToneClass = $monthIndex % 2 === 0 ? 'is-tone-a' : 'is-tone-b'; ?>
                                                        <th colspan="4" class="encantabra-table__month-group <?= e($monthToneClass) ?>"><?= e((string) ($trimesterMonth['label'] ?? '')) ?></th>
                                                    <?php endforeach; ?>
                                                    <th rowspan="2" class="encantabra-table__average-col">Média</th>
                                                </tr>
                                                <tr>
                                                    <?php foreach ($trimesterMonths as $monthIndex => $trimesterMonth): ?>
                                                        <?php $monthToneClass = $monthIndex % 2 === 0 ? 'is-tone-a' : 'is-tone-b'; ?>
                                                        <th class="encantabra-table__metric-col <?= e($monthToneClass) ?> is-month-start">Peso</th>
                                                        <th class="encantabra-table__metric-col <?= e($monthToneClass) ?>">Real</th>
                                                        <th class="encantabra-table__metric-col <?= e($monthToneClass) ?>">Ating</th>
                                                        <th class="encantabra-table__metric-col <?= e($monthToneClass) ?> is-month-end">Pont</th>
                                                    <?php endforeach; ?>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php foreach ($trimesterRows as $trimesterRow): ?>
                                                    <?php $trimesterTone = (string) (($trimesterRow['band']['tone'] ?? 'is-empty')); ?>
                                                    <tr>
                                                        <th scope="row" class="encantabra-table__sticky-col">
                                                            <div class="encantabra-table__sticky-content">
                                                                <span class="encantabra-table__title"><?= e((string) ($trimesterRow['label'] ?? 'Indicador')) ?></span>
                                                            </div>
                                                        </th>
                                                        <?php foreach ($trimesterMonths as $monthIndex => $trimesterMonth): ?>
                                                            <?php
                                                            $monthToneClass = $monthIndex % 2 === 0 ? 'is-tone-a' : 'is-tone-b';
                                                            $monthNumber = (int) ($trimesterMonth['number'] ?? 0);
                                                            $monthValues = (array) (($trimesterRow['months'][$monthNumber] ?? []));
                                                            $monthPoint = isset($monthValues['pont']) ? (float) $monthValues['pont'] : null;
                                                            ?>
                                                            <td class="encantabra-table__month-cell <?= e($monthToneClass) ?> is-month-start"><?= e($formatScore(isset($monthValues['peso']) ? (float) $monthValues['peso'] : null)) ?></td>
                                                            <td class="encantabra-table__month-cell <?= e($monthToneClass) ?>"><?= e($formatWholeMetric(isset($monthValues['real']) ? (float) $monthValues['real'] : null)) ?></td>
                                                            <td class="encantabra-table__month-cell <?= e($monthToneClass) ?>"><?= e($formatWholeMetric(isset($monthValues['ating']) ? (float) $monthValues['ating'] : null)) ?></td>
                                                            <td class="encantabra-table__month-cell <?= e($monthToneClass) ?> is-month-end">
                                                                <span class="encantabra-trimester-score <?= e($resolveScoreTone($monthPoint)) ?>">
                                                                    <?= e($formatWholeMetric($monthPoint)) ?>
                                                                </span>
                                                            </td>
                                                        <?php endforeach; ?>
                                                        <td class="encantabra-table__average-cell">
                                                            <div class="encantabra-trimester-average <?= e($trimesterTone) ?>">
                                                                <strong><?= e($formatScore(isset($trimesterRow['average']) ? (float) $trimesterRow['average'] : null)) ?></strong>
                                                                <span><?= e((string) ($trimesterRow['band']['label'] ?? 'Sem dados')) ?></span>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endif; ?>
                            </section>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </section>
        <?php endif; ?>
    <?php elseif ($encantabraSection === 'regulamento'): ?>
        <section class="encantabra-reg-page">
            <article class="encantabra-reg-hero">
                <p class="encantabra-reg-hero__eyebrow">Regulamento</p>
                <h3>DO PROGRAMA <?= e((string) date('Y')) ?></h3>
                <p class="encantabra-reg-hero__copy">Aqui você entenderá com profundidade as regras dos indicadores do programa.</p>
            </article>

            <div class="encantabra-reg-grid">
                <?php foreach ($regulationResources as $resource): ?>
                    <a class="encantabra-reg-card encantabra-reg-card--link" href="<?= e($placeholderLink) ?>" target="_blank" rel="noopener">
                        <div class="encantabra-reg-card__icon" aria-hidden="true"><i data-lucide="<?= e((string) ($resource['icon'] ?? 'file-text')) ?>"></i></div>
                        <div class="encantabra-reg-card__copy">
                            <h4><?= e((string) ($resource['title'] ?? 'Regulamento')) ?></h4>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        </section>
    <?php else: ?>
        <section class="encantabra-support-page">
            <div class="encantabra-support-top">
                <article class="encantabra-support-card encantabra-support-card--years">
                    <div class="encantabra-support-card__header">
                        <span class="encantabra-support-card__icon" aria-hidden="true"><i data-lucide="award"></i></span>
                        <div>
                            <p class="encantabra-support-card__eyebrow">Destaques</p>
                            <h4>Semestres por ano</h4>
                        </div>
                    </div>

                    <div class="encantabra-support-years">
                        <?php foreach ($supportYearHighlights as $supportYear): ?>
                            <div class="encantabra-support-years__row">
                                <strong><?= e((string) ($supportYear['year'] ?? '')) ?></strong>
                                <div class="encantabra-support-years__actions">
                                    <?php foreach ((array) ($supportYear['periods'] ?? []) as $periodLabel): ?>
                                        <a class="encantabra-support-pill" href="<?= e($placeholderLink) ?>" target="_blank" rel="noopener"><?= e((string) $periodLabel) ?></a>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </article>

                <?php foreach ($supportFeatureCards as $featureCard): ?>
                    <a class="encantabra-support-card encantabra-support-card--link" href="<?= e($placeholderLink) ?>" target="_blank" rel="noopener">
                        <div class="encantabra-support-card__header">
                            <span class="encantabra-support-card__icon" aria-hidden="true"><i data-lucide="<?= e((string) ($featureCard['icon'] ?? 'megaphone')) ?>"></i></span>
                            <div class="encantabra-support-card__title-row">
                                <h4><?= e((string) ($featureCard['title'] ?? 'Destaque')) ?></h4>
                                <?php if (($featureCard['badge'] ?? '') !== ''): ?>
                                    <span class="encantabra-support-card__chip"><?= e((string) $featureCard['badge']) ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <p class="encantabra-support-card__copy"><?= e((string) ($featureCard['copy'] ?? '')) ?></p>
                    </a>
                <?php endforeach; ?>

                <article class="encantabra-support-card encantabra-support-card--channels">
                    <div class="encantabra-support-card__header">
                        <span class="encantabra-support-card__icon" aria-hidden="true"><i data-lucide="life-buoy"></i></span>
                        <div>
                            <h4>Nossos Canais Apoio</h4>
                        </div>
                    </div>

                    <div class="encantabra-support-links">
                        <?php foreach ($supportChannelLinks as $channelLink): ?>
                            <a class="encantabra-support-link-pill" href="<?= e($placeholderLink) ?>" target="_blank" rel="noopener">
                                <span class="encantabra-support-link-pill__icon" aria-hidden="true"><i data-lucide="<?= e((string) ($channelLink['icon'] ?? 'mail')) ?>"></i></span>
                                <span class="encantabra-support-link-pill__copy">
                                    <strong><?= e((string) ($channelLink['label'] ?? 'Canal')) ?></strong>
                                    <span><?= e((string) ($channelLink['copy'] ?? '')) ?></span>
                                </span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </article>
            </div>

            <section class="encantabra-support-tools">
                <header class="encantabra-support-tools__header">
                    <span class="encantabra-support-tools__accent" aria-hidden="true"></span>
                    <div>
                        <p class="encantabra-support-card__eyebrow">Apoio</p>
                        <h4>Ferramentas de Gestão</h4>
                    </div>
                </header>

                <div class="encantabra-support-tools__grid">
                    <?php foreach ($supportManagementTools as $toolGroup): ?>
                        <article class="encantabra-support-tools__card">
                            <h5><?= e((string) ($toolGroup['title'] ?? 'Ferramenta')) ?></h5>
                            <ul class="encantabra-support-tools__list">
                                <?php foreach ((array) ($toolGroup['items'] ?? []) as $toolItem): ?>
                                    <li>
                                        <a class="encantabra-support-tools__item" href="<?= e($placeholderLink) ?>" target="_blank" rel="noopener">
                                            <div class="encantabra-support-tools__item-title">
                                                <i data-lucide="chevron-right" aria-hidden="true"></i>
                                                <span><?= e((string) ($toolItem['label'] ?? 'Item')) ?></span>
                                            </div>
                                            <p><?= e((string) ($toolItem['copy'] ?? '')) ?></p>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </article>
                    <?php endforeach; ?>
                </div>
            </section>
        </section>
    <?php endif; ?>
</section>