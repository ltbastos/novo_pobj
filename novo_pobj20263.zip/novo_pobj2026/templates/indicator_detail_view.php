<?php

declare(strict_types=1);

if (($indicatorFocusId ?? '') === '') {
    return;
}

$indicatorDetailIndicator = is_array($indicatorDetailData['indicator'] ?? null) ? $indicatorDetailData['indicator'] : [];

if ($indicatorDetailIndicator === []) {
    return;
}

$indicatorDetailSummary = is_array($indicatorDetailData['summary'] ?? null) ? $indicatorDetailData['summary'] : [];
$indicatorDetailTrend = array_values(array_slice((array) ($indicatorDetailData['trend'] ?? []), -3));
$indicatorDetailDistributions = is_array($indicatorDetailData['distributions'] ?? null) ? $indicatorDetailData['distributions'] : ['channels' => [], 'statuses' => []];
$indicatorDetailInsights = is_array($indicatorDetailData['insights'] ?? null) ? $indicatorDetailData['insights'] : ['mode' => 'hierarchy', 'label' => '', 'title' => '', 'top' => [], 'bottom' => []];
$indicatorDetailTransactions = array_values((array) ($indicatorDetailData['transactions'] ?? []));
$indicatorDetailSubindicators = array_values((array) ($indicatorDetailIndicator['subindicadores'] ?? []));
$indicatorMetricType = strtoupper((string) ($indicatorDetailIndicator['id_tipo_indicador'] ?? 'VALOR'));
$indicatorDetailValueMetricType = $indicatorMetricType === 'PERCENTUAL' ? 'QUANTIDADE' : $indicatorMetricType;
$indicatorDetailChannelRows = array_values((array) ($indicatorDetailDistributions['channels'] ?? []));
$indicatorDetailTopDrivers = array_values((array) ($indicatorDetailInsights['top'] ?? []));
$indicatorDetailBottomDrivers = array_values((array) ($indicatorDetailInsights['bottom'] ?? []));

usort($indicatorDetailSubindicators, static function (array $left, array $right): int {
    return ((int) ($left['ordem_exibicao'] ?? 999) <=> (int) ($right['ordem_exibicao'] ?? 999))
        ?: strcmp((string) ($left['nome_subindicador'] ?? ''), (string) ($right['nome_subindicador'] ?? ''));
});

$findOptionLabel = static function (array $options, string $value): string {
    foreach ($options as $option) {
        if ((string) ($option['value'] ?? '') === $value) {
            return (string) ($option['label'] ?? $value);
        }
    }

    return $value;
};

$indicatorDetailAppliedFilters = [];

foreach ([
    'segmento' => 'Segmento',
    'diretoria' => 'Diretoria',
    'regional' => 'Regional',
    'agencia' => 'Agência',
    'gerente_gestao' => 'Gerente de gestão',
    'gerente' => 'Gerente',
] as $filterKey => $filterLabel) {
    $filterValue = trim((string) ($summaryFilterValues[$filterKey] ?? ''));

    if ($filterValue === '') {
        continue;
    }

    $indicatorDetailAppliedFilters[] = [
        'label' => $filterLabel,
        'value' => prime_label($findOptionLabel($summaryFilterOptions[$filterKey] ?? [], $filterValue)),
    ];
}

$indicatorDetailCloseQuery = [
    'page' => 'pobj-dashboard',
    'periodo' => $selectedPeriodId ?? '',
    'tab' => $activeTab ?? 'resumo',
    'advanced_filters' => $advancedFiltersState ?? 'open',
];

foreach (($summaryFilterValues ?? []) as $filterKey => $filterValue) {
    if (!is_string($filterValue) || $filterValue === '') {
        continue;
    }

    $indicatorDetailCloseQuery[$filterKey] = $filterValue;
}

if (($activeTab ?? 'resumo') === 'rankings' && ($requestedRankingGroup ?? '') !== '') {
    $indicatorDetailCloseQuery['grupo'] = $requestedRankingGroup;
}

if (($hasManualDateRange ?? false) === true) {
    $indicatorDetailCloseQuery['period_mode'] = 'manual';

    if (($requestedPeriodStart ?? '') !== '') {
        $indicatorDetailCloseQuery['period_start'] = $requestedPeriodStart;
    }

    if (($requestedPeriodEnd ?? '') !== '') {
        $indicatorDetailCloseQuery['period_end'] = $requestedPeriodEnd;
    }
}

$indicatorDetailCloseUrl = app_url($indicatorDetailCloseQuery);
$indicatorDetailPercent = (float) ($indicatorDetailSummary['percentual'] ?? 0.0);
$indicatorDetailHeroTone = $indicatorDetailPercent >= 100.0
    ? 'is-ok'
    : ($indicatorDetailPercent >= 80.0 ? 'is-warn' : 'is-risk');
$indicatorDetailScopeLabel = prime_label((string) ($indicatorDetailInsights['label'] ?? 'Recorte atual'));
$indicatorDetailDriversTitle = trim((string) ($indicatorDetailInsights['title'] ?? 'Quem puxa o indicador neste recorte'));
$indicatorDetailDriversCopy = sprintf('Recorte atual de %s, já filtrado pela hierarquia e pelo período selecionados.', $indicatorDetailScopeLabel !== '' ? $indicatorDetailScopeLabel : 'unidades');

$indicatorChartWidth = 360;
$indicatorChartHeight = 196;
$indicatorChartPaddingLeft = 22;
$indicatorChartPaddingRight = 16;
$indicatorChartPaddingTop = 18;
$indicatorChartPaddingBottom = 34;
$indicatorChartInnerWidth = $indicatorChartWidth - $indicatorChartPaddingLeft - $indicatorChartPaddingRight;
$indicatorChartInnerHeight = $indicatorChartHeight - $indicatorChartPaddingTop - $indicatorChartPaddingBottom;
$indicatorChartMax = 100.0;

foreach ($indicatorDetailTrend as $trendRow) {
    $indicatorChartMax = max(
        $indicatorChartMax,
        (float) (ceil((float) ($trendRow['percentual'] ?? 0.0) / 10) * 10)
    );
}

$indicatorChartMax = min(140.0, max(100.0, $indicatorChartMax));
$indicatorChartPoints = [];

foreach ($indicatorDetailTrend as $trendIndex => $trendRow) {
    $trendCount = count($indicatorDetailTrend);
    $trendPercent = max(0.0, min($indicatorChartMax, (float) ($trendRow['percentual'] ?? 0.0)));
    $trendX = $trendCount <= 1
        ? $indicatorChartPaddingLeft + ($indicatorChartInnerWidth / 2)
        : $indicatorChartPaddingLeft + (($indicatorChartInnerWidth / max(1, $trendCount - 1)) * $trendIndex);
    $trendY = $indicatorChartPaddingTop + ($indicatorChartInnerHeight - (($trendPercent / max(1.0, $indicatorChartMax)) * $indicatorChartInnerHeight));

    $indicatorChartPoints[] = [
        'x' => $trendX,
        'y' => $trendY,
        'month_label' => (string) ($trendRow['month_label'] ?? ''),
        'percentual' => (float) ($trendRow['percentual'] ?? 0.0),
        'real_points' => (float) ($trendRow['real_points'] ?? 0.0),
        'meta_points' => (float) ($trendRow['meta_points'] ?? 0.0),
    ];
}

$indicatorChartPolyline = '';
$indicatorChartAreaPath = '';

if ($indicatorChartPoints !== []) {
    $indicatorChartPolyline = implode(' ', array_map(static function (array $point): string {
        return number_format((float) ($point['x'] ?? 0.0), 2, '.', '') . ',' . number_format((float) ($point['y'] ?? 0.0), 2, '.', '');
    }, $indicatorChartPoints));

    $firstPoint = $indicatorChartPoints[0];
    $lastPoint = $indicatorChartPoints[count($indicatorChartPoints) - 1];
    $indicatorChartAreaPath = 'M ' . number_format((float) ($firstPoint['x'] ?? 0.0), 2, '.', '') . ' ' . ($indicatorChartHeight - $indicatorChartPaddingBottom)
        . ' L ' . implode(' L ', array_map(static function (array $point): string {
            return number_format((float) ($point['x'] ?? 0.0), 2, '.', '') . ' ' . number_format((float) ($point['y'] ?? 0.0), 2, '.', '');
        }, $indicatorChartPoints))
        . ' L ' . number_format((float) ($lastPoint['x'] ?? 0.0), 2, '.', '') . ' ' . ($indicatorChartHeight - $indicatorChartPaddingBottom)
        . ' Z';
}

$indicatorChartGridValues = array_values(array_unique(array_filter([
    0,
    50,
    100,
    (int) $indicatorChartMax,
], static function ($value): bool {
    return is_int($value) || is_float($value);
})));
sort($indicatorChartGridValues);

$indicatorDetailKpis = [
    [
        'label' => 'Meta x realizado',
        'value' => format_metric_readable((float) ($indicatorDetailSummary['realizado'] ?? 0.0), $indicatorMetricType),
        'meta' => 'Meta ' . format_metric_readable((float) ($indicatorDetailSummary['meta'] ?? 0.0), $indicatorMetricType),
    ],
    [
        'label' => 'Pontos',
        'value' => format_points_readable((float) ($indicatorDetailSummary['pontos'] ?? 0.0)) . ' pts',
        'meta' => 'Meta ' . format_points_readable((float) ($indicatorDetailSummary['pontos_meta'] ?? 0.0)) . ' pts',
    ],
    [
        'label' => 'Carteira ativada',
        'value' => format_int_readable((float) ($indicatorDetailSummary['contracts_total'] ?? 0)) . ' contratos',
        'meta' => format_int_readable((float) ($indicatorDetailSummary['clients_total'] ?? 0)) . ' clientes',
    ],
    [
        'label' => 'Volume e variável',
        'value' => format_currency_readable((float) ($indicatorDetailSummary['transaction_volume'] ?? 0.0)),
        'meta' => 'Variável ' . format_currency_readable((float) ($indicatorDetailSummary['variavel'] ?? 0.0)),
    ],
];
?>
<section class="indicator-detail-modal" data-indicator-detail-modal data-close-url="<?= e($indicatorDetailCloseUrl) ?>" aria-labelledby="indicator-detail-modal-title">
    <a class="indicator-detail-modal__backdrop" href="<?= e($indicatorDetailCloseUrl) ?>" data-no-loading aria-label="Fechar detalhe do indicador"></a>
    <div class="indicator-detail-modal__dialog" role="dialog" aria-modal="true" aria-labelledby="indicator-detail-modal-title">
        <header class="indicator-detail-modal__header">
            <div>
                <span class="indicator-detail-modal__eyebrow">Detalhe do card</span>
                <h2 class="indicator-detail-modal__title" id="indicator-detail-modal-title"><?= e((string) ($indicatorDetailIndicator['nome_indicador'] ?? 'Indicador')) ?></h2>
                <p class="indicator-detail-modal__copy"><?= e((string) ($indicatorDetailIndicator['nome_familia'] ?? 'Família')) ?> · <?= e($indicatorMetricType === 'PERCENTUAL' ? 'Percentual' : ($indicatorMetricType === 'QUANTIDADE' ? 'Quantidade' : 'Valor')) ?>. Meta, ritmo, distribuição e base do recorte atual.</p>
            </div>
            <a class="indicator-detail-modal__close" href="<?= e($indicatorDetailCloseUrl) ?>" data-no-loading aria-label="Fechar detalhe do indicador">
                <i data-lucide="x"></i>
                <span>Fechar</span>
            </a>
        </header>

        <section class="indicator-detail <?= e($indicatorDetailHeroTone) ?>" aria-label="Detalhamento do indicador">
    <div class="indicator-detail__kpis">
        <?php foreach ($indicatorDetailKpis as $indicatorKpi): ?>
            <article class="indicator-detail__kpi indicator-detail__kpi--compact">
                <span class="indicator-detail__kpi-label"><?= e((string) ($indicatorKpi['label'] ?? 'KPI')) ?></span>
                <strong class="indicator-detail__kpi-value"><?= e((string) ($indicatorKpi['value'] ?? '0')) ?></strong>
                <small><?= e((string) ($indicatorKpi['meta'] ?? '')) ?></small>
            </article>
        <?php endforeach; ?>
    </div>

    <div class="indicator-detail__grid indicator-detail__grid--headline">
        <article class="indicator-detail__panel indicator-detail__panel--chart">
            <div class="indicator-detail__panel-head">
                <div>
                    <span class="indicator-detail__panel-eyebrow">Performance</span>
                    <h3 class="indicator-detail__panel-title">Indicador nos últimos 3 meses</h3>
                    <p class="indicator-detail__panel-copy">Curva mensal do indicador clicado, já respeitando o recorte hierárquico atual.</p>
                </div>
            </div>

            <?php if ($indicatorDetailTrend === []): ?>
                <p class="indicator-detail__empty">Sem histórico recente para o indicador neste recorte.</p>
            <?php else: ?>
                <div class="indicator-detail__chart-shell">
                    <svg class="indicator-detail__chart-svg" viewBox="0 0 <?= e((string) $indicatorChartWidth) ?> <?= e((string) $indicatorChartHeight) ?>" role="img" aria-label="Performance do indicador nos últimos 3 meses">
                        <defs>
                            <linearGradient id="indicator-detail-chart-fill" x1="0" x2="0" y1="0" y2="1">
                                <stop offset="0%" stop-color="rgba(var(--brand-rgb), 0.26)"></stop>
                                <stop offset="100%" stop-color="rgba(var(--brand-rgb), 0.03)"></stop>
                            </linearGradient>
                        </defs>
                        <?php foreach ($indicatorChartGridValues as $gridValue): ?>
                            <?php
                            $gridY = $indicatorChartPaddingTop + ($indicatorChartInnerHeight - (((float) $gridValue / max(1.0, $indicatorChartMax)) * $indicatorChartInnerHeight));
                            ?>
                            <line class="indicator-detail__chart-grid" x1="<?= e((string) $indicatorChartPaddingLeft) ?>" y1="<?= e(number_format($gridY, 2, '.', '')) ?>" x2="<?= e((string) ($indicatorChartWidth - $indicatorChartPaddingRight)) ?>" y2="<?= e(number_format($gridY, 2, '.', '')) ?>"></line>
                            <text class="indicator-detail__chart-axis" x="<?= e((string) max(0, $indicatorChartPaddingLeft - 8)) ?>" y="<?= e(number_format($gridY - 4, 2, '.', '')) ?>" text-anchor="end"><?= e((string) $gridValue) ?>%</text>
                        <?php endforeach; ?>

                        <?php if ($indicatorChartAreaPath !== ''): ?>
                            <path class="indicator-detail__chart-area" d="<?= e($indicatorChartAreaPath) ?>"></path>
                        <?php endif; ?>

                        <?php if ($indicatorChartPolyline !== ''): ?>
                            <polyline class="indicator-detail__chart-line" points="<?= e($indicatorChartPolyline) ?>"></polyline>
                        <?php endif; ?>

                        <?php foreach ($indicatorChartPoints as $chartPoint): ?>
                            <circle class="indicator-detail__chart-point" cx="<?= e(number_format((float) ($chartPoint['x'] ?? 0.0), 2, '.', '')) ?>" cy="<?= e(number_format((float) ($chartPoint['y'] ?? 0.0), 2, '.', '')) ?>" r="5"></circle>
                            <text class="indicator-detail__chart-label" x="<?= e(number_format((float) ($chartPoint['x'] ?? 0.0), 2, '.', '')) ?>" y="<?= e((string) ($indicatorChartHeight - 8)) ?>" text-anchor="middle"><?= e((string) ($chartPoint['month_label'] ?? '')) ?></text>
                        <?php endforeach; ?>
                    </svg>

                    <div class="indicator-detail__chart-metrics">
                        <?php foreach ($indicatorChartPoints as $chartPoint): ?>
                            <article class="indicator-detail__chart-card">
                                <span><?= e((string) ($chartPoint['month_label'] ?? '')) ?></span>
                                <strong><?= e(number_format((float) ($chartPoint['percentual'] ?? 0.0), 1, ',', '.')) ?>%</strong>
                                <small><?= e(format_points_readable((float) ($chartPoint['real_points'] ?? 0.0))) ?> / <?= e(format_points_readable((float) ($chartPoint['meta_points'] ?? 0.0))) ?> pts</small>
                            </article>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        </article>

        <article class="indicator-detail__panel indicator-detail__panel--drivers">
            <div class="indicator-detail__panel-head">
                <div>
                    <span class="indicator-detail__panel-eyebrow">Quem puxa</span>
                    <h3 class="indicator-detail__panel-title">3 melhores e 3 piores do recorte</h3>
                    <p class="indicator-detail__panel-copy"><?= e($indicatorDetailDriversTitle !== '' ? $indicatorDetailDriversTitle : $indicatorDetailDriversCopy) ?></p>
                </div>
            </div>

            <div class="indicator-detail__driver-columns">
                <div class="indicator-detail__driver-block">
                    <h4 class="indicator-detail__mini-title">Quem puxa para cima</h4>

                    <?php if ($indicatorDetailTopDrivers === []): ?>
                        <p class="indicator-detail__empty">Sem destaques positivos suficientes neste recorte.</p>
                    <?php else: ?>
                        <div class="indicator-detail__driver-list">
                            <?php foreach ($indicatorDetailTopDrivers as $driverRow): ?>
                                <?php $driverGap = (float) ($driverRow['gap'] ?? 0.0); ?>
                                <article class="indicator-detail__driver-item">
                                    <div class="indicator-detail__driver-copy">
                                        <strong><?= e(prime_label((string) ($driverRow['display_label'] ?? 'Sem referência'))) ?></strong>
                                        <span><?= e(format_int_readable((float) ($driverRow['contracts_total'] ?? 0))) ?> contratos · <?= e(format_int_readable((float) ($driverRow['clients_total'] ?? 0))) ?> clientes</span>
                                    </div>
                                    <div class="indicator-detail__driver-metrics">
                                        <strong><?= e(number_format((float) ($driverRow['percentual'] ?? 0.0), 1, ',', '.')) ?>%</strong>
                                        <small>+<?= e(format_points_readable(abs($driverGap))) ?> pts</small>
                                    </div>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="indicator-detail__driver-block">
                    <h4 class="indicator-detail__mini-title">Quem puxa para baixo</h4>

                    <?php if ($indicatorDetailBottomDrivers === []): ?>
                        <p class="indicator-detail__empty">Sem pressões negativas relevantes neste recorte.</p>
                    <?php else: ?>
                        <div class="indicator-detail__driver-list">
                            <?php foreach ($indicatorDetailBottomDrivers as $driverRow): ?>
                                <?php $driverGap = (float) ($driverRow['gap'] ?? 0.0); ?>
                                <article class="indicator-detail__driver-item is-risk">
                                    <div class="indicator-detail__driver-copy">
                                        <strong><?= e(prime_label((string) ($driverRow['display_label'] ?? 'Sem referência'))) ?></strong>
                                        <span><?= e(format_int_readable((float) ($driverRow['contracts_total'] ?? 0))) ?> contratos · <?= e(format_int_readable((float) ($driverRow['clients_total'] ?? 0))) ?> clientes</span>
                                    </div>
                                    <div class="indicator-detail__driver-metrics">
                                        <strong><?= e(number_format((float) ($driverRow['percentual'] ?? 0.0), 1, ',', '.')) ?>%</strong>
                                        <small>-<?= e(format_points_readable(abs($driverGap))) ?> pts</small>
                                    </div>
                                </article>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </article>
    </div>

    <article class="indicator-detail__panel indicator-detail__panel--channels">
        <div class="indicator-detail__panel-head">
            <div>
                <span class="indicator-detail__panel-eyebrow">Canais</span>
                <h3 class="indicator-detail__panel-title">Melhores canais de venda no período</h3>
                <p class="indicator-detail__panel-copy">Ranking dos canais do indicador clicado dentro do mesmo recorte hierárquico.</p>
            </div>
        </div>

        <?php if ($indicatorDetailChannelRows === []): ?>
            <p class="indicator-detail__empty">Sem canais registrados para o período selecionado.</p>
        <?php else: ?>
            <div class="indicator-detail__channel-list">
                <?php foreach ($indicatorDetailChannelRows as $channelRow): ?>
                    <article class="indicator-detail__channel-item">
                        <div class="indicator-detail__channel-copy">
                            <strong><?= e((string) ($channelRow['label'] ?? 'Sem canal')) ?></strong>
                            <span><?= e(format_int_readable((float) ($channelRow['count'] ?? 0))) ?> eventos · <?= e(format_int_readable((float) ($channelRow['contracts_total'] ?? 0))) ?> contratos</span>
                        </div>
                        <div class="indicator-detail__channel-metrics">
                            <strong><?= e(format_metric_readable((float) ($channelRow['value'] ?? 0.0), $indicatorDetailValueMetricType)) ?></strong>
                            <small><?= e(format_int_readable((float) ($channelRow['clients_total'] ?? 0))) ?> clientes</small>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </article>

    <article class="indicator-detail__panel indicator-detail__panel--transactions">
        <div class="indicator-detail__panel-head">
            <div>
                <span class="indicator-detail__panel-eyebrow">Analítico</span>
                <h3 class="indicator-detail__panel-title">Venda a venda do indicador no período selecionado</h3>
                <p class="indicator-detail__panel-copy">
                    <?= e(sprintf('Foram encontrados %d eventos do indicador dentro do recorte atual.', count($indicatorDetailTransactions))) ?>
                </p>
            </div>
        </div>

        <?php if ($indicatorDetailTransactions === []): ?>
            <p class="indicator-detail__empty">Não há transações detalhadas para o indicador no período selecionado.</p>
        <?php else: ?>
            <div class="indicator-detail__table-wrapper">
                <table class="indicator-detail__table">
                    <thead>
                        <tr>
                            <th scope="col">Data</th>
                            <th scope="col">Contrato</th>
                            <th scope="col">Cliente</th>
                            <th scope="col">Gerente</th>
                            <th scope="col">Canal</th>
                            <th scope="col">Status</th>
                            <th scope="col">Valor</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($indicatorDetailTransactions as $transactionRow): ?>
                            <tr>
                                <td><?= e(format_date_br($transactionRow['data_transacao'] ?? null) ?: 'N/A') ?></td>
                                <td><?= e((string) ($transactionRow['numero_contrato'] ?? '—')) ?></td>
                                <td>
                                    <strong><?= e((string) ($transactionRow['nome_cliente'] ?? 'Cliente não identificado')) ?></strong>
                                    <small><?= e((string) ($transactionRow['cnpj'] ?? '')) ?></small>
                                </td>
                                <td><?= e(prime_label((string) ($transactionRow['nome_gerente'] ?? '—'))) ?></td>
                                <td><?= e((string) ($transactionRow['canal_venda'] ?? '—')) ?></td>
                                <td><?= e((string) ($transactionRow['status_transacao'] ?? '—')) ?></td>
                                <td><?= e(format_metric((float) ($transactionRow['valor_realizado'] ?? 0.0), $indicatorMetricType === 'PERCENTUAL' ? 'QUANTIDADE' : $indicatorMetricType)) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </article>
        </section>
    </div>
</section>