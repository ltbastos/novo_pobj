<?php

declare(strict_types=1);

namespace App\Services;

use PDO;
use Throwable;

final class OmegaDashboardService
{
    private const CALLS_TABLE_NAME = 'fomegachamado';
    private const COMMENT_TABLE_NAME = 'fomegachamadocomentario';
    private const MOVEMENT_TABLE_NAME = 'fomegachamadomovimentacao';
    private const STATUS_TABLE_NAME = 'domegastatuschamado';
    private const TIMES_TABLE_NAME = 'domegatimes';
    private const CATEGORY_TABLE_NAME = 'domegacategorias';
    private const ANALYST_TEAM_TABLE_NAME = 'fomegaanalistatime';
    private const FOCAL_TEAM_TABLE_NAME = 'fomegafocaltime';
    private const HIERARCHY_TABLE_NAME = 'dHierarquia';
    private const UI_ORIGIN = 'novo_pobj_ui';

    private const VIEW_DEFINITIONS = [
        'my-calls' => 'Meus chamados',
        'my-work' => 'Meus atendimentos',
        'team-queue' => 'Fila da equipe',
    ];

    private const DEPARTMENT_TYPE_DEFAULTS = [
        'POBJ' => ['Contestar Realizado', 'Outros'],
        'Metas' => ['Contestar Meta', 'Redistribuir Meta'],
    ];

    /** @var PDO */
    private $connection;

    /** @var array<string, bool> */
    private $tableAvailability = [];

    /** @var array<string, array<string, bool>> */
    private $columnAvailability = [];

    public function __construct(PDO $connection)
    {
        $this->connection = $connection;
    }

    private function resolveContextAccess(array $context): array
    {
        $functional = trim((string) (($context['profile'] ?? [])['funcional'] ?? ''));
        $analystTeamIds = $this->resolveMappedTeamIds($functional, 'analyst');
        $managerTeamIds = $this->resolveMappedTeamIds($functional, 'manager');
        $accessibleTeamIds = array_values(array_unique(array_merge($analystTeamIds, $managerTeamIds)));
        sort($accessibleTeamIds);

        return [
            'functional' => $functional,
            'analyst_team_ids' => $analystTeamIds,
            'manager_team_ids' => $managerTeamIds,
            'accessible_team_ids' => $accessibleTeamIds,
            'is_analyst' => $analystTeamIds !== [],
            'is_manager' => $managerTeamIds !== [],
            'can_manage_team' => $managerTeamIds !== [],
            'can_access_dashboard' => $accessibleTeamIds !== [],
            'can_view_priority' => $accessibleTeamIds !== [],
        ];
    }

    public function getDashboardData(array $context, array $requestedFilters = []): array
    {
        $this->ensureCallSchema();

        $access = $this->resolveContextAccess($context);
        $functional = $access['functional'];
        $analystTeamIds = $access['analyst_team_ids'];
        $managerTeamIds = $access['manager_team_ids'];
        $accessibleTeamIds = $access['accessible_team_ids'];
        $isAnalyst = $access['is_analyst'];
        $isManager = $access['is_manager'];
        $canManageTeam = $access['can_manage_team'];
        $canAccessDashboard = $access['can_access_dashboard'];
        $canViewPriority = $access['can_view_priority'];
        $availableViews = ['my-calls' => self::VIEW_DEFINITIONS['my-calls']];

        if ($isAnalyst) {
            $availableViews['my-work'] = self::VIEW_DEFINITIONS['my-work'];
        }

        if ($accessibleTeamIds !== []) {
            $availableViews['team-queue'] = self::VIEW_DEFINITIONS['team-queue'];
        }

        $requestedView = trim((string) ($requestedFilters['view'] ?? 'my-calls'));
        $view = isset($availableViews[$requestedView]) ? $requestedView : 'my-calls';
        $filters = [
            'search' => trim((string) ($requestedFilters['search'] ?? '')),
            'call_id' => trim((string) ($requestedFilters['call_id'] ?? '')),
            'requester' => trim((string) ($requestedFilters['requester'] ?? '')),
            'department' => trim((string) ($requestedFilters['department'] ?? '')),
            'type' => trim((string) ($requestedFilters['type'] ?? '')),
            'priority' => trim((string) ($requestedFilters['priority'] ?? '')),
            'status' => trim((string) ($requestedFilters['status'] ?? '')),
            'opened_from' => trim((string) ($requestedFilters['opened_from'] ?? '')),
            'opened_to' => trim((string) ($requestedFilters['opened_to'] ?? '')),
            'page' => max(1, (int) ($requestedFilters['page'] ?? 1)),
        ];

        if (!$canViewPriority) {
            $filters['priority'] = '';
        }

        $perPage = 8;

        $statusOptions = $this->listStatusOptions();
        $statusCodes = $this->normalizeStatusFilter($filters['status']);
        $counts = $this->fetchViewCounts($functional, $analystTeamIds, $accessibleTeamIds);
        $sourceRows = $this->fetchSourceRows($functional, $analystTeamIds, $accessibleTeamIds, $view);

        $sourceRows = $this->sortRowsByRecency($this->attachCommentThreads($this->attachMovementThreads($sourceRows)));

        $filteredRows = $this->filterRows($sourceRows, $filters, $statusCodes);
        $table = $this->paginateRows($filteredRows, (int) ($filters['page'] ?? 1), $perPage);

        return [
            'views' => array_map(static function (string $id, string $label) use ($counts): array {
                return [
                    'id' => $id,
                    'label' => $label,
                    'count' => (int) ($counts[$id] ?? 0),
                ];
            }, array_keys($availableViews), array_values($availableViews)),
            'active_view' => $view,
            'permissions' => [
                'is_analyst' => $isAnalyst,
                'is_manager' => $isManager,
                'can_manage_team' => $canManageTeam,
                'can_access_dashboard' => $canAccessDashboard,
                'can_view_priority' => $canViewPriority,
            ],
            'filters' => [
                'search' => $filters['search'],
                'call_id' => $filters['call_id'],
                'requester' => $filters['requester'],
                'department' => $filters['department'],
                'type' => $filters['type'],
                'priority' => $filters['priority'],
                'status' => implode(',', $statusCodes),
                'opened_from' => $filters['opened_from'],
                'opened_to' => $filters['opened_to'],
                'page' => $table['current_page'],
            ],
            'status_options' => $statusOptions,
            'facet_options' => $this->buildFacetOptions($sourceRows),
            'editor_options' => $this->buildEditorOptions($accessibleTeamIds),
            'analytics' => $this->buildAnalytics($filteredRows),
            'table' => $table,
        ];
    }

    public function getTeamManagementData(array $context, string $requestedTeamCode = ''): array
    {
        $functional = trim((string) (($context['profile'] ?? [])['funcional'] ?? ''));
        $managerTeamIds = $this->resolveMappedTeamIds($functional, 'manager');

        if ($managerTeamIds === []) {
            return [
                'teams' => [],
                'selected_team' => [],
                'managers' => [],
                'analysts' => [],
                'candidate_analysts' => [],
            ];
        }

        $teams = $this->fetchTeamsByIds($managerTeamIds);

        if ($teams === []) {
            return [
                'teams' => [],
                'selected_team' => [],
                'managers' => [],
                'analysts' => [],
                'candidate_analysts' => [],
            ];
        }

        $selectedTeam = $teams[0];
        $requestedTeamCode = strtoupper(trim($requestedTeamCode));

        foreach ($teams as $team) {
            if (strtoupper((string) ($team['code'] ?? '')) !== $requestedTeamCode) {
                continue;
            }

            $selectedTeam = $team;
            break;
        }

        $selectedTeamId = (int) ($selectedTeam['id'] ?? 0);

        return [
            'teams' => $teams,
            'selected_team' => $selectedTeam,
            'managers' => $this->fetchTeamManagers($selectedTeamId),
            'analysts' => $this->fetchTeamAnalysts($selectedTeamId),
            'candidate_analysts' => $this->fetchAssignableAnalystCandidates($selectedTeamId),
        ];
    }

    public function setTeamAnalystMembership(array $context, string $teamCode, string $analystFunctional, bool $active): bool
    {
        $managerFunctional = trim((string) (($context['profile'] ?? [])['funcional'] ?? ''));
        $analystFunctional = substr(trim($analystFunctional), 0, 7);
        $teamCode = strtoupper(trim($teamCode));

        if ($managerFunctional === '' || $analystFunctional === '' || $teamCode === '' || !$this->hasTable(self::ANALYST_TEAM_TABLE_NAME)) {
            return false;
        }

        $managerTeamIds = $this->resolveMappedTeamIds($managerFunctional, 'manager');
        $team = $this->findTeamByCode($teamCode);
        $teamId = (int) ($team['id'] ?? 0);

        if ($teamId <= 0 || !in_array($teamId, $managerTeamIds, true) || !$this->isAssignableAnalystFunctional($analystFunctional)) {
            return false;
        }

        $selectStatement = $this->connection->prepare(
            'SELECT id_omega_analista_time
               FROM `' . self::ANALYST_TEAM_TABLE_NAME . '` 
              WHERE id_omega_time = :team_id
                AND funcional_analista = :functional
              LIMIT 1'
        );
        $selectStatement->execute([
            'team_id' => $teamId,
            'functional' => $analystFunctional,
        ]);
        $mappingId = (int) $selectStatement->fetchColumn();

        if ($mappingId > 0) {
            $updateStatement = $this->connection->prepare(
                'UPDATE `' . self::ANALYST_TEAM_TABLE_NAME . '` 
                    SET ativo_sn = :active_flag,
                        origem_carga = :origin,
                        dt_atualizacao = CURRENT_TIMESTAMP
                  WHERE id_omega_analista_time = :mapping_id'
            );

            return $updateStatement->execute([
                'active_flag' => $active ? 1 : 0,
                'origin' => self::UI_ORIGIN,
                'mapping_id' => $mappingId,
            ]);
        }

        if (!$active) {
            return true;
        }

        $insertStatement = $this->connection->prepare(
            'INSERT INTO `' . self::ANALYST_TEAM_TABLE_NAME . '` (
                id_omega_time,
                funcional_analista,
                ativo_sn,
                origem_carga
            ) VALUES (
                :team_id,
                :functional,
                1,
                :origin
            )'
        );

        return $insertStatement->execute([
            'team_id' => $teamId,
            'functional' => $analystFunctional,
            'origin' => self::UI_ORIGIN,
        ]);
    }

    public function addComment(array $context, int $callId, string $authorRole, string $comment): array
    {
        $access = $this->resolveContextAccess($context);
        $callId = max(0, $callId);
        $functionalAuthor = substr(trim((string) ($access['functional'] ?? '')), 0, 7);
        $comment = trim($comment);

        if ($callId <= 0 || $comment === '') {
            return [
                'ok' => false,
                'message' => 'Informe o comentário antes de enviar.',
            ];
        }

        if ($functionalAuthor === '') {
            return [
                'ok' => false,
                'message' => 'Selecione um perfil válido antes de comentar.',
            ];
        }

        $existingCall = $this->fetchRawCallById($callId);

        if ($existingCall === []) {
            return [
                'ok' => false,
                'message' => 'O chamado selecionado não foi encontrado.',
            ];
        }

        $requesterFunctional = substr(trim((string) ($existingCall['solicitante_funcional'] ?? '')), 0, 7);
        $statusCode = strtoupper(trim((string) ($existingCall['codigo_status'] ?? 'SEM_STATUS')));
        $isOperational = (bool) ($access['can_access_dashboard'] ?? false);
        $requestedAnalystRole = strtoupper(trim($authorRole)) === 'ANALYST' && $isOperational;
        $normalizedAuthorRole = $requestedAnalystRole ? 'ANALISTA' : 'SOLICITANTE';

        if (!$isOperational && $requesterFunctional !== '' && $requesterFunctional !== $functionalAuthor) {
            return [
                'ok' => false,
                'message' => 'Você não pode interagir com este chamado.',
            ];
        }

        if ($normalizedAuthorRole === 'SOLICITANTE' && $this->isTerminalStatus($statusCode)) {
            return [
                'ok' => false,
                'message' => 'Este chamado já foi finalizado. Abra um novo chamado para continuar.',
            ];
        }

        $this->ensureCommentTable();

        if (!$this->hasTable(self::COMMENT_TABLE_NAME)) {
            return [
                'ok' => false,
                'message' => 'A estrutura de comentários do Omega não está disponível.',
            ];
        }

        $timestamp = date('Y-m-d H:i:s');
        $commentAuthorFunctional = $normalizedAuthorRole === 'ANALISTA'
            ? $functionalAuthor
            : ($requesterFunctional !== '' ? $requesterFunctional : $functionalAuthor);

        $insertStatement = $this->connection->prepare(
            'INSERT INTO `' . self::COMMENT_TABLE_NAME . '` (
                id_omega_chamado,
                funcional_autor,
                tipo_autor,
                comentario,
                dt_comentario,
                ativo_sn,
                origem_carga
            ) VALUES (
                :call_id,
                :functional_author,
                :author_role,
                :comment_text,
                :commented_at,
                1,
                :origin
            )'
        );

        $insertStatement->execute([
            'call_id' => $callId,
            'functional_author' => $commentAuthorFunctional,
            'author_role' => $normalizedAuthorRole,
            'comment_text' => $comment,
            'commented_at' => $timestamp,
            'origin' => self::UI_ORIGIN,
        ]);

        if ($this->hasTable(self::CALLS_TABLE_NAME)) {
            $updateSql = 'UPDATE `' . self::CALLS_TABLE_NAME . '`
                SET dt_ultimo_evento = :commented_at,
                    dt_atualizacao = CURRENT_TIMESTAMP';
            $updateParams = [
                'commented_at' => $timestamp,
                'call_id' => $callId,
            ];

            if ($normalizedAuthorRole === 'ANALISTA' && $functionalAuthor !== '') {
                $updateSql .= ', funcional_analista_atual = :functional_author';
                $updateParams['functional_author'] = $functionalAuthor;
            }

            $updateSql .= ' WHERE id_omega_chamado = :call_id';
            $updateStatement = $this->connection->prepare($updateSql);
            $updateStatement->execute($updateParams);
        }

        return [
            'ok' => true,
            'comment' => [
                'role' => $normalizedAuthorRole === 'ANALISTA' ? 'analyst' : 'user',
                'timestamp' => $timestamp,
                'message' => $comment,
                'functional_author' => $commentAuthorFunctional,
            ],
        ];
    }

    public function saveCall(array $context, array $payload): array
    {
        $this->ensureCallSchema();

        if (!$this->hasTable(self::CALLS_TABLE_NAME)) {
            return [
                'ok' => false,
                'message' => 'A estrutura principal do Omega não está disponível.',
            ];
        }

        $access = $this->resolveContextAccess($context);
        $profile = (array) ($context['profile'] ?? []);
        $junctions = array_values((array) ($context['junctions'] ?? []));
        $currentFunctional = substr(trim((string) ($access['functional'] ?? ($profile['funcional'] ?? ''))), 0, 7);
        $currentName = trim((string) ($profile['nome'] ?? 'Usuário'));
        $currentLevel = substr(trim((string) ($profile['nivel'] ?? 'GC')), 0, 2);
        $currentView = trim((string) ($payload['current_view'] ?? 'my-calls'));
        $callId = max(0, (int) ($payload['call_id'] ?? 0));
        $title = substr(trim((string) ($payload['title'] ?? '')), 0, 200);
        $description = trim((string) ($payload['description'] ?? ''));
        $departmentLabel = $this->normalizeDepartmentLabel((string) ($payload['department'] ?? 'POBJ'));
        $requestedTypeLabel = (string) ($payload['type'] ?? '');
        $requestedQueue = trim((string) ($payload['queue'] ?? ''));
        $requestedPriorityLabel = trim((string) ($payload['priority'] ?? ''));
        $requestedAnalystFunctional = trim((string) ($payload['analyst_functional'] ?? ''));
        $statusCode = strtoupper(trim((string) ($payload['status_code'] ?? 'ABERTO')));
        $isOperational = (bool) ($access['can_access_dashboard'] ?? false);

        if ($currentFunctional === '' || $title === '' || $description === '') {
            return [
                'ok' => false,
                'message' => 'Preencha título e descrição antes de salvar.',
            ];
        }

        $existingCall = $callId > 0 ? $this->fetchRawCallById($callId) : [];

        if ($existingCall !== [] && !$isOperational) {
            $existingRequesterFunctional = substr(trim((string) ($existingCall['solicitante_funcional'] ?? '')), 0, 7);

            if ($existingRequesterFunctional !== '' && $existingRequesterFunctional !== $currentFunctional) {
                return [
                    'ok' => false,
                    'message' => 'Você não pode editar este chamado.',
                ];
            }

            if ($this->isTerminalStatus((string) ($existingCall['codigo_status'] ?? 'SEM_STATUS'))) {
                return [
                    'ok' => false,
                    'message' => 'Este chamado já foi finalizado. Abra um novo chamado para continuar.',
                ];
            }
        }

        if ($existingCall !== [] && !$isOperational) {
            $departmentLabel = $this->normalizeDepartmentLabel((string) ($existingCall['solicitante_segmento'] ?? 'POBJ'));
            $requestedTypeLabel = trim((string) ($existingCall['nome_categoria'] ?? $requestedTypeLabel));
            $requestedQueue = trim((string) ($existingCall['codigo_time'] ?? $existingCall['nome_time'] ?? $requestedQueue));
            $statusCode = strtoupper(trim((string) ($existingCall['codigo_status'] ?? $statusCode)));
            $requestedPriorityLabel = trim((string) ($existingCall['priority_label'] ?? ''));
            $requestedAnalystFunctional = trim((string) ($existingCall['funcional_analista_atual'] ?? ''));
        }

        if (!$isOperational && $existingCall === []) {
            $statusCode = 'ABERTO';
            $requestedPriorityLabel = '';
            $requestedAnalystFunctional = '';
            $requestedQueue = $departmentLabel;
        }

        $statusRecord = $this->resolveStatusRecord($statusCode);

        if ($statusRecord === []) {
            return [
                'ok' => false,
                'message' => 'Selecione um status válido para o chamado.',
            ];
        }

        $selectedTeam = $this->resolveRequestedTeam($requestedQueue, $departmentLabel);

        if ($selectedTeam !== []) {
            $departmentLabel = $this->normalizeDepartmentLabel((string) ($selectedTeam['label'] ?? $departmentLabel));
        }

        $typeLabel = $this->normalizeDepartmentType($departmentLabel, $requestedTypeLabel);
        $junctionMap = $existingCall !== []
            ? [
                'ag' => substr(trim((string) ($existingCall['solicitante_juncao_ag'] ?? '')), 0, 4),
                'gr' => substr(trim((string) ($existingCall['solicitante_juncao_gr'] ?? '')), 0, 4),
                'dr' => substr(trim((string) ($existingCall['solicitante_juncao_dr'] ?? '')), 0, 4),
            ]
            : $this->resolveJunctionMap($junctions);
        $requesterFunctional = $existingCall !== []
            ? substr(trim((string) ($existingCall['solicitante_funcional'] ?? $currentFunctional)), 0, 7)
            : $currentFunctional;
        $requesterName = $existingCall !== []
            ? trim((string) ($existingCall['solicitante_nome'] ?? $currentName))
            : $currentName;
        $requesterLevel = $existingCall !== []
            ? substr(trim((string) ($existingCall['solicitante_nivel'] ?? $currentLevel)), 0, 2)
            : $currentLevel;
        $teamName = trim((string) ($selectedTeam['label'] ?? $selectedTeam['name'] ?? ''));

        if ($teamName === '') {
            $teamName = trim((string) ($existingCall['nome_time'] ?? $departmentLabel));
        }

        $teamId = (int) ($selectedTeam['id'] ?? 0);

        if ($teamId <= 0) {
            $teamId = $this->ensureTeam($teamName !== '' ? $teamName : $departmentLabel);
        }

        if ($teamId <= 0) {
            return [
                'ok' => false,
                'message' => 'Não foi possível localizar a fila selecionada.',
            ];
        }

        $categoryName = $typeLabel !== ''
            ? $typeLabel
            : trim((string) ($existingCall['nome_categoria'] ?? 'Atendimento'));
        $categoryId = $this->ensureCategory($teamId, $categoryName);
        $priorityLabel = $this->normalizePriorityLabel(
            $requestedPriorityLabel !== ''
                ? $requestedPriorityLabel
                : ($existingCall['priority_label'] ?? $this->inferPriorityLabel($statusCode))
        );
        $analystResolution = $this->resolveAnalystFunctionalForSave(
            $existingCall,
            $access,
            $requesterFunctional,
            $currentView,
            $statusCode,
            $requestedAnalystFunctional,
            $teamId
        );

        if (!(bool) ($analystResolution['ok'] ?? false)) {
            return [
                'ok' => false,
                'message' => (string) ($analystResolution['message'] ?? 'Não foi possível validar o analista selecionado.'),
            ];
        }

        $analystFunctional = substr(trim((string) ($analystResolution['functional'] ?? '')), 0, 7);
        $timestamp = date('Y-m-d H:i:s');
        $closedAt = $this->isTerminalStatus($statusCode)
            ? ($existingCall !== [] && trim((string) ($existingCall['dt_fechamento'] ?? '')) !== ''
                ? trim((string) ($existingCall['dt_fechamento'] ?? ''))
                : $timestamp)
            : null;
        $resolutionFinal = $this->isTerminalStatus($statusCode)
            ? substr($description, 0, 1000)
            : null;

        $this->ensureMovementTable();

        $this->connection->beginTransaction();

        try {
            if ($existingCall !== []) {
                $updateStatement = $this->connection->prepare(
                    'UPDATE `' . self::CALLS_TABLE_NAME . '`
                        SET solicitante_nome = :requester_name,
                            solicitante_nivel = :requester_level,
                            solicitante_juncao_ag = :junction_ag,
                            solicitante_juncao_gr = :junction_gr,
                            solicitante_juncao_dr = :junction_dr,
                            solicitante_segmento = :segment_label,
                            id_omega_time_atual = :team_id,
                            id_omega_categoria_atual = :category_id,
                            id_omega_status_atual = :status_id,
                            funcional_analista_atual = :analyst_functional,
                            prioridade_label = :priority_label,
                            titulo = :title,
                            descricao_abertura = :description,
                            dt_ultimo_evento = :updated_at,
                            dt_fechamento = :closed_at,
                            resolucao_final = :resolution_final,
                            ativo_sn = 1,
                            origem_carga = :origin,
                            dt_atualizacao = CURRENT_TIMESTAMP
                      WHERE id_omega_chamado = :call_id'
                );
                $updateStatement->execute([
                    'requester_name' => $requesterName,
                    'requester_level' => $requesterLevel !== '' ? $requesterLevel : 'GC',
                    'junction_ag' => $junctionMap['ag'] !== '' ? $junctionMap['ag'] : null,
                    'junction_gr' => $junctionMap['gr'] !== '' ? $junctionMap['gr'] : null,
                    'junction_dr' => $junctionMap['dr'] !== '' ? $junctionMap['dr'] : null,
                    'segment_label' => $departmentLabel !== '' ? $departmentLabel : 'POBJ',
                    'team_id' => $teamId,
                    'category_id' => $categoryId,
                    'status_id' => (int) ($statusRecord['id'] ?? 0),
                    'analyst_functional' => $analystFunctional !== '' ? $analystFunctional : null,
                    'priority_label' => $priorityLabel,
                    'title' => $title,
                    'description' => $description,
                    'updated_at' => $timestamp,
                    'closed_at' => $closedAt,
                    'resolution_final' => $resolutionFinal,
                    'origin' => self::UI_ORIGIN,
                    'call_id' => $callId,
                ]);

                $this->insertMovement([
                    'call_id' => $callId,
                    'movement_type' => $this->isTerminalStatus($statusCode) ? 'FECHAMENTO' : 'ATUALIZACAO',
                    'responsible_functional' => $currentFunctional,
                    'status_origin_id' => isset($existingCall['id_omega_status_atual']) ? (int) $existingCall['id_omega_status_atual'] : null,
                    'status_destination_id' => (int) ($statusRecord['id'] ?? 0),
                    'time_origin_id' => isset($existingCall['id_omega_time_atual']) ? (int) $existingCall['id_omega_time_atual'] : null,
                    'time_destination_id' => $teamId,
                    'category_origin_id' => isset($existingCall['id_omega_categoria_atual']) ? (int) $existingCall['id_omega_categoria_atual'] : null,
                    'category_destination_id' => $categoryId,
                    'analyst_origin' => substr(trim((string) ($existingCall['funcional_analista_atual'] ?? '')), 0, 7) ?: null,
                    'analyst_destination' => $analystFunctional !== '' ? $analystFunctional : null,
                    'observation' => $this->isTerminalStatus($statusCode)
                        ? 'Finalização registrada via painel Omega.'
                        : 'Atualização registrada via painel Omega.',
                    'moved_at' => $timestamp,
                ]);
            } else {
                $insertStatement = $this->connection->prepare(
                    'INSERT INTO `' . self::CALLS_TABLE_NAME . '` (
                        solicitante_funcional,
                        solicitante_nome,
                        solicitante_nivel,
                        solicitante_juncao_ag,
                        solicitante_juncao_gr,
                        solicitante_juncao_dr,
                        solicitante_segmento,
                        id_omega_time_abertura,
                        id_omega_categoria_abertura,
                        id_omega_time_atual,
                        id_omega_categoria_atual,
                        id_omega_status_atual,
                        funcional_analista_atual,
                        prioridade_label,
                        titulo,
                        descricao_abertura,
                        dt_abertura,
                        dt_ultimo_evento,
                        dt_fechamento,
                        resolucao_final,
                        ativo_sn,
                        origem_carga
                    ) VALUES (
                        :requester_functional,
                        :requester_name,
                        :requester_level,
                        :junction_ag,
                        :junction_gr,
                        :junction_dr,
                        :segment_label,
                        :team_id,
                        :category_id,
                        :team_id_current,
                        :category_id_current,
                        :status_id,
                        :analyst_functional,
                        :priority_label,
                        :title,
                        :description,
                        :opened_at,
                        :updated_at,
                        :closed_at,
                        :resolution_final,
                        1,
                        :origin
                    )'
                );
                $insertStatement->execute([
                    'requester_functional' => $requesterFunctional,
                    'requester_name' => $requesterName,
                    'requester_level' => $requesterLevel !== '' ? $requesterLevel : 'GC',
                    'junction_ag' => $junctionMap['ag'] !== '' ? $junctionMap['ag'] : null,
                    'junction_gr' => $junctionMap['gr'] !== '' ? $junctionMap['gr'] : null,
                    'junction_dr' => $junctionMap['dr'] !== '' ? $junctionMap['dr'] : null,
                    'segment_label' => $departmentLabel !== '' ? $departmentLabel : 'POBJ',
                    'team_id' => $teamId,
                    'category_id' => $categoryId,
                    'team_id_current' => $teamId,
                    'category_id_current' => $categoryId,
                    'status_id' => (int) ($statusRecord['id'] ?? 0),
                    'analyst_functional' => $analystFunctional !== '' ? $analystFunctional : null,
                    'priority_label' => $priorityLabel,
                    'title' => $title,
                    'description' => $description,
                    'opened_at' => $timestamp,
                    'updated_at' => $timestamp,
                    'closed_at' => $closedAt,
                    'resolution_final' => $resolutionFinal,
                    'origin' => self::UI_ORIGIN,
                ]);
                $callId = (int) $this->connection->lastInsertId();

                $this->insertMovement([
                    'call_id' => $callId,
                    'movement_type' => 'ABERTURA',
                    'responsible_functional' => $currentFunctional,
                    'status_origin_id' => null,
                    'status_destination_id' => (int) ($statusRecord['id'] ?? 0),
                    'time_origin_id' => null,
                    'time_destination_id' => $teamId,
                    'category_origin_id' => null,
                    'category_destination_id' => $categoryId,
                    'analyst_origin' => null,
                    'analyst_destination' => $analystFunctional !== '' ? $analystFunctional : null,
                    'observation' => 'Chamado registrado via painel Omega.',
                    'moved_at' => $timestamp,
                ]);
            }

            if ($analystFunctional !== '') {
                $this->ensureFunctionalMappedToTeam($analystFunctional, $teamId, 'analyst');
            }

            $this->connection->commit();
        } catch (Throwable $exception) {
            if ($this->connection->inTransaction()) {
                $this->connection->rollBack();
            }

            return [
                'ok' => false,
                'message' => 'Não foi possível salvar o chamado no banco de dados.',
            ];
        }

        return [
            'ok' => true,
            'record' => $this->findCallById($callId),
        ];
    }

    public function findCallById(int $callId): array
    {
        $this->ensureCallSchema();

        $rawRow = $this->fetchRawCallById(max(0, $callId));

        if ($rawRow === []) {
            return [];
        }

        $rows = [$this->normalizeRow($rawRow)];
        $rows = $this->attachMovementThreads($rows);
        $rows = $this->attachCommentThreads($rows);

        return $rows[0] ?? [];
    }

    private function fetchSourceRows(string $functional, array $analystTeamIds, array $accessibleTeamIds, string $view): array
    {
        if ($functional === '' || !$this->hasTable(self::CALLS_TABLE_NAME)) {
            return [];
        }

        $where = ['c.ativo_sn = 1'];
        $params = [];

        switch ($view) {
            case 'my-work':
                if ($analystTeamIds === []) {
                    return [];
                }

                $placeholders = [];

                foreach ($analystTeamIds as $index => $teamId) {
                    $placeholder = 'analyst_team_' . $index;
                    $placeholders[] = ':' . $placeholder;
                    $params[$placeholder] = $teamId;
                }

                $where[] = 'c.funcional_analista_atual = :functional';
                $where[] = 'c.id_omega_time_atual IN (' . implode(', ', $placeholders) . ')';
                $params['functional'] = $functional;
                break;

            case 'team-queue':
                if ($accessibleTeamIds === []) {
                    return [];
                }

                $placeholders = [];

                foreach ($accessibleTeamIds as $index => $teamId) {
                    $placeholder = 'team_' . $index;
                    $placeholders[] = ':' . $placeholder;
                    $params[$placeholder] = $teamId;
                }

                $where[] = 'c.id_omega_time_atual IN (' . implode(', ', $placeholders) . ')';
                break;

            case 'my-calls':
            default:
                $where[] = 'c.solicitante_funcional = :functional';
                $params['functional'] = $functional;
                break;
        }

        $sql = 'SELECT
                    c.id_omega_chamado,
                    c.titulo,
                    c.descricao_abertura,
                    c.solicitante_nome,
                    c.solicitante_funcional,
                    c.solicitante_segmento,
                    c.funcional_analista_atual,
                    c.dt_abertura,
                    c.dt_ultimo_evento,
                    c.dt_fechamento,
                    c.resolucao_final,
                    COALESCE(c.prioridade_label, "") AS priority_label,
                    COALESCE(t.codigo_time, "") AS codigo_time,
                    COALESCE(t.nome_time, "") AS nome_time,
                    COALESCE(cat.nome_categoria, "") AS nome_categoria,
                    COALESCE(ah.nome, "") AS analyst_name,
                    COALESCE(s.nome_status, "Sem status") AS nome_status,
                    COALESCE(s.codigo_status, "SEM_STATUS") AS codigo_status,
                    COALESCE(s.cor_hex, "#cbd5e1") AS cor_hex
                ' . $this->buildCallsFromSql() . '
                WHERE ' . implode(' AND ', $where) . '
                ORDER BY COALESCE(c.dt_ultimo_evento, c.dt_abertura) DESC, c.id_omega_chamado DESC';

        $statement = $this->connection->prepare($sql);

        foreach ($params as $paramKey => $paramValue) {
            if (is_int($paramValue)) {
                $statement->bindValue(':' . $paramKey, $paramValue, PDO::PARAM_INT);
                continue;
            }

            $statement->bindValue(':' . $paramKey, $paramValue);
        }

        $statement->execute();

        $rows = [];

        foreach ($statement->fetchAll() as $row) {
            $rows[] = $this->normalizeRow($row);
        }

        return $rows;
    }

    private function fetchViewCounts(string $functional, array $analystTeamIds, array $accessibleTeamIds): array
    {
        $counts = [
            'my-calls' => 0,
            'my-work' => 0,
            'team-queue' => 0,
        ];

        if ($functional === '' || !$this->hasTable(self::CALLS_TABLE_NAME)) {
            return $counts;
        }

        $counts['my-calls'] = $this->fetchSingleCount(
            'SELECT COUNT(*) FROM `' . self::CALLS_TABLE_NAME . '` WHERE ativo_sn = 1 AND solicitante_funcional = :functional',
            ['functional' => $functional]
        );

        if ($analystTeamIds !== []) {
            $placeholders = [];
            $params = ['functional' => $functional];

            foreach ($analystTeamIds as $index => $teamId) {
                $placeholder = 'analyst_team_' . $index;
                $placeholders[] = ':' . $placeholder;
                $params[$placeholder] = $teamId;
            }

            $counts['my-work'] = $this->fetchSingleCount(
                'SELECT COUNT(*) FROM `' . self::CALLS_TABLE_NAME . '` WHERE ativo_sn = 1 AND funcional_analista_atual = :functional AND id_omega_time_atual IN (' . implode(', ', $placeholders) . ')',
                $params
            );
        }

        if ($accessibleTeamIds !== []) {
            $placeholders = [];
            $params = [];

            foreach ($accessibleTeamIds as $index => $teamId) {
                $placeholder = 'team_' . $index;
                $placeholders[] = ':' . $placeholder;
                $params[$placeholder] = $teamId;
            }

            $counts['team-queue'] = $this->fetchSingleCount(
                'SELECT COUNT(*) FROM `' . self::CALLS_TABLE_NAME . '` WHERE ativo_sn = 1 AND id_omega_time_atual IN (' . implode(', ', $placeholders) . ')',
                $params
            );
        }

        return $counts;
    }

    private function fetchSingleCount(string $sql, array $params): int
    {
        $statement = $this->connection->prepare($sql);

        foreach ($params as $key => $value) {
            if (is_int($value)) {
                $statement->bindValue(':' . $key, $value, PDO::PARAM_INT);
                continue;
            }

            $statement->bindValue(':' . $key, $value);
        }

        $statement->execute();

        return (int) $statement->fetchColumn();
    }

    private function buildCallsFromSql(): string
    {
        $statusJoin = $this->hasTable(self::STATUS_TABLE_NAME)
            ? 'LEFT JOIN `' . self::STATUS_TABLE_NAME . '` s ON s.id_omega_status = c.id_omega_status_atual'
            : 'LEFT JOIN (SELECT NULL AS id_omega_status, NULL AS codigo_status, NULL AS nome_status, NULL AS cor_hex) s ON 1 = 0';
        $timeJoin = $this->hasTable(self::TIMES_TABLE_NAME)
            ? 'LEFT JOIN `' . self::TIMES_TABLE_NAME . '` t ON t.id_omega_time = c.id_omega_time_atual'
            : 'LEFT JOIN (SELECT NULL AS id_omega_time, NULL AS nome_time) t ON 1 = 0';
        $categoryJoin = $this->hasTable(self::CATEGORY_TABLE_NAME)
            ? 'LEFT JOIN `' . self::CATEGORY_TABLE_NAME . '` cat ON cat.id_omega_categoria = c.id_omega_categoria_atual'
            : 'LEFT JOIN (SELECT NULL AS id_omega_categoria, NULL AS nome_categoria) cat ON 1 = 0';
        $analystJoin = $this->hasTable(self::HIERARCHY_TABLE_NAME)
            ? 'LEFT JOIN `' . self::HIERARCHY_TABLE_NAME . '` ah ON ah.funcional = c.funcional_analista_atual AND ah.ativo_sn = 1'
            : 'LEFT JOIN (SELECT NULL AS funcional, NULL AS nome, NULL AS ativo_sn) ah ON 1 = 0';

        return ' FROM `' . self::CALLS_TABLE_NAME . '` c ' . $statusJoin . ' ' . $timeJoin . ' ' . $categoryJoin . ' ' . $analystJoin;
    }

    private function listStatusOptions(): array
    {
        if (!$this->hasTable(self::STATUS_TABLE_NAME)) {
            return $this->defaultStatusOptions();
        }

        $sql = 'SELECT codigo_status, nome_status, cor_hex
                FROM `' . self::STATUS_TABLE_NAME . '` 
                WHERE ativo_sn = 1
                ORDER BY ordem_fluxo, nome_status';
        $rows = $this->connection->query($sql)->fetchAll();

        if ($rows === []) {
            return $this->defaultStatusOptions();
        }

        $options = [];

        foreach ($rows as $row) {
            $value = trim((string) ($row['codigo_status'] ?? ''));
            $label = trim((string) ($row['nome_status'] ?? ''));

            if ($value === '' || $label === '') {
                continue;
            }

            $options[] = [
                'value' => $value,
                'label' => $label,
                'color' => trim((string) ($row['cor_hex'] ?? '#cbd5e1')),
            ];
        }

        return $options !== [] ? $options : $this->defaultStatusOptions();
    }

    private function defaultStatusOptions(): array
    {
        return [
            ['value' => 'ABERTO', 'label' => 'Aberto', 'color' => '#6CC7BE'],
            ['value' => 'AGUARDANDO', 'label' => 'Aguardando', 'color' => '#7BB9F0'],
            ['value' => 'EM_ATENDIMENTO', 'label' => 'Em atendimento', 'color' => '#9ED8A1'],
            ['value' => 'REJEITADO', 'label' => 'Rejeitado', 'color' => '#F28B82'],
            ['value' => 'FECHADO', 'label' => 'Fechado', 'color' => '#CBD5E1'],
        ];
    }

    private function resolveTeamIds(string $functional): array
    {
        return array_values(array_unique(array_merge(
            $this->resolveMappedTeamIds($functional, 'analyst'),
            $this->resolveMappedTeamIds($functional, 'manager')
        )));
    }

    private function resolveMappedTeamIds(string $functional, string $role): array
    {
        if ($functional === '') {
            return [];
        }

        $tableName = $role === 'analyst' ? self::ANALYST_TEAM_TABLE_NAME : self::FOCAL_TEAM_TABLE_NAME;
        $functionalColumn = $role === 'analyst' ? 'funcional_analista' : 'funcional_focal';

        if (!$this->hasTable($tableName)) {
            return [];
        }

        $sql = 'SELECT DISTINCT id_omega_time
                FROM `' . $tableName . '` 
                WHERE ativo_sn = 1 AND ' . $functionalColumn . ' = :functional';
        $statement = $this->connection->prepare($sql);
        $statement->execute(['functional' => $functional]);

        $teamIds = array_map('intval', array_column($statement->fetchAll(), 'id_omega_time'));
        $teamIds = array_values(array_unique(array_filter($teamIds, static function (int $value): bool {
            return $value > 0;
        })));
        sort($teamIds);

        return $teamIds;
    }

    private function fetchRawCallById(int $callId): array
    {
        if ($callId <= 0 || !$this->hasTable(self::CALLS_TABLE_NAME)) {
            return [];
        }

        $sql = 'SELECT
                    c.id_omega_chamado,
                    c.solicitante_funcional,
                    c.solicitante_nome,
                    c.solicitante_nivel,
                    c.solicitante_juncao_ag,
                    c.solicitante_juncao_gr,
                    c.solicitante_juncao_dr,
                    c.solicitante_segmento,
                    c.id_omega_time_abertura,
                    c.id_omega_categoria_abertura,
                    c.id_omega_time_atual,
                    c.id_omega_categoria_atual,
                    c.id_omega_status_atual,
                    c.funcional_analista_atual,
                    c.titulo,
                    c.descricao_abertura,
                    c.dt_abertura,
                    c.dt_ultimo_evento,
                    c.dt_fechamento,
                    c.resolucao_final,
                    COALESCE(c.prioridade_label, "") AS priority_label,
                    COALESCE(t.codigo_time, "") AS codigo_time,
                    COALESCE(t.nome_time, "") AS nome_time,
                    COALESCE(cat.nome_categoria, "") AS nome_categoria,
                    COALESCE(ah.nome, "") AS analyst_name,
                    COALESCE(s.nome_status, "Sem status") AS nome_status,
                    COALESCE(s.codigo_status, "SEM_STATUS") AS codigo_status,
                    COALESCE(s.cor_hex, "#cbd5e1") AS cor_hex
                ' . $this->buildCallsFromSql() . '
                WHERE c.ativo_sn = 1 AND c.id_omega_chamado = :call_id
                LIMIT 1';
        $statement = $this->connection->prepare($sql);
        $statement->bindValue(':call_id', $callId, PDO::PARAM_INT);
        $statement->execute();

        $row = $statement->fetch();

        return is_array($row) ? $row : [];
    }

    private function resolveStatusRecord(string $statusCode): array
    {
        $statusCode = strtoupper(trim($statusCode));

        if ($statusCode === '' || !$this->hasTable(self::STATUS_TABLE_NAME)) {
            return [];
        }

        $statement = $this->connection->prepare(
            'SELECT id_omega_status, codigo_status, nome_status, cor_hex
               FROM `' . self::STATUS_TABLE_NAME . '` 
              WHERE ativo_sn = 1 AND codigo_status = :status_code
              LIMIT 1'
        );
        $statement->execute(['status_code' => $statusCode]);
        $row = $statement->fetch();

        if (is_array($row)) {
            return [
                'id' => (int) ($row['id_omega_status'] ?? 0),
                'code' => trim((string) ($row['codigo_status'] ?? '')),
                'label' => trim((string) ($row['nome_status'] ?? '')),
                'color' => trim((string) ($row['cor_hex'] ?? '#cbd5e1')),
            ];
        }

        return [];
    }

    private function resolveJunctionMap(array $junctions): array
    {
        $map = ['ag' => '', 'gr' => '', 'dr' => ''];

        foreach ($junctions as $junction) {
            if (!is_array($junction)) {
                continue;
            }

            $type = strtoupper(trim((string) ($junction['tipo_juncao'] ?? '')));
            $code = substr(trim((string) ($junction['juncao'] ?? '')), 0, 4);

            if ($code === '') {
                continue;
            }

            if ($type === 'AG' && $map['ag'] === '') {
                $map['ag'] = $code;
                continue;
            }

            if ($type === 'GR' && $map['gr'] === '') {
                $map['gr'] = $code;
                continue;
            }

            if ($type === 'DR' && $map['dr'] === '') {
                $map['dr'] = $code;
            }
        }

        return $map;
    }

    private function resolveAnalystFunctionalForSave(
        array $existingCall,
        array $access,
        string $requesterFunctional,
        string $currentView,
        string $statusCode,
        string $requestedAnalystFunctional,
        int $teamId
    ): array {
        $currentFunctional = substr(trim((string) ($access['functional'] ?? '')), 0, 7);
        $accessibleTeamIds = array_map('intval', (array) ($access['accessible_team_ids'] ?? []));
        $existingAnalyst = substr(trim((string) ($existingCall['funcional_analista_atual'] ?? '')), 0, 7);
        $currentView = trim($currentView);
        $requestedAnalystFunctional = substr(trim($requestedAnalystFunctional), 0, 7);

        if ($requestedAnalystFunctional !== '') {
            if (!in_array($teamId, $accessibleTeamIds, true) || !$this->isAnalystMappedToTeam($requestedAnalystFunctional, $teamId)) {
                return [
                    'ok' => false,
                    'message' => 'Selecione apenas analistas ativos do seu departamento.',
                    'functional' => '',
                ];
            }

            return [
                'ok' => true,
                'functional' => $requestedAnalystFunctional,
            ];
        }

        if ($existingAnalyst !== '' && $this->isAnalystMappedToTeam($existingAnalyst, $teamId)) {
            return [
                'ok' => true,
                'functional' => $existingAnalyst,
            ];
        }

        if (($currentView === 'my-work' || $currentView === 'team-queue')
            && !$this->isTerminalStatus($statusCode)
            && $currentFunctional !== ''
            && in_array($teamId, $accessibleTeamIds, true)
            && $this->isAnalystMappedToTeam($currentFunctional, $teamId)) {
            return [
                'ok' => true,
                'functional' => $currentFunctional,
            ];
        }

        if ($currentFunctional !== ''
            && $currentFunctional !== $requesterFunctional
            && !$this->isTerminalStatus($statusCode)
            && in_array($teamId, $accessibleTeamIds, true)
            && $this->isAnalystMappedToTeam($currentFunctional, $teamId)) {
            return [
                'ok' => true,
                'functional' => $currentFunctional,
            ];
        }

        return [
            'ok' => true,
            'functional' => '',
        ];
    }

    private function ensureTeam(string $teamName): int
    {
        if (!$this->hasTable(self::TIMES_TABLE_NAME)) {
            return 0;
        }

        $teamName = substr(trim($teamName), 0, 150);

        if ($teamName === '') {
            $teamName = 'POBJ';
        }

        $selectStatement = $this->connection->prepare(
            'SELECT id_omega_time
               FROM `' . self::TIMES_TABLE_NAME . '` 
              WHERE nome_time = :team_name
              LIMIT 1'
        );
        $selectStatement->execute(['team_name' => $teamName]);
        $teamId = (int) $selectStatement->fetchColumn();

        if ($teamId > 0) {
            return $teamId;
        }

        $baseCode = $this->buildOmegaCode($teamName, 50);
        $teamCode = $baseCode;
        $suffix = 2;

        while ($this->omegaTimeCodeExists($teamCode)) {
            $suffixValue = '_' . $suffix;
            $teamCode = substr($baseCode, 0, max(1, 50 - strlen($suffixValue))) . $suffixValue;
            $suffix++;
        }

        $insertStatement = $this->connection->prepare(
            'INSERT INTO `' . self::TIMES_TABLE_NAME . '` (
                codigo_time,
                nome_time,
                descricao,
                ativo_sn,
                origem_carga
            ) VALUES (
                :team_code,
                :team_name,
                :description,
                1,
                :origin
            )'
        );
        $insertStatement->execute([
            'team_code' => $teamCode,
            'team_name' => $teamName,
            'description' => 'Time criado automaticamente pelo painel Omega.',
            'origin' => self::UI_ORIGIN,
        ]);

        return (int) $this->connection->lastInsertId();
    }

    private function omegaTimeCodeExists(string $teamCode): bool
    {
        $statement = $this->connection->prepare(
            'SELECT 1
               FROM `' . self::TIMES_TABLE_NAME . '` 
              WHERE codigo_time = :team_code
              LIMIT 1'
        );
        $statement->execute(['team_code' => $teamCode]);

        return (bool) $statement->fetchColumn();
    }

    private function ensureCategory(int $teamId, string $categoryName): ?int
    {
        if ($teamId <= 0 || !$this->hasTable(self::CATEGORY_TABLE_NAME)) {
            return null;
        }

        $categoryName = substr(trim($categoryName), 0, 150);

        if ($categoryName === '') {
            return null;
        }

        $selectStatement = $this->connection->prepare(
            'SELECT id_omega_categoria
               FROM `' . self::CATEGORY_TABLE_NAME . '` 
              WHERE id_omega_time = :team_id
                AND id_omega_categoria_pai IS NULL
                AND nome_categoria = :category_name
              LIMIT 1'
        );
        $selectStatement->execute([
            'team_id' => $teamId,
            'category_name' => $categoryName,
        ]);
        $categoryId = (int) $selectStatement->fetchColumn();

        if ($categoryId > 0) {
            return $categoryId;
        }

        $orderStatement = $this->connection->prepare(
            'SELECT COALESCE(MAX(ordem_exibicao), 0) + 1
               FROM `' . self::CATEGORY_TABLE_NAME . '` 
              WHERE id_omega_time = :team_id
                AND id_omega_categoria_pai IS NULL'
        );
        $orderStatement->execute(['team_id' => $teamId]);
        $displayOrder = max(1, (int) $orderStatement->fetchColumn());
        $insertStatement = $this->connection->prepare(
            'INSERT INTO `' . self::CATEGORY_TABLE_NAME . '` (
                id_omega_time,
                id_omega_categoria_pai,
                ordem_nivel,
                nome_categoria,
                descricao,
                selecao_final_sn,
                ordem_exibicao,
                ativo_sn,
                origem_carga
            ) VALUES (
                :team_id,
                NULL,
                1,
                :category_name,
                :description,
                1,
                :display_order,
                1,
                :origin
            )'
        );
        $insertStatement->execute([
            'team_id' => $teamId,
            'category_name' => $categoryName,
            'description' => 'Categoria criada automaticamente pelo painel Omega.',
            'display_order' => $displayOrder,
            'origin' => self::UI_ORIGIN,
        ]);

        return (int) $this->connection->lastInsertId();
    }

    private function ensureFunctionalMappedToTeam(string $functional, int $teamId, string $role): void
    {
        $functional = substr(trim($functional), 0, 7);

        if ($functional === '' || $teamId <= 0) {
            return;
        }

        $tableName = $role === 'analyst' ? self::ANALYST_TEAM_TABLE_NAME : self::FOCAL_TEAM_TABLE_NAME;
        $functionalColumn = $role === 'analyst' ? 'funcional_analista' : 'funcional_focal';
        $idColumn = $role === 'analyst' ? 'id_omega_analista_time' : 'id_omega_focal_time';

        if (!$this->hasTable($tableName)) {
            return;
        }

        $selectStatement = $this->connection->prepare(
            'SELECT ' . $idColumn . '
               FROM `' . $tableName . '` 
              WHERE id_omega_time = :team_id
                AND ' . $functionalColumn . ' = :functional
              LIMIT 1'
        );
        $selectStatement->execute([
            'team_id' => $teamId,
            'functional' => $functional,
        ]);

        if ($selectStatement->fetchColumn()) {
            return;
        }

        $insertStatement = $this->connection->prepare(
            'INSERT INTO `' . $tableName . '` (
                id_omega_time,
                ' . $functionalColumn . ',
                ativo_sn,
                origem_carga
            ) VALUES (
                :team_id,
                :functional,
                1,
                :origin
            )'
        );
        $insertStatement->execute([
            'team_id' => $teamId,
            'functional' => $functional,
            'origin' => self::UI_ORIGIN,
        ]);
    }

    private function buildOmegaCode(string $value, int $maxLength): string
    {
        $normalizedValue = strtoupper(trim($value));
        $normalizedValue = strtr($normalizedValue, [
            'Á' => 'A', 'À' => 'A', 'Â' => 'A', 'Ã' => 'A', 'Ä' => 'A',
            'É' => 'E', 'È' => 'E', 'Ê' => 'E', 'Ë' => 'E',
            'Í' => 'I', 'Ì' => 'I', 'Î' => 'I', 'Ï' => 'I',
            'Ó' => 'O', 'Ò' => 'O', 'Ô' => 'O', 'Õ' => 'O', 'Ö' => 'O',
            'Ú' => 'U', 'Ù' => 'U', 'Û' => 'U', 'Ü' => 'U',
            'Ç' => 'C',
        ]);
        $normalizedValue = preg_replace('/[^A-Z0-9]+/', '_', $normalizedValue) ?? '';
        $normalizedValue = trim($normalizedValue, '_');

        if ($normalizedValue === '') {
            $normalizedValue = 'OMEGA';
        }

        return substr($normalizedValue, 0, max(1, $maxLength));
    }

    private function isTerminalStatus(string $statusCode): bool
    {
        return in_array(strtoupper(trim($statusCode)), ['FECHADO', 'FINALIZADO', 'REJEITADO', 'CANCELADO', 'RESOLVIDO'], true);
    }

    private function insertMovement(array $payload): void
    {
        $this->ensureMovementTable();

        if (!$this->hasTable(self::MOVEMENT_TABLE_NAME)) {
            return;
        }

        $callId = max(0, (int) ($payload['call_id'] ?? 0));
        $responsibleFunctional = substr(trim((string) ($payload['responsible_functional'] ?? '')), 0, 7);

        if ($callId <= 0 || $responsibleFunctional === '') {
            return;
        }

        $statement = $this->connection->prepare(
            'INSERT INTO `' . self::MOVEMENT_TABLE_NAME . '` (
                id_omega_chamado,
                tipo_movimentacao,
                funcional_responsavel,
                id_omega_status_origem,
                id_omega_status_destino,
                id_omega_time_origem,
                id_omega_time_destino,
                id_omega_categoria_origem,
                id_omega_categoria_destino,
                funcional_analista_origem,
                funcional_analista_destino,
                observacao,
                dt_movimentacao,
                ativo_sn,
                origem_carga
            ) VALUES (
                :call_id,
                :movement_type,
                :responsible_functional,
                :status_origin_id,
                :status_destination_id,
                :time_origin_id,
                :time_destination_id,
                :category_origin_id,
                :category_destination_id,
                :analyst_origin,
                :analyst_destination,
                :observation,
                :moved_at,
                1,
                :origin
            )'
        );
        $statement->execute([
            'call_id' => $callId,
            'movement_type' => substr(trim((string) ($payload['movement_type'] ?? 'ATUALIZACAO')), 0, 30),
            'responsible_functional' => $responsibleFunctional,
            'status_origin_id' => $payload['status_origin_id'] !== null ? (int) $payload['status_origin_id'] : null,
            'status_destination_id' => $payload['status_destination_id'] !== null ? (int) $payload['status_destination_id'] : null,
            'time_origin_id' => $payload['time_origin_id'] !== null ? (int) $payload['time_origin_id'] : null,
            'time_destination_id' => $payload['time_destination_id'] !== null ? (int) $payload['time_destination_id'] : null,
            'category_origin_id' => $payload['category_origin_id'] !== null ? (int) $payload['category_origin_id'] : null,
            'category_destination_id' => $payload['category_destination_id'] !== null ? (int) $payload['category_destination_id'] : null,
            'analyst_origin' => $payload['analyst_origin'] !== null ? substr(trim((string) $payload['analyst_origin']), 0, 7) : null,
            'analyst_destination' => $payload['analyst_destination'] !== null ? substr(trim((string) $payload['analyst_destination']), 0, 7) : null,
            'observation' => ($payload['observation'] ?? null) !== null ? substr(trim((string) $payload['observation']), 0, 1000) : null,
            'moved_at' => trim((string) ($payload['moved_at'] ?? date('Y-m-d H:i:s'))),
            'origin' => self::UI_ORIGIN,
        ]);
    }

    private function buildFacetOptions(array $rows): array
    {
        $departments = [];
        $types = [];
        $priorities = [];
        $departmentTypeMap = [];

        foreach ($rows as $row) {
            $department = trim((string) ($row['department_label'] ?? ''));
            $type = trim((string) ($row['type_label'] ?? ''));
            $priority = trim((string) ($row['priority_label'] ?? ''));

            if ($department !== '' && strcasecmp($department, 'Equipe Matriz') !== 0) {
                $departments[$department] = $department;
            }

            if ($type !== '') {
                $types[$type] = $type;

                if ($department !== '' && strcasecmp($department, 'Equipe Matriz') !== 0) {
                    $departmentTypeMap[$department][$type] = $type;
                }
            }

            if ($priority !== '') {
                $priorities[$priority] = $priority;
            }
        }

        foreach (self::DEPARTMENT_TYPE_DEFAULTS as $departmentDefault => $typeDefaults) {
            $departments[$departmentDefault] = $departmentDefault;

            foreach ($typeDefaults as $typeDefault) {
                $types[$typeDefault] = $typeDefault;
                $departmentTypeMap[$departmentDefault][$typeDefault] = $typeDefault;
            }
        }

        foreach (['Alta', 'Média', 'Baixa'] as $priorityDefault) {
            $priorities[$priorityDefault] = $priorityDefault;
        }

        ksort($departments);
        ksort($types);
        ksort($priorities);

        return [
            'departments' => array_map(static function (string $value): array {
                return ['value' => $value, 'label' => $value];
            }, array_values($departments)),
            'types' => array_map(static function (string $value): array {
                return ['value' => $value, 'label' => $value];
            }, array_values($types)),
            'priorities' => array_map(static function (string $value): array {
                return ['value' => $value, 'label' => $value];
            }, array_values($priorities)),
            'department_type_map' => array_map(static function (array $departmentTypes): array {
                ksort($departmentTypes);

                return array_values(array_map(static function (string $value): array {
                    return ['value' => $value, 'label' => $value];
                }, array_values($departmentTypes)));
            }, $departmentTypeMap),
        ];
    }

    private function buildEditorOptions(array $accessibleTeamIds): array
    {
        $queues = $this->fetchAllActiveTeams();
        $queueDepartmentMap = [];
        $queueAnalystMap = [];
        $accessibleTeams = $this->fetchTeamsByIds($accessibleTeamIds);

        foreach ($queues as $queue) {
            $queueValue = trim((string) ($queue['value'] ?? ''));

            if ($queueValue === '') {
                continue;
            }

            $queueDepartmentMap[$queueValue] = (string) ($queue['department'] ?? 'POBJ');
        }

        foreach ($accessibleTeams as $team) {
            $teamId = (int) ($team['id'] ?? 0);
            $teamCode = trim((string) ($team['code'] ?? ''));

            if ($teamId <= 0 || $teamCode === '') {
                continue;
            }

            $queueAnalystMap[$teamCode] = array_map(static function (array $analyst): array {
                $functional = trim((string) ($analyst['functional'] ?? ''));
                $name = trim((string) ($analyst['name'] ?? 'Analista'));
                $level = trim((string) ($analyst['level'] ?? ''));
                $label = $name;

                if ($functional !== '') {
                    $label .= ' • ' . $functional;
                }

                if ($level !== '') {
                    $label .= ' • ' . $level;
                }

                return [
                    'value' => $functional,
                    'label' => $label,
                    'name' => $name,
                    'functional' => $functional,
                    'level' => $level,
                ];
            }, $this->fetchTeamAnalysts($teamId));
        }

        return [
            'queues' => $queues,
            'queue_department_map' => $queueDepartmentMap,
            'queue_analyst_map' => $queueAnalystMap,
        ];
    }

    private function normalizeDepartmentLabel(string $department): string
    {
        $department = trim($department);

        if ($department === '' || strcasecmp($department, 'Equipe Matriz') === 0 || strcasecmp($department, 'Matriz') === 0) {
            return 'POBJ';
        }

        foreach (array_keys(self::DEPARTMENT_TYPE_DEFAULTS) as $allowedDepartment) {
            if (strcasecmp($department, $allowedDepartment) === 0) {
                return $allowedDepartment;
            }
        }

        return 'POBJ';
    }

    private function normalizeDepartmentType(string $department, string $type): string
    {
        $allowedTypes = self::DEPARTMENT_TYPE_DEFAULTS[$department] ?? self::DEPARTMENT_TYPE_DEFAULTS['POBJ'];
        $type = trim($type);

        foreach ($allowedTypes as $allowedType) {
            if (strcasecmp($type, $allowedType) === 0) {
                return $allowedType;
            }
        }

        return $allowedTypes[0] ?? 'Outros';
    }

    private function filterRows(array $rows, array $filters, array $statusCodes): array
    {
        $filteredRows = [];

        foreach ($rows as $row) {
            if (!$this->matchesFilters($row, $filters, $statusCodes)) {
                continue;
            }

            $filteredRows[] = $row;
        }

        return $filteredRows;
    }

    private function paginateRows(array $rows, int $page, int $perPage): array
    {
        $totalRows = count($rows);
        $totalPages = max(1, (int) ceil($totalRows / max(1, $perPage)));
        $currentPage = min(max(1, $page), $totalPages);
        $offset = ($currentPage - 1) * $perPage;

        return [
            'rows' => array_slice($rows, $offset, $perPage),
            'total_rows' => $totalRows,
            'current_page' => $currentPage,
            'per_page' => $perPage,
            'total_pages' => $totalPages,
        ];
    }

    private function buildAnalytics(array $rows): array
    {
        $openedTotal = 0;
        $closedTotal = 0;
        $requesters = [];
        $departments = [];
        $priorities = [];
        $types = [];
        $monthly = [];

        foreach ($rows as $row) {
            $statusCode = strtoupper(trim((string) ($row['status_code'] ?? 'SEM_STATUS')));
            $requester = trim((string) ($row['user_label'] ?? 'Usuário'));
            $department = trim((string) ($row['department_label'] ?? 'POBJ'));
            $priority = $this->normalizePriorityLabel((string) ($row['priority_label'] ?? 'Média'));
            $type = trim((string) ($row['type_label'] ?? 'Atendimento'));
            $openedAt = trim((string) ($row['opened_at'] ?? ''));
            $updatedAt = trim((string) ($row['updated_at'] ?? ''));

            if ($this->isTerminalStatus($statusCode)) {
                $closedTotal++;
            } else {
                $openedTotal++;
            }

            $requesters[$requester] = ($requesters[$requester] ?? 0) + 1;
            $departments[$department] = ($departments[$department] ?? 0) + 1;
            $priorities[$priority] = ($priorities[$priority] ?? 0) + 1;
            $types[$type] = ($types[$type] ?? 0) + 1;

            $openedMonth = $this->normalizeMonthKey($openedAt);

            if ($openedMonth !== '') {
                if (!isset($monthly[$openedMonth])) {
                    $monthly[$openedMonth] = ['opened' => 0, 'closed' => 0];
                }

                $monthly[$openedMonth]['opened']++;
            }

            if ($this->isTerminalStatus($statusCode)) {
                $closedMonth = $this->normalizeMonthKey($updatedAt !== '' ? $updatedAt : $openedAt);

                if ($closedMonth !== '') {
                    if (!isset($monthly[$closedMonth])) {
                        $monthly[$closedMonth] = ['opened' => 0, 'closed' => 0];
                    }

                    $monthly[$closedMonth]['closed']++;
                }
            }
        }

        ksort($monthly);

        $monthlySeries = array_map(function (string $monthKey, array $values): array {
            return [
                'month_key' => $monthKey,
                'label' => $this->formatMonthLabel($monthKey),
                'opened' => (int) ($values['opened'] ?? 0),
                'closed' => (int) ($values['closed'] ?? 0),
            ];
        }, array_keys($monthly), array_values($monthly));

        return [
            'summary' => [
                'opened_total' => $openedTotal,
                'closed_total' => $closedTotal,
                'total_rows' => count($rows),
            ],
            'top_requesters' => $this->formatTopItems($requesters),
            'top_departments' => $this->formatTopItems($departments),
            'priority_breakdown' => $this->formatBreakdown($priorities),
            'type_breakdown' => $this->formatBreakdown($types),
            'monthly_volume' => $monthlySeries,
        ];
    }

    private function matchesFilters(array $row, array $filters, array $statusCodes): bool
    {
        if ($filters['search'] !== '') {
            $haystack = strtolower(implode(' ', [
                (string) ($row['id_display'] ?? ''),
                (string) ($row['preview_title'] ?? ''),
                (string) ($row['preview_copy'] ?? ''),
                (string) ($row['type_label'] ?? ''),
                (string) ($row['queue_label'] ?? ''),
                (string) ($row['status_label'] ?? ''),
            ]));

            if (strpos($haystack, strtolower($filters['search'])) === false) {
                return false;
            }
        }

        if ($filters['call_id'] !== '' && strpos((string) ($row['id_display'] ?? ''), preg_replace('/\D+/', '', $filters['call_id']) ?? '') === false) {
            return false;
        }

        if ($filters['requester'] !== '' && strpos(strtolower((string) ($row['user_label'] ?? '')), strtolower($filters['requester'])) === false) {
            return false;
        }

        if ($filters['department'] !== '' && strcasecmp((string) ($row['department_label'] ?? ''), $filters['department']) !== 0) {
            return false;
        }

        if ($filters['type'] !== '' && strcasecmp((string) ($row['type_label'] ?? ''), $filters['type']) !== 0) {
            return false;
        }

        if ($filters['priority'] !== '' && strcasecmp((string) ($row['priority_label'] ?? ''), $filters['priority']) !== 0) {
            return false;
        }

        if ($statusCodes !== [] && !in_array((string) ($row['status_code'] ?? ''), $statusCodes, true)) {
            return false;
        }

        if ($filters['opened_from'] !== '' && $this->extractDate((string) ($row['opened_at'] ?? '')) < $filters['opened_from']) {
            return false;
        }

        if ($filters['opened_to'] !== '' && $this->extractDate((string) ($row['opened_at'] ?? '')) > $filters['opened_to']) {
            return false;
        }

        return true;
    }

    private function normalizeStatusFilter(string $statusFilter): array
    {
        $statusCodes = array_values(array_filter(array_map(static function (string $value): string {
            return strtoupper(trim($value));
        }, explode(',', $statusFilter)), static function (string $value): bool {
            return $value !== '';
        }));

        return array_values(array_unique($statusCodes));
    }

    private function extractDate(string $value): string
    {
        $value = trim($value);

        if ($value === '') {
            return '';
        }

        return substr($value, 0, 10);
    }

    private function normalizeRow(array $row): array
    {
        $rawId = (int) ($row['id_omega_chamado'] ?? 0);
        $title = trim((string) ($row['titulo'] ?? 'Chamado sem título'));
        $requesterName = trim((string) ($row['solicitante_nome'] ?? 'Usuário'));
        $requesterFunctional = trim((string) ($row['solicitante_funcional'] ?? ''));
        $analystFunctional = trim((string) ($row['funcional_analista_atual'] ?? ''));
        $analystName = trim((string) ($row['analyst_name'] ?? ''));
        $segment = $this->normalizeDepartmentLabel((string) ($row['solicitante_segmento'] ?? 'POBJ'));
        $queueCode = trim((string) ($row['codigo_time'] ?? ''));
        $queueName = trim((string) ($row['nome_time'] ?? ''));
        $queueName = $queueName !== '' ? $queueName : $segment;
        $categoryName = trim((string) ($row['nome_categoria'] ?? ''));
        $categoryName = $categoryName !== '' ? $categoryName : $this->normalizeDepartmentType($segment, '');
        $statusName = trim((string) ($row['nome_status'] ?? 'Sem status'));
        $statusCode = strtoupper(trim((string) ($row['codigo_status'] ?? 'SEM_STATUS')));
        $statusColor = trim((string) ($row['cor_hex'] ?? '#cbd5e1'));
        $priorityLabel = $this->normalizePriorityLabel((string) ($row['priority_label'] ?? $this->inferPriorityLabel($statusCode)));
        $description = trim((string) ($row['descricao_abertura'] ?? ''));
        $resolutionFinal = trim((string) ($row['resolucao_final'] ?? ''));
        $closedAt = trim((string) ($row['dt_fechamento'] ?? ''));

        return [
            'id' => $rawId,
            'id_display' => str_pad((string) max(0, $rawId), 6, '0', STR_PAD_LEFT),
            'preview_title' => $title,
            'preview_copy' => trim($requesterName . ($requesterFunctional !== '' ? ' • ' . $requesterFunctional : '')),
            'department_label' => $segment !== '' ? $segment : 'POBJ',
            'type_label' => $categoryName,
            'user_label' => $requesterName,
            'user_code' => $requesterFunctional,
            'priority_label' => $priorityLabel,
            'analyst_label' => $analystName !== '' ? $analystName : ($analystFunctional !== '' ? $analystFunctional : 'Sem analista'),
            'analyst_code' => $analystFunctional,
            'queue_code' => $queueCode !== '' ? $queueCode : $this->buildOmegaCode($queueName, 50),
            'queue_label' => $queueName,
            'opened_at' => (string) ($row['dt_abertura'] ?? ''),
            'updated_at' => (string) ($row['dt_ultimo_evento'] ?? ''),
            'closed_at' => $closedAt,
            'status_label' => $statusName,
            'status_code' => $statusCode,
            'status_color' => $statusColor,
            'description' => $description !== '' ? $description : 'Sem observações registradas.',
            'resolution_final' => $resolutionFinal !== '' ? $resolutionFinal : 'Sem finalização registrada.',
            'thread' => $this->normalizeThread($row, $requesterName, $analystName !== '' ? $analystName : ($analystFunctional !== '' ? $analystFunctional : 'Sem analista'), $statusName),
        ];
    }

    private function normalizeThread(array $row, string $requesterName, string $analystName, string $statusName): array
    {
        $rawTimeline = $row['timeline_entries'] ?? null;

        if (is_array($rawTimeline) && $rawTimeline !== []) {
            $timeline = [];

            foreach ($rawTimeline as $entry) {
                if (!is_array($entry)) {
                    continue;
                }

                $role = trim((string) ($entry['role'] ?? 'user'));
                $author = trim((string) ($entry['author'] ?? ($role === 'analyst' ? $analystName : $requesterName)));
                $message = trim((string) ($entry['message'] ?? ''));

                if ($message === '') {
                    continue;
                }

                $timeline[] = [
                    'role' => $role === 'analyst' ? 'analyst' : 'user',
                    'author' => $author !== '' ? $author : ($role === 'analyst' ? $analystName : $requesterName),
                    'timestamp' => trim((string) ($entry['timestamp'] ?? '')),
                    'message' => $message,
                ];
            }

            if ($timeline !== []) {
                return $timeline;
            }
        }

        $description = trim((string) ($row['descricao_abertura'] ?? ''));
        $openedAt = trim((string) ($row['dt_abertura'] ?? ''));
        $updatedAt = trim((string) ($row['dt_ultimo_evento'] ?? ''));
        $thread = [];

        if ($description !== '') {
            $thread[] = [
                'role' => 'user',
                'author' => $requesterName !== '' ? $requesterName : 'Solicitante',
                'timestamp' => $openedAt,
                'message' => $description,
            ];
        }

        if ($analystName !== '' && $updatedAt !== '' && $updatedAt !== $openedAt) {
            $thread[] = [
                'role' => 'analyst',
                'author' => $analystName,
                'timestamp' => $updatedAt,
                'message' => 'Status atualizado para ' . $statusName . ' e acompanhamento registrado na fila operacional.',
            ];
        }

        return $thread;
    }

    private function formatTopItems(array $items): array
    {
        arsort($items);
        $maxValue = $items !== [] ? max($items) : 0;
        $formatted = [];

        foreach (array_slice($items, 0, 10, true) as $label => $value) {
            $formatted[] = [
                'label' => $label,
                'value' => (int) $value,
                'share' => $maxValue > 0 ? (int) round(((int) $value / $maxValue) * 100) : 0,
            ];
        }

        return $formatted;
    }

    private function formatBreakdown(array $items): array
    {
        $total = array_sum($items);
        arsort($items);
        $formatted = [];

        foreach ($items as $label => $value) {
            $formatted[] = [
                'label' => $label,
                'value' => (int) $value,
                'percentage' => $total > 0 ? round(((int) $value / $total) * 100, 1) : 0.0,
            ];
        }

        return $formatted;
    }

    private function normalizeMonthKey(string $value): string
    {
        $value = trim($value);

        if ($value === '') {
            return '';
        }

        return substr($value, 0, 7);
    }

    private function formatMonthLabel(string $monthKey): string
    {
        $monthKey = trim($monthKey);

        if ($monthKey === '' || strlen($monthKey) < 7) {
            return 'Sem data';
        }

        $monthNames = [
            '01' => 'Jan',
            '02' => 'Fev',
            '03' => 'Mar',
            '04' => 'Abr',
            '05' => 'Mai',
            '06' => 'Jun',
            '07' => 'Jul',
            '08' => 'Ago',
            '09' => 'Set',
            '10' => 'Out',
            '11' => 'Nov',
            '12' => 'Dez',
        ];

        $month = substr($monthKey, 5, 2);
        $year = substr($monthKey, 2, 2);

        return ($monthNames[$month] ?? $month) . '/' . $year;
    }

    private function inferPriorityLabel(string $statusCode): string
    {
        switch (strtoupper($statusCode)) {
            case 'EM_ATENDIMENTO':
                return 'Alta';

            case 'FECHADO':
            case 'REJEITADO':
                return 'Baixa';

            case 'ABERTO':
            case 'CANCELADO':
            case 'AGUARDANDO':
            default:
                return 'Média';
        }
    }

    private function normalizePriorityLabel(string $priorityLabel): string
    {
        switch (mb_strtolower(trim($priorityLabel), 'UTF-8')) {
            case 'alta':
                return 'Alta';

            case 'baixa':
                return 'Baixa';

            case 'media':
            case 'média':
            default:
                return 'Média';
        }
    }

    private function fetchTeamsByIds(array $teamIds): array
    {
        if ($teamIds === [] || !$this->hasTable(self::TIMES_TABLE_NAME)) {
            return [];
        }

        $placeholders = [];
        $params = [];

        foreach (array_values($teamIds) as $index => $teamId) {
            $placeholder = 'team_' . $index;
            $placeholders[] = ':' . $placeholder;
            $params[$placeholder] = (int) $teamId;
        }

        $sql = 'SELECT id_omega_time, codigo_time, nome_time
                  FROM `' . self::TIMES_TABLE_NAME . '` 
                 WHERE ativo_sn = 1
                   AND id_omega_time IN (' . implode(', ', $placeholders) . ')
                 ORDER BY nome_time';
        $statement = $this->connection->prepare($sql);

        foreach ($params as $paramKey => $paramValue) {
            $statement->bindValue(':' . $paramKey, $paramValue, PDO::PARAM_INT);
        }

        $statement->execute();
        $teams = [];

        foreach ($statement->fetchAll() as $row) {
            $teamId = (int) ($row['id_omega_time'] ?? 0);
            $teamCode = trim((string) ($row['codigo_time'] ?? ''));
            $teamName = trim((string) ($row['nome_time'] ?? ''));

            if ($teamId <= 0 || $teamCode === '' || $teamName === '') {
                continue;
            }

            $teams[] = [
                'id' => $teamId,
                'code' => $teamCode,
                'name' => $teamName,
                'label' => $teamName,
            ];
        }

        return $teams;
    }

    private function fetchAllActiveTeams(): array
    {
        if (!$this->hasTable(self::TIMES_TABLE_NAME)) {
            return [];
        }

        $statement = $this->connection->query(
            'SELECT id_omega_time, codigo_time, nome_time
               FROM `' . self::TIMES_TABLE_NAME . '` 
              WHERE ativo_sn = 1
                AND codigo_time <> "EQUIPE_MATRIZ"
              ORDER BY nome_time'
        );

        return array_map(function (array $row): array {
            $code = trim((string) ($row['codigo_time'] ?? ''));
            $label = trim((string) ($row['nome_time'] ?? ''));

            return [
                'id' => (int) ($row['id_omega_time'] ?? 0),
                'value' => $code,
                'code' => $code,
                'label' => $label,
                'name' => $label,
                'department' => $this->normalizeDepartmentLabel($label !== '' ? $label : $code),
            ];
        }, $statement->fetchAll());
    }

    private function findTeamByCode(string $teamCode): array
    {
        if ($teamCode === '' || !$this->hasTable(self::TIMES_TABLE_NAME)) {
            return [];
        }

        $statement = $this->connection->prepare(
            'SELECT id_omega_time, codigo_time, nome_time
               FROM `' . self::TIMES_TABLE_NAME . '` 
              WHERE codigo_time = :team_code
              LIMIT 1'
        );
        $statement->execute(['team_code' => $teamCode]);
        $row = $statement->fetch();

        if (!is_array($row)) {
            return [];
        }

        return [
            'id' => (int) ($row['id_omega_time'] ?? 0),
            'code' => trim((string) ($row['codigo_time'] ?? '')),
            'name' => trim((string) ($row['nome_time'] ?? '')),
            'label' => trim((string) ($row['nome_time'] ?? '')),
        ];
    }

    private function findTeamByName(string $teamName): array
    {
        if ($teamName === '' || !$this->hasTable(self::TIMES_TABLE_NAME)) {
            return [];
        }

        $statement = $this->connection->prepare(
            'SELECT id_omega_time, codigo_time, nome_time
               FROM `' . self::TIMES_TABLE_NAME . '` 
              WHERE nome_time = :team_name
              LIMIT 1'
        );
        $statement->execute(['team_name' => $teamName]);
        $row = $statement->fetch();

        if (!is_array($row)) {
            return [];
        }

        return [
            'id' => (int) ($row['id_omega_time'] ?? 0),
            'code' => trim((string) ($row['codigo_time'] ?? '')),
            'name' => trim((string) ($row['nome_time'] ?? '')),
            'label' => trim((string) ($row['nome_time'] ?? '')),
        ];
    }

    private function resolveRequestedTeam(string $queueIdentifier, string $fallbackDepartment): array
    {
        $queueIdentifier = trim($queueIdentifier);

        if ($queueIdentifier !== '') {
            $team = $this->findTeamByCode($queueIdentifier);

            if ($team !== []) {
                return $team;
            }

            $team = $this->findTeamByName($queueIdentifier);

            if ($team !== []) {
                return $team;
            }
        }

        $fallbackDepartment = $this->normalizeDepartmentLabel($fallbackDepartment);
        $team = $this->findTeamByCode($this->buildOmegaCode($fallbackDepartment, 50));

        if ($team !== []) {
            return $team;
        }

        return $this->findTeamByName($fallbackDepartment);
    }

    private function fetchTeamManagers(int $teamId): array
    {
        if ($teamId <= 0 || !$this->hasTable(self::FOCAL_TEAM_TABLE_NAME)) {
            return [];
        }

        $hierarchyJoin = $this->hasTable(self::HIERARCHY_TABLE_NAME)
            ? 'LEFT JOIN `' . self::HIERARCHY_TABLE_NAME . '` h ON h.funcional = f.funcional_focal AND h.ativo_sn = 1'
            : 'LEFT JOIN (SELECT NULL AS funcional, NULL AS nome, NULL AS nivel) h ON 1 = 0';

        $statement = $this->connection->prepare(
            'SELECT
                f.funcional_focal,
                COALESCE(h.nome, f.funcional_focal) AS nome,
                COALESCE(h.nivel, "") AS nivel
             FROM `' . self::FOCAL_TEAM_TABLE_NAME . '` f
             ' . $hierarchyJoin . '
             WHERE f.id_omega_time = :team_id
               AND f.ativo_sn = 1
             ORDER BY nome'
        );
        $statement->execute(['team_id' => $teamId]);

        return array_map(static function (array $row): array {
            return [
                'functional' => trim((string) ($row['funcional_focal'] ?? '')),
                'name' => trim((string) ($row['nome'] ?? '')),
                'level' => trim((string) ($row['nivel'] ?? '')),
            ];
        }, $statement->fetchAll());
    }

    private function fetchTeamAnalysts(int $teamId): array
    {
        if ($teamId <= 0 || !$this->hasTable(self::ANALYST_TEAM_TABLE_NAME)) {
            return [];
        }

        $hierarchyJoin = $this->hasTable(self::HIERARCHY_TABLE_NAME)
            ? 'LEFT JOIN `' . self::HIERARCHY_TABLE_NAME . '` h ON h.funcional = a.funcional_analista AND h.ativo_sn = 1'
            : 'LEFT JOIN (SELECT NULL AS funcional, NULL AS nome, NULL AS nivel) h ON 1 = 0';

        $statement = $this->connection->prepare(
            'SELECT
                a.funcional_analista,
                COALESCE(h.nome, a.funcional_analista) AS nome,
                COALESCE(h.nivel, "") AS nivel
             FROM `' . self::ANALYST_TEAM_TABLE_NAME . '` a
             ' . $hierarchyJoin . '
             WHERE a.id_omega_time = :team_id
               AND a.ativo_sn = 1
             ORDER BY nome'
        );
        $statement->execute(['team_id' => $teamId]);

        return array_map(static function (array $row): array {
            return [
                'functional' => trim((string) ($row['funcional_analista'] ?? '')),
                'name' => trim((string) ($row['nome'] ?? '')),
                'level' => trim((string) ($row['nivel'] ?? '')),
            ];
        }, $statement->fetchAll());
    }

    private function fetchAssignableAnalystCandidates(int $teamId): array
    {
        if ($teamId <= 0 || !$this->hasTable(self::HIERARCHY_TABLE_NAME)) {
            return [];
        }

        $sql = 'SELECT
                    h.funcional,
                    h.nome,
                    h.nivel
                FROM `' . self::HIERARCHY_TABLE_NAME . '` h
                LEFT JOIN `' . self::ANALYST_TEAM_TABLE_NAME . '` a
                    ON a.funcional_analista = h.funcional
                   AND a.id_omega_time = :team_id
                   AND a.ativo_sn = 1
                WHERE h.ativo_sn = 1
                  AND h.nivel IN ("AG", "GG", "TL", "GC", "PA", "AS")
                  AND a.id_omega_analista_time IS NULL
                ORDER BY h.nome';
        $statement = $this->connection->prepare($sql);
        $statement->execute(['team_id' => $teamId]);

        return array_map(static function (array $row): array {
            return [
                'functional' => trim((string) ($row['funcional'] ?? '')),
                'name' => trim((string) ($row['nome'] ?? '')),
                'level' => trim((string) ($row['nivel'] ?? '')),
            ];
        }, $statement->fetchAll());
    }

    private function isAssignableAnalystFunctional(string $functional): bool
    {
        if ($functional === '' || !$this->hasTable(self::HIERARCHY_TABLE_NAME)) {
            return false;
        }

        $statement = $this->connection->prepare(
            'SELECT 1
               FROM `' . self::HIERARCHY_TABLE_NAME . '` 
              WHERE funcional = :functional
                AND ativo_sn = 1
                AND nivel IN ("AG", "GG", "TL", "GC", "PA", "AS")
              LIMIT 1'
        );
        $statement->execute(['functional' => $functional]);

        return (bool) $statement->fetchColumn();
    }

    private function isAnalystMappedToTeam(string $functional, int $teamId): bool
    {
        $functional = substr(trim($functional), 0, 7);

        if ($functional === '' || $teamId <= 0 || !$this->hasTable(self::ANALYST_TEAM_TABLE_NAME)) {
            return false;
        }

        $statement = $this->connection->prepare(
            'SELECT 1
               FROM `' . self::ANALYST_TEAM_TABLE_NAME . '` 
              WHERE id_omega_time = :team_id
                AND funcional_analista = :functional
                AND ativo_sn = 1
              LIMIT 1'
        );
        $statement->execute([
            'team_id' => $teamId,
            'functional' => $functional,
        ]);

        return (bool) $statement->fetchColumn();
    }

    private function attachMovementThreads(array $rows): array
    {
        if ($rows === []) {
            return [];
        }

        $this->ensureMovementTable();

        if (!$this->hasTable(self::MOVEMENT_TABLE_NAME)) {
            return $rows;
        }

        $rowsById = [];
        $callIds = [];

        foreach ($rows as $row) {
            $callId = (int) ($row['id'] ?? 0);

            if ($callId <= 0) {
                continue;
            }

            $callIds[$callId] = $callId;
            $rowsById[$callId] = $row;
        }

        if ($callIds === []) {
            return $rows;
        }

        $movementsByCallId = $this->fetchMovementsByCallIds(array_values($callIds), $rowsById);

        foreach ($rows as $index => $row) {
            $callId = (int) ($row['id'] ?? 0);

            if ($callId <= 0 || !isset($movementsByCallId[$callId])) {
                continue;
            }

            $mergedThread = $this->mergeThreadEntries((array) ($row['thread'] ?? []), $movementsByCallId[$callId]);
            $rows[$index]['thread'] = $mergedThread;
            $lastThreadTimestamp = $this->resolveLastThreadTimestamp($mergedThread);

            if ($lastThreadTimestamp !== '' && strcmp($lastThreadTimestamp, (string) ($rows[$index]['updated_at'] ?? '')) > 0) {
                $rows[$index]['updated_at'] = $lastThreadTimestamp;
            }
        }

        return $rows;
    }

    private function fetchMovementsByCallIds(array $callIds, array $rowsById): array
    {
        if ($callIds === []) {
            return [];
        }

        $placeholders = [];
        $params = [];

        foreach (array_values($callIds) as $index => $callId) {
            $placeholder = 'call_' . $index;
            $placeholders[] = ':' . $placeholder;
            $params[$placeholder] = (int) $callId;
        }

        $statusOriginJoin = $this->hasTable(self::STATUS_TABLE_NAME)
            ? 'LEFT JOIN `' . self::STATUS_TABLE_NAME . '` so ON so.id_omega_status = m.id_omega_status_origem'
            : 'LEFT JOIN (SELECT NULL AS id_omega_status, NULL AS nome_status) so ON 1 = 0';
        $statusDestinationJoin = $this->hasTable(self::STATUS_TABLE_NAME)
            ? 'LEFT JOIN `' . self::STATUS_TABLE_NAME . '` sd ON sd.id_omega_status = m.id_omega_status_destino'
            : 'LEFT JOIN (SELECT NULL AS id_omega_status, NULL AS nome_status) sd ON 1 = 0';
        $timeOriginJoin = $this->hasTable(self::TIMES_TABLE_NAME)
            ? 'LEFT JOIN `' . self::TIMES_TABLE_NAME . '` to1 ON to1.id_omega_time = m.id_omega_time_origem'
            : 'LEFT JOIN (SELECT NULL AS id_omega_time, NULL AS nome_time) to1 ON 1 = 0';
        $timeDestinationJoin = $this->hasTable(self::TIMES_TABLE_NAME)
            ? 'LEFT JOIN `' . self::TIMES_TABLE_NAME . '` td1 ON td1.id_omega_time = m.id_omega_time_destino'
            : 'LEFT JOIN (SELECT NULL AS id_omega_time, NULL AS nome_time) td1 ON 1 = 0';
        $categoryOriginJoin = $this->hasTable(self::CATEGORY_TABLE_NAME)
            ? 'LEFT JOIN `' . self::CATEGORY_TABLE_NAME . '` co1 ON co1.id_omega_categoria = m.id_omega_categoria_origem'
            : 'LEFT JOIN (SELECT NULL AS id_omega_categoria, NULL AS nome_categoria) co1 ON 1 = 0';
        $categoryDestinationJoin = $this->hasTable(self::CATEGORY_TABLE_NAME)
            ? 'LEFT JOIN `' . self::CATEGORY_TABLE_NAME . '` cd1 ON cd1.id_omega_categoria = m.id_omega_categoria_destino'
            : 'LEFT JOIN (SELECT NULL AS id_omega_categoria, NULL AS nome_categoria) cd1 ON 1 = 0';

        $sql = 'SELECT
                    m.id_omega_chamado,
                    m.tipo_movimentacao,
                    m.funcional_responsavel,
                    m.funcional_analista_origem,
                    m.funcional_analista_destino,
                    m.observacao,
                    m.dt_movimentacao,
                    COALESCE(so.nome_status, "") AS status_origem_nome,
                    COALESCE(sd.nome_status, "") AS status_destino_nome,
                    COALESCE(to1.nome_time, "") AS time_origem_nome,
                    COALESCE(td1.nome_time, "") AS time_destino_nome,
                    COALESCE(co1.nome_categoria, "") AS category_origem_nome,
                    COALESCE(cd1.nome_categoria, "") AS category_destino_nome
                FROM `' . self::MOVEMENT_TABLE_NAME . '` m
                ' . $statusOriginJoin . '
                ' . $statusDestinationJoin . '
                ' . $timeOriginJoin . '
                ' . $timeDestinationJoin . '
                ' . $categoryOriginJoin . '
                ' . $categoryDestinationJoin . '
                WHERE m.ativo_sn = 1
                  AND m.id_omega_chamado IN (' . implode(', ', $placeholders) . ')
                ORDER BY m.dt_movimentacao ASC, m.id_omega_chamado_movimentacao ASC';
        $statement = $this->connection->prepare($sql);

        foreach ($params as $paramKey => $paramValue) {
            $statement->bindValue(':' . $paramKey, $paramValue, PDO::PARAM_INT);
        }

        $statement->execute();
        $movementsByCallId = [];

        foreach ($statement->fetchAll() as $row) {
            $callId = (int) ($row['id_omega_chamado'] ?? 0);

            if ($callId <= 0 || !isset($rowsById[$callId])) {
                continue;
            }

            $message = $this->formatMovementMessage((array) $row);

            if ($message === '') {
                continue;
            }

            $contextRow = (array) $rowsById[$callId];
            $responsibleFunctional = trim((string) ($row['funcional_responsavel'] ?? ''));
            $author = trim((string) ($contextRow['analyst_label'] ?? ''));

            if ($author === '' || ($responsibleFunctional !== '' && trim((string) ($contextRow['analyst_code'] ?? '')) !== $responsibleFunctional)) {
                $author = $responsibleFunctional !== '' ? $responsibleFunctional : 'Operação Omega';
            }

            $movementsByCallId[$callId][] = [
                'role' => 'analyst',
                'author' => $author,
                'timestamp' => trim((string) ($row['dt_movimentacao'] ?? '')),
                'message' => $message,
            ];
        }

        return $movementsByCallId;
    }

    private function formatMovementMessage(array $row): string
    {
        $movementType = strtoupper(trim((string) ($row['tipo_movimentacao'] ?? 'ATUALIZACAO')));
        $statusOrigin = trim((string) ($row['status_origem_nome'] ?? ''));
        $statusDestination = trim((string) ($row['status_destino_nome'] ?? ''));
        $timeOrigin = trim((string) ($row['time_origem_nome'] ?? ''));
        $timeDestination = trim((string) ($row['time_destino_nome'] ?? ''));
        $categoryOrigin = trim((string) ($row['category_origem_nome'] ?? ''));
        $categoryDestination = trim((string) ($row['category_destino_nome'] ?? ''));
        $analystOrigin = trim((string) ($row['funcional_analista_origem'] ?? ''));
        $analystDestination = trim((string) ($row['funcional_analista_destino'] ?? ''));
        $observation = trim((string) ($row['observacao'] ?? ''));
        $parts = [];

        if ($movementType === 'ABERTURA') {
            $openingMessage = 'Chamado aberto no Omega';

            if ($timeDestination !== '') {
                $openingMessage .= ' na fila ' . $timeDestination;
            }

            if ($categoryDestination !== '') {
                $openingMessage .= ' em ' . $categoryDestination;
            }

            $parts[] = $openingMessage . '.';
        }

        if ($statusDestination !== '' && $statusDestination !== $statusOrigin) {
            $parts[] = $statusOrigin !== ''
                ? 'Status alterado de ' . $statusOrigin . ' para ' . $statusDestination . '.'
                : 'Status definido como ' . $statusDestination . '.';
        }

        if ($timeDestination !== '' && $timeDestination !== $timeOrigin) {
            $parts[] = $timeOrigin !== ''
                ? 'Fila alterada de ' . $timeOrigin . ' para ' . $timeDestination . '.'
                : 'Fila definida como ' . $timeDestination . '.';
        }

        if ($categoryDestination !== '' && $categoryDestination !== $categoryOrigin) {
            $parts[] = $categoryOrigin !== ''
                ? 'Categoria alterada de ' . $categoryOrigin . ' para ' . $categoryDestination . '.'
                : 'Categoria definida como ' . $categoryDestination . '.';
        }

        if ($analystDestination !== '' && $analystDestination !== $analystOrigin) {
            $parts[] = $analystOrigin !== ''
                ? 'Responsável alterado de ' . $analystOrigin . ' para ' . $analystDestination . '.'
                : 'Responsável definido como ' . $analystDestination . '.';
        }

        if ($observation !== '') {
            $parts[] = $observation;
        }

        if ($parts === []) {
            switch ($movementType) {
                case 'FECHAMENTO':
                    return 'Fechamento registrado no chamado.';

                case 'ABERTURA':
                    return 'Chamado aberto no Omega.';

                case 'ATUALIZACAO':
                default:
                    return 'Atualização operacional registrada.';
            }
        }

        return implode(' ', $parts);
    }

    private function attachCommentThreads(array $rows): array
    {
        if ($rows === []) {
            return [];
        }

        $this->ensureCommentTable();

        if (!$this->hasTable(self::COMMENT_TABLE_NAME)) {
            return $rows;
        }

        $rowsById = [];
        $callIds = [];

        foreach ($rows as $row) {
            $callId = (int) ($row['id'] ?? 0);

            if ($callId <= 0) {
                continue;
            }

            $callIds[$callId] = $callId;
            $rowsById[$callId] = $row;
        }

        if ($callIds === []) {
            return $rows;
        }

        $commentsByCallId = $this->fetchCommentsByCallIds(array_values($callIds), $rowsById);

        foreach ($rows as $index => $row) {
            $callId = (int) ($row['id'] ?? 0);

            if ($callId <= 0 || !isset($commentsByCallId[$callId])) {
                continue;
            }

            $mergedThread = $this->mergeThreadEntries((array) ($row['thread'] ?? []), $commentsByCallId[$callId]);
            $rows[$index]['thread'] = $mergedThread;
            $lastThreadTimestamp = $this->resolveLastThreadTimestamp($mergedThread);

            if ($lastThreadTimestamp !== '' && strcmp($lastThreadTimestamp, (string) ($rows[$index]['updated_at'] ?? '')) > 0) {
                $rows[$index]['updated_at'] = $lastThreadTimestamp;
            }
        }

        return $rows;
    }

    private function fetchCommentsByCallIds(array $callIds, array $rowsById): array
    {
        if ($callIds === []) {
            return [];
        }

        $placeholders = [];
        $params = [];

        foreach (array_values($callIds) as $index => $callId) {
            $placeholder = 'call_' . $index;
            $placeholders[] = ':' . $placeholder;
            $params[$placeholder] = (int) $callId;
        }

        $sql = 'SELECT
                    id_omega_chamado,
                    funcional_autor,
                    tipo_autor,
                    comentario,
                    dt_comentario
                FROM `' . self::COMMENT_TABLE_NAME . '` 
                WHERE ativo_sn = 1
                    AND id_omega_chamado IN (' . implode(', ', $placeholders) . ')
                ORDER BY dt_comentario ASC, id_omega_chamado_comentario ASC';
        $statement = $this->connection->prepare($sql);

        foreach ($params as $paramKey => $paramValue) {
            $statement->bindValue(':' . $paramKey, $paramValue, PDO::PARAM_INT);
        }

        $statement->execute();
        $commentsByCallId = [];

        foreach ($statement->fetchAll() as $row) {
            $callId = (int) ($row['id_omega_chamado'] ?? 0);

            if ($callId <= 0 || !isset($rowsById[$callId])) {
                continue;
            }

            $comment = trim((string) ($row['comentario'] ?? ''));

            if ($comment === '') {
                continue;
            }

            $authorType = strtoupper(trim((string) ($row['tipo_autor'] ?? '')));
            $functionalAuthor = trim((string) ($row['funcional_autor'] ?? ''));
            $role = $this->resolveCommentRole($authorType, $functionalAuthor, (array) $rowsById[$callId]);
            $contextRow = (array) $rowsById[$callId];
            $author = $role === 'analyst'
                ? trim((string) ($contextRow['analyst_label'] ?? ''))
                : trim((string) ($contextRow['user_label'] ?? ''));

            if ($author === '') {
                $author = $functionalAuthor !== ''
                    ? $functionalAuthor
                    : ($role === 'analyst' ? 'Analista' : 'Solicitante');
            }

            $commentsByCallId[$callId][] = [
                'role' => $role,
                'author' => $author,
                'timestamp' => trim((string) ($row['dt_comentario'] ?? '')),
                'message' => $comment,
            ];
        }

        return $commentsByCallId;
    }

    private function resolveCommentRole(string $authorType, string $functionalAuthor, array $contextRow): string
    {
        if (in_array($authorType, ['ANALISTA', 'ATENDENTE', 'ANALYST'], true)) {
            return 'analyst';
        }

        if (in_array($authorType, ['SOLICITANTE', 'USUARIO', 'USER'], true)) {
            return 'user';
        }

        $analystCode = trim((string) ($contextRow['analyst_code'] ?? ''));

        if ($functionalAuthor !== '' && $analystCode !== '' && $functionalAuthor === $analystCode) {
            return 'analyst';
        }

        return 'user';
    }

    private function mergeThreadEntries(array $baseThread, array $commentThread): array
    {
        $mergedThread = [];

        foreach (array_merge($baseThread, $commentThread) as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            $message = trim((string) ($entry['message'] ?? ''));

            if ($message === '') {
                continue;
            }

            $mergedThread[] = [
                'role' => trim((string) ($entry['role'] ?? 'user')) === 'analyst' ? 'analyst' : 'user',
                'author' => trim((string) ($entry['author'] ?? '')),
                'timestamp' => trim((string) ($entry['timestamp'] ?? '')),
                'message' => $message,
            ];
        }

        usort($mergedThread, static function (array $left, array $right): int {
            $leftTimestamp = trim((string) ($left['timestamp'] ?? ''));
            $rightTimestamp = trim((string) ($right['timestamp'] ?? ''));

            if ($leftTimestamp === $rightTimestamp) {
                return strcmp((string) ($left['message'] ?? ''), (string) ($right['message'] ?? ''));
            }

            if ($leftTimestamp === '') {
                return 1;
            }

            if ($rightTimestamp === '') {
                return -1;
            }

            return strcmp($leftTimestamp, $rightTimestamp);
        });

        return $mergedThread;
    }

    private function resolveLastThreadTimestamp(array $thread): string
    {
        $lastTimestamp = '';

        foreach ($thread as $entry) {
            if (!is_array($entry)) {
                continue;
            }

            $timestamp = trim((string) ($entry['timestamp'] ?? ''));

            if ($timestamp !== '' && ($lastTimestamp === '' || strcmp($timestamp, $lastTimestamp) > 0)) {
                $lastTimestamp = $timestamp;
            }
        }

        return $lastTimestamp;
    }

    private function sortRowsByRecency(array $rows): array
    {
        usort($rows, static function (array $left, array $right): int {
            $leftTimestamp = trim((string) ($left['updated_at'] ?? $left['opened_at'] ?? ''));
            $rightTimestamp = trim((string) ($right['updated_at'] ?? $right['opened_at'] ?? ''));

            if ($leftTimestamp === $rightTimestamp) {
                return (int) ($right['id'] ?? 0) <=> (int) ($left['id'] ?? 0);
            }

            return strcmp($rightTimestamp, $leftTimestamp);
        });

        return $rows;
    }

    private function ensureCommentTable(): void
    {
        if ($this->hasTable(self::COMMENT_TABLE_NAME)) {
            return;
        }

        $this->connection->exec(
            'CREATE TABLE IF NOT EXISTS `' . self::COMMENT_TABLE_NAME . '` (
                `id_omega_chamado_comentario` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_omega_chamado` BIGINT(20) UNSIGNED NOT NULL,
                `funcional_autor` CHAR(7) NOT NULL DEFAULT "",
                `tipo_autor` VARCHAR(20) NOT NULL DEFAULT "SOLICITANTE",
                `comentario` TEXT NOT NULL,
                `dt_comentario` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `ativo_sn` TINYINT(1) NOT NULL DEFAULT 1,
                `origem_carga` VARCHAR(50) DEFAULT NULL,
                `dt_inclusao` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `dt_atualizacao` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id_omega_chamado_comentario`),
                KEY `idx_omega_comentario_chamado` (`id_omega_chamado`),
                KEY `idx_omega_comentario_ativo` (`ativo_sn`, `dt_comentario`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8'
        );

        $this->tableAvailability[self::COMMENT_TABLE_NAME] = true;
    }

    private function ensureMovementTable(): void
    {
        if ($this->hasTable(self::MOVEMENT_TABLE_NAME)) {
            return;
        }

        $this->connection->exec(
            'CREATE TABLE IF NOT EXISTS `' . self::MOVEMENT_TABLE_NAME . '` (
                `id_omega_chamado_movimentacao` BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
                `id_omega_chamado` BIGINT(20) UNSIGNED NOT NULL,
                `tipo_movimentacao` VARCHAR(30) NOT NULL,
                `funcional_responsavel` CHAR(7) NOT NULL,
                `id_omega_status_origem` BIGINT(20) UNSIGNED DEFAULT NULL,
                `id_omega_status_destino` BIGINT(20) UNSIGNED DEFAULT NULL,
                `id_omega_time_origem` BIGINT(20) UNSIGNED DEFAULT NULL,
                `id_omega_time_destino` BIGINT(20) UNSIGNED DEFAULT NULL,
                `id_omega_categoria_origem` BIGINT(20) UNSIGNED DEFAULT NULL,
                `id_omega_categoria_destino` BIGINT(20) UNSIGNED DEFAULT NULL,
                `funcional_analista_origem` CHAR(7) DEFAULT NULL,
                `funcional_analista_destino` CHAR(7) DEFAULT NULL,
                `observacao` VARCHAR(1000) DEFAULT NULL,
                `dt_movimentacao` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `ativo_sn` TINYINT(1) NOT NULL DEFAULT 1,
                `origem_carga` VARCHAR(50) DEFAULT NULL,
                `dt_inclusao` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                `dt_atualizacao` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (`id_omega_chamado_movimentacao`),
                KEY `idx_omega_mov_call` (`id_omega_chamado`),
                KEY `idx_omega_mov_active` (`ativo_sn`, `dt_movimentacao`)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8'
        );

        $this->tableAvailability[self::MOVEMENT_TABLE_NAME] = true;
    }

    private function ensureCallSchema(): void
    {
        if (!$this->hasTable(self::CALLS_TABLE_NAME) || $this->hasColumn(self::CALLS_TABLE_NAME, 'prioridade_label')) {
            return;
        }

        try {
            $this->connection->exec(
                'ALTER TABLE `' . self::CALLS_TABLE_NAME . '` ADD COLUMN prioridade_label VARCHAR(20) DEFAULT NULL AFTER funcional_analista_atual'
            );
        } catch (Throwable $exception) {
            // Ignore duplicate-column or unsupported-schema errors and fall back to inferred priority labels.
        }

        unset($this->columnAvailability[self::CALLS_TABLE_NAME]['prioridade_label']);
    }

    private function hasColumn(string $tableName, string $columnName): bool
    {
        if (isset($this->columnAvailability[$tableName]) && array_key_exists($columnName, $this->columnAvailability[$tableName])) {
            return $this->columnAvailability[$tableName][$columnName];
        }

        $statement = $this->connection->prepare(
            'SELECT COUNT(*)
               FROM information_schema.columns
              WHERE table_schema = DATABASE()
                AND table_name = :table_name
                AND column_name = :column_name'
        );
        $statement->execute([
            'table_name' => $tableName,
            'column_name' => $columnName,
        ]);

        $this->columnAvailability[$tableName][$columnName] = (int) $statement->fetchColumn() > 0;

        return $this->columnAvailability[$tableName][$columnName];
    }

    private function hasTable(string $tableName): bool
    {
        if (array_key_exists($tableName, $this->tableAvailability)) {
            return $this->tableAvailability[$tableName];
        }

        $statement = $this->connection->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = :table_name');
        $statement->execute(['table_name' => $tableName]);
        $this->tableAvailability[$tableName] = (int) $statement->fetchColumn() > 0;

        return $this->tableAvailability[$tableName];
    }
}