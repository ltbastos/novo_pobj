<?php

declare(strict_types=1);

namespace App\Services;

use RuntimeException;
use ZipArchive;

final class KnowledgeDocumentExtractor
{
    /** @var PdfGuideExtractor */
    private $pdfExtractor;

    public function __construct(?PdfGuideExtractor $pdfExtractor = null)
    {
        $this->pdfExtractor = $pdfExtractor ?? new PdfGuideExtractor();
    }

    public function supportsPath(string $filePath): bool
    {
        $extension = $this->extensionOf($filePath);

        return in_array($extension, $this->supportedExtensions(), true);
    }

    public function supportedExtensions(): array
    {
        return [
            'txt',
            'md',
            'csv',
            'tsv',
            'pdf',
            'docx',
            'docm',
            'xlsx',
            'xlsm',
            'pptx',
            'pptm',
        ];
    }

    public function extractText(string $filePath): string
    {
        if (!is_file($filePath) || !is_readable($filePath)) {
            throw new RuntimeException('A fonte de dados nao pode ser lida.');
        }

        $extension = $this->extensionOf($filePath);

        switch ($extension) {
            case 'txt':
            case 'md':
            case 'csv':
            case 'tsv':
                return $this->extractPlainText($filePath);

            case 'pdf':
                return $this->pdfExtractor->extractText($filePath);

            case 'docx':
            case 'docm':
                return $this->extractOfficeArchive($filePath, [
                    '/^word\/(document|header\d+|footer\d+|footnotes|endnotes)\.xml$/i',
                    '/^docProps\/(core|app)\.xml$/i',
                ]);

            case 'xlsx':
            case 'xlsm':
                return $this->extractOfficeArchive($filePath, [
                    '/^xl\/sharedStrings\.xml$/i',
                    '/^xl\/comments\d*\.xml$/i',
                    '/^docProps\/(core|app)\.xml$/i',
                ]);

            case 'pptx':
            case 'pptm':
                return $this->extractOfficeArchive($filePath, [
                    '/^ppt\/slides\/slide\d+\.xml$/i',
                    '/^ppt\/notesSlides\/notesSlide\d+\.xml$/i',
                    '/^docProps\/(core|app)\.xml$/i',
                ]);
        }

        throw new RuntimeException('Formato de fonte de dados nao suportado.');
    }

    private function extractPlainText(string $filePath): string
    {
        $contents = file_get_contents($filePath);

        if (!is_string($contents) || trim($contents) === '') {
            throw new RuntimeException('Nao encontrei conteudo textual nessa fonte de dados.');
        }

        $normalized = $this->normalizeText($contents);

        if ($normalized === '') {
            throw new RuntimeException('Nao encontrei conteudo textual nessa fonte de dados.');
        }

        return $normalized;
    }

    private function extractOfficeArchive(string $filePath, array $entryPatterns): string
    {
        if (!class_exists(ZipArchive::class)) {
            throw new RuntimeException('A extensao ZipArchive do PHP precisa estar habilitada para ler documentos Office.');
        }

        $archive = new ZipArchive();
        $openResult = $archive->open($filePath);

        if ($openResult !== true) {
            throw new RuntimeException('Nao foi possivel abrir a fonte Office enviada.');
        }

        $parts = [];

        for ($index = 0; $index < $archive->numFiles; $index++) {
            $entryName = (string) $archive->getNameIndex($index);

            if (!$this->matchesAnyPattern($entryName, $entryPatterns)) {
                continue;
            }

            $entryContents = $archive->getFromIndex($index);

            if (!is_string($entryContents) || trim($entryContents) === '') {
                continue;
            }

            $text = $this->extractXmlText($entryContents);

            if ($text !== '') {
                $parts[] = $text;
            }
        }

        $archive->close();

        $combined = $this->normalizeText(implode("\n\n", $parts));

        if ($combined === '') {
            throw new RuntimeException('Nao encontrei texto legivel nessa fonte Office.');
        }

        return $combined;
    }

    private function extractXmlText(string $xml): string
    {
        $xml = preg_replace('/<\/(w:p|a:p|si|row|text:p|dc:title|dc:subject|dc:description)>/i', "$0\n", $xml) ?? $xml;
        $xml = preg_replace('/<(br|w:br|a:br)\s*\/?\s*>/i', "\n", $xml) ?? $xml;
        $text = html_entity_decode(strip_tags($xml), ENT_QUOTES | ENT_XML1, 'UTF-8');

        return $this->normalizeText($text);
    }

    private function matchesAnyPattern(string $entryName, array $entryPatterns): bool
    {
        foreach ($entryPatterns as $pattern) {
            if (@preg_match($pattern, $entryName) === 1) {
                return true;
            }
        }

        return false;
    }

    private function normalizeText(string $text): string
    {
        $text = str_replace(["\r\n", "\r"], "\n", $text);
        $text = preg_replace('/\x{FEFF}/u', '', $text) ?? $text;
        $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]+/u', ' ', $text) ?? $text;
        $text = preg_replace('/[ \t]+/', ' ', $text) ?? $text;
        $text = preg_replace('/\n{3,}/', "\n\n", $text) ?? $text;

        return trim($text);
    }

    private function extensionOf(string $filePath): string
    {
        return strtolower((string) pathinfo($filePath, PATHINFO_EXTENSION));
    }
}