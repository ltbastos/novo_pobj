<?php

declare(strict_types=1);

namespace App\Services;

use DateTimeImmutable;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use RuntimeException;
use SplFileInfo;

final class PrimeAssistantService
{
    private const OUT_OF_SCOPE_MESSAGE = 'Posso ajudar apenas com o POBJ. Isso não está no manual. 🙂';

    /** @var KnowledgeDocumentExtractor */
    private $extractor;

    /** @var string */
    private $knowledgeRoot;

    /** @var string */
    private $cacheRoot;

    /** @var string */
    private $indexPath;

    /** @var array */
    private $config;

    public function __construct(
        ?KnowledgeDocumentExtractor $extractor = null,
        ?string $knowledgeRoot = null,
        ?string $cacheRoot = null
    ) {
        $this->config = $this->loadConfig();
        $this->extractor = $extractor ?? new KnowledgeDocumentExtractor();

        $configuredKnowledgeRoot = trim((string) ($this->config['knowledge_base_path'] ?? ''));
        $this->knowledgeRoot = $knowledgeRoot ?? ($configuredKnowledgeRoot !== '' ? $configuredKnowledgeRoot : project_path('base_conhecimento'));
        $this->cacheRoot = $cacheRoot ?? storage_path('assistant-cache');
        $this->indexPath = $this->cacheRoot . DIRECTORY_SEPARATOR . 'knowledge.index.json';

        ensure_directory($this->knowledgeRoot);
        ensure_directory($this->cacheRoot);
    }

    public function listGuides(): array
    {
        $documents = [];

        foreach ($this->discoverKnowledgeDocuments() as $document) {
            $documents[] = [
                'id' => (string) ($document['id'] ?? ''),
                'name' => (string) ($document['name'] ?? 'Fonte'),
                'uploaded_at' => (string) ($document['updated_at'] ?? ''),
                'chars' => $this->documentCharacterCount((string) ($document['path'] ?? '')),
                'excerpt' => (string) ($document['type_label'] ?? ''),
            ];
        }

        return $documents;
    }

    public function answerQuestion(string $question, array $history = [], string $userName = ''): array
    {
        $question = trim($question);

        if ($question === '') {
            throw new RuntimeException('Campo "question" é obrigatório.');
        }

        $model = $this->configuredModel();
        $index = $this->buildOrLoadIndex();

        if (empty($index['items'])) {
            return [
                'answer' => self::OUT_OF_SCOPE_MESSAGE,
                'sources' => [],
                'model' => $model,
            ];
        }

        $top = $this->retrieveTopK($question, $index, 6);

        if ($top === []) {
            return [
                'answer' => self::OUT_OF_SCOPE_MESSAGE,
                'sources' => [],
                'model' => $model,
            ];
        }

        $answer = $this->requestOpenAi(
            $this->buildSystemPrompt(),
            $this->buildUserPrompt($this->extractUserName($userName), $question, $this->buildContext($top)),
            $model
        );

        if ($this->isOutOfScopeAnswer($answer)) {
            return [
                'answer' => self::OUT_OF_SCOPE_MESSAGE,
                'sources' => [],
                'model' => $model,
            ];
        }

        return [
            'answer' => $answer,
            'sources' => $this->buildSources($top),
            'model' => $model,
        ];
    }

    private function requestOpenAi(string $systemPrompt, string $userPrompt, string $model): string
    {
        $response = $this->httpPostJson(
            'https://api.openai.com/v1/chat/completions',
            ['Authorization: Bearer ' . $this->configuredApiKey()],
            $this->buildChatPayload($systemPrompt, $userPrompt, $model)
        );

        $content = $response['choices'][0]['message']['content'] ?? '';

        if (is_array($content)) {
            $content = implode("\n", array_values(array_filter(array_map(static function ($item): string {
                return trim((string) ($item['text'] ?? $item['content'] ?? ''));
            }, $content))));
        }

        $answer = trim((string) $content);

        if ($answer === '') {
            throw new RuntimeException('A OpenAI não retornou texto na resposta.');
        }

        return $answer;
    }

    private function buildChatPayload(string $systemPrompt, string $userPrompt, string $model): array
    {
        $payload = [
            'model' => $model,
            'messages' => [
                ['role' => 'system', 'content' => $systemPrompt],
                ['role' => 'user', 'content' => $userPrompt],
            ],
        ];

        if (!preg_match('/\b(gpt-5-mini|gpt-5-nano)\b/i', $model)) {
            $payload['temperature'] = 0.2;
        }

        return $payload;
    }

    private function buildSystemPrompt(): string
    {
        return <<<'SYS'
    Você é o **Assistente POBJ** para agências no Brasil.
REGRAS OBRIGATÓRIAS:
    1) ESCOPO FECHADO: responda **somente** com base no conteúdo dos manuais do **POBJ** fornecidos no *Contexto*.
   • Se a pergunta estiver fora do escopo ou o contexto não trouxer evidência suficiente, responda **em 1 linha**:
        "Posso ajudar apenas com o POBJ. Isso não está no manual. 🙂"
2) ESTILO: seja **direto ao ponto**, **nada verboso**. No máximo **2–3 frases curtas** ou **até 3 bullets** (curtos).
   • Tom simpático e animado; use **1 emoji** pertinente (no início ou fim). Evite vários emojis.
3) CITAÇÕES: quando afirmar uma regra/dado, referencie o trecho como **[arquivo #chunk]** quando isso ajudar.
4) AMBIGUIDADE: se faltar um detalhe essencial, faça **no máximo 1** pergunta de esclarecimento em 1 linha.
5) PERSONALIZAÇÃO: se for informado "Usuário: NOME", **cumprimente pelo primeiro nome** no início (ex.: "Oi, Ana!").
6) Português do Brasil, claro e profissional.
SYS;
    }

    private function buildUserPrompt(string $userName, string $question, string $context): string
    {
        $userLine = $userName !== '' ? 'Usuário: ' . $userName : 'Usuário: (não informado)';

        return $userLine . "\n"
            . 'Pergunta: ' . $question . "\n\n"
            . 'Contexto (trechos recuperados dos manuais):' . "\n"
            . $context;
    }

    private function buildContext(array $top): string
    {
        $context = '';

        foreach ($top as $index => $hit) {
            $context .= '[' . ($index + 1) . '] (' . (string) ($hit['name'] ?? 'Fonte') . ' #' . (string) ($hit['chunk_id'] ?? '') . ")\n"
                . trim((string) ($hit['text'] ?? ''))
                . "\n\n";
        }

        return $context !== '' ? trim($context) : 'Nenhum documento disponível em base_conhecimento.';
    }

    private function buildSources(array $top): array
    {
        $sources = [];

        foreach ($top as $index => $hit) {
            $sources[] = [
                'rank' => $index + 1,
                'file' => (string) ($hit['name'] ?? 'Fonte'),
                'path' => (string) ($hit['source'] ?? ''),
                'chunk' => (string) ($hit['chunk_id'] ?? ''),
                'score' => round((float) ($hit['score'] ?? 0.0), 4),
            ];
        }

        return $sources;
    }

    private function extractUserName(string $userName): string
    {
        $parts = preg_split('/\s+/', trim($userName)) ?: [];

        return $parts !== [] ? trim((string) $parts[0]) : '';
    }

    private function buildOrLoadIndex(): array
    {
        $documents = $this->discoverKnowledgeDocuments();
        $signature = [];

        foreach ($documents as $document) {
            $path = (string) ($document['path'] ?? '');
            $signature[$path] = is_file($path) ? (int) (filemtime($path) ?: 0) : 0;
        }

        if (is_file($this->indexPath)) {
            $index = json_decode((string) file_get_contents($this->indexPath), true);

            if (is_array($index) && ($index['signature'] ?? null) === $signature) {
                return $index;
            }
        }

        $items = [];

        foreach ($documents as $document) {
            $path = (string) ($document['path'] ?? '');
            $text = $this->documentText($path);

            if ($text === '') {
                continue;
            }

            foreach ($this->chunkText($text, 1600, 200) as $chunk) {
                $items[] = [
                    'source' => $path,
                    'name' => (string) ($document['name'] ?? basename($path)),
                    'chunk_id' => (int) ($chunk['id'] ?? 0),
                    'text' => (string) ($chunk['text'] ?? ''),
                ];
            }
        }

        if ($items === []) {
            $index = [
                'items' => [],
                'embeddings' => [],
                'signature' => $signature,
                'built_at' => time(),
            ];

            file_put_contents($this->indexPath, json_encode($index, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

            return $index;
        }

        $inputs = array_map(static function (array $item): string {
            return (string) ($item['text'] ?? '');
        }, $items);

        $index = [
            'items' => $items,
            'embeddings' => $this->embed($inputs),
            'signature' => $signature,
            'built_at' => time(),
        ];

        file_put_contents($this->indexPath, json_encode($index, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));

        return $index;
    }

    private function retrieveTopK(string $query, array $index, int $limit = 6): array
    {
        if ($query === '' || empty($index['items']) || empty($index['embeddings'])) {
            return [];
        }

        $queryEmbeddings = $this->embed([$query]);
        $queryVector = $queryEmbeddings[0] ?? null;

        if (!is_array($queryVector)) {
            return [];
        }

        $scored = [];

        foreach ((array) ($index['items'] ?? []) as $itemIndex => $item) {
            $embedding = $index['embeddings'][$itemIndex] ?? null;

            if (!is_array($embedding)) {
                continue;
            }

            $scored[] = [
                'score' => $this->cosine($queryVector, $embedding),
                'source' => (string) ($item['source'] ?? ''),
                'name' => (string) ($item['name'] ?? 'Fonte'),
                'chunk_id' => (int) ($item['chunk_id'] ?? 0),
                'text' => (string) ($item['text'] ?? ''),
            ];
        }

        usort($scored, static function (array $left, array $right): int {
            return ((float) ($left['score'] ?? 0.0) < (float) ($right['score'] ?? 0.0)) ? 1 : -1;
        });

        return array_slice($scored, 0, max(1, $limit));
    }

    private function embed(array $texts): array
    {
        if ($texts === []) {
            return [];
        }

        $apiKey = $this->configuredApiKey();
        $model = $this->configuredEmbeddingModel();
        $batchSize = 80;
        $vectors = [];

        for ($offset = 0, $count = count($texts); $offset < $count; $offset += $batchSize) {
            $slice = array_slice($texts, $offset, $batchSize);
            $response = $this->httpPostJson(
                'https://api.openai.com/v1/embeddings',
                ['Authorization: Bearer ' . $apiKey],
                [
                    'model' => $model,
                    'input' => array_values($slice),
                ]
            );

            foreach ((array) ($response['data'] ?? []) as $index => $row) {
                $vectors[$offset + $index] = $row['embedding'] ?? [];
            }
        }

        ksort($vectors);

        return array_values($vectors);
    }

    private function cosine(array $left, array $right): float
    {
        $dot = 0.0;
        $leftNorm = 0.0;
        $rightNorm = 0.0;
        $count = min(count($left), count($right));

        for ($index = 0; $index < $count; $index++) {
            $leftValue = (float) $left[$index];
            $rightValue = (float) $right[$index];
            $dot += $leftValue * $rightValue;
            $leftNorm += $leftValue * $leftValue;
            $rightNorm += $rightValue * $rightValue;
        }

        return ($leftNorm > 0.0 && $rightNorm > 0.0)
            ? $dot / (sqrt($leftNorm) * sqrt($rightNorm))
            : 0.0;
    }

    private function httpPostJson(string $url, array $headers, array $payload): array
    {
        if (!function_exists('curl_init')) {
            throw new RuntimeException('A extensão cURL do PHP precisa estar habilitada para chamar a OpenAI.');
        }

        $request = curl_init($url);
        $headers[] = 'Content-Type: application/json';

        curl_setopt_array($request, [
            CURLOPT_POST => true,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
            CURLOPT_TIMEOUT => 90,
        ]);

        $rawResponse = curl_exec($request);

        if ($rawResponse === false) {
            $error = curl_error($request);
            curl_close($request);
            throw new RuntimeException('Falha de rede: ' . ($error !== '' ? $error : 'erro desconhecido.'));
        }

        $statusCode = (int) (curl_getinfo($request, CURLINFO_HTTP_CODE) ?: 0);
        curl_close($request);

        $decoded = json_decode($rawResponse, true);

        if (!is_array($decoded)) {
            throw new RuntimeException('Resposta inválida da API (HTTP ' . $statusCode . ').');
        }

        if ($statusCode < 200 || $statusCode >= 300) {
            $message = $decoded['error']['message'] ?? ($decoded['error'] ?? 'Erro da API');
            throw new RuntimeException('OpenAI HTTP ' . $statusCode . ': ' . $message);
        }

        return $decoded;
    }

    private function discoverKnowledgeDocuments(): array
    {
        if (!is_dir($this->knowledgeRoot)) {
            return [];
        }

        $documents = [];
        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($this->knowledgeRoot, \FilesystemIterator::SKIP_DOTS)
        );

        foreach ($iterator as $fileInfo) {
            if (!$fileInfo instanceof SplFileInfo || !$fileInfo->isFile()) {
                continue;
            }

            $path = $fileInfo->getPathname();
            $name = $fileInfo->getFilename();

            if (strpos($name, '~$') === 0 || !$this->extractor->supportsPath($path)) {
                continue;
            }

            $documents[] = [
                'id' => sha1($path),
                'path' => $path,
                'name' => $this->relativeKnowledgePath($path),
                'updated_at' => (new DateTimeImmutable('@' . (string) $fileInfo->getMTime()))->format(DATE_ATOM),
                'type_label' => strtoupper((string) pathinfo($path, PATHINFO_EXTENSION)),
            ];
        }

        usort($documents, static function (array $left, array $right): int {
            return strcmp((string) ($left['name'] ?? ''), (string) ($right['name'] ?? ''));
        });

        return $documents;
    }

    private function documentText(string $filePath): string
    {
        if ($filePath === '' || !is_file($filePath)) {
            return '';
        }

        $cachePath = $this->documentCachePath($filePath);

        if (is_file($cachePath)) {
            $cached = file_get_contents($cachePath);

            return is_string($cached) ? trim($cached) : '';
        }

        try {
            $text = trim($this->extractor->extractText($filePath));
        } catch (RuntimeException $exception) {
            return '';
        }

        if ($text === '') {
            return '';
        }

        $this->purgeStaleDocumentCaches($filePath, $cachePath);
        file_put_contents($cachePath, $text);

        return $text;
    }

    private function documentCharacterCount(string $filePath): int
    {
        $text = $this->documentText($filePath);

        return $text !== '' ? $this->stringLength($text) : 0;
    }

    private function documentCachePath(string $filePath): string
    {
        $resolvedPath = realpath($filePath) ?: $filePath;
        $hash = sha1($resolvedPath);
        $modifiedAt = is_file($filePath) ? (string) (filemtime($filePath) ?: 0) : '0';

        return $this->cacheRoot . DIRECTORY_SEPARATOR . $hash . '-' . $modifiedAt . '.txt';
    }

    private function purgeStaleDocumentCaches(string $filePath, string $currentCachePath): void
    {
        $resolvedPath = realpath($filePath) ?: $filePath;
        $hash = sha1($resolvedPath);
        $pattern = $this->cacheRoot . DIRECTORY_SEPARATOR . $hash . '-*.txt';

        foreach (glob($pattern) ?: [] as $cachePath) {
            if ($cachePath === $currentCachePath) {
                continue;
            }

            @unlink($cachePath);
        }
    }

    private function chunkText(string $text, int $chunkSize = 1600, int $overlap = 200): array
    {
        $text = str_replace("\r", '', $text);
        $length = strlen($text);
        $cursor = 0;
        $chunkId = 1;
        $chunks = [];

        while ($cursor < $length) {
            $end = min($length, $cursor + $chunkSize);
            $slice = trim(substr($text, $cursor, $end - $cursor));

            if ($slice !== '') {
                $chunks[] = [
                    'id' => $chunkId++,
                    'text' => $slice,
                ];
            }

            if ($end >= $length) {
                break;
            }

            $cursor = max(0, $end - $overlap);
        }

        return $chunks;
    }

    private function relativeKnowledgePath(string $filePath): string
    {
        $root = str_replace('\\', '/', rtrim($this->knowledgeRoot, "\\/"));
        $path = str_replace('\\', '/', $filePath);

        if (strpos($path, $root . '/') === 0) {
            return substr($path, strlen($root) + 1);
        }

        return basename($filePath);
    }

    private function isOutOfScopeAnswer(string $answer): bool
    {
        $normalized = $this->normalizeForSearch($answer);

        if ($normalized === '') {
            return true;
        }

        return strpos($normalized, 'posso ajudar apenas com o pobj') !== false
            || strpos($normalized, 'isso nao esta no manual') !== false;
    }

    private function normalizeForSearch(string $value): string
    {
        $value = $this->toLower($value);
        $value = strtr($value, [
            'á' => 'a',
            'à' => 'a',
            'ã' => 'a',
            'â' => 'a',
            'ä' => 'a',
            'é' => 'e',
            'è' => 'e',
            'ê' => 'e',
            'ë' => 'e',
            'í' => 'i',
            'ì' => 'i',
            'î' => 'i',
            'ï' => 'i',
            'ó' => 'o',
            'ò' => 'o',
            'õ' => 'o',
            'ô' => 'o',
            'ö' => 'o',
            'ú' => 'u',
            'ù' => 'u',
            'û' => 'u',
            'ü' => 'u',
            'ç' => 'c',
        ]);

        if (function_exists('iconv')) {
            $ascii = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $value);

            if (is_string($ascii) && $ascii !== '') {
                $value = $ascii;
            }
        }

        $value = preg_replace('/[^a-z0-9\s]+/', ' ', $value) ?? $value;
        $value = preg_replace('/\s+/', ' ', trim($value)) ?? trim($value);

        return trim($value);
    }

    private function stringLength(string $value): int
    {
        return function_exists('mb_strlen') ? (int) mb_strlen($value, 'UTF-8') : strlen($value);
    }

    private function toLower(string $value): string
    {
        return function_exists('mb_strtolower') ? (string) mb_strtolower($value, 'UTF-8') : strtolower($value);
    }

    private function loadConfig(): array
    {
        $configPath = project_path('config/assistant.php');

        if (!is_file($configPath)) {
            return [];
        }

        $config = require $configPath;

        return is_array($config) ? $config : [];
    }

    private function configuredApiKey(): string
    {
        $apiKey = trim((string) ($this->config['openai_api_key'] ?? ''));

        if ($apiKey === '') {
            $apiKey = trim((string) getenv('OPENAI_API_KEY'));
        }

        if ($apiKey === '') {
            throw new RuntimeException('OPENAI_API_KEY não configurada');
        }

        return $apiKey;
    }

    private function configuredModel(): string
    {
        $model = trim((string) ($this->config['openai_model'] ?? 'gpt-5-mini'));

        return $model !== '' ? $model : 'gpt-5-mini';
    }

    private function configuredEmbeddingModel(): string
    {
        $model = trim((string) ($this->config['openai_embed_model'] ?? 'text-embedding-3-small'));

        return $model !== '' ? $model : 'text-embedding-3-small';
    }
}