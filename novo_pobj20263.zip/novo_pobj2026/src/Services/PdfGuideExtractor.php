<?php

declare(strict_types=1);

namespace App\Services;

use RuntimeException;

final class PdfGuideExtractor
{
    public function extractText(string $pdfPath): string
    {
        if (!is_file($pdfPath) || !is_readable($pdfPath)) {
            throw new RuntimeException('O PDF enviado nao pode ser lido.');
        }

        $contents = file_get_contents($pdfPath);

        if ($contents === false || $contents === '') {
            throw new RuntimeException('Nao foi possivel abrir o conteudo do PDF.');
        }

        $textSegments = [];

        if (preg_match_all('/<<(.*?)>>\s*stream\r?\n(.*?)\r?\nendstream/s', $contents, $matches, PREG_SET_ORDER)) {
            foreach ($matches as $match) {
                $dictionary = (string) ($match[1] ?? '');
                $stream = (string) ($match[2] ?? '');
                $decoded = $this->decodeStream($dictionary, $stream);

                if ($decoded === '') {
                    continue;
                }

                $streamText = $this->extractTextBlocks($decoded);

                if ($streamText !== '') {
                    $textSegments[] = $streamText;
                }
            }
        }

        $text = $this->normalizeText(implode("\n", $textSegments));

        if ($text === '') {
            $text = $this->normalizeText($this->extractTextBlocks($contents));
        }

        if ($text === '') {
            throw new RuntimeException('Nao encontrei texto legivel nesse PDF. Tente um PDF com texto selecionavel.');
        }

        return $text;
    }

    private function decodeStream(string $dictionary, string $stream): string
    {
        $stream = trim($stream, "\r\n");

        if ($stream === '') {
            return '';
        }

        if (stripos($dictionary, '/FlateDecode') !== false) {
            $decoded = @zlib_decode($stream);

            if (!is_string($decoded) || $decoded === '') {
                $decoded = @gzuncompress($stream);
            }

            if (is_string($decoded) && $decoded !== '') {
                return $decoded;
            }
        }

        return $stream;
    }

    private function extractTextBlocks(string $content): string
    {
        $segments = [];

        if (preg_match_all('/BT(.*?)ET/s', $content, $matches)) {
            $segments = $matches[1];
        }

        if ($segments === []) {
            $segments = [$content];
        }

        $parts = [];

        foreach ($segments as $segment) {
            $literalMatches = [];
            preg_match_all('/\[(.*?)\]\s*TJ/s', $segment, $literalMatches);

            foreach ((array) ($literalMatches[1] ?? []) as $arrayChunk) {
                $parts[] = $this->extractArrayStrings((string) $arrayChunk);
            }

            $singleMatches = [];
            preg_match_all('/(\((?:\\\\.|[^\\\\)])*\)|<[0-9A-Fa-f\s]+>)\s*(?:Tj|\'|\")/s', $segment, $singleMatches);

            foreach ((array) ($singleMatches[1] ?? []) as $rawToken) {
                $parts[] = $this->decodePdfToken((string) $rawToken);
            }
        }

        return trim(implode("\n", array_filter(array_map('trim', $parts))));
    }

    private function extractArrayStrings(string $arrayChunk): string
    {
        $parts = [];

        if (preg_match_all('/\((?:\\\\.|[^\\\\)])*\)|<[0-9A-Fa-f\s]+>/', $arrayChunk, $matches)) {
            foreach ((array) ($matches[0] ?? []) as $token) {
                $parts[] = $this->decodePdfToken((string) $token);
            }
        }

        return trim(implode(' ', array_filter(array_map('trim', $parts))));
    }

    private function decodePdfToken(string $token): string
    {
        $token = trim($token);

        if ($token === '') {
            return '';
        }

        if ($token[0] === '(') {
            return $this->decodeLiteralString($token);
        }

        if ($token[0] === '<') {
            return $this->decodeHexString($token);
        }

        return '';
    }

    private function decodeLiteralString(string $token): string
    {
        $value = substr($token, 1, -1);

        $value = preg_replace_callback('/\\\\([0-7]{1,3})/', static function (array $match): string {
            return chr(octdec((string) ($match[1] ?? '0')));
        }, $value) ?? $value;

        $replacements = [
            '\\\\n' => "\n",
            '\\\\r' => "\r",
            '\\\\t' => "\t",
            '\\\\b' => "\b",
            '\\\\f' => "\f",
            '\\\\(' => '(',
            '\\\\)' => ')',
            '\\\\\\\\' => '\\\\',
        ];

        return strtr($value, $replacements);
    }

    private function decodeHexString(string $token): string
    {
        $hex = preg_replace('/[^0-9A-Fa-f]/', '', substr($token, 1, -1));

        if (!is_string($hex) || $hex === '') {
            return '';
        }

        if (strlen($hex) % 2 !== 0) {
            $hex .= '0';
        }

        $binary = hex2bin($hex);

        if ($binary === false || $binary === '') {
            return '';
        }

        if (substr($binary, 0, 2) === "\xFE\xFF" && function_exists('mb_convert_encoding')) {
            return (string) mb_convert_encoding(substr($binary, 2), 'UTF-8', 'UTF-16BE');
        }

        if (substr($binary, 0, 2) === "\xFF\xFE" && function_exists('mb_convert_encoding')) {
            return (string) mb_convert_encoding(substr($binary, 2), 'UTF-8', 'UTF-16LE');
        }

        return $binary;
    }

    private function normalizeText(string $text): string
    {
        $text = str_replace(["\r\n", "\r"], "\n", $text);
        $text = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F]+/', ' ', $text) ?? $text;
        $text = preg_replace('/[ \t]+/', ' ', $text) ?? $text;
        $text = preg_replace('/\n{3,}/', "\n\n", $text) ?? $text;

        return trim($text);
    }
}