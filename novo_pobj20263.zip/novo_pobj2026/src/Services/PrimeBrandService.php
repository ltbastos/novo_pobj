<?php

declare(strict_types=1);

namespace App\Services;

use PDO;

final class PrimeBrandService
{
    /** @var PDO */
    private $connection;

    /** @var bool|null */
    private $hasManagementRelationTable = null;

    /** @var bool|null */
    private $hasMesuSubsegmentColumn = null;

    public function __construct(PDO $connection)
    {
        $this->connection = $connection;
    }

    public function resolveVisualTheme(?array $context, array $filters): array
    {
        $isPrime = $this->matchesSelectedFilters($filters);

        if (!$isPrime && is_array($context)) {
            $isPrime = $this->matchesProfileContext($context);
        }

        return [
            'code' => $isPrime ? 'prime' : 'classic',
            'is_prime' => $isPrime,
            'label' => $isPrime ? 'Bradesco Prime' : 'Bradesco Empresas',
            'logo_path' => 'assets/img/logo-bradesco-white.svg',
            'logo_alt' => 'Bradesco',
            'reference_path' => 'assets/img/prime-reference.svg',
            'bubble_label' => $isPrime ? 'IA Prime' : 'IA POBJ',
            'badge_copy' => $isPrime ? 'Modo Prime' : 'Modo POBJ',
        ];
    }

    private function matchesSelectedFilters(array $filters): bool
    {
        $agency = trim((string) ($filters['agencia'] ?? ''));

        if ($agency !== '' && $this->matchesPrimeAgency($agency)) {
            return true;
        }

        $regional = trim((string) ($filters['regional'] ?? ''));

        if ($regional !== '' && $this->matchesPrimeRegional($regional)) {
            return true;
        }

        $directorate = trim((string) ($filters['diretoria'] ?? ''));

        if ($directorate !== '' && $this->matchesPrimeDirectorate($directorate)) {
            return true;
        }

        $managementFunctional = trim((string) ($filters['gerente_gestao'] ?? ''));

        if ($managementFunctional !== '' && $this->matchesPrimeFunctional($managementFunctional)) {
            return true;
        }

        $commercialFunctional = trim((string) ($filters['gerente'] ?? ''));

        return $commercialFunctional !== '' && $this->matchesPrimeFunctional($commercialFunctional);
    }

    private function matchesProfileContext(array $context): bool
    {
        $scope = is_array($context['scope'] ?? null) ? $context['scope'] : [];
        $allowed = array_values(array_filter((array) ($scope['allowed'] ?? []), static function ($value): bool {
            return trim((string) $value) !== '';
        }));
        $scopeCode = strtoupper(trim((string) ($scope['code'] ?? '')));

        if ($allowed !== []) {
            if ($scopeCode === 'AG' && $this->matchesPrimeAgencies($allowed)) {
                return true;
            }

            if ($scopeCode === 'GR' && $this->matchesPrimeRegionals($allowed)) {
                return true;
            }

            if ($scopeCode === 'DR' && $this->matchesPrimeDirectorates($allowed)) {
                return true;
            }
        }

        $profile = is_array($context['profile'] ?? null) ? $context['profile'] : [];
        $functional = trim((string) ($profile['funcional'] ?? ''));

        return $functional !== '' && $this->matchesPrimeFunctional($functional);
    }

    private function matchesPrimeAgency(string $agency): bool
    {
        return $this->matchesByMesuField('juncao_ag', [$agency]);
    }

    private function matchesPrimeRegional(string $regional): bool
    {
        return $this->matchesByMesuField('juncao_gr', [$regional]);
    }

    private function matchesPrimeDirectorate(string $directorate): bool
    {
        return $this->matchesByMesuField('juncao_dr', [$directorate]);
    }

    private function matchesPrimeAgencies(array $agencies): bool
    {
        return $this->matchesByMesuField('juncao_ag', $agencies);
    }

    private function matchesPrimeRegionals(array $regionals): bool
    {
        return $this->matchesByMesuField('juncao_gr', $regionals);
    }

    private function matchesPrimeDirectorates(array $directorates): bool
    {
        return $this->matchesByMesuField('juncao_dr', $directorates);
    }

    private function matchesByMesuField(string $field, array $values): bool
    {
        $values = array_values(array_filter(array_map(static function ($value): string {
            return trim((string) $value);
        }, $values), static function (string $value): bool {
            return $value !== '';
        }));

        if ($values === []) {
            return false;
        }

        [$inSql, $params] = $this->buildInCondition('m.' . $field, $values, 'prime_field_');
        $sql = "SELECT 1
                FROM dMesu m
                WHERE m.ativo_sn = 1
                  AND $inSql
                  AND " . $this->primeConditionSql('m') . '
                LIMIT 1';

        return $this->queryExists($sql, $params);
    }

    private function matchesPrimeFunctional(string $functional): bool
    {
        $functional = trim($functional);

        if ($functional === '') {
            return false;
        }

        $directSql = "SELECT 1
                      FROM fMeta f
                      INNER JOIN dMesu m
                          ON m.juncao_ag = f.juncao_ag
                         AND m.ativo_sn = 1
                      WHERE f.ativo_sn = 1
                        AND f.funcional = :functional
                                                AND " . $this->primeConditionSql('m') . '
                      LIMIT 1';

        if ($this->queryExists($directSql, ['functional' => $functional])) {
            return true;
        }

        if ($this->hasManagementRelationTable()) {
            $managementSql = "SELECT 1
                              FROM fGestaoGerente gg
                              INNER JOIN fMeta f
                                  ON f.funcional = gg.funcional_gerente
                                 AND f.ativo_sn = 1
                              INNER JOIN dMesu m
                                  ON m.juncao_ag = f.juncao_ag
                                 AND m.ativo_sn = 1
                              WHERE gg.ativo_sn = 1
                                AND gg.funcional_gerente_gestao = :functional
                                                                AND " . $this->primeConditionSql('m') . '
                              LIMIT 1';

            if ($this->queryExists($managementSql, ['functional' => $functional])) {
                return true;
            }
        }

        $junctionSql = "SELECT 1
                        FROM fMultiJuncao j
                        INNER JOIN dMesu m
                            ON m.ativo_sn = 1
                           AND (
                                (j.tipo_juncao = 'AG' AND m.juncao_ag = j.juncao)
                                OR (j.tipo_juncao = 'GR' AND m.juncao_gr = j.juncao)
                                OR (j.tipo_juncao = 'DR' AND m.juncao_dr = j.juncao)
                           )
                        WHERE j.ativo_sn = 1
                          AND j.funcional = :functional
                                                    AND " . $this->primeConditionSql('m') . '
                        LIMIT 1';

        return $this->queryExists($junctionSql, ['functional' => $functional]);
    }

    private function primeConditionSql(string $alias): string
    {
        if ($this->hasMesuSubsegmentColumn()) {
            return sprintf("LOWER(COALESCE(%s.subsegmento, '')) = 'prime'", $alias);
        }

        return sprintf(
            "(LOWER(COALESCE(%s.nome_diretoria, '')) LIKE '%%norte%%' OR LOWER(COALESCE(%s.nome_regional, '')) LIKE '%%norte%%' OR LOWER(COALESCE(%s.nome_agencia, '')) LIKE '%%norte%%')",
            $alias,
            $alias,
            $alias
        );
    }

    private function buildInCondition(string $field, array $values, string $prefix): array
    {
        $params = [];
        $placeholders = [];

        foreach ($values as $index => $value) {
            $param = $prefix . $index;
            $params[$param] = $value;
            $placeholders[] = ':' . $param;
        }

        return [sprintf('%s IN (%s)', $field, implode(', ', $placeholders)), $params];
    }

    private function queryExists(string $sql, array $params): bool
    {
        $statement = $this->connection->prepare($sql);
        $statement->execute($params);

        return (bool) $statement->fetchColumn();
    }

    private function hasManagementRelationTable(): bool
    {
        if ($this->hasManagementRelationTable !== null) {
            return $this->hasManagementRelationTable;
        }

        $statement = $this->connection->query(
            "SELECT 1
             FROM information_schema.TABLES
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'fGestaoGerente'
             LIMIT 1"
        );

        $this->hasManagementRelationTable = (bool) $statement->fetchColumn();

        return $this->hasManagementRelationTable;
    }

    private function hasMesuSubsegmentColumn(): bool
    {
        if ($this->hasMesuSubsegmentColumn !== null) {
            return $this->hasMesuSubsegmentColumn;
        }

        $statement = $this->connection->query(
            "SELECT 1
             FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = 'dMesu'
               AND COLUMN_NAME = 'subsegmento'
             LIMIT 1"
        );

        $this->hasMesuSubsegmentColumn = (bool) $statement->fetchColumn();

        return $this->hasMesuSubsegmentColumn;
    }
}