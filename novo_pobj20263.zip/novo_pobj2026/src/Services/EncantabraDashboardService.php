<?php

declare(strict_types=1);

namespace App\Services;

use PDO;

final class EncantabraDashboardService
{
    private const TABLE_NAME = 'encantabra';
    private const TABLE = '`encantabra`';

    /** @var PDO */
    private $connection;

    /** @var bool|null */
    private $tableAvailable = null;

    public function __construct(PDO $connection)
    {
        $this->connection = $connection;
    }

    public function prepareFilters(array $requestedFilters = []): array
    {
        $profileOptions = [
            ['value' => 'SG', 'label' => 'Segmento'],
            ['value' => 'AG', 'label' => 'Agência'],
            ['value' => 'GC', 'label' => 'Gerente / Funcional'],
        ];

        if (!$this->hasLocalTable()) {
            return [
                'options' => [
                    'anomes' => [],
                    'perfil' => $profileOptions,
                    'segmento' => [],
                    'juncao' => [],
                    'funcional' => [],
                    'indicador' => [],
                ],
                'values' => [
                    'anomes' => '',
                    'perfil' => 'SG',
                    'segmento' => '',
                    'juncao' => '',
                    'funcional' => '',
                    'indicador' => '',
                ],
            ];
        }

        $monthOptions = $this->fetchMonthOptions();
        $segmentOptions = $this->fetchDistinctOptions('SEGMENTO_PAINEL');
        $requestedJuncao = trim((string) ($requestedFilters['juncao'] ?? ''));
        $requestedFunctional = trim((string) ($requestedFilters['funcional'] ?? ''));
        $requestedProfile = strtoupper(trim((string) ($requestedFilters['perfil'] ?? '')));
        $inferredProfile = 'SG';

        if ($requestedFunctional !== '') {
            $inferredProfile = 'GC';
        } elseif ($requestedJuncao !== '') {
            $inferredProfile = 'AG';
        }

        $selectedMonth = $this->sanitizeOption(
            trim((string) ($requestedFilters['anomes'] ?? '')),
            $monthOptions,
            (string) ($monthOptions[0]['value'] ?? '')
        );
        $selectedProfile = $this->sanitizeOption(
            $requestedProfile,
            $profileOptions,
            $inferredProfile
        );
        $selectedSegment = $this->sanitizeOption(
            trim((string) ($requestedFilters['segmento'] ?? '')),
            $segmentOptions,
            ''
        );

        $juncaoOptions = $this->fetchPairOptions(
            'COD_JUNC',
            'NOME_JUNC',
            [
                'anomes' => $selectedMonth,
                'perfil' => 'AG',
                'segmento' => $selectedSegment,
            ]
        );
        $selectedJuncao = $this->sanitizeOption($requestedJuncao, $juncaoOptions, '');

        $functionalOptions = $this->fetchPairOptions(
            'COD_FUNC',
            'NOME_FUNC',
            [
                'anomes' => $selectedMonth,
                'perfil' => 'GC',
                'segmento' => $selectedSegment,
                'juncao' => $selectedJuncao,
            ]
        );
        $selectedFunctional = $this->sanitizeOption($requestedFunctional, $functionalOptions, '');

        if ($selectedFunctional !== '' && $selectedProfile !== 'GC' && $requestedProfile === '') {
            $selectedProfile = 'GC';
        } elseif ($selectedJuncao !== '' && $selectedProfile === 'SG' && $requestedProfile === '') {
            $selectedProfile = 'AG';
        }

        $indicatorOptions = $this->fetchDistinctOptions(
            'INDICADOR',
            [
                'anomes' => $selectedMonth,
                'perfil' => $selectedProfile,
                'segmento' => $selectedSegment,
                'juncao' => $selectedJuncao,
                'funcional' => $selectedFunctional,
            ]
        );
        $selectedIndicator = $this->sanitizeOption(
            trim((string) ($requestedFilters['indicador'] ?? '')),
            $indicatorOptions,
            ''
        );

        return [
            'options' => [
                'anomes' => $monthOptions,
                'perfil' => $profileOptions,
                'segmento' => $segmentOptions,
                'juncao' => $juncaoOptions,
                'funcional' => $functionalOptions,
                'indicador' => $indicatorOptions,
            ],
            'values' => [
                'anomes' => $selectedMonth,
                'perfil' => $selectedProfile,
                'segmento' => $selectedSegment,
                'juncao' => $selectedJuncao,
                'funcional' => $selectedFunctional,
                'indicador' => $selectedIndicator,
            ],
        ];
    }

    public function getDashboardData(array $filters, int $analyticPage = 1): array
    {
        if (!$this->hasLocalTable()) {
            return [
                'reference' => [
                    'month_label' => '',
                    'scope_label' => 'Base EncantaBra não disponível no banco local.',
                    'profile_label' => 'Visão EncantaBra',
                    'segment_label' => '',
                ],
                'summary' => [
                    'score_avg' => 0.0,
                    'meta_avg' => 0.0,
                    'real_avg' => 0.0,
                    'rows_total' => 0,
                    'entities_total' => 0,
                    'indicators_total' => 0,
                    'best_indicator' => null,
                    'worst_indicator' => null,
                    'band' => ['label' => 'Sem dados', 'range' => 'Sem leitura', 'tone' => 'is-empty'],
                ],
                'status' => ['fan' => 0, 'encantador' => 0, 'expectativa' => 0, 'critico' => 0],
                'chart' => ['labels' => [], 'series' => [], 'max_value' => 150.0],
                'trimester_tables' => ['year' => '', 'tables' => []],
                'table' => ['title' => 'Performance mês a mês por indicador', 'subtitle' => '', 'columns' => [], 'rows' => []],
            ];
        }

        $selectedMonth = trim((string) ($filters['anomes'] ?? ''));
        $chartMonths = $this->buildMonthWindow($selectedMonth, 12);
        $summary = $this->fetchSummaryMetrics($filters);
        $indicatorRows = $this->fetchIndicatorTableRows($filters);
        $band = $this->resolveBandMeta(isset($summary['score_avg']) ? (float) $summary['score_avg'] : null);
        $bestIndicator = $indicatorRows !== [] ? $indicatorRows[0] : null;
        $worstIndicator = $indicatorRows !== [] ? $indicatorRows[count($indicatorRows) - 1] : null;
        $selectedYear = $this->resolveSelectedYear($selectedMonth);
        $analyticTable = $this->fetchAnalyticTableData($filters, $selectedYear, $analyticPage, 20);

        return [
            'reference' => [
                'month_label' => $this->formatAnoMesLabel($selectedMonth, false),
                'scope_label' => $this->buildScopeLabel($filters),
                'profile_label' => $this->resolveProfileLabel((string) ($filters['perfil'] ?? 'SG')),
                'segment_label' => trim((string) ($filters['segmento'] ?? '')) !== '' ? trim((string) $filters['segmento']) : 'Todos os segmentos',
            ],
            'summary' => [
                'score_avg' => (float) ($summary['score_avg'] ?? 0.0),
                'meta_avg' => (float) ($summary['meta_avg'] ?? 0.0),
                'real_avg' => (float) ($summary['real_avg'] ?? 0.0),
                'rows_total' => (int) ($summary['rows_total'] ?? 0),
                'entities_total' => (int) ($summary['entities_total'] ?? 0),
                'indicators_total' => (int) ($summary['indicators_total'] ?? count($indicatorRows)),
                'best_indicator' => $bestIndicator,
                'worst_indicator' => $worstIndicator,
                'band' => $band,
            ],
            'status' => $this->fetchStatusSummary($filters),
            'chart' => $this->buildMonthlyChart($filters, $chartMonths),
            'trimester_tables' => [
                'year' => $selectedYear,
                'tables' => $this->buildTrimesterTables($filters, $selectedYear),
            ],
            'table' => $analyticTable,
        ];
    }

    private function fetchAnalyticTableData(array $filters, string $year, int $page, int $perPage): array
    {
        if ($year === '') {
            return [
                'title' => 'Performance mês a mês por indicador',
                'subtitle' => 'Todas as colunas já vêm calculadas pela base EncantaBra; exibimos sem novas transformações.',
                'columns' => [],
                'rows' => [],
                'total_rows' => 0,
                'current_page' => 1,
                'per_page' => $perPage,
                'total_pages' => 1,
            ];
        }

        [$whereSql, $params] = $this->buildWhereClause($filters, ['anomes']);
        $countSql = 'SELECT COUNT(*)
                     FROM ' . self::TABLE . '
                     WHERE ' . $whereSql . '
                       AND LEFT(CAST(ANO_MES AS CHAR), 4) = :table_year';

        $countStatement = $this->connection->prepare($countSql);
        $countStatement->execute(array_merge($params, ['table_year' => $year]));
        $totalRows = (int) $countStatement->fetchColumn();
        $totalPages = max(1, (int) ceil($totalRows / max(1, $perPage)));
        $currentPage = min(max(1, $page), $totalPages);
        $offset = ($currentPage - 1) * $perPage;

        $sql = 'SELECT *
                FROM ' . self::TABLE . '
                WHERE ' . $whereSql . '
                  AND LEFT(CAST(ANO_MES AS CHAR), 4) = :table_year
                ORDER BY ANO_MES DESC, TIPO_PAINEL ASC, COD_JUNC ASC, COD_FUNC ASC, INDICADOR ASC
                LIMIT :table_limit OFFSET :table_offset';

        $statement = $this->connection->prepare($sql);
        foreach ($params as $paramKey => $paramValue) {
            $statement->bindValue(':' . $paramKey, $paramValue);
        }

        $statement->bindValue(':table_year', $year);
        $statement->bindValue(':table_limit', max(1, $perPage), PDO::PARAM_INT);
        $statement->bindValue(':table_offset', max(0, $offset), PDO::PARAM_INT);
        $statement->execute();
        $rows = $statement->fetchAll();
        $columns = isset($rows[0]) && is_array($rows[0]) ? array_keys($rows[0]) : [];

        return [
            'title' => 'Performance mês a mês por indicador',
            'subtitle' => 'Todas as colunas já vêm calculadas pela base EncantaBra; exibimos sem novas transformações.',
            'columns' => $columns,
            'rows' => $rows,
            'total_rows' => $totalRows,
            'current_page' => $currentPage,
            'per_page' => max(1, $perPage),
            'total_pages' => $totalPages,
        ];
    }

    private function fetchMonthOptions(): array
    {
        $sql = 'SELECT DISTINCT ANO_MES AS value FROM ' . self::TABLE . ' WHERE ANO_MES IS NOT NULL AND ANO_MES <> "" ORDER BY ANO_MES DESC';
        $statement = $this->connection->query($sql);
        $options = [];

        foreach ($statement->fetchAll() as $row) {
            $value = trim((string) ($row['value'] ?? ''));

            if ($value === '') {
                continue;
            }

            $options[] = [
                'value' => $value,
                'label' => $this->formatAnoMesLabel($value, false),
            ];
        }

        return $options;
    }

    private function fetchDistinctOptions(string $column, array $filters = []): array
    {
        [$whereSql, $params] = $this->buildWhereClause($filters, []);
        $sql = sprintf(
            'SELECT DISTINCT %1$s AS value FROM %2$s WHERE %3$s AND %1$s IS NOT NULL AND %1$s <> "" ORDER BY %1$s ASC',
            $column,
            self::TABLE,
            $whereSql
        );
        $statement = $this->connection->prepare($sql);
        $statement->execute($params);
        $options = [];

        foreach ($statement->fetchAll() as $row) {
            $value = trim((string) ($row['value'] ?? ''));

            if ($value === '') {
                continue;
            }

            $options[] = [
                'value' => $value,
                'label' => $value,
            ];
        }

        return $options;
    }

    private function fetchPairOptions(string $codeColumn, string $labelColumn, array $filters = []): array
    {
        [$whereSql, $params] = $this->buildWhereClause($filters, []);
        $sql = sprintf(
            'SELECT DISTINCT %1$s AS value, %2$s AS label FROM %3$s WHERE %4$s AND %1$s IS NOT NULL AND %1$s <> "" AND %2$s IS NOT NULL AND %2$s <> "" ORDER BY %2$s ASC',
            $codeColumn,
            $labelColumn,
            self::TABLE,
            $whereSql
        );
        $statement = $this->connection->prepare($sql);
        $statement->execute($params);
        $options = [];

        foreach ($statement->fetchAll() as $row) {
            $value = trim((string) ($row['value'] ?? ''));
            $label = trim((string) ($row['label'] ?? ''));

            if ($value === '' || $label === '') {
                continue;
            }

            $options[] = [
                'value' => $value,
                'label' => $label,
            ];
        }

        return $options;
    }

    private function sanitizeOption(string $requestedValue, array $options, string $defaultValue = ''): string
    {
        foreach ($options as $option) {
            if ((string) ($option['value'] ?? '') === $requestedValue) {
                return $requestedValue;
            }
        }

        return $defaultValue;
    }

    private function fetchSummaryMetrics(array $filters): array
    {
        [$whereSql, $params] = $this->buildWhereClause($filters, []);
        $scoreSql = $this->resolveScoreSql();
        $entitySql = $this->resolveEntitySql((string) ($filters['perfil'] ?? 'SG'));
        $sql = 'SELECT COUNT(*) AS rows_total,
                       COUNT(DISTINCT INDICADOR) AS indicators_total,
                       COUNT(DISTINCT ' . $entitySql . ') AS entities_total,
                       COALESCE(AVG(META), 0) AS meta_avg,
                       COALESCE(AVG(REALIZADO), 0) AS real_avg,
                       COALESCE(AVG(' . $scoreSql . '), 0) AS score_avg
                FROM ' . self::TABLE . '
                WHERE ' . $whereSql;

        $statement = $this->connection->prepare($sql);
        $statement->execute($params);
        $row = $statement->fetch();

        return is_array($row) ? $row : [];
    }

    private function fetchStatusSummary(array $filters): array
    {
        [$whereSql, $params] = $this->buildWhereClause($filters, []);
        $scoreSql = $this->resolveScoreSql();
        $sql = 'SELECT
                    SUM(CASE WHEN ' . $scoreSql . ' >= 110 THEN 1 ELSE 0 END) AS fan,
                    SUM(CASE WHEN ' . $scoreSql . ' >= 90 AND ' . $scoreSql . ' < 110 THEN 1 ELSE 0 END) AS encantador,
                    SUM(CASE WHEN ' . $scoreSql . ' >= 70 AND ' . $scoreSql . ' < 90 THEN 1 ELSE 0 END) AS expectativa,
                    SUM(CASE WHEN ' . $scoreSql . ' < 70 THEN 1 ELSE 0 END) AS critico
                FROM ' . self::TABLE . '
                WHERE ' . $whereSql;

        $statement = $this->connection->prepare($sql);
        $statement->execute($params);
        $row = $statement->fetch();

        return [
            'fan' => (int) ($row['fan'] ?? 0),
            'encantador' => (int) ($row['encantador'] ?? 0),
            'expectativa' => (int) ($row['expectativa'] ?? 0),
            'critico' => (int) ($row['critico'] ?? 0),
        ];
    }

    private function buildMonthlyChart(array $filters, array $months): array
    {
        if ($months === []) {
            return ['labels' => [], 'series' => [], 'max_value' => 100.0];
        }

        $monthKeys = array_map(static function (array $month): string {
            return (string) ($month['key'] ?? '');
        }, $months);
        [$monthSql, $monthParams] = $this->buildMonthInClause($monthKeys, 'chart_month');
        [$whereSql, $params] = $this->buildWhereClause($filters, ['anomes']);
        $scoreSql = $this->resolveScoreSql();
        $sql = 'SELECT ANO_MES,
                       COALESCE(AVG(' . $scoreSql . '), 0) AS score_avg
                FROM ' . self::TABLE . '
                WHERE ' . $whereSql . '
                  AND ' . $monthSql . '
                GROUP BY ANO_MES
                ORDER BY ANO_MES ASC';

        $statement = $this->connection->prepare($sql);
        $statement->execute(array_merge($params, $monthParams));
        $seriesMap = [];

        foreach ($statement->fetchAll() as $row) {
            $monthKey = trim((string) ($row['ANO_MES'] ?? ''));

            if ($monthKey === '') {
                continue;
            }

            $seriesMap[$monthKey] = (float) ($row['score_avg'] ?? 0.0);
        }

        $labels = [];
        $values = [];
        $benchmark = [];

        foreach ($months as $month) {
            $monthKey = (string) ($month['key'] ?? '');
            $labels[] = (string) ($month['label'] ?? $monthKey);
            $values[] = isset($seriesMap[$monthKey]) ? (float) $seriesMap[$monthKey] : 0.0;
            $benchmark[] = 90.0;
        }

        $maxValue = $this->resolveVisualScaleMax(array_merge($values, $benchmark), 100.0);

        return [
            'labels' => $labels,
            'series' => [
                [
                    'label' => 'Score médio',
                    'color' => '#cc092f',
                    'values' => $values,
                ],
                [
                    'label' => 'Faixa Encantador',
                    'color' => '#1d4ed8',
                    'values' => $benchmark,
                ],
            ],
            'max_value' => $maxValue,
        ];
    }

    private function buildTrimesterTables(array $filters, string $year): array
    {
        if ($year === '') {
            return [];
        }

        [$whereSql, $params] = $this->buildWhereClause($filters, ['anomes']);
        $scoreSql = $this->resolveScoreSql();
        $sql = 'SELECT INDICADOR,
                       COD_INDICADOR,
                       ANO_MES,
                       COALESCE(AVG(PESO), 0) AS peso_avg,
                       COALESCE(AVG(REALIZADO), 0) AS real_avg,
                       COALESCE(AVG(ATINGIMENTO), 0) AS ating_avg,
                       COALESCE(AVG(' . $scoreSql . '), 0) AS pont_avg
                FROM ' . self::TABLE . '
                WHERE ' . $whereSql . '
                  AND LEFT(CAST(ANO_MES AS CHAR), 4) = :trimester_year
                GROUP BY INDICADOR, COD_INDICADOR, ANO_MES
                HAVING COALESCE(INDICADOR, "") <> ""
                ORDER BY INDICADOR ASC, ANO_MES ASC';

        $statement = $this->connection->prepare($sql);
        $statement->execute(array_merge($params, ['trimester_year' => $year]));
        $rows = $statement->fetchAll();

        return [
            $this->buildTrimesterTableDefinition('first_trimester', '1º trimestre', [1, 2, 3], $rows),
            $this->buildTrimesterTableDefinition('second_trimester', '2º trimestre', [4, 5, 6], $rows),
            $this->buildTrimesterTableDefinition('third_trimester', '3º trimestre', [7, 8, 9], $rows),
            $this->buildTrimesterTableDefinition('fourth_trimester', '4º trimestre', [10, 11, 12], $rows),
        ];
    }

    private function buildTrimesterTableDefinition(string $id, string $title, array $months, array $rows): array
    {
        $groupedRows = [];

        foreach ($rows as $row) {
            $month = $this->extractMonthNumber($row['ANO_MES'] ?? null);

            if ($month === null || !in_array($month, $months, true)) {
                continue;
            }

            $indicator = trim((string) ($row['INDICADOR'] ?? ''));

            if ($indicator === '') {
                continue;
            }

            $rowKey = trim((string) ($row['COD_INDICADOR'] ?? '')) !== ''
                ? trim((string) ($row['COD_INDICADOR'] ?? ''))
                : $indicator;

            if (!isset($groupedRows[$rowKey])) {
                $groupedRows[$rowKey] = [
                    'key' => $rowKey,
                    'label' => $indicator,
                    'months' => [],
                    'average' => null,
                    'band' => ['label' => 'Sem dados', 'range' => 'Sem leitura', 'tone' => 'is-empty'],
                ];
            }

            $groupedRows[$rowKey]['months'][$month] = [
                'peso' => $this->nullableFloat($row['peso_avg'] ?? null),
                'real' => $this->nullableFloat($row['real_avg'] ?? null),
                'ating' => $this->nullableFloat($row['ating_avg'] ?? null),
                'pont' => $this->nullableFloat($row['pont_avg'] ?? null),
            ];
        }

        foreach ($groupedRows as $rowKey => $groupedRow) {
            $averages = [];

            foreach ($months as $month) {
                $monthScore = $groupedRow['months'][$month]['pont'] ?? null;

                if ($monthScore === null) {
                    continue;
                }

                $averages[] = $monthScore;
            }

            $average = $averages !== [] ? array_sum($averages) / count($averages) : null;
            $groupedRows[$rowKey]['average'] = $average;
            $groupedRows[$rowKey]['band'] = $this->resolveBandMeta($average);
        }

        usort($groupedRows, static function (array $left, array $right): int {
            return strcmp((string) ($left['label'] ?? ''), (string) ($right['label'] ?? ''));
        });

        $monthDefinitions = [];

        foreach ($months as $month) {
            $monthDefinitions[] = [
                'number' => $month,
                'label' => $this->resolveMonthShortLabel($month),
            ];
        }

        return [
            'id' => $id,
            'title' => $title,
            'months' => $monthDefinitions,
            'rows' => array_values($groupedRows),
        ];
    }

    private function resolveVisualScaleMax(array $values, float $minimum = 100.0): float
    {
        $highestValue = $minimum;

        foreach ($values as $value) {
            if (!is_numeric($value)) {
                continue;
            }

            $highestValue = max($highestValue, (float) $value);
        }

        return ceil($highestValue / 10.0) * 10.0;
    }

    private function fetchRanking(array $filters): array
    {
        $rankingMeta = $this->resolveRankingMeta($filters);
        [$whereSql, $params] = $this->buildWhereClause($filters, []);
        $scoreSql = $this->resolveScoreSql();
        $sql = 'SELECT ' . $rankingMeta['group_sql'] . ' AS group_value,
                       ' . $rankingMeta['label_sql'] . ' AS display_label,
                       COALESCE(AVG(' . $scoreSql . '), 0) AS score_avg,
                       COALESCE(AVG(META), 0) AS meta_avg,
                       COALESCE(AVG(REALIZADO), 0) AS real_avg,
                       COUNT(*) AS row_count
                FROM ' . self::TABLE . '
                WHERE ' . $whereSql . '
                GROUP BY group_value, display_label
                HAVING COALESCE(group_value, "") <> ""
                ORDER BY score_avg DESC, display_label ASC';

        $statement = $this->connection->prepare($sql);
        $statement->execute($params);
        $rows = [];

        foreach ($statement->fetchAll() as $row) {
            $label = trim((string) ($row['display_label'] ?? ''));

            if ($label === '') {
                continue;
            }

            $score = (float) ($row['score_avg'] ?? 0.0);
            $rows[] = [
                'display_label' => $label,
                'score_avg' => $score,
                'meta_avg' => (float) ($row['meta_avg'] ?? 0.0),
                'real_avg' => (float) ($row['real_avg'] ?? 0.0),
                'row_count' => (int) ($row['row_count'] ?? 0),
                'tone' => $this->resolveBandMeta($score)['tone'],
            ];
        }

        $bottomRows = $rows;
        usort($bottomRows, static function (array $left, array $right): int {
            return ($left['score_avg'] <=> $right['score_avg']) ?: strcmp((string) $left['display_label'], (string) $right['display_label']);
        });

        return [
            'title' => $rankingMeta['title'],
            'top' => array_slice($rows, 0, 5),
            'bottom' => array_slice($bottomRows, 0, 5),
        ];
    }

    private function buildIndicatorHeatmap(array $filters, array $months, array $indicatorRows): array
    {
        if ($months === []) {
            return ['title' => 'Heatmap — Score por indicador', 'rows' => [], 'months' => [], 'data' => []];
        }

        $monthKeys = array_map(static function (array $month): string {
            return (string) ($month['key'] ?? '');
        }, $months);
        [$monthSql, $monthParams] = $this->buildMonthInClause($monthKeys, 'heatmap_month');
        [$whereSql, $params] = $this->buildWhereClause($filters, ['anomes']);
        $scoreSql = $this->resolveScoreSql();
        $sql = 'SELECT INDICADOR,
                       ANO_MES,
                       COALESCE(AVG(' . $scoreSql . '), 0) AS score_avg,
                       COALESCE(AVG(META), 0) AS meta_avg,
                       COALESCE(AVG(REALIZADO), 0) AS real_avg,
                       COUNT(*) AS row_count
                FROM ' . self::TABLE . '
                WHERE ' . $whereSql . '
                  AND ' . $monthSql . '
                GROUP BY INDICADOR, ANO_MES
                ORDER BY INDICADOR ASC, ANO_MES ASC';

        $statement = $this->connection->prepare($sql);
        $statement->execute(array_merge($params, $monthParams));
        $data = [];

        foreach ($statement->fetchAll() as $row) {
            $indicator = trim((string) ($row['INDICADOR'] ?? ''));
            $monthKey = trim((string) ($row['ANO_MES'] ?? ''));

            if ($indicator === '' || $monthKey === '') {
                continue;
            }

            $data[$indicator][$monthKey] = [
                'score' => (float) ($row['score_avg'] ?? 0.0),
                'meta' => (float) ($row['meta_avg'] ?? 0.0),
                'real' => (float) ($row['real_avg'] ?? 0.0),
                'rows' => (int) ($row['row_count'] ?? 0),
            ];
        }

        $rows = [];

        foreach ($indicatorRows as $row) {
            $indicator = trim((string) ($row['indicator'] ?? ''));

            if ($indicator === '') {
                continue;
            }

            $rows[] = [
                'key' => $indicator,
                'label' => $indicator,
            ];
        }

        if ($rows === []) {
            $rowKeys = array_keys($data);

            foreach ($rowKeys as $rowKey) {
                $rows[] = ['key' => (string) $rowKey, 'label' => (string) $rowKey];
            }
        }

        return [
            'title' => 'Heatmap — Score médio por indicador',
            'rows' => $rows,
            'months' => $months,
            'data' => $data,
        ];
    }

    private function fetchIndicatorTableRows(array $filters): array
    {
        [$whereSql, $params] = $this->buildWhereClause($filters, []);
        $scoreSql = $this->resolveScoreSql();
        $sql = 'SELECT INDICADOR,
                       COALESCE(AVG(META), 0) AS meta_avg,
                       COALESCE(AVG(REALIZADO), 0) AS real_avg,
                       COALESCE(AVG(' . $scoreSql . '), 0) AS score_avg,
                       COUNT(*) AS row_count
                FROM ' . self::TABLE . '
                WHERE ' . $whereSql . '
                GROUP BY INDICADOR
                HAVING COALESCE(INDICADOR, "") <> ""
                ORDER BY score_avg DESC, INDICADOR ASC';

        $statement = $this->connection->prepare($sql);
        $statement->execute($params);
        $rows = [];

        foreach ($statement->fetchAll() as $row) {
            $indicator = trim((string) ($row['INDICADOR'] ?? ''));

            if ($indicator === '') {
                continue;
            }

            $score = (float) ($row['score_avg'] ?? 0.0);
            $rows[] = [
                'indicator' => $indicator,
                'meta_avg' => (float) ($row['meta_avg'] ?? 0.0),
                'real_avg' => (float) ($row['real_avg'] ?? 0.0),
                'score_avg' => $score,
                'row_count' => (int) ($row['row_count'] ?? 0),
                'band' => $this->resolveBandMeta($score),
            ];
        }

        return $rows;
    }

    private function resolveRankingMeta(array $filters): array
    {
        $profile = (string) ($filters['perfil'] ?? 'SG');
        $hasJuncao = trim((string) ($filters['juncao'] ?? '')) !== '';
        $hasFunctional = trim((string) ($filters['funcional'] ?? '')) !== '';

        if ($profile === 'GC' && !$hasFunctional) {
            return [
                'title' => 'Gerentes com melhor e pior score',
                'group_sql' => 'CAST(COD_FUNC AS CHAR)',
                'label_sql' => 'TRIM(CONCAT(COD_FUNC, " • ", NOME_FUNC))',
            ];
        }

        if ($profile === 'AG' && !$hasJuncao) {
            return [
                'title' => 'Agências com melhor e pior score',
                'group_sql' => 'CAST(COD_JUNC AS CHAR)',
                'label_sql' => 'TRIM(CONCAT(COD_JUNC, " • ", NOME_JUNC))',
            ];
        }

        return [
            'title' => 'Indicadores com melhor e pior score',
            'group_sql' => 'TRIM(INDICADOR)',
            'label_sql' => 'TRIM(INDICADOR)',
        ];
    }

    private function resolveBandMeta(?float $score): array
    {
        if ($score === null) {
            return ['label' => 'Sem dados', 'range' => 'Sem leitura', 'tone' => 'is-empty'];
        }

        if ($score >= 110.0) {
            return ['label' => 'Cliente fã', 'range' => '110 a 150', 'tone' => 'is-fan'];
        }

        if ($score >= 90.0) {
            return ['label' => 'Encantador', 'range' => '90 a 109,99', 'tone' => 'is-encantador'];
        }

        if ($score >= 70.0) {
            return ['label' => 'Atende expectativa', 'range' => '70 a 89,99', 'tone' => 'is-expected'];
        }

        return ['label' => 'Crítico', 'range' => '0 a 69,99', 'tone' => 'is-far'];
    }

    private function buildScopeLabel(array $filters): string
    {
        $parts = [$this->resolveProfileLabel((string) ($filters['perfil'] ?? 'SG'))];
        $segment = trim((string) ($filters['segmento'] ?? ''));
        $juncao = trim((string) ($filters['juncao'] ?? ''));
        $functional = trim((string) ($filters['funcional'] ?? ''));
        $indicator = trim((string) ($filters['indicador'] ?? ''));

        if ($segment !== '') {
            $parts[] = $segment;
        }

        if ($juncao !== '') {
            $juncaoLabel = $this->lookupLabelByCode('COD_JUNC', 'NOME_JUNC', $juncao);

            if ($juncaoLabel !== '') {
                $parts[] = $juncaoLabel;
            }
        }

        if ($functional !== '') {
            $functionalLabel = $this->lookupLabelByCode('COD_FUNC', 'NOME_FUNC', $functional);

            if ($functionalLabel !== '') {
                $parts[] = $functionalLabel;
            }
        }

        if ($indicator !== '') {
            $parts[] = $indicator;
        }

        return implode(' • ', array_values(array_filter($parts, static function (string $value): bool {
            return trim($value) !== '';
        })));
    }

    private function lookupLabelByCode(string $codeColumn, string $labelColumn, string $codeValue): string
    {
        if (!$this->hasLocalTable()) {
            return '';
        }

        $sql = sprintf(
            'SELECT %1$s AS label FROM %2$s WHERE %3$s = :code LIMIT 1',
            $labelColumn,
            self::TABLE,
            $codeColumn
        );
        $statement = $this->connection->prepare($sql);
        $statement->execute(['code' => $codeValue]);
        $label = $statement->fetchColumn();

        return trim((string) $label);
    }

    private function buildMonthWindow(string $selectedMonth, int $window): array
    {
        $options = $this->fetchMonthOptions();
        $filtered = array_values(array_filter($options, static function (array $option) use ($selectedMonth): bool {
            return (string) ($option['value'] ?? '') !== '' && strcmp((string) ($option['value'] ?? ''), $selectedMonth) <= 0;
        }));

        if ($filtered === []) {
            return [];
        }

        $slice = array_slice($filtered, max(0, count($filtered) - $window));
        $months = [];

        foreach ($slice as $month) {
            $value = (string) ($month['value'] ?? '');

            if ($value === '') {
                continue;
            }

            $months[] = [
                'key' => $value,
                'label' => $this->formatAnoMesLabel($value, true),
                'full_label' => $this->formatAnoMesLabel($value, false),
            ];
        }

        return $months;
    }

    private function resolveSelectedYear(string $selectedMonth): string
    {
        $digits = preg_replace('/[^0-9]/', '', $selectedMonth) ?? '';

        if (strlen($digits) >= 4) {
            return substr($digits, 0, 4);
        }

        $monthOptions = $this->fetchMonthOptions();
        $fallbackMonth = trim((string) ($monthOptions[0]['value'] ?? ''));
        $fallbackDigits = preg_replace('/[^0-9]/', '', $fallbackMonth) ?? '';

        return strlen($fallbackDigits) >= 4 ? substr($fallbackDigits, 0, 4) : '';
    }

    private function extractMonthNumber($anoMes): ?int
    {
        if ($anoMes === null || $anoMes === '') {
            return null;
        }

        $digits = preg_replace('/[^0-9]/', '', (string) $anoMes) ?? '';

        if (strlen($digits) < 6) {
            return null;
        }

        $month = (int) substr($digits, -2);

        return $month >= 1 && $month <= 12 ? $month : null;
    }

    private function resolveMonthShortLabel(int $month): string
    {
        $months = [
            1 => 'Jan',
            2 => 'Fev',
            3 => 'Mar',
            4 => 'Abr',
            5 => 'Mai',
            6 => 'Jun',
            7 => 'Jul',
            8 => 'Ago',
            9 => 'Set',
            10 => 'Out',
            11 => 'Nov',
            12 => 'Dez',
        ];

        return $months[$month] ?? (string) $month;
    }

    private function nullableFloat($value): ?float
    {
        if ($value === null || $value === '' || !is_numeric($value)) {
            return null;
        }

        return (float) $value;
    }

    private function buildMonthInClause(array $months, string $prefix): array
    {
        $parts = [];
        $params = [];

        foreach ($months as $index => $month) {
            $paramKey = $prefix . '_' . $index;
            $parts[] = ':' . $paramKey;
            $params[$paramKey] = $month;
        }

        if ($parts === []) {
            return ['1 = 0', []];
        }

        return ['ANO_MES IN (' . implode(', ', $parts) . ')', $params];
    }

    private function buildWhereClause(array $filters, array $excludeKeys = []): array
    {
        $map = [
            'anomes' => 'ANO_MES',
            'perfil' => 'TIPO_PAINEL',
            'segmento' => 'SEGMENTO_PAINEL',
            'juncao' => 'COD_JUNC',
            'funcional' => 'COD_FUNC',
            'indicador' => 'INDICADOR',
        ];
        $conditions = ['1 = 1'];
        $params = [];

        foreach ($map as $filterKey => $column) {
            if (in_array($filterKey, $excludeKeys, true)) {
                continue;
            }

            $value = trim((string) ($filters[$filterKey] ?? ''));

            if ($value === '') {
                continue;
            }

            $paramKey = 'filter_' . $filterKey;
            $conditions[] = $column . ' = :' . $paramKey;
            $params[$paramKey] = $value;
        }

        return [implode(' AND ', $conditions), $params];
    }

    private function resolveScoreSql(): string
    {
        return 'COALESCE(NOVA_PONTUACAO, PONTUACAO, ATINGIMENTO, REALIZADO, 0)';
    }

    private function resolveEntitySql(string $profile): string
    {
        if ($profile === 'GC') {
            return 'NULLIF(CAST(COD_FUNC AS CHAR), "")';
        }

        if ($profile === 'AG') {
            return 'NULLIF(CAST(COD_JUNC AS CHAR), "")';
        }

        return 'NULLIF(SEGMENTO_PAINEL, "")';
    }

    private function resolveProfileLabel(string $profile): string
    {
        $map = [
            'SG' => 'Visão de segmento',
            'AG' => 'Visão por agência',
            'GC' => 'Visão por gerente',
        ];

        return $map[$profile] ?? 'Visão EncantaBra';
    }

    private function formatAnoMesLabel(string $value, bool $shortYear): string
    {
        $value = preg_replace('/[^0-9]/', '', $value) ?? '';

        if (strlen($value) !== 6) {
            return $value;
        }

        $year = substr($value, 0, 4);
        $monthNumber = (int) substr($value, 4, 2);
        $months = [
            1 => 'jan',
            2 => 'fev',
            3 => 'mar',
            4 => 'abr',
            5 => 'mai',
            6 => 'jun',
            7 => 'jul',
            8 => 'ago',
            9 => 'set',
            10 => 'out',
            11 => 'nov',
            12 => 'dez',
        ];
        $monthLabel = $months[$monthNumber] ?? $value;

        if ($shortYear) {
            return $monthLabel . '/' . substr($year, -2);
        }

        return ucfirst($monthLabel) . '/' . $year;
    }

    private function hasLocalTable(): bool
    {
        if ($this->tableAvailable !== null) {
            return $this->tableAvailable;
        }

        $statement = $this->connection->prepare(
            'SELECT 1
             FROM information_schema.tables
             WHERE table_schema = DATABASE()
               AND table_name = :table_name
             LIMIT 1'
        );
        $statement->execute(['table_name' => self::TABLE_NAME]);
        $this->tableAvailable = (bool) $statement->fetchColumn();

        return $this->tableAvailable;
    }
}