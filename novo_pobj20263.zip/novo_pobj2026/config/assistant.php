<?php

declare(strict_types=1);

return [
    // Chave server-side. Nao expor no front.
    'openai_api_key' => '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',
    'openai_model' => 'gpt-5-mini',
    'openai_embed_model' => 'text-embedding-3-small',
    'knowledge_base_path' => project_path('base_conhecimento'),
];