ALTER TABLE dMesu
    ADD COLUMN IF NOT EXISTS id_segmento BIGINT UNSIGNED NULL AFTER nome_diretoria,
    ADD COLUMN IF NOT EXISTS subsegmento VARCHAR(20) NOT NULL DEFAULT 'Classic' AFTER id_segmento;

UPDATE dMesu m
LEFT JOIN (
    SELECT src.juncao_ag, MAX(src.segmento) AS segmento
    FROM (
        SELECT f.juncao_ag, f.segmento
        FROM fMeta f
        WHERE f.ativo_sn = 1
          AND COALESCE(f.segmento, '') <> ''

        UNION ALL

        SELECT r.juncao_ag, r.segmento
        FROM fRealizado r
        WHERE r.ativo_sn = 1
          AND COALESCE(r.segmento, '') <> ''
    ) src
    GROUP BY src.juncao_ag
) fact_segment
    ON fact_segment.juncao_ag = m.juncao_ag
LEFT JOIN dSegmento s
    ON s.segmento = fact_segment.segmento
SET m.id_segmento = COALESCE(s.id_segmento, m.id_segmento),
    m.subsegmento = CASE
        WHEN LOWER(COALESCE(m.nome_diretoria, '')) LIKE '%norte%'
          OR LOWER(COALESCE(m.nome_regional, '')) LIKE '%norte%'
          OR LOWER(COALESCE(m.nome_agencia, '')) LIKE '%norte%'
        THEN 'Prime'
        ELSE 'Classic'
    END;

UPDATE dMesu m
LEFT JOIN dSegmento s_negocios
    ON s_negocios.segmento = 'NEGOCIOS'
LEFT JOIN dSegmento s_digital
    ON s_digital.segmento = 'DIGITAL'
SET m.id_segmento = CASE
    WHEN m.id_segmento IS NOT NULL THEN m.id_segmento
    WHEN LOWER(COALESCE(m.nome_diretoria, '')) LIKE '%norte%'
      OR LOWER(COALESCE(m.nome_regional, '')) LIKE '%norte%'
      OR LOWER(COALESCE(m.nome_agencia, '')) LIKE '%norte%'
    THEN s_negocios.id_segmento
    ELSE s_digital.id_segmento
END
WHERE m.id_segmento IS NULL;