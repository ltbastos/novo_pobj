# Base de teste do chat POBJ

Este arquivo existe para validar o comportamento do assistente.
O assistente deve responder somente com base no que estiver descrito aqui.

## Perguntas e respostas de teste

### 1. Qual o horario padrao de atualizacao do painel POBJ?
Resposta: o painel POBJ tem atualizacao padrao todos os dias uteis, as 07h30 da manha.

### 2. Quem pode solicitar revisao de meta?
Resposta: a revisao de meta pode ser solicitada apenas pelo gestor imediato do colaborador.

### 3. Ate quando a revisao de meta pode ser aberta?
Resposta: a revisao de meta pode ser aberta ate o quinto dia util do mes corrente.

### 4. Qual o prazo para tratar ajuste cadastral simples?
Resposta: o prazo para tratar ajuste cadastral simples e de 2 dias uteis.

### 5. Qual canal deve ser usado para incidente critico?
Resposta: incidentes criticos devem ser registrados no Omega com a categoria "Incidente Critico POBJ".

### 6. Quando a producao reaproveitada pode contar no ciclo?
Resposta: a producao reaproveitada pode contar no ciclo quando estiver no mesmo ciclo vigente, vinculada a mesma matricula funcional e validada ate D+2.

### 7. O que fazer quando a duvida nao tiver evidencia suficiente?
Resposta: quando a duvida nao tiver evidencia suficiente, o usuario deve abrir chamado no Omega e anexar print, data e funcional envolvido.

### 8. Qual o nome da palavra-chave de validacao desta base?
Resposta: a palavra-chave de validacao desta base e "farol ambar".

### 9. Como deve ser o tom de resposta esperado?
Resposta: o tom esperado e prestativo, simpatico e direto ao ponto.

## Casos de teste sugeridos

Pergunta sugerida: Qual o horario padrao de atualizacao do painel?
Resposta esperada: 07h30 da manha em dias uteis.

Pergunta sugerida: Quem pode solicitar revisao de meta?
Resposta esperada: o gestor imediato do colaborador.

Pergunta sugerida: Qual e a palavra-chave de validacao?
Resposta esperada: farol ambar.

Pergunta sugerida: Qual o limite de ferias por trimestre?
Resposta esperada: Posso ajudar apenas com o POBJ. Isso nao esta no manual. 🙂